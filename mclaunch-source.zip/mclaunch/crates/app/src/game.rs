//! Launching and supervising the game, instance bookkeeping.

use std::path::PathBuf;
use std::sync::Arc;
use std::time::Instant;

use mclaunch_core::args::QuickJoin;
use mclaunch_core::instance::{list_instances, unique_name, InstanceConfig};
use mclaunch_core::version::load_resolved;
use mclaunch_core::Progress;
use mclaunch_launch::{EventSink, ExitInfo, GameEvent, LaunchRequest, LogLine};
use tokio::sync::Notify;

use crate::app::{McApp, Screen, ToastKind};
use crate::backend::JobDone;

/// Cap on lines kept in the Logs screen.
const MAX_LOG_LINES: usize = 50_000;

pub struct RunningGame {
    pub instance: String,
    pub version: String,
    pub kill: Arc<Notify>,
    pub started: Instant,
    pub pid: Option<u32>,
}

#[derive(Debug, Clone)]
pub struct CrashInfo {
    pub instance: String,
    pub report: Option<PathBuf>,
    pub summary: String,
    pub code: Option<i32>,
    /// Likely causes and fixes recognised in the log / crash report.
    pub hints: Vec<&'static str>,
}

/// Known crash signatures and what to do about them.
pub fn crash_hints(text: &str) -> Vec<&'static str> {
    let has = |s: &str| text.contains(s);
    let mut hints = Vec::new();
    if has("UnsupportedClassVersionError") {
        hints.push("A jar was built for a newer Java than the one used: pick a newer Java (Edit → Java) or drop a newer JDK into java/.");
    }
    if has("ClassCastException") && (has("URLClassLoader") || has("AppClassLoader")) {
        hints.push("LaunchWrapper versions (≤1.12.2, old Forge, OptiFine on old versions) need Java 8: set Java 8 in Edit → Java.");
    }
    if has("java.lang.OutOfMemoryError") {
        hints.push("Out of memory: raise the instance's max memory (Edit → Memory), especially with shaders or big modpacks.");
    }
    if has("Could not reserve enough space for object heap") || has("Invalid maximum heap size") {
        hints.push("Java could not reserve the heap: lower max memory or use a 64-bit Java.");
    }
    if has("Pixel format not accelerated")
        || has("GLFW error 65542")
        || has("WGL: The driver does not appear to support OpenGL")
        || has("No OpenGL context found")
    {
        hints.push("The graphics driver does not provide OpenGL: update your GPU driver (on laptops, run Java on the dedicated GPU).");
    }
    if has("LinuxDisplay.getAvailableDisplayModes") {
        hints.push("LWJGL 2 needs xrandr on Linux: install x11-xserver-utils (mclaunch normally provides a stand-in).");
    }
    if has("MixinApplyError") || has("Mixin apply failed") || has("InvalidMixinException") {
        hints.push("A mod's mixins failed to apply: make sure every mod matches this Minecraft and loader version.");
    }
    if has("Incompatible mods found")
        || has("ModResolutionException")
        || has("Missing or unsupported mandatory dependencies")
        || has("requires any version of")
    {
        hints.push("Missing or incompatible mod dependencies: read the lines above for which mod needs what.");
    }
    if has("DuplicateModsFoundException") || has("Found duplicate mods") {
        hints.push("Two copies of the same mod are in mods/: keep only one.");
    }
    if has("Failed to verify username") || has("Invalid session") {
        hints.push("The server is in online mode; offline profiles can only join servers with online-mode=false.");
    }
    hints
}

/// "Description: ..." and the exception line from a crash report.
pub fn summarize_crash_report(text: &str) -> String {
    let mut lines = text.lines();
    let mut out = Vec::new();
    while let Some(l) = lines.next() {
        if let Some(d) = l.strip_prefix("Description: ") {
            out.push(d.trim().to_string());
            for next in lines.by_ref() {
                let t = next.trim();
                if !t.is_empty() {
                    out.push(t.to_string());
                    break;
                }
            }
            break;
        }
    }
    if out.is_empty() {
        text.lines()
            .find(|l| l.contains("Exception") || l.contains("Error"))
            .unwrap_or("The game crashed")
            .trim()
            .to_string()
    } else {
        out.join(" — ")
    }
}

impl McApp {
    pub fn selected_instance(&self) -> Option<&InstanceConfig> {
        let name = self.config.selected_instance.as_deref();
        self.instances
            .iter()
            .find(|i| Some(i.name.as_str()) == name)
            .or_else(|| self.instances.first())
    }

    pub fn select_instance(&mut self, name: &str) {
        if self.config.selected_instance.as_deref() != Some(name) {
            self.config.selected_instance = Some(name.to_string());
            self.save_config();
        }
        self.refresh_shader_status(name);
    }

    pub fn refresh_instances(&mut self) {
        let paths = self.services().paths.clone();
        let b = self.backend.clone();
        self.backend.spawn(async move {
            let list = tokio::task::spawn_blocking(move || list_instances(&paths))
                .await
                .unwrap_or_default();
            b.apply(move |app| {
                app.instances = list;
                let ids: Vec<String> = app.instances.iter().map(|i| i.version_id.clone()).collect();
                for id in ids {
                    app.ensure_version_java(&id);
                }
            });
        });
    }

    /// Learn the required Java of an installed version (background).
    pub fn ensure_version_java(&mut self, id: &str) {
        if id.is_empty() || self.version_java.contains_key(id) {
            return;
        }
        self.version_java.insert(id.to_string(), 0);
        let paths = self.services().paths.clone();
        let id = id.to_string();
        let b = self.backend.clone();
        self.backend.spawn(async move {
            let res = tokio::task::spawn_blocking({
                let id = id.clone();
                move || {
                    load_resolved(&paths, &id)
                        .map(|r| mclaunch_core::javareq::required_java(&r.merged))
                }
            })
            .await;
            b.apply(move |app| match res {
                Ok(Ok(major)) => {
                    app.version_java.insert(id, major);
                }
                _ => {
                    // Not installed yet; try again after an install.
                    app.version_java.remove(&id);
                    app.version_java_missing.insert(id);
                }
            });
        });
    }

    pub fn save_instance(&mut self, cfg: &InstanceConfig) -> Result<(), String> {
        let svc = self.services().clone();
        cfg.save(&svc.paths, &svc.safe).map_err(|e| e.to_string())?;
        match self.instances.iter_mut().find(|i| i.name == cfg.name) {
            Some(existing) => *existing = cfg.clone(),
            None => self.instances.push(cfg.clone()),
        }
        self.version_java_missing.remove(&cfg.version_id);
        self.ensure_version_java(&cfg.version_id);
        Ok(())
    }

    pub fn push_log(&mut self, line: LogLine) {
        if self.game_log.len() >= MAX_LOG_LINES {
            self.game_log.pop_front();
        }
        self.game_log.push_back(line);
    }

    pub fn launch_instance(&mut self, name: &str) {
        if let Some(g) = &self.game {
            let msg = format!("{} is already running", g.instance);
            self.toast(ToastKind::Error, msg);
            return;
        }
        if self.launching.is_some() {
            return;
        }
        let Some(inst) = self.instances.iter().find(|i| i.name == name).cloned() else {
            return;
        };
        let Some(username) = self.config.active_username().map(str::to_string) else {
            self.account_dialog = Some(Default::default());
            self.toast(ToastKind::Info, "Create an offline profile first");
            return;
        };
        if inst.version_id.is_empty() {
            self.toast(
                ToastKind::Error,
                "This instance has no Minecraft version; edit it first",
            );
            return;
        }
        let runtimes = self.java.clone();
        let quick_join = QuickJoin::parse(&self.quick_join);
        self.config.touch_recent(name);
        self.config.selected_instance = Some(name.to_string());
        self.save_config();
        self.game_log.clear();
        self.last_crash = None;
        self.launching = Some(name.to_string());
        let name = name.to_string();

        self.backend
            .job(format!("Launching {name}"), move |j| async move {
                let svc = j.services.clone();
                let prepared = async {
                    (j.progress)(Progress::stage(format!(
                        "Checking files for {}",
                        inst.version_id
                    )));
                    let report = svc
                        .installer()
                        .ensure_ready(&inst.version_id, &j.progress)
                        .await?;
                    (j.progress)(Progress::stage("Preparing launch"));
                    let (paths, safe, inst2) = (svc.paths.clone(), svc.safe.clone(), inst.clone());
                    let (plan, note) = tokio::task::spawn_blocking(move || -> anyhow::Result<_> {
                        let resolved = load_resolved(&paths, &inst2.version_id)?;
                        let (java, note) =
                            mclaunch_launch::choose_java(&runtimes, &inst2, &resolved.merged)?;
                        let plan = mclaunch_launch::prepare(
                            &paths,
                            &safe,
                            &resolved,
                            &LaunchRequest {
                                instance: &inst2,
                                username: &username,
                                quick_join,
                                java,
                            },
                        )?;
                        Ok((plan, note))
                    })
                    .await??;
                    anyhow::Ok((report, plan, note))
                }
                .await;
                j.backend.apply(|app| app.launching = None);
                let (report, plan, note) = prepared?;

                let kill = Arc::new(Notify::new());
                let b = j.backend.clone();
                let sink: EventSink = Arc::new(move |ev| match ev {
                    GameEvent::Log(line) => b.apply(move |app| app.push_log(line)),
                    GameEvent::Started { pid } => b.apply(move |app| {
                        if let Some(g) = &mut app.game {
                            g.pid = pid;
                        }
                    }),
                });
                let game = RunningGame {
                    instance: name.clone(),
                    version: inst.version_id.clone(),
                    kill: kill.clone(),
                    started: Instant::now(),
                    pid: None,
                };
                let version = inst.version_id.clone();
                j.backend.apply(move |app| {
                    app.game = Some(game);
                    if app.config.minimize_on_launch {
                        app.minimize_pending = true;
                    }
                    app.reports.insert(version, report);
                    if let Some(n) = note {
                        app.push_log(LogLine::launcher(n.clone()));
                        app.toast(ToastKind::Info, n);
                    }
                });
                let done = j.backend.clone();
                let safe = j.services.safe.clone();
                let n2 = name.clone();
                j.backend.spawn(async move {
                    let res = mclaunch_launch::run(plan, safe, sink, kill).await;
                    done.apply(move |app| app.on_game_exit(&n2, res));
                });
                Ok(JobDone::quiet())
            });
    }

    pub fn stop_game(&mut self) {
        if let Some(g) = &self.game {
            g.kill.notify_one();
        }
    }

    fn on_game_exit(&mut self, name: &str, res: mclaunch_launch::Result<ExitInfo>) {
        self.game = None;
        self.refresh_shader_status(name);
        let exit = match res {
            Ok(e) => e,
            Err(e) => {
                self.toast(ToastKind::Error, format!("{name}: {e}"));
                return;
            }
        };
        if let Some(inst) = self.instances.iter_mut().find(|i| i.name == name) {
            inst.last_played = Some(chrono::Utc::now());
            inst.play_time_secs += exit.duration_secs;
            if let Some(gpu) = &exit.gpu {
                inst.gpu = Some(gpu.summary());
                inst.gl_version = gpu.gl_version.clone();
            }
            let cfg = inst.clone();
            let svc = self.services().clone();
            self.backend.spawn(async move {
                let _ = tokio::task::spawn_blocking(move || cfg.save(&svc.paths, &svc.safe)).await;
            });
        }
        if exit.success || exit.killed {
            self.toast(ToastKind::Info, format!("{name} closed"));
            return;
        }
        let summary = exit
            .crash_report
            .as_ref()
            .and_then(|p| std::fs::read_to_string(p).ok())
            .map(|t| summarize_crash_report(&t))
            .or_else(|| {
                self.game_log
                    .iter()
                    .find(|l| l.is_crash_marker())
                    .map(|l| l.text.clone())
            })
            .unwrap_or_else(|| format!("exited with code {:?}", exit.code));
        let mut evidence: String = exit
            .crash_report
            .as_ref()
            .and_then(|p| std::fs::read_to_string(p).ok())
            .unwrap_or_default();
        for l in self.game_log.iter().rev().take(400) {
            evidence.push_str(&l.text);
            evidence.push('\n');
        }
        self.last_crash = Some(CrashInfo {
            instance: name.to_string(),
            report: exit.crash_report.clone(),
            summary: summary.clone(),
            code: exit.code,
            hints: crash_hints(&evidence),
        });
        self.toast(ToastKind::Error, format!("{name} crashed: {summary}"));
        self.screen = Screen::Logs;
        self.log_ui.follow = false;
        self.log_ui.jump_to_crash = true;
    }

    /// Copy an instance (every file, including saves) to a new name.
    pub fn duplicate_instance(&mut self, name: &str) {
        let Some(src) = self.instances.iter().find(|i| i.name == name).cloned() else {
            return;
        };
        let new_name = unique_name(&self.services().paths, &format!("{name} (copy)"));
        self.backend
            .job(format!("Duplicating {name}"), move |j| async move {
                let svc = j.services.clone();
                let nn = new_name.clone();
                let cfg = tokio::task::spawn_blocking(move || -> anyhow::Result<InstanceConfig> {
                    let from = svc.paths.instance_dir(&src.name);
                    let to = svc.paths.instance_dir(&nn);
                    copy_tree(&svc.safe, &from, &to)?;
                    let mut cfg = src.clone();
                    cfg.name = nn;
                    cfg.created = Some(chrono::Utc::now());
                    cfg.last_played = None;
                    cfg.play_time_secs = 0;
                    cfg.save(&svc.paths, &svc.safe)?;
                    Ok(cfg)
                })
                .await??;
                Ok(
                    JobDone::msg(format!("Created {new_name}")).then(move |app| {
                        app.instances.push(cfg);
                        app.refresh_instances();
                    }),
                )
            });
    }

    /// Move an instance to the recycle bin after typed confirmation.
    pub fn trash_instance(&mut self, name: String, typed: String) {
        if self.game.as_ref().is_some_and(|g| g.instance == name) {
            self.toast(
                ToastKind::Error,
                "Stop the game before deleting its instance",
            );
            return;
        }
        self.backend
            .job(format!("Deleting {name}"), move |j| async move {
                let safe = j.services.safe.clone();
                let n = name.clone();
                tokio::task::spawn_blocking(move || safe.trash_instance(&n, &typed)).await??;
                Ok(
                    JobDone::msg(format!("{name} moved to the recycle bin")).then(move |app| {
                        app.instances.retain(|i| i.name != name);
                        if app.config.selected_instance.as_deref() == Some(name.as_str()) {
                            app.config.selected_instance = None;
                        }
                        app.config.recent_instances.retain(|n| *n != name);
                        app.save_config();
                    }),
                )
            });
    }
}

/// Recursively copy `from` into a new folder `to` without overwriting.
fn copy_tree(
    safe: &mclaunch_safety::SafePath,
    from: &std::path::Path,
    to: &std::path::Path,
) -> anyhow::Result<()> {
    safe.create_dir_all(to)?;
    for entry in std::fs::read_dir(from)? {
        let entry = entry?;
        let ft = entry.file_type()?;
        let dest = to.join(entry.file_name());
        if ft.is_dir() {
            copy_tree(safe, &entry.path(), &dest)?;
        } else if ft.is_file() {
            safe.copy_new(&entry.path(), &dest)?;
        }
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn hints() {
        assert!(crash_hints(
            "java.lang.UnsupportedClassVersionError: x has been compiled by a more recent version"
        )
        .iter()
        .any(|h| h.contains("newer Java")));
        assert!(crash_hints("java.lang.ClassCastException: class jdk.internal.loader.ClassLoaders$AppClassLoader cannot be cast to class java.net.URLClassLoader")
            .iter()
            .any(|h| h.contains("Java 8")));
        assert!(crash_hints("all good").is_empty());
    }

    #[test]
    fn crash_summary() {
        let report = "---- Minecraft Crash Report ----\n// Ooh. Shiny.\n\nTime: x\nDescription: Initializing game\n\njava.lang.ExceptionInInitializerError\n\tat x\n";
        assert_eq!(
            summarize_crash_report(report),
            "Initializing game — java.lang.ExceptionInInitializerError"
        );
        assert_eq!(
            summarize_crash_report("boom NullPointerException here"),
            "boom NullPointerException here"
        );
    }
}
