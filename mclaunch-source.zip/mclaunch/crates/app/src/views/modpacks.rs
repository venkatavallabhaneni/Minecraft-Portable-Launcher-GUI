//! Modpacks: install a Modrinth, CurseForge, MultiMC/Prism or plain-zip
//! modpack into a new instance.

use std::collections::HashSet;
use std::path::PathBuf;

use eframe::egui::{self, Align, Layout, RichText, Ui};
use mclaunch_core::instance::{unique_name, validate_name, InstanceConfig, LoaderKind};
use mclaunch_core::manifest::VersionType;
use mclaunch_core::Progress;
use mclaunch_loaders::modpack::{self, Cancel, ManualFile, PackFormat, PackInfo};
use mclaunch_loaders::Loaders;

use crate::app::{McApp, Screen, ToastKind};
use crate::backend::{JobDone, JobId};
use crate::views::loaders::install_game;
use crate::views::settings::open_path;
use crate::widgets;

#[derive(Default)]
pub struct ModpacksUi {
    /// Archive being read.
    pub reading: Option<PathBuf>,
    pub pack: Option<PackInfo>,
    pub error: Option<String>,
    /// Instance name to create.
    pub name: String,
    /// Minecraft version / loader (editable for plain zips).
    pub mc: String,
    pub loader: LoaderKind,
    pub job: Option<JobId>,
    /// Set while the install can still be cancelled.
    pub cancel: Option<Cancel>,
    pub result: Option<Installed>,
}

pub struct Installed {
    pub instance: String,
    pub summary: String,
    pub manual: Vec<ManualFile>,
    pub notes: Vec<String>,
}

/// The user's Downloads folder, where browsers save manual downloads.
fn downloads_dir() -> Option<PathBuf> {
    std::env::var_os("USERPROFILE")
        .or_else(|| std::env::var_os("HOME"))
        .map(|h| PathBuf::from(h).join("Downloads"))
}

impl McApp {
    /// Ask for a modpack file.
    pub fn pick_modpack(&mut self) {
        let dialog = rfd::AsyncFileDialog::new()
            .set_title("Open modpack")
            .add_filter("Modpack", &["mrpack", "zip"])
            .pick_file();
        let b = self.backend.clone();
        self.backend.spawn(async move {
            if let Some(file) = dialog.await {
                let path = file.path().to_path_buf();
                b.apply(move |app| app.open_modpack(path));
            }
        });
    }

    /// Read a modpack archive (background) and show it on the Modpacks
    /// screen.
    pub fn open_modpack(&mut self, path: PathBuf) {
        self.screen = Screen::Modpacks;
        if self.modpacks_ui.job.is_some() {
            self.toast(ToastKind::Error, "A modpack is being installed; wait for it to finish");
            return;
        }
        let ui = &mut self.modpacks_ui;
        ui.reading = Some(path.clone());
        ui.pack = None;
        ui.error = None;
        ui.result = None;
        let known: Option<HashSet<String>> = self.manifest.as_ref().map(|m| {
            m.versions
                .iter()
                .filter(|v| v.kind == VersionType::Release)
                .map(|v| v.id.clone())
                .collect()
        });
        let b = self.backend.clone();
        self.backend.spawn(async move {
            let res = tokio::task::spawn_blocking(move || {
                modpack::read_pack(&path, known.as_ref()).map_err(|e| e.to_string())
            })
            .await
            .unwrap_or_else(|e| Err(e.to_string()));
            b.apply(move |app| {
                app.modpacks_ui.reading = None;
                match res {
                    Ok(pack) => {
                        let base = modpack::instance_name(&pack.name);
                        app.modpacks_ui.name = unique_name(&app.services().paths, &base);
                        app.modpacks_ui.mc = pack.mc_version.clone().unwrap_or_default();
                        app.modpacks_ui.loader = pack.loader;
                        app.modpacks_ui.pack = Some(pack);
                    }
                    Err(e) => app.modpacks_ui.error = Some(e),
                }
            });
        });
    }

    pub fn install_modpack(&mut self) {
        let ui = &self.modpacks_ui;
        let Some(mut pack) = ui.pack.clone() else {
            return;
        };
        if ui.job.is_some() {
            return;
        }
        if let Err(e) = validate_name(&ui.name) {
            self.toast(ToastKind::Error, e);
            return;
        }
        let name = ui.name.clone();
        if self.services().paths.instance_dir(&name).exists() {
            self.toast(ToastKind::Error, format!("An instance named \"{name}\" already exists"));
            return;
        }
        if ui.mc.is_empty() {
            self.toast(ToastKind::Error, "Choose the Minecraft version first");
            return;
        }
        // Plain zips: the user may correct what was detected.
        if pack.mc_version.as_deref() != Some(ui.mc.as_str()) || pack.loader != ui.loader {
            pack.mc_version = Some(ui.mc.clone());
            if pack.loader != ui.loader {
                pack.loader = ui.loader;
                pack.loader_version = None;
                pack.loader_min = None;
            }
        }
        let mc = ui.mc.clone();
        let cancel = Cancel::default();
        let runtimes = self.java.clone();
        let key = Some(self.config.curseforge_api_key.trim().to_string()).filter(|k| !k.is_empty());
        let memory = modpack::suggested_memory_mb(&pack, self.config.default_ram_mb);
        let token = cancel.clone();
        let id = self.backend.job(format!("Installing modpack {}", pack.name), move |j| async move {
            let svc = j.services.clone();
            let loaders = Loaders::new(svc.installer());
            let work = async {
                let plan = modpack::plan(&loaders, &pack, key.as_deref(), &j.progress).await?;
                let plan = modpack::download(&loaders, plan, &j.progress).await?;
                let version = modpack::loader_version(&loaders, &pack, &mc).await?;
                let game = install_game(
                    &svc,
                    &runtimes,
                    modpack::software(pack.loader),
                    &mc,
                    version.as_deref().unwrap_or_default(),
                    &j.progress,
                )
                .await?;
                anyhow::Ok((plan, game))
            };
            let res = tokio::select! {
                r = work => Some(r),
                _ = token.cancelled() => None,
            };
            j.backend.apply(|app| app.modpacks_ui.cancel = None);
            let finish = |app: &mut McApp| app.modpacks_ui.job = None;
            let (plan, game) = match res {
                Some(Ok(v)) => v,
                Some(Err(e)) => {
                    j.backend.apply(finish);
                    return Err(e);
                }
                None => {
                    j.backend.apply(finish);
                    return Ok(JobDone::msg(
                        "Modpack install cancelled. Files downloaded so far are kept for next time.",
                    ));
                }
            };

            (j.progress)(Progress::stage("Creating the instance"));
            let mut cfg = InstanceConfig::new(&name, &mc, memory);
            cfg.version_id = game.version_id;
            cfg.loader = pack.loader;
            cfg.loader_version = game.loader_version;
            cfg.icon = "📦".into();
            cfg.notes = format!(
                "{} modpack {}{}",
                pack.format.label(),
                pack.name,
                pack.version
                    .as_deref()
                    .map(|v| format!(" {v}"))
                    .unwrap_or_default()
            );
            let created = tokio::task::spawn_blocking({
                let (svc, pack, plan, cfg) = (svc.clone(), pack.clone(), plan.clone(), cfg.clone());
                move || modpack::create_instance(&svc.paths, &svc.safe, &pack, &plan, &cfg)
            })
            .await;
            let report = match created {
                Ok(Ok(r)) => r,
                Ok(Err(e)) => {
                    j.backend.apply(finish);
                    return Err(e.into());
                }
                Err(e) => {
                    j.backend.apply(finish);
                    return Err(e.into());
                }
            };
            let manual = plan.manual.len();
            let summary = format!(
                "{} file(s) downloaded, {} from the pack; Minecraft {mc}{}",
                report.added,
                report.overrides,
                cfg.loader_version
                    .as_deref()
                    .map(|v| format!(", {} {v}", cfg.loader.label()))
                    .unwrap_or_default()
            );
            let msg = if manual == 0 {
                format!("Modpack installed → {name}")
            } else {
                format!("Modpack installed → {name}; {manual} file(s) need a manual download")
            };
            Ok(JobDone::msg(msg).then(move |app| {
                app.modpacks_ui.job = None;
                if let Err(e) = app.save_instance(&cfg) {
                    app.toast(ToastKind::Error, e);
                }
                app.select_instance(&cfg.name);
                app.refresh_installed();
                app.modpacks_ui.pack = None;
                app.modpacks_ui.result = Some(Installed {
                    instance: cfg.name.clone(),
                    summary,
                    manual: plan.manual,
                    notes: plan.notes,
                });
            }))
        });
        self.modpacks_ui.job = Some(id);
        self.modpacks_ui.cancel = Some(cancel);
    }

    /// Look for manually downloaded files and add them to the instance.
    pub fn find_manual_files(&mut self, dirs: Vec<PathBuf>) {
        let Some(name) = self.modpacks_ui.result.as_ref().map(|r| r.instance.clone()) else {
            return;
        };
        let svc = self.services().clone();
        let dir = svc.paths.instance_dir(&name);
        self.backend.job("Adding downloaded files", move |_j| async move {
            let (added, still) = tokio::task::spawn_blocking(move || {
                modpack::add_manual_files(&svc.safe, &dir, &dirs)
            })
            .await??;
            let msg = if added.is_empty() {
                "None of the files were found (names and checksums must match)".to_string()
            } else {
                format!("Added {}", added.join(", "))
            };
            Ok(JobDone::msg(msg).then(move |app| {
                if let Some(r) = &mut app.modpacks_ui.result {
                    r.manual = still;
                }
            }))
        });
    }

    fn pick_manual_folder(&mut self) {
        let dialog = rfd::AsyncFileDialog::new()
            .set_title("Folder with the downloaded files")
            .pick_folder();
        let b = self.backend.clone();
        self.backend.spawn(async move {
            if let Some(dir) = dialog.await {
                let path = dir.path().to_path_buf();
                b.apply(move |app| app.find_manual_files(vec![path]));
            }
        });
    }
}

enum Action {
    Open,
    Install,
    Cancel,
    Play(String),
    Folder(String),
    Url(String),
    FindDownloads,
    FindIn,
    Clear,
}

pub fn show(app: &mut McApp, ui: &mut Ui) {
    let pal = app.pal;
    let mut actions = Vec::new();
    ui.horizontal(|ui| {
        widgets::pixel_heading(ui, "Modpacks", 16.0);
        ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
            let busy = app.modpacks_ui.job.is_some();
            if ui
                .add_enabled(!busy, egui::Button::new("📂 Open modpack…"))
                .clicked()
            {
                actions.push(Action::Open);
            }
        });
    });
    ui.add_space(10.0);

    egui::ScrollArea::vertical()
        .id_salt("modpacks_scroll_1")
        .auto_shrink([false, false])
        .show(ui, |ui| {
            let state = &app.modpacks_ui;
            if state.pack.is_none() && state.reading.is_none() && state.result.is_none() {
                intro(ui, &pal, &mut actions);
            }
            if let Some(path) = &state.reading {
                widgets::card(ui, &pal, |ui| {
                    ui.horizontal(|ui| {
                        ui.spinner();
                        ui.label(format!(
                            "Reading {}…",
                            path.file_name().unwrap_or_default().to_string_lossy()
                        ));
                    });
                });
            }
            if let Some(e) = &state.error {
                widgets::card(ui, &pal, |ui| {
                    ui.label(RichText::new("Could not read this modpack").strong().color(pal.danger));
                    ui.label(e.as_str());
                });
                ui.add_space(10.0);
            }
            if app.modpacks_ui.pack.is_some() {
                pack_card(app, ui, &mut actions);
                ui.add_space(10.0);
            }
            if app.modpacks_ui.result.is_some() {
                result_card(app, ui, &mut actions);
            }
        });

    for a in actions {
        match a {
            Action::Open => app.pick_modpack(),
            Action::Install => app.install_modpack(),
            Action::Cancel => {
                if let Some(c) = &app.modpacks_ui.cancel {
                    c.cancel();
                }
            }
            Action::Play(n) => {
                app.select_instance(&n);
                app.screen = Screen::Play;
                app.launch_instance(&n);
            }
            Action::Folder(n) => {
                let dir = app.services().paths.instance_dir(&n);
                open_path(app, &dir);
            }
            Action::Url(u) => {
                if let Err(e) = open::that_detached(&u) {
                    app.toast(ToastKind::Error, format!("Cannot open {u}: {e}"));
                }
            }
            Action::FindDownloads => match downloads_dir() {
                Some(d) => app.find_manual_files(vec![d]),
                None => app.toast(ToastKind::Error, "Cannot find your Downloads folder"),
            },
            Action::FindIn => app.pick_manual_folder(),
            Action::Clear => {
                app.modpacks_ui.pack = None;
                app.modpacks_ui.error = None;
            }
        }
    }
}

fn intro(ui: &mut Ui, pal: &crate::theme::Palette, actions: &mut Vec<Action>) {
    widgets::card(ui, pal, |ui| {
        ui.set_width(ui.available_width());
        ui.label(RichText::new("Install a modpack into a new instance").strong().size(16.0));
        ui.add_space(6.0);
        for line in [
            "Modrinth packs (.mrpack)",
            "CurseForge packs (.zip with manifest.json)",
            "MultiMC / Prism Launcher exports",
            "Any zip of a .minecraft folder (mods/, config/, …): the Minecraft version and loader are read from the mods",
        ] {
            ui.label(format!("•  {line}"));
        }
        ui.add_space(6.0);
        ui.label(widgets::dim(
            "The format, Minecraft version and mod loader (Fabric, Quilt, Forge, NeoForge) are detected automatically. \
             Mods are downloaded 8 at a time with size and hash checks, then a new instance is created. Existing instances are never changed.",
            pal,
        ));
        ui.add_space(8.0);
        ui.horizontal(|ui| {
            if widgets::accent_button(ui, pal, "📂 Open modpack…").clicked() {
                actions.push(Action::Open);
            }
            ui.label(widgets::dim("or drop the file onto the window", pal));
        });
    });
}

fn pack_card(app: &mut McApp, ui: &mut Ui, actions: &mut Vec<Action>) {
    let pal = app.pal;
    let releases: Vec<String> = app
        .manifest
        .as_ref()
        .map(|m| {
            m.versions
                .iter()
                .filter(|v| v.kind == VersionType::Release)
                .map(|v| v.id.clone())
                .collect()
        })
        .unwrap_or_default();
    let busy = app.modpacks_ui.job.is_some();
    let job = app.modpacks_ui.job.and_then(|id| app.jobs.get(&id));
    let progress = job.map(crate::app::job_text);
    let cancellable = app.modpacks_ui.cancel.is_some();
    let paths = app.services().paths.clone();
    let st = &mut app.modpacks_ui;
    let Some(pack) = &st.pack else { return };
    let editable = pack.format == PackFormat::Generic || pack.mc_version.is_none();

    widgets::card(ui, &pal, |ui| {
        ui.set_width(ui.available_width());
        ui.horizontal(|ui| {
            ui.label(RichText::new(&pack.name).strong().size(18.0));
            widgets::badge(ui, pack.format.label(), pal.info);
            if let Some(v) = &pack.version {
                widgets::badge(ui, v, pal.dim);
            }
            ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
                if !busy && ui.small_button("✖").on_hover_text("Close").clicked() {
                    actions.push(Action::Clear);
                }
            });
        });
        let by = [
            pack.author.as_deref().map(|a| format!("by {a}")),
            pack.summary.clone(),
        ]
        .into_iter()
        .flatten()
        .collect::<Vec<_>>()
        .join(" — ");
        if !by.is_empty() {
            ui.label(widgets::dim(by, &pal));
        }
        ui.add_space(8.0);
        egui::Grid::new("modpack_info")
            .num_columns(2)
            .spacing([24.0, 8.0])
            .show(ui, |ui| {
                ui.label("Minecraft");
                if editable && !busy {
                    egui::ComboBox::from_id_salt("modpack_mc")
                        .selected_text(if st.mc.is_empty() { "choose…" } else { st.mc.as_str() })
                        .height(300.0)
                        .show_ui(ui, |ui| {
                            for v in &releases {
                                ui.selectable_value(&mut st.mc, v.clone(), v);
                            }
                        });
                } else {
                    ui.label(RichText::new(&st.mc).strong());
                }
                ui.end_row();

                ui.label("Mod loader");
                if pack.format == PackFormat::Generic && !busy {
                    egui::ComboBox::from_id_salt("modpack_loader")
                        .selected_text(st.loader.label())
                        .show_ui(ui, |ui| {
                            for k in [
                                LoaderKind::Fabric,
                                LoaderKind::Quilt,
                                LoaderKind::Forge,
                                LoaderKind::NeoForge,
                                LoaderKind::Vanilla,
                            ] {
                                ui.selectable_value(&mut st.loader, k, k.label());
                            }
                        });
                } else {
                    let text = match (&pack.loader, &pack.loader_version) {
                        (LoaderKind::Vanilla, _) => "None (vanilla)".to_string(),
                        (k, Some(v)) => format!("{k} {v}"),
                        (k, None) => k.label().to_string(),
                    };
                    ui.label(RichText::new(text).strong());
                }
                ui.end_row();

                ui.label("Files");
                let mut parts = Vec::new();
                if pack.remote_count() > 0 {
                    parts.push(format!("{} to download", pack.remote_count()));
                }
                if pack.bundled_mods > 0 {
                    parts.push(format!("{} bundled mod(s)", pack.bundled_mods));
                }
                if parts.is_empty() {
                    parts.push("bundled only".into());
                }
                ui.label(parts.join(" · "));
                ui.end_row();

                ui.label("New instance");
                ui.vertical(|ui| {
                    ui.add_enabled(
                        !busy,
                        egui::TextEdit::singleline(&mut st.name).desired_width(280.0),
                    );
                    let problem = validate_name(&st.name).err().or_else(|| {
                        paths
                            .instance_dir(&st.name)
                            .exists()
                            .then(|| "An instance with this name already exists".to_string())
                    });
                    if let (Some(p), false) = (problem, busy) {
                        ui.label(RichText::new(p).color(pal.danger).small());
                    }
                });
                ui.end_row();
            });

        if !pack.notes.is_empty() || !pack.manual.is_empty() {
            ui.add_space(6.0);
            for n in &pack.notes {
                ui.label(widgets::dim(format!("•  {n}"), &pal));
            }
            if !pack.manual.is_empty() {
                ui.label(
                    RichText::new(format!(
                        "⚠ {} file(s) can't be downloaded automatically; you'll get links after the install",
                        pack.manual.len()
                    ))
                    .color(pal.warn),
                );
            }
        }
        ui.add_space(10.0);
        match (busy, progress) {
            (true, Some((frac, text))) => {
                ui.horizontal(|ui| {
                    if cancellable && ui.button("✖ Cancel").clicked() {
                        actions.push(Action::Cancel);
                    }
                    ui.add(
                        egui::ProgressBar::new(frac)
                            .text(text)
                            .fill(pal.accent.gamma_multiply(0.85))
                            .desired_width(ui.available_width()),
                    );
                });
            }
            (true, None) => {
                ui.horizontal(|ui| {
                    ui.spinner();
                    ui.label("Starting…");
                });
            }
            (false, _) => {
                let ok = !st.mc.is_empty()
                    && validate_name(&st.name).is_ok()
                    && !paths.instance_dir(&st.name).exists();
                ui.horizontal(|ui| {
                    let resp = ui.add_enabled_ui(ok, |ui| {
                        widgets::accent_button(ui, &pal, "⬇ Install modpack")
                    });
                    if resp.inner.clicked() {
                        actions.push(Action::Install);
                    }
                    ui.label(widgets::dim(
                        "Creates a new instance; nothing else is changed.",
                        &pal,
                    ));
                });
            }
        }
    });
}

fn result_card(app: &mut McApp, ui: &mut Ui, actions: &mut Vec<Action>) {
    let pal = app.pal;
    let Some(r) = &app.modpacks_ui.result else { return };
    widgets::card(ui, &pal, |ui| {
        ui.set_width(ui.available_width());
        ui.horizontal(|ui| {
            ui.label(
                RichText::new(format!("✔ Installed \"{}\"", r.instance))
                    .strong()
                    .size(16.0)
                    .color(pal.accent),
            );
            ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
                if ui.button("📂 Open folder").clicked() {
                    actions.push(Action::Folder(r.instance.clone()));
                }
                if widgets::accent_button(ui, &pal, "▶ Play").clicked() {
                    actions.push(Action::Play(r.instance.clone()));
                }
            });
        });
        ui.label(widgets::dim(&r.summary, &pal));
        for n in &r.notes {
            ui.label(widgets::dim(format!("•  {n}"), &pal));
        }
        if r.manual.is_empty() {
            return;
        }
        ui.add_space(10.0);
        ui.label(
            RichText::new(format!(
                "⚠ {} file(s) must be downloaded by hand",
                r.manual.len()
            ))
            .strong()
            .color(pal.warn),
        );
        ui.label(widgets::dim(
            "Their authors don't allow other apps to download them (or the lookup failed). Open each page, download the exact file, then let the launcher pick them up.",
            &pal,
        ));
        ui.add_space(6.0);
        egui::Grid::new("manual_files")
            .num_columns(4)
            .striped(true)
            .spacing([16.0, 6.0])
            .show(ui, |ui| {
                for h in ["Mod", "File", "Why", ""] {
                    ui.label(RichText::new(h).color(pal.dim).strong());
                }
                ui.end_row();
                for m in &r.manual {
                    let file = m.file_name.clone().unwrap_or_else(|| "unknown".into());
                    widgets::fixed_label(ui, 200.0, RichText::new(&m.name)).on_hover_text(&m.name);
                    widgets::fixed_label(ui, 240.0, widgets::mono(&file)).on_hover_text(&file);
                    widgets::fixed_label(ui, 240.0, widgets::dim(&m.reason, &pal))
                        .on_hover_text(&m.reason);
                    if ui.button("🌐 Open page").clicked() {
                        actions.push(Action::Url(m.url.clone()));
                    }
                    ui.end_row();
                }
            });
        ui.add_space(8.0);
        ui.horizontal(|ui| {
            if ui
                .button("🔍 Look in Downloads")
                .on_hover_text("Checks names and checksums, then adds the files")
                .clicked()
            {
                actions.push(Action::FindDownloads);
            }
            if ui.button("📂 Choose folder…").clicked() {
                actions.push(Action::FindIn);
            }
        });
    });
}
