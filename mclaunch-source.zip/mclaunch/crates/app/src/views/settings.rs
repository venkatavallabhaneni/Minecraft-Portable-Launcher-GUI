//! Settings: theme, downloads, offline mode, defaults.

use std::sync::atomic::Ordering;

use eframe::egui::{self, Ui};
use mclaunch_core::config::Theme;

use crate::app::McApp;
use crate::widgets;

pub fn show(app: &mut McApp, ui: &mut Ui, ctx: &egui::Context) {
    let pal = app.pal;
    widgets::pixel_heading(ui, "Settings", 16.0);
    ui.add_space(12.0);
    let before = app.config.clone();

    egui::ScrollArea::vertical()
        .id_salt("settings_scroll_1").auto_shrink([false, false]).show(ui, |ui| {
        widgets::card(ui, &pal, |ui| {
            ui.heading("Appearance");
            ui.add_space(6.0);
            egui::Grid::new("appearance").num_columns(2).spacing([24.0, 10.0]).show(ui, |ui| {
                ui.label("Theme");
                ui.horizontal(|ui| {
                    ui.selectable_value(&mut app.config.theme, Theme::Dark, "🌙 Dark");
                    ui.selectable_value(&mut app.config.theme, Theme::Light, "☀ Light");
                });
                ui.end_row();
                ui.label("Accent colour");
                ui.horizontal(|ui| {
                    let mut rgb = mclaunch_core::config::parse_hex_color(&app.config.accent)
                        .unwrap_or([0x5D, 0xBB, 0x63]);
                    if ui.color_edit_button_srgb(&mut rgb).changed() {
                        app.config.accent = format!("#{:02X}{:02X}{:02X}", rgb[0], rgb[1], rgb[2]);
                    }
                    if ui.button("Reset").clicked() {
                        app.config.accent = "#5DBB63".into();
                    }
                });
                ui.end_row();
                ui.label("UI scale");
                ui.add(egui::Slider::new(&mut app.config.ui_scale, 0.75..=2.0).step_by(0.05));
                ui.end_row();
                ui.label("Language");
                egui::ComboBox::from_id_salt("lang")
                    .selected_text("English")
                    .show_ui(ui, |ui| {
                        ui.selectable_value(&mut app.config.language, "en".to_string(), "English");
                    })
                    .response
                    .on_hover_text("More languages can be added later.");
                ui.end_row();
            });
        });
        ui.add_space(10.0);
        widgets::card(ui, &pal, |ui| {
            ui.heading("Network");
            ui.add_space(6.0);
            egui::Grid::new("network").num_columns(2).spacing([24.0, 10.0]).show(ui, |ui| {
                ui.label("Offline mode");
                ui.checkbox(
                    &mut app.config.offline_mode,
                    "Never use the network (launch from verified cache only)",
                );
                ui.end_row();
                ui.label("Parallel downloads");
                ui.add(egui::Slider::new(&mut app.config.download_threads, 1..=64));
                ui.end_row();
                ui.label("CurseForge API key");
                ui.horizontal(|ui| {
                    ui.add(
                        egui::TextEdit::singleline(&mut app.config.curseforge_api_key)
                            .password(true)
                            .hint_text("optional")
                            .desired_width(260.0),
                    );
                    if ui.link("Get one").clicked() {
                        let _ = open::that_detached("https://console.curseforge.com/");
                    }
                });
                ui.end_row();
            });
            ui.label(widgets::dim(
                "CurseForge modpacks install without a key. With one, downloads are SHA-1 checked and mods whose authors block other apps are listed for manual download.",
                &pal,
            ));
            ui.add_space(4.0);
            ui.label(widgets::dim(
                "No telemetry. The network is only used for Mojang, mod loader, Modrinth and CurseForge endpoints, and only when needed.",
                &pal,
            ));
        });
        ui.add_space(10.0);
        widgets::card(ui, &pal, |ui| {
            ui.heading("Defaults");
            ui.add_space(6.0);
            egui::Grid::new("defaults").num_columns(2).spacing([24.0, 10.0]).show(ui, |ui| {
                ui.label("When the game starts");
                ui.checkbox(&mut app.config.minimize_on_launch, "Minimize the launcher");
                ui.end_row();
                ui.label("Default memory for new instances");
                ui.add(
                    egui::Slider::new(&mut app.config.default_ram_mb, 1024..=16384)
                        .step_by(256.0)
                        .suffix(" MB"),
                );
                ui.end_row();
            });
        });
        ui.add_space(10.0);
        widgets::card(ui, &pal, |ui| {
            ui.heading("Folders");
            ui.add_space(6.0);
            let root = app.services().paths.root.clone();
            ui.label(widgets::mono(root.display().to_string()));
            ui.horizontal(|ui| {
                if ui.button("📂 Open launcher folder").clicked() {
                    open_path(app, &root);
                }
                if ui.button("📜 Open logs folder").clicked() {
                    let logs = app.services().paths.logs_dir();
                    open_path(app, &logs);
                }
            });
        });
    });

    if app.config != before {
        app.config = std::mem::take(&mut app.config).sanitized();
        let svc = app.services().clone();
        svc.threads
            .store(app.config.download_threads, Ordering::Relaxed);
        svc.http.set_offline(app.config.offline_mode);
        if app.config.theme != before.theme
            || app.config.accent != before.accent
            || app.config.ui_scale != before.ui_scale
        {
            app.apply_theme(ctx);
        }
        if app.config.offline_mode != before.offline_mode && !app.config.offline_mode {
            app.refresh_manifest(false);
        }
        app.save_config();
    }
}

pub fn open_path(app: &mut McApp, path: &std::path::Path) {
    if let Err(e) = std::fs::create_dir_all(path).and_then(|_| open::that_detached(path)) {
        app.toast(
            crate::app::ToastKind::Error,
            format!("Cannot open {}: {e}", path.display()),
        );
    }
}
