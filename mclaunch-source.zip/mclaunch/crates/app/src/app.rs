//! Application state and the frame layout (top bar, navigation, status bar).

use std::collections::{BTreeMap, HashMap, HashSet, VecDeque};
use std::path::PathBuf;
use std::time::{Duration, Instant};

use eframe::egui::{self, Align, Color32, Layout, RichText};
use mclaunch_core::manifest::VersionManifest;
use mclaunch_core::{human_bytes, Config, InstanceConfig, Progress};
use mclaunch_download::install::{installed_versions, InstalledVersion};
use mclaunch_download::{ManifestSource, VerifyReport};
use mclaunch_java::{JavaManager, JavaRuntime, ScanError};
use mclaunch_launch::LogLine;
use tokio::sync::mpsc::UnboundedReceiver;

use crate::backend::{AppEvent, Backend, JobDone, JobId, Services};
use crate::game::{CrashInfo, RunningGame};
use crate::theme::{self, Palette};
use crate::views;
use crate::widgets;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Screen {
    Play,
    Instances,
    Modpacks,
    Versions,
    Loaders,
    Lan,
    Servers,
    Java,
    Logs,
    Settings,
}

impl Screen {
    pub const NAV: [Screen; 9] = [
        Screen::Play,
        Screen::Instances,
        Screen::Modpacks,
        Screen::Versions,
        Screen::Loaders,
        Screen::Lan,
        Screen::Servers,
        Screen::Java,
        Screen::Logs,
    ];

    pub fn label(self) -> &'static str {
        match self {
            Screen::Play => "▶  Play",
            Screen::Instances => "📦  Instances",
            Screen::Modpacks => "📥  Modpacks",
            Screen::Versions => "⬇  Versions",
            Screen::Loaders => "🔧  Loaders",
            Screen::Lan => "🌐  LAN",
            Screen::Servers => "🖥  Servers",
            Screen::Java => "☕  Java",
            Screen::Logs => "📜  Logs",
            Screen::Settings => "⚙  Settings",
        }
    }

    pub fn from_name(name: &str) -> Option<Screen> {
        Some(match name.to_ascii_lowercase().as_str() {
            "play" => Screen::Play,
            "instances" => Screen::Instances,
            "modpacks" => Screen::Modpacks,
            "versions" => Screen::Versions,
            "loaders" => Screen::Loaders,
            "lan" => Screen::Lan,
            "servers" => Screen::Servers,
            "java" => Screen::Java,
            "logs" => Screen::Logs,
            "settings" => Screen::Settings,
            _ => return None,
        })
    }
}

pub struct JobState {
    pub label: String,
    pub progress: Option<Progress>,
    last_sample: (Instant, u64),
    /// Smoothed bytes per second.
    pub speed: f64,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ToastKind {
    Info,
    Success,
    Error,
}

pub struct Toast {
    pub kind: ToastKind,
    pub text: String,
    pub created: Instant,
}

pub struct VersionsUi {
    pub search: String,
    pub release: bool,
    pub snapshot: bool,
    pub beta: bool,
    pub alpha: bool,
    pub installed_only: bool,
    pub focus_search: bool,
}

impl Default for VersionsUi {
    fn default() -> Self {
        Self {
            search: String::new(),
            release: true,
            snapshot: false,
            beta: false,
            alpha: false,
            installed_only: false,
            focus_search: false,
        }
    }
}

/// Developer aids driven by environment variables.
struct ScreenshotPlan {
    path: PathBuf,
    requested: bool,
    at: Instant,
    /// Stop the running game before closing.
    stop_game: bool,
}

pub struct McApp {
    pub backend: Backend,
    rx: UnboundedReceiver<AppEvent>,
    pub config: Config,
    pub pal: Palette,
    pub screen: Screen,
    pub manifest: Option<VersionManifest>,
    pub manifest_source: Option<ManifestSource>,
    pub installed: Vec<InstalledVersion>,
    pub reports: HashMap<String, VerifyReport>,
    /// Version ids with a running install/verify/repair.
    pub busy_versions: HashSet<String>,
    pub jobs: BTreeMap<JobId, JobState>,
    pub toasts: Vec<Toast>,
    pub versions_ui: VersionsUi,
    pub java: Vec<JavaRuntime>,
    pub java_errors: Vec<ScanError>,
    pub java_scanning: bool,
    pub instances: Vec<InstanceConfig>,
    pub instance_dialog: Option<views::instances::InstanceDialog>,
    pub delete_dialog: Option<views::instances::DeleteDialog>,
    pub account_dialog: Option<views::accounts::AccountDialog>,
    /// Required Java major per installed version id (0 = loading).
    pub version_java: HashMap<String, u32>,
    pub version_java_missing: HashSet<String>,
    pub game: Option<RunningGame>,
    /// Instance currently being prepared for launch.
    pub launching: Option<String>,
    pub game_log: VecDeque<LogLine>,
    pub log_ui: views::logs::LogUi,
    pub last_crash: Option<CrashInfo>,
    /// Quick-join address (`host:port`), empty for none.
    pub quick_join: String,
    pub loaders_ui: views::loaders::LoadersUi,
    pub modpacks_ui: views::modpacks::ModpacksUi,
    pub shader_status: HashMap<String, mclaunch_loaders::shaders::ShaderStatus>,
    /// The launcher's own OpenGL renderer + version string (pre-flight).
    pub host_gl: Option<(String, String)>,
    pub lan_games: Vec<mclaunch_lan::LanGame>,
    pub lan_error: Option<String>,
    pub lan_ui: views::lan::LanUi,
    pub servers: Vec<mclaunch_server::ServerConfig>,
    pub running_servers: HashMap<String, crate::servers::RunningServer>,
    pub server_logs: HashMap<String, VecDeque<String>>,
    pub servers_ui: views::servers::ServersUi,
    host_gl_checked: bool,
    /// Minimize the window on the next frame (game just started).
    pub minimize_pending: bool,
    autoplay: bool,
    screenshot: Option<ScreenshotPlan>,
    frames: u64,
}

impl McApp {
    pub fn new(
        cc: &eframe::CreationContext<'_>,
        services: Services,
        config: Config,
        rt: tokio::runtime::Handle,
        open: Vec<PathBuf>,
    ) -> Self {
        let (tx, rx) = tokio::sync::mpsc::unbounded_channel();
        let backend = Backend::new(services, rt, tx, cc.egui_ctx.clone());
        theme::install_fonts(&cc.egui_ctx);
        let pal = Palette::new(config.theme, &config.accent);
        theme::apply(&cc.egui_ctx, &pal, config.ui_scale);

        let screen = std::env::var("MCLAUNCH_SCREEN")
            .ok()
            .and_then(|s| Screen::from_name(&s))
            .unwrap_or(Screen::Play);
        let delay: u64 = std::env::var("MCLAUNCH_SCREENSHOT_DELAY")
            .ok()
            .and_then(|s| s.parse().ok())
            .unwrap_or(3);
        let screenshot = std::env::var_os("MCLAUNCH_SCREENSHOT").map(|p| ScreenshotPlan {
            path: PathBuf::from(p),
            requested: false,
            at: Instant::now() + Duration::from_secs(delay),
            stop_game: true,
        });
        let autoplay = std::env::var_os("MCLAUNCH_AUTOPLAY").is_some();

        let mut app = Self {
            backend,
            rx,
            config,
            pal,
            screen,
            manifest: None,
            manifest_source: None,
            installed: Vec::new(),
            reports: HashMap::new(),
            busy_versions: HashSet::new(),
            jobs: BTreeMap::new(),
            toasts: Vec::new(),
            versions_ui: VersionsUi::default(),
            java: Vec::new(),
            java_errors: Vec::new(),
            java_scanning: false,
            instances: Vec::new(),
            instance_dialog: None,
            delete_dialog: None,
            account_dialog: None,
            version_java: HashMap::new(),
            version_java_missing: HashSet::new(),
            game: None,
            launching: None,
            game_log: VecDeque::new(),
            log_ui: Default::default(),
            last_crash: None,
            quick_join: String::new(),
            loaders_ui: Default::default(),
            modpacks_ui: Default::default(),
            shader_status: HashMap::new(),
            host_gl: None,
            lan_games: Vec::new(),
            lan_error: None,
            lan_ui: Default::default(),
            servers: Vec::new(),
            running_servers: HashMap::new(),
            server_logs: HashMap::new(),
            servers_ui: Default::default(),
            host_gl_checked: false,
            minimize_pending: false,
            autoplay,
            screenshot,
            frames: 0,
        };
        app.refresh_manifest(false);
        app.refresh_installed();
        app.rescan_java(false);
        app.refresh_instances();
        app.start_lan_discovery();
        app.refresh_servers();
        if app.config.accounts.is_empty() {
            app.account_dialog = Some(Default::default());
        }
        if !open.is_empty() {
            app.import_files(open);
        }
        app
    }

    // ---------------------------------------------------------------- state

    pub fn services(&self) -> &Services {
        &self.backend.services
    }

    pub fn save_config(&mut self) {
        let svc = self.services();
        if let Err(e) = self.config.save(&svc.safe, &svc.paths.config_file()) {
            self.toast(ToastKind::Error, format!("Could not save settings: {e}"));
        }
    }

    pub fn apply_theme(&mut self, ctx: &egui::Context) {
        self.pal = Palette::new(self.config.theme, &self.config.accent);
        theme::apply(ctx, &self.pal, self.config.ui_scale);
    }

    pub fn toast(&mut self, kind: ToastKind, text: impl Into<String>) {
        let text = text.into();
        match kind {
            ToastKind::Error => tracing::warn!("{text}"),
            _ => tracing::info!("{text}"),
        }
        self.toasts.push(Toast {
            kind,
            text,
            created: Instant::now(),
        });
        if self.toasts.len() > 5 {
            self.toasts.remove(0);
        }
    }

    pub fn job_started(&mut self, id: JobId, label: String) {
        let now = Instant::now();
        self.jobs.insert(
            id,
            JobState {
                label,
                progress: None,
                last_sample: (now, 0),
                speed: 0.0,
            },
        );
    }

    fn handle_events(&mut self) {
        while let Ok(ev) = self.rx.try_recv() {
            match ev {
                AppEvent::Progress(id, p) => {
                    if let Some(job) = self.jobs.get_mut(&id) {
                        let now = Instant::now();
                        let (t0, b0) = job.last_sample;
                        let dt = now.duration_since(t0).as_secs_f64();
                        if dt >= 0.25 {
                            let inst = p.bytes_done.saturating_sub(b0) as f64 / dt;
                            job.speed = if job.speed == 0.0 {
                                inst
                            } else {
                                job.speed * 0.7 + inst * 0.3
                            };
                            job.last_sample = (now, p.bytes_done);
                        }
                        job.progress = Some(p);
                    }
                }
                AppEvent::Finished(id, res) => {
                    let label = self.jobs.remove(&id).map(|j| j.label).unwrap_or_default();
                    match res {
                        Ok(Some(msg)) => self.toast(ToastKind::Success, msg),
                        Ok(None) => {}
                        Err(e) => self.toast(ToastKind::Error, format!("{label} failed: {e}")),
                    }
                }
                AppEvent::Apply(f) => f(self),
            }
        }
    }

    // ------------------------------------------------------------- actions

    /// Load the version list (network when allowed, otherwise cache).
    pub fn refresh_manifest(&mut self, user_requested: bool) {
        self.backend
            .job("Loading version list", move |j| async move {
                let (manifest, source) = j.services.installer().fetch_manifest().await?;
                let msg = match (user_requested, source) {
                    (true, ManifestSource::Network) => Some(format!(
                        "Version list updated ({} versions)",
                        manifest.versions.len()
                    )),
                    (true, ManifestSource::Cache) => {
                        Some("Offline: showing the cached version list".to_string())
                    }
                    _ => None,
                };
                Ok(JobDone {
                    message: msg,
                    apply: None,
                }
                .then(move |app| {
                    app.manifest = Some(manifest);
                    app.manifest_source = Some(source);
                }))
            });
    }

    pub fn refresh_installed(&mut self) {
        let paths = self.services().paths.clone();
        let b = self.backend.clone();
        self.backend.spawn(async move {
            let list = tokio::task::spawn_blocking(move || installed_versions(&paths))
                .await
                .unwrap_or_default();
            b.apply(move |app| app.installed = list);
        });
    }

    /// Scan `java/` for runtimes. `force` re-hashes every archive.
    pub fn rescan_java(&mut self, force: bool) {
        if self.java_scanning {
            return;
        }
        self.java_scanning = true;
        let include_system = self.config.use_system_java;
        self.backend
            .job("Scanning Java runtimes", move |j| async move {
                let svc = j.services.clone();
                let progress = j.progress.clone();
                let report = tokio::task::spawn_blocking(move || {
                    JavaManager::new(svc.paths, svc.safe).scan(include_system, force, &progress)
                })
                .await;
                let report = match report {
                    Ok(r) => r,
                    Err(e) => {
                        j.backend.apply(|app| app.java_scanning = false);
                        anyhow::bail!("java scan crashed: {e}");
                    }
                };
                let msg = (force || !report.extracted.is_empty()).then(|| {
                    format!(
                        "Java: {} runtime(s) found{}",
                        report.runtimes.len(),
                        if report.extracted.is_empty() {
                            String::new()
                        } else {
                            format!(", extracted {}", report.extracted.join(", "))
                        }
                    )
                });
                Ok(JobDone {
                    message: msg,
                    apply: None,
                }
                .then(move |app| {
                    app.java_scanning = false;
                    app.java = report.runtimes;
                    app.java_errors = report.errors;
                }))
            });
    }

    /// Listen for "Open to LAN" broadcasts for the life of the app.
    fn start_lan_discovery(&mut self) {
        let b = self.backend.clone();
        let b2 = self.backend.clone();
        let stop = std::sync::Arc::new(tokio::sync::Notify::new());
        self.backend.spawn(async move {
            let res =
                mclaunch_lan::listen(move |games| b.apply(move |app| app.lan_games = games), stop)
                    .await;
            if let Err(e) = res {
                tracing::warn!(error = %e, "LAN discovery unavailable");
                b2.apply(move |app| app.lan_error = Some(e.to_string()));
            }
        });
    }

    pub fn is_installed(&self, id: &str) -> bool {
        self.installed.iter().any(|v| v.id == id && v.has_integrity)
    }

    pub fn install_version(&mut self, id: String) {
        if !self.busy_versions.insert(id.clone()) {
            return;
        }
        self.backend
            .job(format!("Installing {id}"), move |j| async move {
                let res = j.services.installer().install(&id, &j.progress).await;
                let id2 = id.clone();
                j.backend.apply(move |app| {
                    app.busy_versions.remove(&id2);
                    app.refresh_installed();
                    app.version_java_missing.remove(&id2);
                    app.version_java.remove(&id2);
                });
                let report = res?;
                Ok(JobDone::msg(format!(
                    "{id} installed: {} files, {} downloaded ({})",
                    report.files,
                    report.downloaded,
                    human_bytes(report.bytes)
                ))
                .then(move |app| {
                    app.reports.remove(&id);
                }))
            });
    }

    pub fn verify_version(&mut self, id: String) {
        if !self.busy_versions.insert(id.clone()) {
            return;
        }
        self.backend
            .job(format!("Verifying {id}"), move |j| async move {
                let res = j.services.installer().verify(&id, &j.progress).await;
                let id2 = id.clone();
                j.backend.apply(move |app| {
                    app.busy_versions.remove(&id2);
                });
                let report = res?;
                let msg = format!("{id}: {}", report.summary());
                Ok(JobDone::msg(msg).then(move |app| {
                    if !report.is_ok() {
                        app.toast(
                            ToastKind::Error,
                            format!("{}: press Repair to fix it", report.version),
                        );
                    }
                    app.reports.insert(id, report);
                }))
            });
    }

    pub fn repair_version(&mut self, id: String) {
        if !self.busy_versions.insert(id.clone()) {
            return;
        }
        self.backend
            .job(format!("Repairing {id}"), move |j| async move {
                let res = j.services.installer().repair(&id, &j.progress).await;
                let id2 = id.clone();
                j.backend.apply(move |app| {
                    app.busy_versions.remove(&id2);
                    app.refresh_installed();
                });
                let report = res?;
                let msg = report.summary();
                Ok(JobDone::msg(msg).then(move |app| {
                    app.reports.insert(id, report.after);
                }))
            });
    }

    // ------------------------------------------------------------------ UI

    fn top_bar(&mut self, ctx: &egui::Context) {
        let pal = self.pal;
        egui::TopBottomPanel::top("top")
            .exact_height(46.0)
            .frame(
                egui::Frame::new()
                    .fill(pal.panel)
                    .inner_margin(egui::Margin::symmetric(14, 8)),
            )
            .show(ctx, |ui| {
                ui.horizontal_centered(|ui| {
                    widgets::logo(ui, 2.0);
                    widgets::pixel_heading(ui, "mclaunch", 16.0);
                    ui.label(widgets::dim(
                        format!("v{}", mclaunch_core::LAUNCHER_VERSION),
                        &pal,
                    ));
                    ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
                        if ui
                            .selectable_label(
                                self.screen == Screen::Settings,
                                Screen::Settings.label(),
                            )
                            .clicked()
                        {
                            self.screen = Screen::Settings;
                        }
                        ui.add_space(8.0);
                        views::accounts::menu(self, ui);
                    });
                });
            });
    }

    fn nav(&mut self, ctx: &egui::Context) {
        let pal = self.pal;
        egui::SidePanel::left("nav")
            .exact_width(158.0)
            .resizable(false)
            .frame(
                egui::Frame::new()
                    .fill(pal.panel)
                    .inner_margin(egui::Margin::symmetric(8, 12)),
            )
            .show(ctx, |ui| {
                ui.spacing_mut().item_spacing.y = 4.0;
                for screen in Screen::NAV {
                    let selected = self.screen == screen;
                    let text = RichText::new(screen.label()).size(15.0).color(if selected {
                        pal.accent_text
                    } else {
                        pal.text
                    });
                    let button = egui::Button::new(text)
                        .fill(if selected {
                            pal.accent
                        } else {
                            Color32::TRANSPARENT
                        })
                        .min_size(egui::vec2(ui.available_width(), 34.0))
                        .corner_radius(egui::CornerRadius::same(8));
                    let resp = ui.add(button);
                    if resp.clicked() {
                        self.screen = screen;
                    }
                }
            });
    }

    fn status_bar(&mut self, ctx: &egui::Context) {
        let pal = self.pal;
        egui::TopBottomPanel::bottom("status")
            .exact_height(32.0)
            .frame(
                egui::Frame::new()
                    .fill(pal.panel)
                    .inner_margin(egui::Margin::symmetric(12, 4)),
            )
            .show(ctx, |ui| {
                ui.horizontal_centered(|ui| {
                    // Right side first so the progress bar can take the rest.
                    let right = |ui: &mut egui::Ui, app: &McApp| {
                        let (text, color) = app.network_badge();
                        ui.label(RichText::new(text).color(color));
                    };
                    match self.jobs.iter().next_back() {
                        Some((_, job)) => {
                            let others = self.jobs.len() - 1;
                            let (frac, text) = job_text(job);
                            ui.label(RichText::new(format!("⬇ {}", job.label)).color(pal.text));
                            ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
                                right(ui, self);
                                if others > 0 {
                                    ui.label(widgets::dim(format!("+{others} more"), &pal));
                                }
                                if job.speed > 1.0 {
                                    ui.label(format!("{}/s", human_bytes(job.speed as u64)));
                                }
                                let bar = egui::ProgressBar::new(frac)
                                    .text(text)
                                    .fill(pal.accent.gamma_multiply(0.85))
                                    .desired_width(ui.available_width() - 8.0);
                                ui.add(bar);
                            });
                        }
                        None => {
                            ui.label(widgets::dim("Ready", &pal));
                            ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
                                right(ui, self);
                            });
                        }
                    }
                });
            });
    }

    /// Text and colour for the network/offline indicator.
    pub fn network_badge(&self) -> (String, Color32) {
        if self.config.offline_mode {
            ("✈ Offline mode".into(), self.pal.warn)
        } else {
            match self.manifest_source {
                Some(ManifestSource::Network) => ("✔ Online".into(), self.pal.accent),
                Some(ManifestSource::Cache) => ("✔ Offline OK (cached)".into(), self.pal.warn),
                None => ("…".into(), self.pal.dim),
            }
        }
    }

    fn toasts_ui(&mut self, ctx: &egui::Context) {
        let ttl = Duration::from_secs(7);
        self.toasts.retain(|t| t.created.elapsed() < ttl);
        if self.toasts.is_empty() {
            return;
        }
        let pal = self.pal;
        egui::Area::new(egui::Id::new("toasts"))
            .anchor(egui::Align2::RIGHT_BOTTOM, egui::vec2(-14.0, -42.0))
            .order(egui::Order::Foreground)
            .show(ctx, |ui| {
                ui.set_max_width(420.0);
                let mut dismiss = None;
                for (i, t) in self.toasts.iter().enumerate() {
                    let color = match t.kind {
                        ToastKind::Info => pal.info,
                        ToastKind::Success => pal.accent,
                        ToastKind::Error => pal.danger,
                    };
                    let resp = egui::Frame::new()
                        .fill(pal.panel_hi)
                        .stroke(egui::Stroke::new(1.5_f32, color))
                        .corner_radius(egui::CornerRadius::same(8))
                        .inner_margin(egui::Margin::same(10))
                        .show(ui, |ui| {
                            ui.label(RichText::new(&t.text).color(pal.text));
                        })
                        .response
                        .interact(egui::Sense::click());
                    if resp.clicked() {
                        dismiss = Some(i);
                    }
                    ui.add_space(4.0);
                }
                if let Some(i) = dismiss {
                    self.toasts.remove(i);
                }
            });
        ctx.request_repaint_after(Duration::from_millis(500));
    }

    fn shortcuts(&mut self, ctx: &egui::Context) {
        let (ctrl_f, enter) = ctx.input(|i| {
            (
                i.modifiers.command && i.key_pressed(egui::Key::F),
                i.key_pressed(egui::Key::Enter) && i.modifiers.is_none(),
            )
        });
        if ctrl_f {
            self.screen = Screen::Versions;
            self.versions_ui.focus_search = true;
        }
        let dialog_open = self.instance_dialog.is_some()
            || self.delete_dialog.is_some()
            || self.account_dialog.is_some();
        if enter
            && self.screen == Screen::Play
            && !dialog_open
            && !ctx.wants_keyboard_input()
            && self.game.is_none()
        {
            if let Some(name) = self.selected_instance().map(|i| i.name.clone()) {
                self.launch_instance(&name);
            }
        }
    }

    /// Query the launcher's own GL context once (shader pre-flight).
    fn detect_host_gl(&mut self, frame: &eframe::Frame) {
        if self.host_gl_checked {
            return;
        }
        self.host_gl_checked = true;
        if let Some(gl) = frame.gl() {
            use eframe::glow::HasContext;
            // SAFETY: plain glGetString queries on the live context eframe
            // hands us during `update`.
            let (renderer, version) = unsafe {
                (
                    gl.get_parameter_string(eframe::glow::RENDERER),
                    gl.get_parameter_string(eframe::glow::VERSION),
                )
            };
            tracing::info!(%renderer, %version, "launcher OpenGL context");
            self.host_gl = Some((renderer, version));
        }
    }

    fn handle_drops(&mut self, ctx: &egui::Context) {
        let dropped: Vec<PathBuf> = ctx.input(|i| {
            i.raw
                .dropped_files
                .iter()
                .filter_map(|f| f.path.clone())
                .collect()
        });
        if !dropped.is_empty() {
            self.import_files(dropped);
        }
        let hovering = ctx.input(|i| !i.raw.hovered_files.is_empty());
        if hovering {
            let pal = self.pal;
            let screen = ctx.screen_rect();
            let painter = ctx.layer_painter(egui::LayerId::new(
                egui::Order::Foreground,
                egui::Id::new("drop_overlay"),
            ));
            painter.rect_filled(screen, 0.0_f32, Color32::from_black_alpha(170));
            painter.rect_stroke(
                screen.shrink(12.0),
                12.0_f32,
                egui::Stroke::new(3.0_f32, pal.accent),
                egui::StrokeKind::Inside,
            );
            let target = self
                .selected_instance()
                .map(|i| format!("into \"{}\"", i.name))
                .unwrap_or_default();
            painter.text(
                screen.center(),
                egui::Align2::CENTER_CENTER,
                format!("Drop to import {target}\nmodpacks · shader packs · resource packs · mods · OptiFine · Java archives"),
                egui::FontId::proportional(20.0),
                Color32::WHITE,
            );
        }
    }

    fn autoplay_tick(&mut self) {
        if self.autoplay && self.manifest.is_some() && !self.java_scanning {
            if let Some(name) = self.selected_instance().map(|i| i.name.clone()) {
                self.autoplay = false;
                self.launch_instance(&name);
                self.screen = Screen::Logs;
            }
        }
    }

    fn screenshot_tick(&mut self, ctx: &egui::Context) {
        let Some(plan) = &mut self.screenshot else {
            return;
        };
        ctx.request_repaint_after(Duration::from_millis(100));
        if !plan.requested && Instant::now() >= plan.at && self.frames > 10 {
            plan.requested = true;
            ctx.send_viewport_cmd(egui::ViewportCommand::Screenshot(Default::default()));
        }
        let image = ctx.input(|i| {
            i.events.iter().find_map(|e| match e {
                egui::Event::Screenshot { image, .. } => Some(image.clone()),
                _ => None,
            })
        });
        if let Some(image) = image {
            if let Err(e) = crate::screenshot::save(&plan.path, &image) {
                eprintln!("screenshot failed: {e}");
            }
            if plan.stop_game {
                if let Some(g) = &self.game {
                    g.kill.notify_one();
                }
            }
            ctx.send_viewport_cmd(egui::ViewportCommand::Close);
        }
    }
}

pub(crate) fn job_text(job: &JobState) -> (f32, String) {
    match &job.progress {
        Some(p) => {
            let frac = p.fraction();
            let detail = if p.bytes_total > 0 {
                format!(
                    "{} — {:.0}%  ({} / {})",
                    p.stage,
                    frac * 100.0,
                    human_bytes(p.bytes_done),
                    human_bytes(p.bytes_total)
                )
            } else if p.total > 0 {
                format!("{} — {}/{}", p.stage, p.done, p.total)
            } else {
                p.stage.clone()
            };
            (frac, detail)
        }
        None => (0.0, "starting…".into()),
    }
}

impl eframe::App for McApp {
    fn update(&mut self, ctx: &egui::Context, frame: &mut eframe::Frame) {
        self.frames += 1;
        self.handle_events();
        self.detect_host_gl(frame);
        if std::mem::take(&mut self.minimize_pending) {
            ctx.send_viewport_cmd(egui::ViewportCommand::Minimized(true));
        }
        self.handle_drops(ctx);
        self.shortcuts(ctx);
        self.top_bar(ctx);
        self.status_bar(ctx);
        self.nav(ctx);
        let pal = self.pal;
        egui::CentralPanel::default()
            .frame(
                egui::Frame::new()
                    .fill(pal.bg)
                    .inner_margin(egui::Margin::same(16)),
            )
            .show(ctx, |ui| match self.screen {
                Screen::Versions => views::versions::show(self, ui),
                Screen::Settings => views::settings::show(self, ui, ctx),
                Screen::Java => views::java::show(self, ui),
                Screen::Play => views::play::show(self, ui),
                Screen::Instances => views::instances::show(self, ui),
                Screen::Logs => views::logs::show(self, ui),
                Screen::Loaders => views::loaders::show(self, ui),
                Screen::Modpacks => views::modpacks::show(self, ui),
                Screen::Lan => views::lan::show(self, ui),
                Screen::Servers => views::servers::show(self, ui),
            });
        views::instances::dialog(self, ctx);
        views::instances::delete_dialog(self, ctx);
        views::accounts::dialog(self, ctx);
        self.toasts_ui(ctx);
        if self.game.is_some() || !self.running_servers.is_empty() {
            ctx.request_repaint_after(Duration::from_secs(1));
        }
        if !self.jobs.is_empty() {
            ctx.request_repaint_after(Duration::from_millis(250));
        }
        self.autoplay_tick();
        self.screenshot_tick(ctx);
    }
}
