//! Modrinth API (used for the one-click shader stacks).

use std::path::{Path, PathBuf};

use mclaunch_safety::SafetyError;
use serde::Deserialize;

use crate::{LoaderError, Loaders, Result};

const API: &str = "https://api.modrinth.com/v2";

#[derive(Debug, Clone, Deserialize)]
pub struct MrHashes {
    #[serde(default)]
    pub sha1: Option<String>,
}

#[derive(Debug, Clone, Deserialize)]
pub struct MrFile {
    pub url: String,
    pub filename: String,
    #[serde(default)]
    pub primary: bool,
    #[serde(default)]
    pub size: Option<u64>,
    pub hashes: MrHashes,
}

#[derive(Debug, Clone, Deserialize)]
pub struct MrDependency {
    #[serde(default)]
    pub project_id: Option<String>,
    #[serde(default)]
    pub version_id: Option<String>,
    pub dependency_type: String,
}

#[derive(Debug, Clone, Deserialize)]
pub struct MrVersion {
    pub id: String,
    pub project_id: String,
    pub version_number: String,
    #[serde(default)]
    pub version_type: String,
    #[serde(default)]
    pub game_versions: Vec<String>,
    #[serde(default)]
    pub loaders: Vec<String>,
    pub files: Vec<MrFile>,
    #[serde(default)]
    pub dependencies: Vec<MrDependency>,
}

impl MrVersion {
    pub fn primary_file(&self) -> Option<&MrFile> {
        self.files
            .iter()
            .find(|f| f.primary)
            .or_else(|| self.files.first())
    }
}

fn enc(list: &str) -> String {
    format!("%5B%22{}%22%5D", list.replace('"', ""))
}

fn key(s: &str) -> String {
    s.chars()
        .map(|c| {
            if c.is_ascii_alphanumeric() || c == '.' || c == '-' {
                c
            } else {
                '_'
            }
        })
        .collect()
}

/// Versions of `project` for a loader + game version, newest first.
pub async fn project_versions(
    l: &Loaders,
    project: &str,
    loader: &str,
    mc: &str,
) -> Result<Vec<MrVersion>> {
    let url = format!(
        "{API}/project/{project}/version?loaders={}&game_versions={}",
        enc(loader),
        enc(mc)
    );
    let cache =
        l.cache_dir("modrinth")
            .join(format!("{}-{}-{}.json", key(project), key(loader), key(mc)));
    let (versions, _): (Vec<MrVersion>, bool) = l.cached_json(&url, &cache).await?;
    Ok(versions)
}

/// Prefer the newest release, then beta, then alpha.
pub fn best(versions: &[MrVersion]) -> Option<&MrVersion> {
    ["release", "beta", "alpha"]
        .iter()
        .find_map(|t| versions.iter().find(|v| v.version_type == *t))
        .or_else(|| versions.first())
}

/// Download (cached in `loaders/modrinth/files/`) and add to `mods_dir`
/// without overwriting. Returns the destination and whether it was added.
pub async fn install_into(
    l: &Loaders,
    version: &MrVersion,
    mods_dir: &Path,
) -> Result<(PathBuf, bool)> {
    let file = version
        .primary_file()
        .ok_or_else(|| LoaderError::Failed(format!("{} has no files", version.version_number)))?;
    if !mclaunch_safety::is_plain_name(&file.filename) {
        return Err(LoaderError::Failed(format!(
            "bad file name {}",
            file.filename
        )));
    }
    let cached = l.cache_dir("modrinth").join("files").join(&file.filename);
    let task = mclaunch_download::DownloadTask::new(&file.url, &cached)
        .sha1(file.hashes.sha1.clone())
        .size(file.size);
    let summary = l
        .installer
        .downloader()
        .run(
            vec![task],
            "Downloading mods",
            &mclaunch_core::progress::noop_progress(),
        )
        .await;
    if !summary.is_ok() {
        return Err(LoaderError::Failed(summary.failure_text()));
    }
    let dest = mods_dir.join(&file.filename);
    match l.safe().copy_new(&cached, &dest) {
        Ok(_) => Ok((dest, true)),
        Err(SafetyError::AlreadyExists(_)) => Ok((dest, false)),
        Err(e) => Err(e.into()),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parse_and_pick() {
        let v: Vec<MrVersion> = serde_json::from_str(
            r#"[
            {"id": "b", "project_id": "YL57xq9U", "version_number": "1.9.0-beta", "version_type": "beta", "game_versions": ["1.21.4"], "loaders": ["fabric"], "files": [{"url": "u", "filename": "iris-b.jar", "primary": true, "size": 1, "hashes": {"sha1": "x", "sha512": "y"}}], "dependencies": []},
            {"id": "a", "project_id": "YL57xq9U", "version_number": "1.8.8", "version_type": "release", "game_versions": ["1.21.4"], "loaders": ["fabric", "quilt"], "files": [{"url": "u", "filename": "iris.jar", "primary": true, "hashes": {"sha1": "x"}}], "dependencies": [{"version_id": null, "project_id": "AANobbMI", "file_name": null, "dependency_type": "required"}]}
            ]"#,
        )
        .unwrap();
        let b = best(&v).unwrap();
        assert_eq!(b.version_number, "1.8.8");
        assert_eq!(b.primary_file().unwrap().filename, "iris.jar");
        assert_eq!(b.dependencies[0].project_id.as_deref(), Some("AANobbMI"));
        assert_eq!(enc("fabric"), "%5B%22fabric%22%5D");
    }
}
