//! Mod loaders (Fabric, Quilt, Forge, NeoForge, OptiFine) and server
//! software (Paper, Purpur, Folia, Spigot, vanilla, Fabric/Forge servers).
//!
//! Everything fetched from the network is cached under `loaders/` so a
//! reinstall, or browsing the compatibility matrix, works offline.

pub mod forge;
pub mod meta;
pub mod modpack;
pub mod modrinth;
pub mod optifine;
pub mod servers;
pub mod shaders;

use std::path::{Path, PathBuf};
use std::time::Duration;

use mclaunch_core::{LauncherPaths, Progress, ProgressFn};
use mclaunch_download::{DownloadError, Http, Installer};
use mclaunch_safety::SafePath;
use serde::{Deserialize, Serialize};
use tokio::io::{AsyncBufReadExt, BufReader};

#[derive(Debug, thiserror::Error)]
pub enum LoaderError {
    #[error("{0}")]
    Unsupported(String),
    #[error("{0}")]
    Failed(String),
    #[error("invalid data from {what}: {message}")]
    Parse { what: String, message: String },
    #[error("I/O error on {path}: {source}")]
    Io {
        path: PathBuf,
        #[source]
        source: std::io::Error,
    },
    #[error(transparent)]
    Download(#[from] DownloadError),
    #[error(transparent)]
    Safety(#[from] mclaunch_safety::SafetyError),
    #[error(transparent)]
    Core(#[from] mclaunch_core::CoreError),
}

pub type Result<T> = std::result::Result<T, LoaderError>;

pub(crate) fn io_err(path: &Path) -> impl FnOnce(std::io::Error) -> LoaderError + '_ {
    move |source| LoaderError::Io {
        path: path.to_path_buf(),
        source,
    }
}

/// Every piece of software the compatibility matrix knows about.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum Software {
    Fabric,
    Quilt,
    Forge,
    NeoForge,
    OptiFine,
    Paper,
    Purpur,
    Folia,
    Spigot,
}

impl Software {
    pub const ALL: [Software; 9] = [
        Software::Fabric,
        Software::Quilt,
        Software::Forge,
        Software::NeoForge,
        Software::OptiFine,
        Software::Paper,
        Software::Purpur,
        Software::Folia,
        Software::Spigot,
    ];

    pub fn label(self) -> &'static str {
        match self {
            Software::Fabric => "Fabric",
            Software::Quilt => "Quilt",
            Software::Forge => "Forge",
            Software::NeoForge => "NeoForge",
            Software::OptiFine => "OptiFine",
            Software::Paper => "Paper",
            Software::Purpur => "Purpur",
            Software::Folia => "Folia",
            Software::Spigot => "Spigot",
        }
    }

    /// Runs in the game client (as opposed to server-only software).
    pub fn client_side(self) -> bool {
        matches!(
            self,
            Software::Fabric
                | Software::Quilt
                | Software::Forge
                | Software::NeoForge
                | Software::OptiFine
        )
    }

    pub fn loader_kind(self) -> Option<mclaunch_core::LoaderKind> {
        use mclaunch_core::LoaderKind as L;
        Some(match self {
            Software::Fabric => L::Fabric,
            Software::Quilt => L::Quilt,
            Software::Forge => L::Forge,
            Software::NeoForge => L::NeoForge,
            Software::OptiFine => L::OptiFine,
            _ => return None,
        })
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct LoaderVersion {
    pub version: String,
    pub stable: bool,
    /// Marked "recommended" by the project (Forge promotions).
    pub recommended: bool,
}

impl LoaderVersion {
    pub fn new(version: impl Into<String>, stable: bool) -> Self {
        Self {
            version: version.into(),
            stable,
            recommended: false,
        }
    }
}

/// Result of installing a client loader.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct InstalledLoader {
    pub software: Software,
    /// Version id to launch (`versions/<id>/<id>.json`).
    pub version_id: String,
    pub mc_version: String,
    pub loader_version: String,
}

/// Shared context for loader operations.
#[derive(Clone)]
pub struct Loaders {
    pub installer: Installer,
}

impl Loaders {
    pub fn new(installer: Installer) -> Self {
        Self { installer }
    }

    pub fn paths(&self) -> &LauncherPaths {
        &self.installer.paths
    }

    pub fn safe(&self) -> &SafePath {
        &self.installer.safe
    }

    pub fn http(&self) -> &Http {
        &self.installer.http
    }

    pub fn cache_dir(&self, what: &str) -> PathBuf {
        self.paths().loaders_dir().join(what)
    }

    /// GET with an on-disk cache: network when possible (refreshing the
    /// cache), otherwise the cached copy. Returns `(bytes, from_cache)`.
    pub async fn cached_get(&self, url: &str, cache: &Path) -> Result<(Vec<u8>, bool)> {
        if !self.http().is_offline() {
            match self.http().get_bytes(url).await {
                Ok(bytes) => {
                    self.safe().write(cache, &bytes)?;
                    return Ok((bytes, false));
                }
                Err(e) => {
                    tracing::debug!(url, error = %e, "fetch failed; trying cache");
                    if !cache.is_file() {
                        return Err(e.into());
                    }
                }
            }
        }
        match std::fs::read(cache) {
            Ok(b) => Ok((b, true)),
            Err(_) => Err(DownloadError::Offline(url.to_string()).into()),
        }
    }

    pub async fn cached_json<T: serde::de::DeserializeOwned>(
        &self,
        url: &str,
        cache: &Path,
    ) -> Result<(T, bool)> {
        let (bytes, cached) = self.cached_get(url, cache).await?;
        let v = serde_json::from_slice(&bytes).map_err(|e| LoaderError::Parse {
            what: url.to_string(),
            message: e.to_string(),
        })?;
        Ok((v, cached))
    }

    /// Download `url` to `dest` once (kept for offline reinstalls).
    pub async fn fetch_file(&self, url: &str, dest: &Path, sha1: Option<String>) -> Result<()> {
        if dest.is_file() && sha1.is_none() {
            return Ok(());
        }
        let task = mclaunch_download::DownloadTask::new(url, dest).sha1(sha1);
        let summary = self
            .installer
            .downloader()
            .run(
                vec![task],
                "Downloading",
                &mclaunch_core::progress::noop_progress(),
            )
            .await;
        if summary.is_ok() {
            Ok(())
        } else {
            Err(LoaderError::Failed(summary.failure_text()))
        }
    }

    /// Versions of `software` available for Minecraft `mc`.
    pub async fn versions(
        &self,
        software: Software,
        mc: &str,
    ) -> Result<(Vec<LoaderVersion>, bool)> {
        match software {
            Software::Fabric => meta::versions(self, meta::MetaLoader::Fabric, mc).await,
            Software::Quilt => meta::versions(self, meta::MetaLoader::Quilt, mc).await,
            Software::Forge => forge::versions(self, forge::ForgeFlavor::Forge, mc).await,
            Software::NeoForge => forge::versions(self, forge::ForgeFlavor::NeoForge, mc).await,
            Software::OptiFine => Ok((optifine::imported_for(self.paths(), mc), false)),
            Software::Paper | Software::Purpur | Software::Folia => {
                servers::paper_like_versions(self, software, mc).await
            }
            Software::Spigot => servers::spigot_available(self, mc).await,
        }
    }

    /// Install a client loader on top of vanilla `mc`. `java` runs Forge /
    /// NeoForge installers and the OptiFine patcher.
    pub async fn install_client(
        &self,
        software: Software,
        mc: &str,
        version: &str,
        java: Option<&Path>,
        progress: &ProgressFn,
    ) -> Result<InstalledLoader> {
        // The vanilla version must be complete first.
        progress(Progress::stage(format!("Installing Minecraft {mc}")));
        self.installer.install(mc, progress).await?;
        let id = match software {
            Software::Fabric => meta::install(self, meta::MetaLoader::Fabric, mc, version).await?,
            Software::Quilt => meta::install(self, meta::MetaLoader::Quilt, mc, version).await?,
            Software::Forge | Software::NeoForge => {
                let flavor = if software == Software::Forge {
                    forge::ForgeFlavor::Forge
                } else {
                    forge::ForgeFlavor::NeoForge
                };
                let java = java.ok_or_else(|| {
                    LoaderError::Failed(format!(
                        "{} needs Java to run its installer",
                        software.label()
                    ))
                })?;
                forge::install(self, flavor, mc, version, java, progress).await?
            }
            Software::OptiFine => {
                let jar = optifine::find_imported(self.paths(), mc, version)
                    .ok_or_else(|| LoaderError::Failed("Import the OptiFine jar first".into()))?;
                optifine::install_vanilla(self, &jar, java, progress).await?
            }
            other => {
                return Err(LoaderError::Unsupported(format!(
                    "{} is server software",
                    other.label()
                )))
            }
        };
        // Download remaining libraries and record the SHA-256 manifest.
        progress(Progress::stage(format!("Verifying {id}")));
        self.installer.install(&id, progress).await?;
        Ok(InstalledLoader {
            software,
            version_id: id,
            mc_version: mc.to_string(),
            loader_version: version.to_string(),
        })
    }
}

/// Run a helper Java program (installers, patchers), streaming its output
/// lines into `progress`. Fails on non-zero exit or after `timeout`.
pub async fn run_java(
    java: &Path,
    args: &[String],
    cwd: &Path,
    label: &str,
    progress: &ProgressFn,
    timeout: Duration,
) -> Result<Vec<String>> {
    tracing::info!(java = %java.display(), ?args, "running helper");
    let mut cmd = tokio::process::Command::new(java);
    cmd.args(args)
        .current_dir(cwd)
        .stdin(std::process::Stdio::null())
        .stdout(std::process::Stdio::piped())
        .stderr(std::process::Stdio::piped())
        .kill_on_drop(true);
    #[cfg(windows)]
    cmd.creation_flags(0x0800_0000);
    let mut child = cmd
        .spawn()
        .map_err(|e| LoaderError::Failed(format!("could not start {}: {e}", java.display())))?;
    let stdout = child.stdout.take();
    let stderr = child.stderr.take();
    let (tx, mut rx) = tokio::sync::mpsc::unbounded_channel::<String>();
    for stream in [
        stdout.map(|s| Box::new(s) as Box<dyn tokio::io::AsyncRead + Unpin + Send>),
        stderr.map(|s| Box::new(s) as Box<dyn tokio::io::AsyncRead + Unpin + Send>),
    ]
    .into_iter()
    .flatten()
    {
        let tx = tx.clone();
        tokio::spawn(async move {
            let mut lines = BufReader::new(stream).lines();
            while let Ok(Some(l)) = lines.next_line().await {
                let _ = tx.send(l);
            }
        });
    }
    drop(tx);
    let mut output = Vec::new();
    let collect = async {
        while let Some(line) = rx.recv().await {
            tracing::debug!(target: "mclaunch::helper", "{line}");
            let short: String = line.chars().take(90).collect();
            progress(Progress::stage(format!("{label}: {short}")));
            output.push(line);
        }
        child.wait().await
    };
    let status = tokio::time::timeout(timeout, collect)
        .await
        .map_err(|_| LoaderError::Failed(format!("{label} timed out")))?
        .map_err(|e| LoaderError::Failed(format!("{label}: {e}")))?;
    if !status.success() {
        let tail: Vec<&String> = output.iter().rev().take(8).collect();
        let tail: Vec<&str> = tail.into_iter().rev().map(String::as_str).collect();
        return Err(LoaderError::Failed(format!(
            "{label} failed ({status}):\n{}",
            tail.join("\n")
        )));
    }
    Ok(output)
}

/// Read one entry of a zip/jar into memory.
pub fn read_zip_entry(jar: &Path, name: &str) -> Result<Option<Vec<u8>>> {
    use std::io::Read;
    let file = std::fs::File::open(jar).map_err(io_err(jar))?;
    let mut zip =
        zip::ZipArchive::new(std::io::BufReader::new(file)).map_err(|e| LoaderError::Parse {
            what: jar.display().to_string(),
            message: e.to_string(),
        })?;
    let mut entry = match zip.by_name(name) {
        Ok(e) => e,
        Err(zip::result::ZipError::FileNotFound) => return Ok(None),
        Err(e) => {
            return Err(LoaderError::Parse {
                what: jar.display().to_string(),
                message: e.to_string(),
            })
        }
    };
    let mut buf = Vec::new();
    entry.read_to_end(&mut buf).map_err(io_err(jar))?;
    Ok(Some(buf))
}

/// Names of all entries in a zip/jar.
pub fn zip_entry_names(jar: &Path) -> Result<Vec<String>> {
    let file = std::fs::File::open(jar).map_err(io_err(jar))?;
    let zip =
        zip::ZipArchive::new(std::io::BufReader::new(file)).map_err(|e| LoaderError::Parse {
            what: jar.display().to_string(),
            message: e.to_string(),
        })?;
    Ok(zip.file_names().map(str::to_string).collect())
}

/// Compare dotted version strings numerically where possible.
pub fn version_cmp(a: &str, b: &str) -> std::cmp::Ordering {
    let parse = |s: &str| -> Vec<(u64, String)> {
        s.split(['.', '-', '+', '_'])
            .map(|p| {
                let digits: String = p.chars().take_while(|c| c.is_ascii_digit()).collect();
                (digits.parse().unwrap_or(0), p.to_string())
            })
            .collect()
    };
    parse(a).cmp(&parse(b))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn version_ordering() {
        use std::cmp::Ordering::*;
        assert_eq!(version_cmp("47.10.0", "47.9.2"), Greater);
        assert_eq!(version_cmp("0.16.10", "0.16.9"), Greater);
        assert_eq!(version_cmp("21.1.200", "21.1.200"), Equal);
        assert_eq!(version_cmp("1.20.1-47.2.0", "1.20.1-47.10.0"), Less);
    }
}

/// Guess which loader a version id belongs to (for profiles picked from the
/// installed list): `fabric-loader-0.16.10-1.21.4`, `quilt-loader-…`,
/// `1.20.1-forge-47.2.0`, `neoforge-21.1.200`, `1.20.1-OptiFine_HD_U_I6`.
pub fn detect_loader(id: &str) -> Option<(mclaunch_core::LoaderKind, String)> {
    use mclaunch_core::LoaderKind as L;
    if let Some(rest) = id.strip_prefix("fabric-loader-") {
        return Some((
            L::Fabric,
            rest.split('-').next().unwrap_or(rest).to_string(),
        ));
    }
    if let Some(rest) = id.strip_prefix("quilt-loader-") {
        return Some((
            L::Quilt,
            rest.rsplit_once('-')
                .map(|(v, _)| v)
                .unwrap_or(rest)
                .to_string(),
        ));
    }
    if let Some(rest) = id.strip_prefix("neoforge-") {
        return Some((L::NeoForge, rest.to_string()));
    }
    if let Some((_, ed)) = id.split_once("-OptiFine_") {
        return Some((L::OptiFine, ed.to_string()));
    }
    let lower = id.to_ascii_lowercase();
    if let Some(idx) = lower.find("-forge") {
        let v = id[idx + 6..].trim_start_matches('-').to_string();
        return Some((L::Forge, v));
    }
    None
}

#[cfg(test)]
mod detect_tests {
    use super::detect_loader;
    use mclaunch_core::LoaderKind as L;

    #[test]
    fn detect() {
        assert_eq!(
            detect_loader("fabric-loader-0.16.10-1.21.4"),
            Some((L::Fabric, "0.16.10".into()))
        );
        assert_eq!(
            detect_loader("quilt-loader-0.20.0-beta.9-1.21.1"),
            Some((L::Quilt, "0.20.0-beta.9".into()))
        );
        assert_eq!(
            detect_loader("neoforge-21.1.200"),
            Some((L::NeoForge, "21.1.200".into()))
        );
        assert_eq!(
            detect_loader("1.20.1-forge-47.2.0"),
            Some((L::Forge, "47.2.0".into()))
        );
        assert_eq!(
            detect_loader("1.7.10-Forge10.13.4.1614-1.7.10"),
            Some((L::Forge, "10.13.4.1614-1.7.10".into()))
        );
        assert_eq!(
            detect_loader("1.20.1-OptiFine_HD_U_I6"),
            Some((L::OptiFine, "HD_U_I6".into()))
        );
        assert_eq!(detect_loader("1.21.4"), None);
    }
}
