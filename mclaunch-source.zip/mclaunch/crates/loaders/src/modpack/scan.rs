//! Mod jar metadata: which loader a jar is for, which Minecraft versions it
//! accepts, which mod ids it provides and requires. Used to understand plain
//! zips that have no pack manifest.

use std::collections::{BTreeMap, BTreeSet, HashSet};
use std::io::Cursor;

use mclaunch_core::LoaderKind;

use super::read_entry_limited;
use crate::version_cmp;

/// Metadata files are small; nested jars may be larger.
const META_LIMIT: u64 = 4 * 1024 * 1024;
const NESTED_LIMIT: u64 = 64 * 1024 * 1024;

#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct ModMeta {
    /// Loaders this jar has metadata for.
    pub loaders: Vec<LoaderKind>,
    /// Mod ids provided, including `provides` and nested jars.
    pub ids: Vec<String>,
    /// Required mod ids, per loader.
    pub depends: Vec<(LoaderKind, String)>,
    /// Minecraft version votes `(version, weight)`.
    pub mc: Vec<(String, u32)>,
    /// Lowest Forge/NeoForge version required.
    pub forge_min: Option<String>,
}

/// Mod ids that are the game or the loader itself.
const BUILTIN: &[&str] = &[
    "minecraft",
    "java",
    "fabricloader",
    "fabric-loader",
    "quilt_loader",
    "forge",
    "neoforge",
    "fml",
    "javafml",
    "lowcodefml",
    "mixinextras",
];

/// Read a mod jar's metadata. Never fails: unreadable jars give an empty
/// result.
pub fn scan_jar(bytes: &[u8], file_name: &str) -> ModMeta {
    let mut meta = ModMeta::default();
    scan_into(bytes, &mut meta, 0);
    filename_votes(file_name, &mut meta.mc);
    meta.loaders.dedup();
    meta
}

fn scan_into(bytes: &[u8], meta: &mut ModMeta, depth: u32) {
    let Ok(mut zip) = zip::ZipArchive::new(Cursor::new(bytes)) else {
        return;
    };
    let mut read = |name: &str| -> Option<Vec<u8>> {
        let mut e = zip.by_name(name).ok()?;
        read_entry_limited(&mut e, META_LIMIT).ok()
    };
    // Nested jars only contribute the ids they provide.
    let top = depth == 0;
    if let Some(b) = read("fabric.mod.json") {
        fabric(&b, meta, top);
    }
    if let Some(b) = read("quilt.mod.json") {
        quilt(&b, meta, top);
    }
    if let Some(b) = read("META-INF/neoforge.mods.toml") {
        forge_toml(&b, meta, LoaderKind::NeoForge, top);
    }
    if let Some(b) = read("META-INF/mods.toml") {
        forge_toml(&b, meta, LoaderKind::Forge, top);
    }
    if let Some(b) = read("mcmod.info") {
        mcmod_info(&b, meta, top);
    }
    if depth >= 2 {
        return;
    }
    let nested: Vec<String> = zip
        .file_names()
        .filter(|n| {
            (n.starts_with("META-INF/jars/") || n.starts_with("META-INF/jarjar/"))
                && n.ends_with(".jar")
        })
        .map(str::to_string)
        .collect();
    for n in nested {
        let Ok(mut e) = zip.by_name(&n) else { continue };
        if e.size() > NESTED_LIMIT {
            continue;
        }
        if let Ok(inner) = read_entry_limited(&mut e, NESTED_LIMIT) {
            let mut sub = ModMeta::default();
            scan_into(&inner, &mut sub, depth + 1);
            meta.ids.extend(sub.ids);
        }
    }
}

fn strings(v: &serde_json::Value) -> Vec<String> {
    match v {
        serde_json::Value::String(s) => vec![s.clone()],
        serde_json::Value::Array(a) => a
            .iter()
            .filter_map(|x| x.as_str().map(str::to_string))
            .collect(),
        _ => Vec::new(),
    }
}

/// Lenient JSON: some mods ship raw newlines inside strings.
fn json(bytes: &[u8]) -> Option<serde_json::Value> {
    serde_json::from_slice(bytes).ok().or_else(|| {
        let text = String::from_utf8_lossy(bytes).replace(['\n', '\r', '\t'], " ");
        serde_json::from_str(&text).ok()
    })
}

fn fabric(bytes: &[u8], meta: &mut ModMeta, top: bool) {
    let Some(v) = json(bytes) else { return };
    if let Some(id) = v.get("id").and_then(|x| x.as_str()) {
        meta.ids.push(id.to_string());
    }
    if let Some(p) = v.get("provides") {
        meta.ids.extend(strings(p));
    }
    if !top {
        return;
    }
    meta.loaders.push(LoaderKind::Fabric);
    if let Some(deps) = v.get("depends").and_then(|d| d.as_object()) {
        for (id, pred) in deps {
            if id == "minecraft" {
                for p in strings(pred) {
                    predicate_votes(&p, &mut meta.mc);
                }
            }
            meta.depends.push((LoaderKind::Fabric, id.clone()));
        }
    }
}

fn quilt(bytes: &[u8], meta: &mut ModMeta, top: bool) {
    let Some(v) = json(bytes) else { return };
    let Some(ql) = v.get("quilt_loader") else { return };
    if let Some(id) = ql.get("id").and_then(|x| x.as_str()) {
        meta.ids.push(id.to_string());
    }
    if let Some(p) = ql.get("provides").and_then(|p| p.as_array()) {
        for item in p {
            match item {
                serde_json::Value::String(s) => meta.ids.push(s.clone()),
                other => {
                    if let Some(id) = other.get("id").and_then(|x| x.as_str()) {
                        meta.ids.push(id.to_string());
                    }
                }
            }
        }
    }
    if !top {
        return;
    }
    meta.loaders.push(LoaderKind::Quilt);
    if let Some(deps) = ql.get("depends").and_then(|d| d.as_array()) {
        for d in deps {
            let (id, versions, optional) = match d {
                serde_json::Value::String(s) => (s.clone(), None, false),
                other => (
                    other
                        .get("id")
                        .and_then(|x| x.as_str())
                        .unwrap_or_default()
                        .to_string(),
                    other.get("versions"),
                    other.get("optional").and_then(|x| x.as_bool()) == Some(true),
                ),
            };
            if id.is_empty() || optional {
                continue;
            }
            if id == "minecraft" {
                for p in versions.map(strings).unwrap_or_default() {
                    predicate_votes(&p, &mut meta.mc);
                }
            }
            meta.depends.push((LoaderKind::Quilt, id));
        }
    }
}

fn forge_toml(bytes: &[u8], meta: &mut ModMeta, flavor: LoaderKind, top: bool) {
    let text = String::from_utf8_lossy(bytes);
    let Ok(doc) = text.parse::<toml::Table>() else {
        return;
    };
    let mut flavor = flavor;
    let deps = doc.get("dependencies").and_then(|d| d.as_table());
    // NeoForge 1.20.2–1.20.4 mods still use mods.toml.
    if deps.is_some_and(|d| {
        d.values()
            .filter_map(|v| v.as_array())
            .flatten()
            .any(|x| x.get("modId").and_then(|m| m.as_str()) == Some("neoforge"))
    }) {
        flavor = LoaderKind::NeoForge;
    }
    if let Some(mods) = doc.get("mods").and_then(|m| m.as_array()) {
        for m in mods {
            if let Some(id) = m.get("modId").and_then(|x| x.as_str()) {
                meta.ids.push(id.to_string());
            }
        }
    }
    if !top {
        return;
    }
    meta.loaders.push(flavor);
    let Some(deps) = deps else { return };
    for list in deps.values().filter_map(|v| v.as_array()) {
        for d in list {
            let Some(id) = d.get("modId").and_then(|x| x.as_str()) else {
                continue;
            };
            let range = d.get("versionRange").and_then(|x| x.as_str()).unwrap_or("");
            match id {
                "minecraft" => range_votes(range, &mut meta.mc),
                "forge" | "neoforge" => {
                    if let Some(lower) = range_lower(range) {
                        meta.forge_min = Some(lower);
                    }
                }
                _ => {}
            }
            let required = d.get("mandatory").and_then(|x| x.as_bool()) == Some(true)
                || d.get("type")
                    .and_then(|x| x.as_str())
                    .is_some_and(|t| t.eq_ignore_ascii_case("required"));
            if required {
                meta.depends.push((flavor, id.to_string()));
            }
        }
    }
}

fn mcmod_info(bytes: &[u8], meta: &mut ModMeta, top: bool) {
    let Some(v) = json(bytes) else { return };
    let list = match &v {
        serde_json::Value::Array(a) => a.clone(),
        other => other
            .get("modList")
            .and_then(|m| m.as_array())
            .cloned()
            .unwrap_or_default(),
    };
    for m in &list {
        if let Some(id) = m.get("modid").and_then(|x| x.as_str()) {
            meta.ids.push(id.to_string());
        }
        if top {
            if let Some(mc) = m.get("mcversion").and_then(|x| x.as_str()) {
                if release_like(mc) {
                    meta.mc.push((mc.to_string(), 3));
                }
            }
        }
    }
    if top && !meta.loaders.contains(&LoaderKind::Forge) {
        meta.loaders.push(LoaderKind::Forge);
    }
}

/// `1.20.1`, `1.20`, `26.1`: release ids, no snapshots.
fn release_like(v: &str) -> bool {
    let parts: Vec<&str> = v.split('.').collect();
    (2..=3).contains(&parts.len())
        && parts
            .iter()
            .all(|p| !p.is_empty() && p.len() <= 3 && p.chars().all(|c| c.is_ascii_digit()))
}

/// Fabric/Quilt predicates: `1.20.1`, `~1.20.1`, `>=1.20 <1.21`, `1.20.x`.
fn predicate_votes(pred: &str, out: &mut Vec<(String, u32)>) {
    for token in pred.split_whitespace().filter(|t| *t != "||") {
        let op_len = token
            .find(|c: char| !matches!(c, '<' | '>' | '=' | '~' | '^'))
            .unwrap_or(token.len());
        let (op, ver) = token.split_at(op_len);
        let mut ver = ver.split(['-', '+']).next().unwrap_or("").to_string();
        let mut weight = match op {
            "" | "=" => 3,
            "~" => 2,
            ">=" | "^" => 1,
            _ => 0,
        };
        if let Some(base) = ver.strip_suffix(".x").or_else(|| ver.strip_suffix(".*")) {
            ver = base.to_string();
            weight = weight.min(1);
        }
        if weight > 0 && release_like(&ver) {
            out.push((ver, weight));
        }
    }
}

/// Maven ranges: `[1.20.1]` (exact), `[1.20.1,1.21)`, `[1.20,)`.
fn range_votes(range: &str, out: &mut Vec<(String, u32)>) {
    let inner = range.trim().trim_start_matches(['[', '(']).trim_end_matches([']', ')']);
    let parts: Vec<&str> = inner.split(',').map(str::trim).collect();
    match parts.as_slice() {
        [one] if release_like(one) && range.trim_start().starts_with('[') => {
            out.push((one.to_string(), 3))
        }
        [lo, ..] if release_like(lo) => out.push((lo.to_string(), 2)),
        _ => {}
    }
}

fn range_lower(range: &str) -> Option<String> {
    let inner = range.trim().trim_start_matches(['[', '(']);
    let lo = inner.split([',', ']', ')']).next()?.trim();
    (!lo.is_empty() && lo.chars().next()?.is_ascii_digit()).then(|| lo.to_string())
}

/// `sodium-fabric-0.5.8+mc1.20.1.jar`, `jei-1.18.2-forge-10.2.1.jar`.
fn filename_votes(file_name: &str, out: &mut Vec<(String, u32)>) {
    let stem = file_name.strip_suffix(".jar").unwrap_or(file_name);
    let re = regex::Regex::new(r"(?:^|[-_+ ])(?:mc|MC)?(1\.\d{1,2}(?:\.\d{1,2})?)(?:$|[-_+ ])")
        .expect("valid regex");
    if let Some(c) = re.captures(stem) {
        out.push((c[1].to_string(), 1));
    }
}

/// What the bundled mods of a plain zip say about the pack.
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct Detection {
    pub mc: Option<String>,
    /// Mods that voted for `mc`.
    pub mc_mods: usize,
    pub loader: LoaderKind,
    pub loader_mods: usize,
    pub loader_min: Option<String>,
}

pub fn detect(metas: &[ModMeta], known: Option<&HashSet<String>>) -> Detection {
    let mut d = Detection::default();
    // Minecraft version: weighted votes, one vote per version per mod.
    let mut score: BTreeMap<String, (u32, usize)> = BTreeMap::new();
    for m in metas {
        let mut best: BTreeMap<&str, u32> = BTreeMap::new();
        for (v, w) in &m.mc {
            let e = best.entry(v.as_str()).or_default();
            *e = (*e).max(*w);
        }
        for (v, w) in best {
            if known.is_some_and(|k| !k.contains(v)) {
                continue;
            }
            let e = score.entry(v.to_string()).or_default();
            e.0 += w;
            e.1 += 1;
        }
    }
    if let Some((v, (_, n))) = score
        .iter()
        .max_by(|a, b| a.1 .0.cmp(&b.1 .0).then_with(|| version_cmp(a.0, b.0)))
    {
        d.mc = Some(v.clone());
        d.mc_mods = *n;
    }

    // Loader: majority, Quilt only when nothing is Forge-like.
    let count = |k: LoaderKind| metas.iter().filter(|m| m.loaders.contains(&k)).count();
    let (fabric, quilt, forge, neo) = (
        count(LoaderKind::Fabric),
        count(LoaderKind::Quilt),
        count(LoaderKind::Forge),
        count(LoaderKind::NeoForge),
    );
    let mut ranked = [
        (LoaderKind::Fabric, fabric),
        (LoaderKind::NeoForge, neo),
        (LoaderKind::Forge, forge),
    ];
    ranked.sort_by_key(|a| std::cmp::Reverse(a.1));
    if quilt > 0 && forge + neo == 0 {
        d.loader = LoaderKind::Quilt;
        d.loader_mods = quilt + fabric;
    } else if ranked[0].1 > 0 {
        d.loader = ranked[0].0;
        d.loader_mods = ranked[0].1;
    }
    if matches!(d.loader, LoaderKind::Forge | LoaderKind::NeoForge) {
        d.loader_min = metas
            .iter()
            .filter(|m| m.loaders.contains(&d.loader))
            .filter_map(|m| m.forge_min.clone())
            .max_by(|a, b| version_cmp(a, b));
    }
    d
}

/// Required ids not provided by any bundled mod, for `loader`.
pub fn missing(
    provided: &BTreeSet<String>,
    requires: &[(LoaderKind, String)],
    loader: LoaderKind,
) -> Vec<String> {
    let has_fabric_api = provided.contains("fabric-api") || provided.contains("fabric");
    let applies = |k: LoaderKind| {
        k == loader || (loader == LoaderKind::Quilt && k == LoaderKind::Fabric)
    };
    let out: BTreeSet<String> = requires
        .iter()
        .filter(|(k, _)| applies(*k))
        .map(|(_, id)| id)
        .filter(|id| !BUILTIN.contains(&id.as_str()) && !provided.contains(*id))
        .filter(|id| !(has_fabric_api && (id.starts_with("fabric-") || id.starts_with("fabric_"))))
        .cloned()
        .collect();
    out.into_iter().collect()
}
