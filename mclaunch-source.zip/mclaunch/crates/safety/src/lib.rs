//! `SafePath` — the single guard that every destructive file operation in
//! mclaunch goes through.
//!
//! The hard rule of the launcher is that it never deletes, overwrites or moves
//! user data. User data lives in well known folders inside an instance or a
//! local server (`saves/`, `mods/`, `world*/`, `config/`, ...). Repair,
//! uninstall and update code paths never call `std::fs::remove_*`, `rename` or
//! `write` directly; they call the methods on [`SafePath`], which refuse to act
//! on anything inside (or containing) a protected folder.
//!
//! Adding *new* files to a protected folder is allowed through
//! [`SafePath::create_new`] / [`SafePath::copy_new`]: those use `create_new`
//! semantics and fail if anything already exists at the destination, so they
//! can install a shader pack or a mod without ever clobbering one.

use std::ffi::OsStr;
use std::fs;
use std::io::{self, Write};
use std::path::{Component, Path, PathBuf};

/// Folder (relative to the launcher root) that holds game instances.
pub const INSTANCES_DIR: &str = "instances";
/// Folder (relative to the launcher root) that holds local servers.
pub const SERVERS_DIR: &str = "servers";

/// Folder names that are user data inside an instance or server.
/// Matching is case-insensitive.
pub const PROTECTED_DIRS: &[&str] = &[
    "saves",
    "mods",
    "shaderpacks",
    "resourcepacks",
    "texturepacks",
    "config",
    "screenshots",
    "plugins",
    "schematics",
];

/// Any folder whose name starts with this prefix (`world`, `world_nether`,
/// `world_the_end`, `World1`, ...) is protected too.
pub const PROTECTED_PREFIX: &str = "world";

#[derive(Debug, thiserror::Error)]
pub enum SafetyError {
    #[error("refusing to modify protected user data: {0}")]
    Protected(PathBuf),
    #[error("refusing to modify {0}: it contains protected user data")]
    ContainsProtected(PathBuf),
    #[error("refusing to modify {0}: it is outside the launcher folder")]
    OutsideRoot(PathBuf),
    #[error("refusing to modify the launcher folder itself")]
    Root,
    #[error("{0} already exists; not overwriting")]
    AlreadyExists(PathBuf),
    #[error("the typed confirmation does not match '{0}'")]
    ConfirmationMismatch(String),
    #[error("'{0}' is not a valid name")]
    InvalidName(String),
    #[error("could not move {0} to the recycle bin: {1}")]
    Trash(PathBuf, String),
    #[error("I/O error on {path}: {source}")]
    Io {
        path: PathBuf,
        #[source]
        source: io::Error,
    },
}

pub type Result<T> = std::result::Result<T, SafetyError>;

fn io_err(path: &Path) -> impl FnOnce(io::Error) -> SafetyError + '_ {
    move |source| SafetyError::Io {
        path: path.to_path_buf(),
        source,
    }
}

/// Guard for all destructive file-system operations below a launcher root.
#[derive(Debug, Clone)]
pub struct SafePath {
    /// Canonicalized launcher root.
    root: PathBuf,
}

impl SafePath {
    /// Create a guard for `root`. The directory is created if missing.
    pub fn new(root: impl AsRef<Path>) -> Result<Self> {
        let root = root.as_ref();
        fs::create_dir_all(root).map_err(io_err(root))?;
        let root = fs::canonicalize(root).map_err(io_err(root))?;
        Ok(Self { root })
    }

    pub fn root(&self) -> &Path {
        &self.root
    }

    /// Resolve `path` to an absolute, normalized path with symlinks of the
    /// existing part resolved. Relative paths are taken relative to the root.
    pub fn resolve(&self, path: &Path) -> Result<PathBuf> {
        let abs = if path.is_absolute() {
            path.to_path_buf()
        } else {
            self.root.join(path)
        };
        let normalized = normalize_lexically(&abs);

        // Canonicalize the longest existing ancestor so that symlinks cannot be
        // used to smuggle a protected folder in under an innocent name.
        let mut existing = normalized.as_path();
        let mut rest: Vec<&OsStr> = Vec::new();
        loop {
            match fs::symlink_metadata(existing) {
                Ok(_) => break,
                Err(_) => match (existing.parent(), existing.file_name()) {
                    (Some(parent), Some(name)) => {
                        rest.push(name);
                        existing = parent;
                    }
                    _ => break,
                },
            }
        }
        let mut resolved = fs::canonicalize(existing).unwrap_or_else(|_| existing.to_path_buf());
        for name in rest.iter().rev() {
            resolved.push(name);
        }
        Ok(resolved)
    }

    /// Path of `resolved` relative to the root, or an error when outside.
    fn relative<'a>(&self, original: &Path, resolved: &'a Path) -> Result<&'a Path> {
        resolved
            .strip_prefix(&self.root)
            .map_err(|_| SafetyError::OutsideRoot(original.to_path_buf()))
    }

    /// Is `path` (or anything above it) a protected user-data folder?
    pub fn is_protected(&self, path: &Path) -> bool {
        match self.resolve(path) {
            Ok(resolved) => match resolved.strip_prefix(&self.root) {
                Ok(rel) => rel_is_protected(rel),
                // Outside the root is never ours to touch.
                Err(_) => true,
            },
            Err(_) => true,
        }
    }

    /// Validate that `path` may be deleted, overwritten or moved. Returns the
    /// resolved path to operate on.
    pub fn check_modify(&self, path: &Path) -> Result<PathBuf> {
        let resolved = self.resolve(path)?;
        let rel = self.relative(path, &resolved)?;
        if rel.as_os_str().is_empty() {
            return Err(SafetyError::Root);
        }
        if rel_is_protected(rel) {
            tracing::warn!(path = %path.display(), "SafePath blocked modification of protected data");
            return Err(SafetyError::Protected(path.to_path_buf()));
        }
        Ok(resolved)
    }

    /// Like [`check_modify`](Self::check_modify) but also refuses directories
    /// that *contain* protected folders (e.g. a whole instance).
    pub fn check_remove_tree(&self, path: &Path) -> Result<PathBuf> {
        let resolved = self.check_modify(path)?;
        let rel = self.relative(path, &resolved)?;
        if rel_contains_protected(rel) {
            tracing::warn!(path = %path.display(), "SafePath blocked removal of a tree containing user data");
            return Err(SafetyError::ContainsProtected(path.to_path_buf()));
        }
        Ok(resolved)
    }

    /// Delete a single file. Missing files are not an error.
    pub fn remove_file(&self, path: &Path) -> Result<()> {
        let resolved = self.check_modify(path)?;
        match fs::remove_file(&resolved) {
            Ok(()) => Ok(()),
            Err(e) if e.kind() == io::ErrorKind::NotFound => Ok(()),
            Err(e) => Err(io_err(path)(e)),
        }
    }

    /// Recursively delete a directory that holds no user data (caches,
    /// extracted runtimes, per-launch natives, ...). Missing is not an error.
    pub fn remove_dir_all(&self, path: &Path) -> Result<()> {
        let resolved = self.check_remove_tree(path)?;
        match fs::remove_dir_all(&resolved) {
            Ok(()) => Ok(()),
            Err(e) if e.kind() == io::ErrorKind::NotFound => Ok(()),
            Err(e) => Err(io_err(path)(e)),
        }
    }

    /// Create (or replace) a file atomically: write to a sibling temp file and
    /// rename over the target. Refused inside protected folders.
    pub fn write(&self, path: &Path, contents: &[u8]) -> Result<()> {
        let resolved = self.check_modify(path)?;
        if let Some(parent) = resolved.parent() {
            fs::create_dir_all(parent).map_err(io_err(parent))?;
        }
        let tmp = temp_sibling(&resolved);
        {
            let mut f = fs::File::create(&tmp).map_err(io_err(&tmp))?;
            f.write_all(contents).map_err(io_err(&tmp))?;
            f.sync_all().map_err(io_err(&tmp))?;
        }
        fs::rename(&tmp, &resolved).map_err(|e| {
            let _ = fs::remove_file(&tmp);
            io_err(path)(e)
        })
    }

    /// Move/rename `from` to `to`, replacing `to` if it exists. Both ends must
    /// be outside protected folders.
    pub fn rename(&self, from: &Path, to: &Path) -> Result<()> {
        let src = self.check_remove_tree(from)?;
        let dst = self.check_modify(to)?;
        if let Some(parent) = dst.parent() {
            fs::create_dir_all(parent).map_err(io_err(parent))?;
        }
        fs::rename(&src, &dst).map_err(io_err(from))
    }

    /// Copy `from` over `to` (replacing it). `to` must not be protected.
    pub fn copy_file(&self, from: &Path, to: &Path) -> Result<u64> {
        let dst = self.check_modify(to)?;
        if let Some(parent) = dst.parent() {
            fs::create_dir_all(parent).map_err(io_err(parent))?;
        }
        fs::copy(from, &dst).map_err(io_err(to))
    }

    /// Create a brand new file. Allowed everywhere inside the root, including
    /// protected folders, because it can never overwrite anything: it fails
    /// with [`SafetyError::AlreadyExists`] if the path is taken.
    pub fn create_new(&self, path: &Path, contents: &[u8]) -> Result<()> {
        let resolved = self.resolve(path)?;
        self.relative(path, &resolved)?;
        if let Some(parent) = resolved.parent() {
            fs::create_dir_all(parent).map_err(io_err(parent))?;
        }
        let mut f = fs::OpenOptions::new()
            .write(true)
            .create_new(true)
            .open(&resolved)
            .map_err(|e| {
                if e.kind() == io::ErrorKind::AlreadyExists {
                    SafetyError::AlreadyExists(path.to_path_buf())
                } else {
                    io_err(path)(e)
                }
            })?;
        f.write_all(contents).map_err(io_err(path))?;
        f.sync_all().map_err(io_err(path))
    }

    /// Copy `from` to a destination that must not exist yet (see
    /// [`create_new`](Self::create_new)).
    pub fn copy_new(&self, from: &Path, to: &Path) -> Result<u64> {
        let src = fs::File::open(from).map_err(io_err(from))?;
        self.create_new_from(to, src)
    }

    /// Stream `src` into a destination that must not exist yet (see
    /// [`create_new`](Self::create_new)). Used for archive extraction.
    pub fn create_new_from(&self, to: &Path, mut src: impl io::Read) -> Result<u64> {
        let resolved = self.resolve(to)?;
        self.relative(to, &resolved)?;
        if let Some(parent) = resolved.parent() {
            fs::create_dir_all(parent).map_err(io_err(parent))?;
        }
        let mut dst = fs::OpenOptions::new()
            .write(true)
            .create_new(true)
            .open(&resolved)
            .map_err(|e| {
                if e.kind() == io::ErrorKind::AlreadyExists {
                    SafetyError::AlreadyExists(to.to_path_buf())
                } else {
                    io_err(to)(e)
                }
            })?;
        let n = io::copy(&mut src, &mut dst).map_err(io_err(to))?;
        dst.sync_all().map_err(io_err(to))?;
        Ok(n)
    }

    /// Creating directories never destroys anything; allowed inside the root.
    pub fn create_dir_all(&self, path: &Path) -> Result<()> {
        let resolved = self.resolve(path)?;
        self.relative(path, &resolved)?;
        fs::create_dir_all(&resolved).map_err(io_err(path))
    }

    /// Move a whole instance (`instances/<name>`) to the OS recycle bin. The
    /// user must have typed the exact instance name as `confirmation`.
    /// Never uses `remove_dir_all`.
    pub fn trash_instance(&self, name: &str, confirmation: &str) -> Result<PathBuf> {
        self.trash_child(INSTANCES_DIR, name, confirmation)
    }

    /// Move a whole local server (`servers/<name>`) to the OS recycle bin.
    pub fn trash_server(&self, name: &str, confirmation: &str) -> Result<PathBuf> {
        self.trash_child(SERVERS_DIR, name, confirmation)
    }

    fn trash_child(&self, parent: &str, name: &str, confirmation: &str) -> Result<PathBuf> {
        if confirmation != name {
            return Err(SafetyError::ConfirmationMismatch(name.to_string()));
        }
        if !is_plain_name(name) {
            return Err(SafetyError::InvalidName(name.to_string()));
        }
        let target = self.root.join(parent).join(name);
        let resolved = self.resolve(&target)?;
        let rel = self.relative(&target, &resolved)?;
        let comps: Vec<_> = rel.components().collect();
        if comps.len() != 2 || comps[0].as_os_str() != OsStr::new(parent) {
            return Err(SafetyError::OutsideRoot(target));
        }
        if !resolved.is_dir() {
            return Err(SafetyError::Io {
                path: target,
                source: io::Error::new(io::ErrorKind::NotFound, "no such folder"),
            });
        }
        tracing::info!(path = %resolved.display(), "moving to recycle bin");
        trash::delete(&resolved)
            .map_err(|e| SafetyError::Trash(resolved.clone(), e.to_string()))?;
        Ok(resolved)
    }
}

/// A single path component that is safe to use as a folder name.
pub fn is_plain_name(name: &str) -> bool {
    !name.is_empty()
        && name != "."
        && name != ".."
        && !name.contains(['/', '\\', ':', '\0'])
        && name.trim() == name
}

fn temp_sibling(path: &Path) -> PathBuf {
    let mut name = path
        .file_name()
        .map(|n| n.to_os_string())
        .unwrap_or_default();
    name.push(format!(".mclaunch-tmp-{}", std::process::id()));
    path.with_file_name(name)
}

/// Remove `.` and resolve `..` without touching the file system.
pub fn normalize_lexically(path: &Path) -> PathBuf {
    let mut out = PathBuf::new();
    for comp in path.components() {
        match comp {
            Component::CurDir => {}
            Component::ParentDir => {
                // Never pop past the root/prefix.
                let popped = match out.components().next_back() {
                    Some(Component::Normal(_)) => out.pop(),
                    _ => false,
                };
                if !popped && !out.has_root() {
                    out.push("..");
                }
            }
            other => out.push(other.as_os_str()),
        }
    }
    out
}

fn name_is_protected(name: &OsStr) -> bool {
    let lower = name.to_string_lossy().to_lowercase();
    PROTECTED_DIRS.iter().any(|p| lower == *p) || lower.starts_with(PROTECTED_PREFIX)
}

/// `rel` is a path relative to the launcher root.
fn rel_is_protected(rel: &Path) -> bool {
    let comps: Vec<&OsStr> = rel.components().map(|c| c.as_os_str()).collect();
    if comps.len() < 3 {
        return false;
    }
    let top = comps[0].to_string_lossy().to_lowercase();
    if top != INSTANCES_DIR && top != SERVERS_DIR {
        return false;
    }
    // instances/<name>/<anything below that is user data>
    comps[2..].iter().any(|c| name_is_protected(c))
}

/// Does the tree rooted at `rel` contain protected folders?
fn rel_contains_protected(rel: &Path) -> bool {
    let comps: Vec<&OsStr> = rel.components().map(|c| c.as_os_str()).collect();
    match comps.first() {
        None => true, // the root itself
        Some(top) => {
            let top = top.to_string_lossy().to_lowercase();
            // `instances/`, `instances/<name>`, `servers/`, `servers/<name>`
            (top == INSTANCES_DIR || top == SERVERS_DIR) && comps.len() <= 2
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    struct Fixture {
        _dir: tempfile::TempDir,
        root: PathBuf,
        safe: SafePath,
    }

    fn fixture() -> Fixture {
        let dir = tempfile::tempdir().unwrap();
        let root = dir.path().to_path_buf();
        let safe = SafePath::new(&root).unwrap();
        let root = safe.root().to_path_buf();
        for d in PROTECTED_DIRS {
            let p = root.join("instances/Survival").join(d);
            fs::create_dir_all(&p).unwrap();
            fs::write(p.join("data.bin"), b"precious").unwrap();
        }
        for d in ["world", "world_nether", "world_the_end"] {
            let p = root.join("servers/Lobby").join(d);
            fs::create_dir_all(&p).unwrap();
            fs::write(p.join("level.dat"), b"precious").unwrap();
        }
        fs::create_dir_all(root.join("instances/Survival/saves/New World/region")).unwrap();
        fs::write(
            root.join("instances/Survival/saves/New World/level.dat"),
            b"precious",
        )
        .unwrap();
        fs::create_dir_all(root.join("versions/1.21")).unwrap();
        fs::write(root.join("versions/1.21/1.21.jar"), b"jar").unwrap();
        Fixture {
            _dir: dir,
            root,
            safe,
        }
    }

    fn assert_protected<T: std::fmt::Debug>(r: Result<T>) {
        match r {
            Err(SafetyError::Protected(_)) | Err(SafetyError::ContainsProtected(_)) => {}
            other => panic!("expected protection error, got {other:?}"),
        }
    }

    #[test]
    fn delete_inside_each_protected_instance_folder_fails() {
        let f = fixture();
        for d in PROTECTED_DIRS {
            let file = f.root.join("instances/Survival").join(d).join("data.bin");
            assert_protected(f.safe.remove_file(&file));
            assert!(file.exists(), "{d} file must survive");
            let dir = f.root.join("instances/Survival").join(d);
            assert_protected(f.safe.remove_dir_all(&dir));
            assert!(dir.exists(), "{d} folder must survive");
        }
    }

    #[test]
    fn delete_inside_world_folders_fails() {
        let f = fixture();
        for d in ["world", "world_nether", "world_the_end"] {
            let file = f.root.join("servers/Lobby").join(d).join("level.dat");
            assert_protected(f.safe.remove_file(&file));
            assert_protected(f.safe.remove_dir_all(file.parent().unwrap()));
            assert!(file.exists());
        }
        let world = f.root.join("instances/Survival/saves/New World");
        assert_protected(f.safe.remove_dir_all(&world));
        assert_protected(f.safe.remove_file(&world.join("level.dat")));
        // an instance-level world folder (very old versions) is protected too
        assert!(f
            .safe
            .is_protected(&f.root.join("instances/Survival/World1")));
    }

    #[test]
    fn overwrite_and_move_inside_protected_fail() {
        let f = fixture();
        for d in PROTECTED_DIRS {
            let file = f.root.join("instances/Survival").join(d).join("data.bin");
            assert_protected(f.safe.write(&file, b"clobber"));
            assert_protected(
                f.safe
                    .copy_file(&f.root.join("versions/1.21/1.21.jar"), &file),
            );
            assert_protected(f.safe.rename(&file, &f.root.join("versions/stolen.bin")));
            assert_protected(f.safe.rename(&f.root.join("versions/1.21/1.21.jar"), &file));
            assert_eq!(fs::read(&file).unwrap(), b"precious");
        }
    }

    #[test]
    fn protection_is_case_insensitive() {
        let f = fixture();
        assert!(f
            .safe
            .is_protected(&f.root.join("instances/Survival/SAVES/x")));
        assert!(f
            .safe
            .is_protected(&f.root.join("instances/Survival/Mods/a.jar")));
        assert!(f
            .safe
            .is_protected(&f.root.join("servers/Lobby/World_Nether")));
    }

    #[test]
    fn nested_protected_folders_are_protected() {
        let f = fixture();
        assert!(f
            .safe
            .is_protected(&f.root.join("instances/Survival/.minecraft/saves/w")));
        assert!(!f
            .safe
            .is_protected(&f.root.join("instances/Survival/logs/latest.log")));
    }

    #[test]
    fn removing_a_whole_instance_or_the_instances_dir_fails() {
        let f = fixture();
        assert_protected(f.safe.remove_dir_all(&f.root.join("instances/Survival")));
        assert_protected(f.safe.remove_dir_all(&f.root.join("instances")));
        assert_protected(f.safe.remove_dir_all(&f.root.join("servers/Lobby")));
        assert_protected(f.safe.remove_dir_all(&f.root.join("servers")));
        assert!(matches!(
            f.safe.remove_dir_all(&f.root),
            Err(SafetyError::Root)
        ));
        assert!(f
            .root
            .join("instances/Survival/saves/New World/level.dat")
            .exists());
    }

    #[test]
    fn dot_dot_traversal_is_caught() {
        let f = fixture();
        let sneaky = f
            .root
            .join("versions/../instances/Survival/saves/New World/level.dat");
        assert_protected(f.safe.remove_file(&sneaky));
        let sneaky_rel = Path::new("libraries/x/../../instances/Survival/mods");
        assert_protected(f.safe.remove_dir_all(sneaky_rel));
    }

    #[test]
    fn outside_root_is_refused() {
        let f = fixture();
        let outside = tempfile::tempdir().unwrap();
        let file = outside.path().join("x.txt");
        fs::write(&file, b"x").unwrap();
        assert!(matches!(
            f.safe.remove_file(&file),
            Err(SafetyError::OutsideRoot(_))
        ));
        assert!(file.exists());
        let escape = f.root.join("../../../etc/passwd");
        assert!(f.safe.remove_file(&escape).is_err());
    }

    #[cfg(unix)]
    #[test]
    fn symlink_into_protected_is_caught() {
        let f = fixture();
        let link = f.root.join("versions/link");
        std::os::unix::fs::symlink(f.root.join("instances/Survival/saves"), &link).unwrap();
        assert_protected(f.safe.remove_dir_all(&link.join("New World")));
        assert_protected(f.safe.remove_file(&link.join("New World/level.dat")));
        assert!(f
            .root
            .join("instances/Survival/saves/New World/level.dat")
            .exists());
    }

    #[test]
    fn unprotected_operations_work() {
        let f = fixture();
        let jar = f.root.join("versions/1.21/1.21.jar");
        f.safe.write(&jar, b"new jar").unwrap();
        assert_eq!(fs::read(&jar).unwrap(), b"new jar");
        f.safe.remove_file(&jar).unwrap();
        assert!(!jar.exists());
        f.safe
            .remove_dir_all(&f.root.join("versions/1.21"))
            .unwrap();
        assert!(!f.root.join("versions/1.21").exists());
        // removing missing things is fine
        f.safe.remove_file(&jar).unwrap();
        // instance metadata next to the protected folders is editable
        f.safe
            .write(
                &f.root.join("instances/Survival/instance.toml"),
                b"name = 'x'",
            )
            .unwrap();
    }

    #[test]
    fn create_new_inside_protected_never_overwrites() {
        let f = fixture();
        let new_mod = f.root.join("instances/Survival/mods/sodium.jar");
        f.safe.create_new(&new_mod, b"sodium").unwrap();
        assert_eq!(fs::read(&new_mod).unwrap(), b"sodium");
        let existing = f.root.join("instances/Survival/mods/data.bin");
        assert!(matches!(
            f.safe.create_new(&existing, b"clobber"),
            Err(SafetyError::AlreadyExists(_))
        ));
        assert_eq!(fs::read(&existing).unwrap(), b"precious");
        let src = f.root.join("versions/1.21/1.21.jar");
        assert!(matches!(
            f.safe.copy_new(&src, &existing),
            Err(SafetyError::AlreadyExists(_))
        ));
        f.safe
            .copy_new(&src, &f.root.join("instances/Survival/shaderpacks/BSL.zip"))
            .unwrap();
    }

    #[test]
    fn trash_requires_exact_confirmation() {
        let f = fixture();
        assert!(matches!(
            f.safe.trash_instance("Survival", "survival"),
            Err(SafetyError::ConfirmationMismatch(_))
        ));
        assert!(matches!(
            f.safe.trash_instance("../versions", "../versions"),
            Err(SafetyError::InvalidName(_))
        ));
        assert!(matches!(
            f.safe.trash_server("Lobby", ""),
            Err(SafetyError::ConfirmationMismatch(_))
        ));
        assert!(f.root.join("instances/Survival").exists());
    }

    #[test]
    fn normalize() {
        assert_eq!(
            normalize_lexically(Path::new("/a/b/../c/./d")),
            PathBuf::from("/a/c/d")
        );
        assert_eq!(normalize_lexically(Path::new("/../a")), PathBuf::from("/a"));
        assert_eq!(
            normalize_lexically(Path::new("a/../../b")),
            PathBuf::from("../b")
        );
    }
}
