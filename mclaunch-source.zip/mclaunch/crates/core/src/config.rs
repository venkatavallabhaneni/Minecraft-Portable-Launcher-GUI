//! `config.toml` — launcher-wide settings.

use std::path::Path;

use serde::{Deserialize, Serialize};

use crate::{CoreError, Result};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, Default)]
#[serde(rename_all = "lowercase")]
pub enum Theme {
    #[default]
    Dark,
    Light,
}

/// A saved multiplayer server for the quick-join dropdown.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct SavedServer {
    pub name: String,
    /// `host` or `host:port`.
    pub address: String,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(default)]
pub struct Config {
    /// Offline usernames the user has created.
    pub accounts: Vec<String>,
    /// Index into `accounts` of the active one.
    pub active_account: usize,
    pub theme: Theme,
    /// Accent colour as `#RRGGBB`.
    pub accent: String,
    /// Parallel downloads.
    pub download_threads: usize,
    /// Never touch the network when set.
    pub offline_mode: bool,
    /// Default max heap for new instances, in MiB.
    pub default_ram_mb: u32,
    pub language: String,
    /// Also detect Java from `JAVA_HOME`/`PATH` in addition to `java/*.zip`.
    pub use_system_java: bool,
    pub selected_instance: Option<String>,
    /// Most recently played first.
    pub recent_instances: Vec<String>,
    pub servers: Vec<SavedServer>,
    /// Hide the launcher window while the game runs.
    pub minimize_on_launch: bool,
    /// UI scale factor.
    pub ui_scale: f32,
    /// Optional CurseForge API key (console.curseforge.com). Enables SHA-1
    /// checks and respects authors' third-party download settings.
    pub curseforge_api_key: String,
}

impl Default for Config {
    fn default() -> Self {
        Self {
            accounts: Vec::new(),
            active_account: 0,
            theme: Theme::Dark,
            accent: "#5DBB63".to_string(),
            download_threads: 16,
            offline_mode: false,
            default_ram_mb: 4096,
            language: "en".to_string(),
            use_system_java: true,
            selected_instance: None,
            recent_instances: Vec::new(),
            servers: Vec::new(),
            minimize_on_launch: false,
            ui_scale: 1.0,
            curseforge_api_key: String::new(),
        }
    }
}

impl Config {
    /// Load the config, falling back to defaults when missing. A corrupt file
    /// is reported as an error so the caller can decide (the app keeps the
    /// broken file and starts with defaults).
    pub fn load(path: &Path) -> Result<Self> {
        match std::fs::read_to_string(path) {
            Ok(text) => toml::from_str::<Config>(&text)
                .map(Config::sanitized)
                .map_err(|e| CoreError::Toml {
                    path: path.to_path_buf(),
                    message: e.to_string(),
                }),
            Err(e) if e.kind() == std::io::ErrorKind::NotFound => Ok(Self::default()),
            Err(e) => Err(crate::io_err(path)(e)),
        }
    }

    /// Persist atomically through the `SafePath` guard.
    pub fn save(&self, safe: &mclaunch_safety::SafePath, path: &Path) -> Result<()> {
        let text = toml::to_string_pretty(self).map_err(|e| CoreError::Toml {
            path: path.to_path_buf(),
            message: e.to_string(),
        })?;
        safe.write(path, text.as_bytes())?;
        Ok(())
    }

    /// Clamp values that would break the launcher.
    pub fn sanitized(mut self) -> Self {
        self.download_threads = self.download_threads.clamp(1, 64);
        self.default_ram_mb = self.default_ram_mb.clamp(512, 65536);
        if !(0.5..=3.0).contains(&self.ui_scale) {
            self.ui_scale = 1.0;
        }
        self.accounts
            .retain(|a| crate::offline::validate_username(a).is_ok());
        if self.active_account >= self.accounts.len() {
            self.active_account = 0;
        }
        if parse_hex_color(&self.accent).is_none() {
            self.accent = Config::default().accent;
        }
        self
    }

    pub fn active_username(&self) -> Option<&str> {
        self.accounts.get(self.active_account).map(String::as_str)
    }

    /// Move `name` to the front of the recent list.
    pub fn touch_recent(&mut self, name: &str) {
        self.recent_instances.retain(|n| n != name);
        self.recent_instances.insert(0, name.to_string());
        self.recent_instances.truncate(8);
    }
}

/// Parse `#RRGGBB` into bytes.
pub fn parse_hex_color(s: &str) -> Option<[u8; 3]> {
    let hex = s.strip_prefix('#')?;
    if hex.len() != 6 {
        return None;
    }
    let v = u32::from_str_radix(hex, 16).ok()?;
    Some([(v >> 16) as u8, (v >> 8) as u8, v as u8])
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn roundtrip_and_defaults() {
        let dir = tempfile::tempdir().unwrap();
        let safe = mclaunch_safety::SafePath::new(dir.path()).unwrap();
        let path = safe.root().join("config.toml");
        let cfg = Config::load(&path).unwrap();
        assert_eq!(cfg, Config::default());
        let mut cfg = cfg;
        cfg.accounts.push("Venkat".into());
        cfg.download_threads = 8;
        cfg.save(&safe, &path).unwrap();
        let back = Config::load(&path).unwrap();
        assert_eq!(back, cfg);
    }

    #[test]
    fn partial_file_uses_defaults_and_sanitizes() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("config.toml");
        std::fs::write(
            &path,
            "download_threads = 999\naccounts = ['ok_name', 'bad name!']\naccent='nope'\n",
        )
        .unwrap();
        let cfg = Config::load(&path).unwrap();
        assert_eq!(cfg.download_threads, 64);
        assert_eq!(cfg.accounts, vec!["ok_name".to_string()]);
        assert_eq!(cfg.accent, "#5DBB63");
        assert!(!cfg.offline_mode);
    }

    #[test]
    fn hex() {
        assert_eq!(parse_hex_color("#5DBB63"), Some([0x5d, 0xbb, 0x63]));
        assert_eq!(parse_hex_color("5DBB63"), None);
    }

    #[test]
    fn recent() {
        let mut c = Config::default();
        c.touch_recent("a");
        c.touch_recent("b");
        c.touch_recent("a");
        assert_eq!(c.recent_instances, vec!["a", "b"]);
    }
}
