//! Instances: a game directory plus the settings used to launch it.
//! Stored as `instances/<name>/instance.toml`.

use std::fmt;
use std::path::Path;

use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};

use crate::paths::LauncherPaths;
use crate::{CoreError, Result};

pub const INSTANCE_FILE: &str = "instance.toml";

/// Sub-folders created in every new instance.
pub const INSTANCE_SUBDIRS: &[&str] = &[
    "saves",
    "mods",
    "resourcepacks",
    "shaderpacks",
    "config",
    "screenshots",
];

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize, Default)]
#[serde(rename_all = "lowercase")]
pub enum LoaderKind {
    #[default]
    Vanilla,
    Fabric,
    Quilt,
    Forge,
    NeoForge,
    OptiFine,
}

impl LoaderKind {
    pub const ALL: [LoaderKind; 6] = [
        LoaderKind::Vanilla,
        LoaderKind::Fabric,
        LoaderKind::Quilt,
        LoaderKind::Forge,
        LoaderKind::NeoForge,
        LoaderKind::OptiFine,
    ];

    pub fn label(self) -> &'static str {
        match self {
            LoaderKind::Vanilla => "Vanilla",
            LoaderKind::Fabric => "Fabric",
            LoaderKind::Quilt => "Quilt",
            LoaderKind::Forge => "Forge",
            LoaderKind::NeoForge => "NeoForge",
            LoaderKind::OptiFine => "OptiFine",
        }
    }

    /// Does this loader load mods from `mods/`?
    pub fn uses_mods_folder(self) -> bool {
        !matches!(self, LoaderKind::Vanilla | LoaderKind::OptiFine)
    }
}

impl fmt::Display for LoaderKind {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(self.label())
    }
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(default)]
pub struct InstanceConfig {
    /// Folder name under `instances/` (also the display name).
    pub name: String,
    /// Id passed to the launcher: a vanilla id or a loader profile id.
    pub version_id: String,
    /// The vanilla Minecraft version underneath.
    pub mc_version: String,
    pub loader: LoaderKind,
    pub loader_version: Option<String>,
    /// Path to a java executable, or a major version number such as `17`.
    pub java_override: Option<String>,
    pub max_memory_mb: u32,
    pub min_memory_mb: u32,
    /// Extra JVM arguments.
    pub jvm_args: String,
    /// Extra game arguments.
    pub game_args: String,
    pub resolution: Option<(u32, u32)>,
    /// Shader stack installed via "Enable shaders".
    pub shaders: bool,
    /// Single emoji/glyph shown on the instance card.
    pub icon: String,
    pub created: Option<DateTime<Utc>>,
    pub last_played: Option<DateTime<Utc>>,
    pub play_time_secs: u64,
    pub notes: String,
    /// GPU / OpenGL seen in the game log (shader pre-flight).
    pub gpu: Option<String>,
    /// OpenGL `major.minor` seen in the game log.
    pub gl_version: Option<String>,
}

impl Default for InstanceConfig {
    fn default() -> Self {
        Self {
            name: String::new(),
            version_id: String::new(),
            mc_version: String::new(),
            loader: LoaderKind::Vanilla,
            loader_version: None,
            java_override: None,
            max_memory_mb: 4096,
            min_memory_mb: 512,
            jvm_args: DEFAULT_JVM_ARGS.to_string(),
            game_args: String::new(),
            resolution: None,
            shaders: false,
            icon: "⛏".to_string(),
            created: None,
            last_played: None,
            play_time_secs: 0,
            notes: String::new(),
            gpu: None,
            gl_version: None,
        }
    }
}

/// Default JVM flags: G1GC tuned for a 4–6 GB heap (good for shaders).
pub const DEFAULT_JVM_ARGS: &str = "-XX:+UseG1GC -XX:+ParallelRefProcEnabled -XX:MaxGCPauseMillis=200 -XX:+UnlockExperimentalVMOptions -XX:+DisableExplicitGC -XX:G1NewSizePercent=30 -XX:G1MaxNewSizePercent=40 -XX:G1HeapRegionSize=8M -XX:G1ReservePercent=20";

/// Validate a name used as an instance (or server) folder.
pub fn validate_name(name: &str) -> std::result::Result<(), String> {
    let trimmed = name.trim();
    if trimmed.is_empty() {
        return Err("Name cannot be empty".into());
    }
    if trimmed != name {
        return Err("Name cannot start or end with spaces".into());
    }
    if name.chars().count() > 48 {
        return Err("Name is too long (max 48)".into());
    }
    if name.starts_with('.') {
        return Err("Name cannot start with a dot".into());
    }
    const BAD: &[char] = &['/', '\\', ':', '*', '?', '"', '<', '>', '|', '\0'];
    if name.chars().any(|c| BAD.contains(&c) || c.is_control()) {
        return Err("Name contains characters not allowed in folder names".into());
    }
    let upper = name.to_ascii_uppercase();
    let stem = upper.split('.').next().unwrap_or("");
    const RESERVED: &[&str] = &[
        "CON", "PRN", "AUX", "NUL", "COM1", "COM2", "COM3", "COM4", "LPT1", "LPT2", "LPT3",
    ];
    if RESERVED.contains(&stem) {
        return Err("That name is reserved on Windows".into());
    }
    if !mclaunch_safety::is_plain_name(name) {
        return Err("Invalid name".into());
    }
    Ok(())
}

impl InstanceConfig {
    pub fn new(name: &str, mc_version: &str, default_ram_mb: u32) -> Self {
        Self {
            name: name.to_string(),
            version_id: mc_version.to_string(),
            mc_version: mc_version.to_string(),
            max_memory_mb: default_ram_mb,
            created: Some(Utc::now()),
            ..Default::default()
        }
    }

    pub fn dir(&self, paths: &LauncherPaths) -> std::path::PathBuf {
        paths.instance_dir(&self.name)
    }

    pub fn load(dir: &Path) -> Result<Self> {
        let path = dir.join(INSTANCE_FILE);
        let text = std::fs::read_to_string(&path).map_err(crate::io_err(&path))?;
        let mut cfg: InstanceConfig = toml::from_str(&text).map_err(|e| CoreError::Toml {
            path: path.clone(),
            message: e.to_string(),
        })?;
        // The folder name is authoritative.
        if let Some(name) = dir.file_name() {
            cfg.name = name.to_string_lossy().into_owned();
        }
        if cfg.mc_version.is_empty() {
            cfg.mc_version = cfg.version_id.clone();
        }
        Ok(cfg)
    }

    /// Write `instance.toml` and make sure the standard sub-folders exist.
    pub fn save(&self, paths: &LauncherPaths, safe: &mclaunch_safety::SafePath) -> Result<()> {
        validate_name(&self.name).map_err(CoreError::Invalid)?;
        let dir = self.dir(paths);
        for sub in INSTANCE_SUBDIRS {
            safe.create_dir_all(&dir.join(sub))?;
        }
        let text = toml::to_string_pretty(self).map_err(|e| CoreError::Toml {
            path: dir.join(INSTANCE_FILE),
            message: e.to_string(),
        })?;
        safe.write(&dir.join(INSTANCE_FILE), text.as_bytes())?;
        Ok(())
    }
}

/// Load every instance under `instances/`, sorted by most recently played.
pub fn list_instances(paths: &LauncherPaths) -> Vec<InstanceConfig> {
    let mut out = Vec::new();
    let Ok(entries) = std::fs::read_dir(paths.instances_dir()) else {
        return out;
    };
    for entry in entries.flatten() {
        let dir = entry.path();
        if !dir.join(INSTANCE_FILE).is_file() {
            continue;
        }
        match InstanceConfig::load(&dir) {
            Ok(cfg) => out.push(cfg),
            Err(e) => tracing::warn!(error = %e, "skipping unreadable instance"),
        }
    }
    out.sort_by(|a, b| {
        b.last_played
            .cmp(&a.last_played)
            .then_with(|| a.name.to_lowercase().cmp(&b.name.to_lowercase()))
    });
    out
}

/// A free instance name based on `base` ("Name", "Name (2)", ...).
pub fn unique_name(paths: &LauncherPaths, base: &str) -> String {
    if !paths.instance_dir(base).exists() {
        return base.to_string();
    }
    (2..)
        .map(|n| format!("{base} ({n})"))
        .find(|n| !paths.instance_dir(n).exists())
        .unwrap_or_else(|| base.to_string())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn names() {
        assert!(validate_name("Survival 1.21 + Shaders").is_ok());
        assert!(validate_name("").is_err());
        assert!(validate_name(" x").is_err());
        assert!(validate_name("a/b").is_err());
        assert!(validate_name("..").is_err());
        assert!(validate_name("con").is_err());
        assert!(validate_name(".hidden").is_err());
    }

    #[test]
    fn save_load_list() {
        let dir = tempfile::tempdir().unwrap();
        let safe = mclaunch_safety::SafePath::new(dir.path()).unwrap();
        let paths = LauncherPaths::new(safe.root());
        let mut a = InstanceConfig::new("Alpha", "1.21.4", 4096);
        a.loader = LoaderKind::Fabric;
        a.resolution = Some((1280, 720));
        a.save(&paths, &safe).unwrap();
        let mut b = InstanceConfig::new("Beta", "b1.7.3", 2048);
        b.last_played = Some(Utc::now());
        b.save(&paths, &safe).unwrap();
        assert!(paths.instance_dir("Alpha").join("saves").is_dir());
        assert!(paths.instance_dir("Alpha").join("shaderpacks").is_dir());
        let list = list_instances(&paths);
        assert_eq!(list.len(), 2);
        assert_eq!(list[0].name, "Beta", "most recently played first");
        assert_eq!(list[1].loader, LoaderKind::Fabric);
        assert_eq!(list[1].resolution, Some((1280, 720)));
        assert_eq!(unique_name(&paths, "Alpha"), "Alpha (2)");
        assert_eq!(unique_name(&paths, "Gamma"), "Gamma");
    }
}
