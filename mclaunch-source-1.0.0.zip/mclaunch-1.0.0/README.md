# mclaunch

An offline-first Minecraft: Java Edition launcher written in Rust. One portable
executable, no sign-in, no telemetry. It plays every version from `rd-132211`
to the newest snapshot, installs mod loaders and shaders, and runs local
servers.

> **Offline mode is for people who own Minecraft: Java Edition.** mclaunch
> only downloads game files from Mojang's official servers (or uses your local
> copy) and never redistributes Mojang or OptiFine binaries.

## Quick start

1. Put `mclaunch.exe` (or `mclaunch` on Linux/macOS) in an empty folder. That
   folder holds everything; move it anywhere, e.g. a USB stick.
2. Drop Java archives into the `java/` folder next to it (see below).
3. Start it, pick a username (3–16 letters, digits or `_`), create an instance
   and press **PLAY** (or Enter).

The first download of a version needs the network once. After that, the
version list, game files, loaders and installers are cached, and the game
launches offline after a SHA-256 integrity check.

## Java: drop zips into `java/`

mclaunch does not use an installer for Java. Download JDK or JRE archives (for
example from [Adoptium](https://adoptium.net/temurin/releases/)) and drop them
into `java/`, e.g. `java/8.zip`, `java/17.zip`, `java/21.zip`, `java/25.zip`.
`.zip`, `.tar.gz` and `.tgz` all work, and the file names don't matter.

- Each archive is hashed (SHA-256) and extracted once into
  `java/.extracted/<hash>/`. Replacing an archive re-extracts it.
- The real version is detected by running `java -XshowSettings:properties
  -version`.
- The **Java** tab lists every runtime (archive, version, vendor, path,
  SHA-256). Press **Rescan** after adding archives, or just drop the archive
  onto the window.

Each Minecraft version declares the Java it needs (`javaVersion` in its JSON).
For JSONs without it, mclaunch falls back to: ≤1.16.5 → 8, 1.17 → 16,
1.18–1.20.4 → 17, 1.20.5+ → 21. Current releases (26.x) ask for Java 25. If
nothing matches you get a message like *"Minecraft 1.21 needs Java 21 — drop
a JDK 21 zip into java/"*. You can force a Java major version or a custom
`java` path per instance (**Edit → Java**). Java from `JAVA_HOME`/`PATH` can
also be used (Java tab checkbox).

## Folder layout

```
mclaunch.exe
config.toml            settings (theme, threads, offline mode, profiles, …)
java/                  your JDK archives; java/.extracted/ is launcher-managed
versions/<id>/         version JSONs and client jars
libraries/  assets/    shared game files
instances/<name>/      one game directory per instance
  saves/ mods/ resourcepacks/ shaderpacks/ config/ screenshots/
loaders/               cached loader installers, version lists, mods and modpack files
global-mods/           global mod list (global.json) and imported global jars
servers/<name>/        local servers
integrity/<id>.sha256  SHA-256 manifest per installed version
logs/                  launcher logs and exported game logs
```

## Your data is never touched

Every delete, overwrite and move goes through one guard (`SafePath`). It
refuses to modify anything inside `saves/`, `mods/`, `world*/`,
`shaderpacks/`, `resourcepacks/`, `config/`, `screenshots/` (and `plugins/`)
of any instance or server. The launcher may only **add** new files there
(shader mods, imported packs), never replace existing ones. The two
exceptions are actions you take on the Mods tab: disabling a mod renames it
(`x.jar` → `x.jar.disabled`, never over another file), and removing or
updating one moves the old file to the recycle bin. Repair and
updates only rewrite game files. Deleting an instance or server requires
typing its name and moves the folder to the recycle bin.

## Integrity: Verify and Repair

Downloads are checked against Mojang's SHA-1 and size. After an install,
mclaunch records a SHA-256 of every file in `integrity/<id>.sha256`.

- **Verify** re-hashes everything and reports OK / missing / corrupt.
- **Repair** re-downloads only the missing or corrupt files, then re-verifies
  with SHA-256.
- In **offline mode** (Settings) the network is never used. A version
  launches if its SHA-256 check passes.

## Mod loaders

The **Loaders** tab shows which loaders exist for a Minecraft version and
installs them into a new instance (or the selected one):

| Loader | How |
|---|---|
| Fabric, Quilt | meta API profile (`inheritsFrom` vanilla) |
| Forge 1.12.2+, NeoForge | official installer, run headless (`--installClient`) |
| Forge ≤ 1.12.1 | version JSON and universal jar from the installer |
| OptiFine | you import the jar (its licence forbids redistribution) |

Installers and version lists are cached in `loaders/`, so reinstalling works
offline. Forge is funded by ads on its download page; please consider
[supporting it](https://www.patreon.com/LexManos/).

## Shaders

1. Make an instance with a loader: Fabric or Quilt (Iris + Sodium), NeoForge
   (Iris + Sodium, or Oculus + Embeddium), Forge (Oculus + Embeddium).
2. On the Play screen press **Enable shaders**. The matching mods for that
   exact Minecraft version come from Modrinth (cached), and the heap is raised
   to at least 4 GB with G1GC flags.
3. Drop shader pack `.zip` files onto the window, or use **+ Shader pack…**.
   They go into the instance's `shaderpacks/`.
4. In game: Options → Video Settings → Shader Packs (Iris: press `O`). The
   first pack is preselected only if the shader config doesn't exist yet.

For **vanilla**: download OptiFine for your version from optifine.net, then
use **Import OptiFine jar…** (or drop it on the window) and install it from
the Loaders tab. Shaders need OpenGL 3.2+. The Play screen shows your GPU and
OpenGL version and warns if it's too old.

## Mods

The **Mods** tab manages the mods of one instance, or the **global** mod
list. Pick the target at the top.

- **Browse** searches Modrinth, or CurseForge with an API key. **Install**
  picks the newest release for the instance's Minecraft version and loader
  and adds its required dependencies. Without a CurseForge key you can
  still install by **Project ID** (shown on the mod's CurseForge page);
  the website's dependency list is used.
- **Versions…** (on a search result, or next to a CurseForge Project ID)
  picks an exact version. Choose the Minecraft version first, then one of
  the loaders that version of the mod supports. The newest release for that
  combination is preselected, and older versions and betas are in the list.
  Dependencies are resolved for the same Minecraft version and loader. If
  the mod is already installed, the chosen version replaces it and the old
  jar goes to the recycle bin. You are warned when the choice doesn't match
  the instance. CurseForge lists the newest 500 files of a project.
- **Import from computer…** (or dropping `.jar` files on the Mods screen)
  adds jars after checking they contain mod metadata.
- **Installed** lists every jar with its name and version (read from the
  jar). The switch disables a mod by renaming it to `.jar.disabled`, and 🗑
  moves it to the recycle bin after asking. **Check for updates** looks up
  each jar on Modrinth by checksum. This works for jars from anywhere that
  are also published there. Updating puts the old file in the recycle bin.
- **Global mods** are added to every instance with a mod loader when it
  launches (switch off per instance with **Use global mods**). Modrinth and
  CurseForge entries get the right build for each instance's Minecraft
  version and loader. Imported jars (kept in `global-mods/`) are only added
  where their loader and Minecraft version fit. Switching a global mod off
  or removing it disables its copies (`.disabled`) at the next launch;
  nothing is deleted. **Apply to instances now** does this immediately.
- What the launcher installed is recorded in
  `instances/<name>/mclaunch-mods.json`, along with source, project and
  version.

## Modpacks

The **Modpacks** tab (or **Instances → Import modpack…**, or dropping the
file onto the window) installs a modpack into a **new** instance:

| Format | Detected by |
|---|---|
| Modrinth `.mrpack` | `modrinth.index.json` |
| CurseForge `.zip` | `manifest.json` (`minecraftModpack`) |
| MultiMC / Prism export | `mmc-pack.json` + `.minecraft/` |
| Any zip of a game folder | `mods/`, `config/`, … (optionally inside `.minecraft/` or one wrapper folder) |

- The Minecraft version and loader (Fabric, Quilt, Forge, NeoForge) come
  from the pack. For plain zips they are read from the bundled mods
  (`fabric.mod.json`, `quilt.mod.json`, `mods.toml`, `neoforge.mods.toml`,
  `mcmod.info`), and you can correct them before installing. Required mods
  that a plain zip is missing (e.g. Fabric API) are fetched from Modrinth.
- Files are downloaded 8 at a time, with retries and resume. Each one is
  checked against its size and SHA-1 (and SHA-512 for Modrinth). They are
  cached in `loaders/modpacks/`, so a reinstall works offline. **Cancel**
  stops the install and keeps what was downloaded.
- Overrides (configs, bundled mods, resource packs…) are copied first and
  `client-overrides` win over `overrides`. Paths that would escape the
  instance folder are skipped.
- `.mrpack` downloads are limited to the hosts the format allows
  (cdn.modrinth.com, github.com, raw.githubusercontent.com, gitlab.com).
- **CurseForge** works without an API key: the public website gives each
  file's name and size, and the download is size-checked. With a key
  (Settings → Network, from [console.curseforge.com](https://console.curseforge.com/)),
  files are SHA-1 checked and sorted by category. Mods whose authors block
  third-party downloads are listed instead of downloaded.
- Files that can't be downloaded are listed with a link to their page.
  Download them in your browser, then press **Look in Downloads** (or
  **Choose folder…**). The launcher adds the files whose names and checksums
  match. The list is also saved in the instance as `modpack.json`.
- The new instance gets at least 4 GB of memory (6 GB for packs with more
  than 150 mods). If anything fails, the half-built folder goes to the
  recycle bin; existing instances are never touched.

## LAN and servers

- **Open to LAN** works as in vanilla. The **LAN** tab lists games announced
  on your network (UDP multicast 224.0.2.60:4445) and joins them with the
  selected instance. Manual `host:port` join is there too.
- The **Servers** tab creates local servers (Vanilla, Paper, Purpur, Folia,
  Spigot via BuildTools, Fabric, Forge, NeoForge). It has Start/Stop, a live
  console, a `server.properties` form and a RAM setting. You accept the EULA
  yourself with a checkbox.
- Local servers default to `online-mode=false` so offline profiles can join.
  **That means anyone can join with any name: only use it for LAN or private
  play** (and a whitelist if the port is reachable from the internet).
- Quick-join: pick a saved server or LAN game on the Play screen. mclaunch
  uses `--quickPlayMultiplayer` on 1.20+ and `--server/--port` on older
  versions.

## Keyboard

- **Enter**: play the selected instance (Play screen)
- **Ctrl+F**: search versions

## Building

Requires Rust 1.87+ (stable).

```bash
cargo build --release -p mclaunch
```

The binary is `target/release/mclaunch(.exe)`, fully self-contained (the
fonts and icon are embedded). On Windows the release build is a GUI app
with no console window. Linux needs the usual X11/Wayland and OpenGL
libraries at runtime.

`scripts/package.sh` builds release binaries into `dist/`. On Linux/macOS it
also cross-compiles `dist/mclaunch.exe` for Windows when
[`zig`](https://ziglang.org/download/) and `cargo-zigbuild` are installed.

### GitHub Actions

`.github/workflows/build.yml` builds macOS (Intel), Windows and Linux on
every push; the files are under the run's
**Artifacts**. Pushing a tag (`git tag v1.0.0 && git push --tags`) also
publishes them as a GitHub release.

The macOS builds are not signed. On first start macOS will block them:
right-click → **Open**, or run `xattr -d com.apple.quarantine mclaunch`.

### Tests

```bash
cargo clippy --all-targets -- -D warnings
cargo test
```

Integration tests that need the network and Java are `#[ignore]`d. Run them
with a scratch launcher root that has Java archives in `java/`:

```bash
MCLAUNCH_IT_ROOT=/path/to/root cargo test -p mclaunch-launch --test launch_matrix -- --ignored --test-threads=1
MCLAUNCH_IT_ROOT=/path/to/root cargo test -p mclaunch-launch --test loader_matrix -- --ignored --test-threads=1
MCLAUNCH_IT_ROOT=/path/to/root cargo test -p mclaunch-server --test server_it -- --ignored --test-threads=1
cargo test -p mclaunch-loaders --test shaders_it -- --ignored
MCLAUNCH_IT_ROOT=/path/to/root cargo test -p mclaunch-loaders --test modpack_it -- --ignored --test-threads=1
cargo test -p mclaunch-loaders --test mods_it -- --ignored --test-threads=1
cargo test -p mclaunch-download -- --ignored
```

- The launch matrix covers rd-132211, a1.2.6, b1.7.3, 1.5.2, 1.8.9, 1.12.2,
  1.16.5, 1.20.1, the latest release and the latest snapshot.
- The loader matrix covers Fabric, Quilt, Forge (1.20.1, 1.12.2, legacy
  1.7.10) and NeoForge.
- Add `MCLAUNCH_IT_LAUNCH=1` to actually start each game (a window opens for
  about 20 seconds).

### Environment variables

| Variable | Effect |
|---|---|
| `MCLAUNCH_HOME` | Use this folder instead of the executable's folder |
| `MCLAUNCH_LOG` | Log filter, e.g. `debug` or `mclaunch_launch=trace` |
| `MCLAUNCH_SCREEN` | Start on a tab (`play`, `mods`, `modpacks`, `versions`, `servers`, …) |
| `MCLAUNCH_SCREENSHOT` | Save a PNG of the window after a few seconds, then exit |
| `MCLAUNCH_AUTOPLAY` | Launch the selected instance at startup (testing) |

## Architecture

```
crates/
  core/      paths, config, manifest + version JSON models, rules, args, instances
  safety/    SafePath guard
  download/  HTTP, parallel downloader, SHA-1/SHA-256 integrity, install/verify/repair
  java/      java/ archive scan, extraction, detection, version mapping
  launch/    classpath, natives, legacy fixes, process spawn, log parsing
  loaders/   Fabric/Quilt/Forge/NeoForge/OptiFine, Modrinth, modpacks, server sources, shaders
  lan/       LAN discovery
  server/    local servers
  app/       egui front-end (binary: mclaunch)
```

Long tasks run on tokio. The UI receives progress and results over a
`tokio::sync::mpsc` channel and never blocks.

## Notes and limitations

- Old LWJGL 2 versions on Linux need the `xrandr` program. mclaunch provides
  a small stand-in if it's missing.
- The OptiFine patch step uses OptiFine's own `optifine.Patcher` and falls
  back to the plain jar. It has not been tested against every OptiFine
  release.
- Spigot's BuildTools needs `git` on Linux/macOS (it downloads a portable
  git on Windows).
- Local skins (`skins/`) are not implemented yet.
- The UI is English only for now.
- The header font is *Press Start 2P* (SIL Open Font License 1.1, see
  `crates/app/assets/fonts/OFL.txt`).
