//! Offline profiles: no sign-in, just a username.

use md5::{Digest, Md5};

/// Validate an offline username: 3–16 characters of `[A-Za-z0-9_]`.
pub fn validate_username(name: &str) -> Result<(), String> {
    let len = name.chars().count();
    if !(3..=16).contains(&len) {
        return Err("Username must be 3–16 characters long".into());
    }
    if !name.chars().all(|c| c.is_ascii_alphanumeric() || c == '_') {
        return Err("Only letters, digits and _ are allowed".into());
    }
    Ok(())
}

/// The UUID vanilla servers assign to offline players:
/// `UUID.nameUUIDFromBytes(("OfflinePlayer:" + name).getBytes(UTF_8))`,
/// i.e. an MD5-based version 3 UUID.
pub fn offline_uuid(name: &str) -> String {
    let mut bytes: [u8; 16] = Md5::digest(format!("OfflinePlayer:{name}").as_bytes()).into();
    bytes[6] = (bytes[6] & 0x0f) | 0x30; // version 3
    bytes[8] = (bytes[8] & 0x3f) | 0x80; // IETF variant
    let hex: String = bytes.iter().map(|b| format!("{b:02x}")).collect();
    format!(
        "{}-{}-{}-{}-{}",
        &hex[0..8],
        &hex[8..12],
        &hex[12..16],
        &hex[16..20],
        &hex[20..32]
    )
}

/// `user_type` for offline play: very old builds expect `mojang`.
pub fn user_type_for(kind: Option<&crate::VersionType>) -> &'static str {
    match kind {
        Some(k) if k.is_legacy() => "mojang",
        _ => "legacy",
    }
}

/// Access token passed to the game in offline mode.
pub const OFFLINE_ACCESS_TOKEN: &str = "0";

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn known_offline_uuids() {
        // Values produced by Java's UUID.nameUUIDFromBytes.
        assert_eq!(
            offline_uuid("Notch"),
            "b50ad385-829d-3141-a216-7e7d7539ba7f"
        );
        assert_eq!(
            offline_uuid("Steve"),
            "5627dd98-e6be-3c21-b8a8-e92344183641"
        );
    }

    #[test]
    fn username_rules() {
        assert!(validate_username("Venkat").is_ok());
        assert!(validate_username("a_b_9").is_ok());
        assert!(validate_username("ab").is_err());
        assert!(validate_username("abcdefghijklmnopq").is_err());
        assert!(validate_username("bad name").is_err());
        assert!(validate_username("émile").is_err());
    }
}
