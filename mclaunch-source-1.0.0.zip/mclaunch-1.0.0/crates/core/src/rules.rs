//! Rule evaluation for libraries and arguments.
//!
//! A list of rules starts as "disallowed"; every rule that matches the current
//! environment sets the outcome to its action. An empty or missing list means
//! "allowed". Anything we do not understand (unknown OS names, unknown
//! features, malformed regexes) does not match, and is logged, so unknown
//! future rules default to the safe outcome.

use std::collections::BTreeMap;

use serde::{Deserialize, Serialize};

use crate::platform;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum RuleAction {
    Allow,
    Disallow,
}

#[derive(Debug, Clone, Default, PartialEq, Eq, Serialize, Deserialize)]
pub struct OsRule {
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub name: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub version: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub arch: Option<String>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct Rule {
    pub action: RuleAction,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub os: Option<OsRule>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub features: Option<BTreeMap<String, bool>>,
}

/// The environment rules are evaluated against.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct RuleContext {
    pub os_name: String,
    pub os_arch: String,
    pub os_version: String,
    pub features: BTreeMap<String, bool>,
}

impl RuleContext {
    /// The machine we are running on, with no features enabled.
    pub fn current() -> Self {
        Self {
            os_name: platform::os_name().to_string(),
            os_arch: platform::os_arch().to_string(),
            os_version: platform::os_version().to_string(),
            features: BTreeMap::new(),
        }
    }

    pub fn for_os(os_name: &str, os_arch: &str) -> Self {
        Self {
            os_name: os_name.to_string(),
            os_arch: os_arch.to_string(),
            os_version: String::new(),
            features: BTreeMap::new(),
        }
    }

    pub fn with_feature(mut self, name: &str, enabled: bool) -> Self {
        self.features.insert(name.to_string(), enabled);
        self
    }

    pub fn feature(&self, name: &str) -> bool {
        self.features.get(name).copied().unwrap_or(false)
    }
}

const KNOWN_OS: &[&str] = &["windows", "osx", "linux"];
const KNOWN_FEATURES: &[&str] = &[
    "is_demo_user",
    "has_custom_resolution",
    "has_quick_plays_support",
    "is_quick_play_singleplayer",
    "is_quick_play_multiplayer",
    "is_quick_play_realms",
];

fn arch_matches(rule_arch: &str, ours: &str) -> bool {
    let norm = |a: &str| -> String {
        match a.to_ascii_lowercase().as_str() {
            "amd64" | "x64" | "x86_64" => "x86_64".into(),
            "x86" | "i386" | "i686" => "x86".into(),
            "arm64" | "aarch64" => "arm64".into(),
            "arm" | "arm32" => "arm32".into(),
            other => other.into(),
        }
    };
    norm(rule_arch) == norm(ours)
}

impl Rule {
    /// Does this rule's condition hold in `ctx`?
    pub fn matches(&self, ctx: &RuleContext) -> bool {
        if let Some(os) = &self.os {
            if let Some(name) = &os.name {
                if !KNOWN_OS.contains(&name.as_str()) {
                    tracing::debug!(os = %name, "unknown OS name in rule; treating as non-matching");
                }
                if name != &ctx.os_name {
                    return false;
                }
            }
            if let Some(arch) = &os.arch {
                if !arch_matches(arch, &ctx.os_arch) {
                    return false;
                }
            }
            if let Some(version) = &os.version {
                match regex::Regex::new(version) {
                    Ok(re) => {
                        if !re.is_match(&ctx.os_version) {
                            return false;
                        }
                    }
                    Err(e) => {
                        tracing::warn!(regex = %version, error = %e, "bad os.version regex in rule");
                        return false;
                    }
                }
            }
        }
        if let Some(features) = &self.features {
            for (name, wanted) in features {
                if !KNOWN_FEATURES.contains(&name.as_str()) {
                    tracing::debug!(feature = %name, "unknown feature in rule; assuming disabled");
                }
                if ctx.feature(name) != *wanted {
                    return false;
                }
            }
        }
        true
    }
}

/// Evaluate a rule list. `None`/empty means allowed.
pub fn rules_allow(rules: Option<&[Rule]>, ctx: &RuleContext) -> bool {
    let Some(rules) = rules else { return true };
    if rules.is_empty() {
        return true;
    }
    let mut allowed = false;
    for rule in rules {
        if rule.matches(ctx) {
            allowed = rule.action == RuleAction::Allow;
        }
    }
    allowed
}

/// Feature names referenced anywhere in a rule list.
pub fn referenced_features(rules: &[Rule]) -> impl Iterator<Item = &str> {
    rules
        .iter()
        .filter_map(|r| r.features.as_ref())
        .flat_map(|f| f.keys().map(String::as_str))
}

#[cfg(test)]
mod tests {
    use super::*;

    fn rules(json: &str) -> Vec<Rule> {
        serde_json::from_str(json).unwrap()
    }

    #[test]
    fn empty_allows() {
        let ctx = RuleContext::for_os("linux", "x86_64");
        assert!(rules_allow(None, &ctx));
        assert!(rules_allow(Some(&[]), &ctx));
    }

    #[test]
    fn os_allow_list() {
        let r = rules(r#"[{"action":"allow","os":{"name":"osx"}}]"#);
        assert!(rules_allow(Some(&r), &RuleContext::for_os("osx", "x86_64")));
        assert!(!rules_allow(
            Some(&r),
            &RuleContext::for_os("linux", "x86_64")
        ));
    }

    #[test]
    fn allow_then_disallow() {
        // lwjgl 2.9.x on everything but osx
        let r = rules(r#"[{"action":"allow"},{"action":"disallow","os":{"name":"osx"}}]"#);
        assert!(rules_allow(
            Some(&r),
            &RuleContext::for_os("windows", "x86_64")
        ));
        assert!(!rules_allow(
            Some(&r),
            &RuleContext::for_os("osx", "x86_64")
        ));
    }

    #[test]
    fn os_version_regex() {
        let r = rules(
            r#"[{"action":"allow"},{"action":"disallow","os":{"name":"osx","version":"^10\\.5\\.\\d$"}}]"#,
        );
        let mut ctx = RuleContext::for_os("osx", "x86_64");
        ctx.os_version = "10.5.8".into();
        assert!(!rules_allow(Some(&r), &ctx));
        ctx.os_version = "14.2".into();
        assert!(rules_allow(Some(&r), &ctx));
    }

    #[test]
    fn arch_rule_is_32_bit_only() {
        let r = rules(r#"[{"action":"allow","os":{"arch":"x86"}}]"#);
        assert!(!rules_allow(
            Some(&r),
            &RuleContext::for_os("windows", "x86_64")
        ));
        assert!(rules_allow(
            Some(&r),
            &RuleContext::for_os("windows", "x86")
        ));
    }

    #[test]
    fn features() {
        let r = rules(r#"[{"action":"allow","features":{"has_custom_resolution":true}}]"#);
        let ctx = RuleContext::for_os("linux", "x86_64");
        assert!(!rules_allow(Some(&r), &ctx));
        assert!(rules_allow(
            Some(&r),
            &ctx.clone().with_feature("has_custom_resolution", true)
        ));
    }

    #[test]
    fn unknown_things_default_safely() {
        let ctx = RuleContext::for_os("linux", "x86_64").with_feature("is_demo_user", false);
        let r = rules(r#"[{"action":"allow","os":{"name":"haiku"}}]"#);
        assert!(!rules_allow(Some(&r), &ctx));
        let r = rules(r#"[{"action":"allow","features":{"is_future_feature":true}}]"#);
        assert!(!rules_allow(Some(&r), &ctx));
        let r = rules(r#"[{"action":"allow","os":{"name":"linux","version":"("}}]"#);
        assert!(!rules_allow(Some(&r), &ctx));
    }
}
