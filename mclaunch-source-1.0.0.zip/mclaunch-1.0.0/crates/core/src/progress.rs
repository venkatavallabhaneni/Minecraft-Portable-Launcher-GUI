//! Progress reporting from long-running tasks to the UI.

use std::sync::Arc;

#[derive(Debug, Clone, Default, PartialEq)]
pub struct Progress {
    /// Human readable stage ("Downloading assets").
    pub stage: String,
    pub done: u64,
    pub total: u64,
    pub bytes_done: u64,
    pub bytes_total: u64,
}

impl Progress {
    pub fn stage(stage: impl Into<String>) -> Self {
        Self {
            stage: stage.into(),
            ..Default::default()
        }
    }

    /// 0.0–1.0, preferring bytes when known.
    pub fn fraction(&self) -> f32 {
        if self.bytes_total > 0 {
            (self.bytes_done as f64 / self.bytes_total as f64).clamp(0.0, 1.0) as f32
        } else if self.total > 0 {
            (self.done as f64 / self.total as f64).clamp(0.0, 1.0) as f32
        } else {
            0.0
        }
    }
}

/// Callback receiving progress updates. The app wraps a
/// `tokio::sync::mpsc` sender in one of these.
pub type ProgressFn = Arc<dyn Fn(Progress) + Send + Sync>;

pub fn noop_progress() -> ProgressFn {
    Arc::new(|_| {})
}
