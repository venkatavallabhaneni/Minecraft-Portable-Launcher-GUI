//! Core models and pure logic for mclaunch: paths, config, Mojang's version
//! manifest and version JSON format, rule evaluation, argument building,
//! offline profiles and instances. No network access happens here.

pub mod args;
pub mod assets;
pub mod config;
pub mod instance;
pub mod javareq;
pub mod manifest;
pub mod maven;
pub mod offline;
pub mod paths;
pub mod platform;
pub mod progress;
pub mod rules;
pub mod version;

pub use config::Config;
pub use instance::{InstanceConfig, LoaderKind};
pub use manifest::{ManifestEntry, VersionManifest, VersionType};
pub use paths::LauncherPaths;
pub use progress::{Progress, ProgressFn};
pub use rules::RuleContext;
pub use version::{Library, VersionJson};

/// Launcher name passed to the game as `${launcher_name}`.
pub const LAUNCHER_NAME: &str = "mclaunch";
/// Launcher version passed to the game as `${launcher_version}`.
pub const LAUNCHER_VERSION: &str = env!("CARGO_PKG_VERSION");
/// User agent for every HTTP request we make.
pub const USER_AGENT: &str = concat!(
    "mclaunch/",
    env!("CARGO_PKG_VERSION"),
    " (offline launcher)"
);

#[derive(Debug, thiserror::Error)]
pub enum CoreError {
    #[error("I/O error on {path}: {source}")]
    Io {
        path: std::path::PathBuf,
        #[source]
        source: std::io::Error,
    },
    #[error("invalid JSON in {path}: {source}")]
    Json {
        path: std::path::PathBuf,
        #[source]
        source: serde_json::Error,
    },
    #[error("invalid config {path}: {message}")]
    Toml {
        path: std::path::PathBuf,
        message: String,
    },
    #[error(transparent)]
    Safety(#[from] mclaunch_safety::SafetyError),
    #[error("{0}")]
    Invalid(String),
}

pub type Result<T> = std::result::Result<T, CoreError>;

pub(crate) fn io_err(path: &std::path::Path) -> impl FnOnce(std::io::Error) -> CoreError + '_ {
    move |source| CoreError::Io {
        path: path.to_path_buf(),
        source,
    }
}

/// Read and parse a JSON file.
pub fn read_json<T: serde::de::DeserializeOwned>(path: &std::path::Path) -> Result<T> {
    let bytes = std::fs::read(path).map_err(io_err(path))?;
    serde_json::from_slice(&bytes).map_err(|source| CoreError::Json {
        path: path.to_path_buf(),
        source,
    })
}

/// Format a byte count for humans ("12.4 MB").
pub fn human_bytes(bytes: u64) -> String {
    const UNITS: [&str; 5] = ["B", "KB", "MB", "GB", "TB"];
    let mut value = bytes as f64;
    let mut unit = 0;
    while value >= 1024.0 && unit < UNITS.len() - 1 {
        value /= 1024.0;
        unit += 1;
    }
    if unit == 0 {
        format!("{bytes} B")
    } else {
        format!("{value:.1} {}", UNITS[unit])
    }
}

#[cfg(test)]
mod tests {
    #[test]
    fn human_bytes() {
        assert_eq!(super::human_bytes(512), "512 B");
        assert_eq!(super::human_bytes(1536), "1.5 KB");
        assert_eq!(super::human_bytes(13_002_342), "12.4 MB");
    }
}
