//! Builds the JVM and game argument lists for both argument formats:
//! the legacy `minecraftArguments` string (≤1.12.2) and the modern
//! `arguments.game` / `arguments.jvm` lists with rules (1.13+).

use std::collections::BTreeMap;

use crate::platform;
use crate::rules::{rules_allow, RuleContext};
use crate::version::{Argument, VersionJson};

/// Values substituted for `${name}` placeholders.
pub type Vars = BTreeMap<String, String>;

/// Where to quick-join after the game starts.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct QuickJoin {
    pub host: String,
    pub port: u16,
}

impl QuickJoin {
    /// Parse `host`, `host:port` or `[v6]:port`.
    pub fn parse(address: &str) -> Option<Self> {
        let address = address.trim();
        if address.is_empty() {
            return None;
        }
        if let Some(rest) = address.strip_prefix('[') {
            let (host, tail) = rest.split_once(']')?;
            let port = match tail.strip_prefix(':') {
                Some(p) => p.parse().ok()?,
                None => 25565,
            };
            return Some(Self {
                host: host.to_string(),
                port,
            });
        }
        match address.rsplit_once(':') {
            Some((host, port)) if !host.contains(':') => Some(Self {
                host: host.to_string(),
                port: port.parse().ok()?,
            }),
            _ => Some(Self {
                host: address.to_string(),
                port: 25565,
            }),
        }
    }

    pub fn address(&self) -> String {
        if self.host.contains(':') {
            format!("[{}]:{}", self.host, self.port)
        } else {
            format!("{}:{}", self.host, self.port)
        }
    }
}

#[derive(Debug, Clone, Default)]
pub struct ArgOptions {
    pub resolution: Option<(u32, u32)>,
    pub quick_join: Option<QuickJoin>,
    /// Extra JVM arguments (memory, user flags), appended after the
    /// version's own so they win.
    pub extra_jvm: Vec<String>,
    /// Extra game arguments, appended last.
    pub extra_game: Vec<String>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct BuiltArgs {
    pub jvm: Vec<String>,
    pub main_class: String,
    pub game: Vec<String>,
}

impl BuiltArgs {
    /// Everything after the java executable.
    pub fn command_line(&self) -> Vec<String> {
        let mut v = self.jvm.clone();
        v.push(self.main_class.clone());
        v.extend(self.game.iter().cloned());
        v
    }
}

/// Replace every `${name}` in `s` using `vars`. Unknown placeholders are left
/// verbatim (as the official launcher does) and logged.
pub fn substitute(s: &str, vars: &Vars) -> String {
    let mut out = String::with_capacity(s.len());
    let mut rest = s;
    while let Some(start) = rest.find("${") {
        out.push_str(&rest[..start]);
        let after = &rest[start + 2..];
        match after.find('}') {
            Some(end) => {
                let key = &after[..end];
                match vars.get(key) {
                    Some(v) => out.push_str(v),
                    None => {
                        tracing::warn!(placeholder = key, "unknown launch placeholder");
                        out.push_str(&rest[start..start + 2 + end + 1]);
                    }
                }
                rest = &after[end + 1..];
            }
            None => {
                out.push_str(&rest[start..]);
                rest = "";
            }
        }
    }
    out.push_str(rest);
    out
}

fn expand(list: &[Argument], ctx: &RuleContext, vars: &Vars, out: &mut Vec<String>) {
    for arg in list {
        match arg {
            Argument::Plain(s) => out.push(substitute(s, vars)),
            Argument::Conditional { rules, value } => {
                if rules_allow(Some(rules), ctx) {
                    out.extend(value.values().into_iter().map(|v| substitute(v, vars)));
                }
            }
        }
    }
}

/// JVM arguments the official launcher adds for versions without
/// `arguments.jvm`.
fn legacy_jvm_args(ctx: &RuleContext) -> Vec<String> {
    let mut v = Vec::new();
    match ctx.os_name.as_str() {
        "osx" => v.push("-XstartOnFirstThread".to_string()),
        "windows" => v.push(
            "-XX:HeapDumpPath=MojangTricksIntelDriversForPerformance_javaw.exe_minecraft.exe.heapdump"
                .to_string(),
        ),
        _ => {}
    }
    if ctx.os_arch == "x86" {
        v.push("-Xss1M".to_string());
    }
    v.extend(
        [
            "-Djava.library.path=${natives_directory}",
            "-Dminecraft.launcher.brand=${launcher_name}",
            "-Dminecraft.launcher.version=${launcher_version}",
            "-cp",
            "${classpath}",
        ]
        .map(String::from),
    );
    v
}

/// Build the full argument lists. `vars` must contain the standard
/// placeholders (see [`standard_vars`]).
pub fn build_args(version: &VersionJson, vars: &Vars, opts: &ArgOptions) -> BuiltArgs {
    let supports_quick_play = version.uses_feature("is_quick_play_multiplayer");
    let mut ctx = RuleContext::current()
        .with_feature("is_demo_user", false)
        .with_feature("has_custom_resolution", opts.resolution.is_some());
    if opts.quick_join.is_some() && supports_quick_play {
        ctx = ctx.with_feature("is_quick_play_multiplayer", true);
    }
    build_args_with_ctx(version, vars, opts, &ctx)
}

/// [`build_args`] with an explicit rule context (used by tests).
pub fn build_args_with_ctx(
    version: &VersionJson,
    vars: &Vars,
    opts: &ArgOptions,
    ctx: &RuleContext,
) -> BuiltArgs {
    let mut vars = vars.clone();
    if let Some((w, h)) = opts.resolution {
        vars.insert("resolution_width".into(), w.to_string());
        vars.insert("resolution_height".into(), h.to_string());
    }
    if let Some(q) = &opts.quick_join {
        vars.insert("quickPlayMultiplayer".into(), q.address());
    }

    // ---- JVM ----
    let mut jvm = Vec::new();
    let modern_jvm = version
        .arguments
        .as_ref()
        .map(|a| {
            a.jvm.iter().any(|arg| match arg {
                Argument::Plain(s) => s.contains("${classpath}"),
                Argument::Conditional { value, .. } => {
                    value.values().iter().any(|s| s.contains("${classpath}"))
                }
            })
        })
        .unwrap_or(false);
    if !modern_jvm {
        for a in legacy_jvm_args(ctx) {
            jvm.push(substitute(&a, &vars));
        }
    }
    if let Some(args) = &version.arguments {
        expand(&args.jvm, ctx, &vars, &mut jvm);
    }
    for a in &opts.extra_jvm {
        jvm.push(substitute(a, &vars));
    }

    // ---- game ----
    let mut game = Vec::new();
    if let Some(legacy) = &version.minecraft_arguments {
        for token in legacy.split_whitespace() {
            game.push(substitute(token, &vars));
        }
        if let Some((w, h)) = opts.resolution {
            // Only the 1.6+ argument parser understands these.
            if legacy.contains("--gameDir") && legacy.contains("--username") {
                game.extend([
                    "--width".into(),
                    w.to_string(),
                    "--height".into(),
                    h.to_string(),
                ]);
            }
        }
    }
    if let Some(args) = &version.arguments {
        expand(&args.game, ctx, &vars, &mut game);
    }
    if let Some(q) = &opts.quick_join {
        if !ctx.feature("is_quick_play_multiplayer") {
            game.extend([
                "--server".into(),
                q.host.clone(),
                "--port".into(),
                q.port.to_string(),
            ]);
        }
    }
    game.extend(opts.extra_game.iter().cloned());

    BuiltArgs {
        jvm,
        main_class: version
            .main_class
            .clone()
            .unwrap_or_else(|| "net.minecraft.client.main.Main".to_string()),
        game,
    }
}

/// Inputs for the standard placeholder set.
#[derive(Debug, Clone)]
pub struct VarInputs<'a> {
    pub username: &'a str,
    /// UUID with dashes.
    pub uuid: &'a str,
    pub access_token: &'a str,
    pub user_type: &'a str,
    pub version_name: &'a str,
    pub version_type: &'a str,
    pub game_dir: &'a str,
    pub assets_root: &'a str,
    pub assets_index_name: &'a str,
    pub game_assets: &'a str,
    pub natives_dir: &'a str,
    pub library_dir: &'a str,
    pub classpath: &'a str,
}

/// The placeholder values every version expects.
pub fn standard_vars(i: &VarInputs<'_>) -> Vars {
    let mut v = Vars::new();
    let mut put = |k: &str, val: &str| {
        v.insert(k.to_string(), val.to_string());
    };
    put("auth_player_name", i.username);
    put("auth_uuid", &i.uuid.replace('-', ""));
    put("auth_access_token", i.access_token);
    // Pre-1.6 versions take a session id; "-" means offline.
    put("auth_session", "-");
    put("auth_xuid", "0");
    put("clientid", "0");
    put("user_type", i.user_type);
    put("user_properties", "{}");
    put("profile_name", i.username);
    put("version_name", i.version_name);
    put("version_type", i.version_type);
    put("game_directory", i.game_dir);
    put("assets_root", i.assets_root);
    put("assets_index_name", i.assets_index_name);
    put("game_assets", i.game_assets);
    put("natives_directory", i.natives_dir);
    put("library_directory", i.library_dir);
    put("classpath", i.classpath);
    put("classpath_separator", platform::classpath_separator());
    put("launcher_name", crate::LAUNCHER_NAME);
    put("launcher_version", crate::LAUNCHER_VERSION);
    v
}

/// Split a user-entered argument string, honouring double quotes.
pub fn split_user_args(s: &str) -> Vec<String> {
    let mut out = Vec::new();
    let mut cur = String::new();
    let mut in_quotes = false;
    let mut has_token = false;
    for ch in s.chars() {
        match ch {
            '"' => {
                in_quotes = !in_quotes;
                has_token = true;
            }
            c if c.is_whitespace() && !in_quotes => {
                if has_token {
                    out.push(std::mem::take(&mut cur));
                    has_token = false;
                }
            }
            c => {
                cur.push(c);
                has_token = true;
            }
        }
    }
    if has_token {
        out.push(cur);
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    fn vars() -> Vars {
        standard_vars(&VarInputs {
            username: "Steve",
            uuid: "b50ad385-829d-3141-a216-7e7d7539ba7f",
            access_token: "0",
            user_type: "legacy",
            version_name: "1.20.1",
            version_type: "release",
            game_dir: "/g",
            assets_root: "/a",
            assets_index_name: "5",
            game_assets: "/a",
            natives_dir: "/n",
            library_dir: "/l",
            classpath: "/l/a.jar:/v/1.20.1.jar",
        })
    }

    #[test]
    fn substitution() {
        let v = vars();
        assert_eq!(
            substitute("-Dx=${natives_directory}/java", &v),
            "-Dx=/n/java"
        );
        assert_eq!(substitute("${unknown_thing}", &v), "${unknown_thing}");
        assert_eq!(substitute("a ${broken", &v), "a ${broken");
        assert_eq!(
            substitute("${auth_uuid}", &v),
            "b50ad385829d3141a2167e7d7539ba7f"
        );
    }

    #[test]
    fn legacy_format() {
        let version: VersionJson = serde_json::from_str(
            r#"{"id": "1.8.9", "mainClass": "net.minecraft.client.main.Main",
                "minecraftArguments": "--username ${auth_player_name} --version ${version_name} --gameDir ${game_directory} --assetsDir ${assets_root} --assetIndex ${assets_index_name} --uuid ${auth_uuid} --accessToken ${auth_access_token} --userProperties ${user_properties} --userType ${user_type}"}"#,
        )
        .unwrap();
        let ctx = RuleContext::for_os("linux", "x86_64");
        let opts = ArgOptions {
            resolution: Some((854, 480)),
            quick_join: QuickJoin::parse("192.168.1.5:25566"),
            extra_jvm: vec!["-Xmx2G".into()],
            extra_game: vec![],
        };
        let b = build_args_with_ctx(&version, &vars(), &opts, &ctx);
        assert_eq!(b.main_class, "net.minecraft.client.main.Main");
        assert!(b.jvm.contains(&"-Djava.library.path=/n".to_string()));
        let cp = b.jvm.iter().position(|a| a == "-cp").unwrap();
        assert_eq!(b.jvm[cp + 1], "/l/a.jar:/v/1.20.1.jar");
        assert_eq!(b.jvm.last().unwrap(), "-Xmx2G");
        assert_eq!(&b.game[..2], &["--username", "Steve"]);
        assert!(b.game.windows(2).any(|w| w == ["--userProperties", "{}"]));
        assert!(b.game.windows(2).any(|w| w == ["--width", "854"]));
        assert!(b.game.windows(2).any(|w| w == ["--server", "192.168.1.5"]));
        assert!(b.game.windows(2).any(|w| w == ["--port", "25566"]));
    }

    #[test]
    fn pre_1_6_gets_no_resolution_flags() {
        let version: VersionJson = serde_json::from_str(
            r#"{"id": "b1.7.3", "mainClass": "net.minecraft.launchwrapper.Launch",
                "minecraftArguments": "${auth_player_name} ${auth_session} --gameDir ${game_directory} --assetsDir ${game_assets}"}"#,
        )
        .unwrap();
        let ctx = RuleContext::for_os("windows", "x86_64");
        let opts = ArgOptions {
            resolution: Some((854, 480)),
            ..Default::default()
        };
        let b = build_args_with_ctx(&version, &vars(), &opts, &ctx);
        assert_eq!(
            b.game,
            vec!["Steve", "-", "--gameDir", "/g", "--assetsDir", "/a"]
        );
        assert!(b.jvm[0].starts_with("-XX:HeapDumpPath="));
    }

    #[test]
    fn modern_format_with_rules_and_quick_play() {
        let version: VersionJson = serde_json::from_str(
            r#"{"id": "1.20.1", "mainClass": "net.minecraft.client.main.Main",
              "arguments": {
                "game": ["--username", "${auth_player_name}", "--version", "${version_name}",
                  {"rules": [{"action": "allow", "features": {"is_demo_user": true}}], "value": "--demo"},
                  {"rules": [{"action": "allow", "features": {"has_custom_resolution": true}}], "value": ["--width", "${resolution_width}", "--height", "${resolution_height}"]},
                  {"rules": [{"action": "allow", "features": {"is_quick_play_multiplayer": true}}], "value": ["--quickPlayMultiplayer", "${quickPlayMultiplayer}"]}],
                "jvm": [
                  {"rules": [{"action": "allow", "os": {"name": "osx"}}], "value": ["-XstartOnFirstThread"]},
                  {"rules": [{"action": "allow", "os": {"arch": "x86"}}], "value": "-Xss1M"},
                  "-Djava.library.path=${natives_directory}", "-cp", "${classpath}"]
              }}"#,
        )
        .unwrap();
        let ctx = RuleContext::for_os("osx", "arm64")
            .with_feature("has_custom_resolution", true)
            .with_feature("is_quick_play_multiplayer", true);
        let opts = ArgOptions {
            resolution: Some((1280, 720)),
            quick_join: QuickJoin::parse("localhost"),
            ..Default::default()
        };
        let b = build_args_with_ctx(&version, &vars(), &opts, &ctx);
        assert_eq!(
            b.jvm,
            vec![
                "-XstartOnFirstThread",
                "-Djava.library.path=/n",
                "-cp",
                "/l/a.jar:/v/1.20.1.jar"
            ]
        );
        assert_eq!(
            b.game,
            vec![
                "--username",
                "Steve",
                "--version",
                "1.20.1",
                "--width",
                "1280",
                "--height",
                "720",
                "--quickPlayMultiplayer",
                "localhost:25565"
            ]
        );
        assert!(version.uses_feature("is_quick_play_multiplayer"));
    }

    #[test]
    fn loader_with_legacy_parent_gets_default_jvm_args() {
        // Fabric on 1.12.2: parent has minecraftArguments, child adds jvm args.
        let version: VersionJson = serde_json::from_str(
            r#"{"id": "fabric-1.12.2", "mainClass": "net.fabricmc.loader.impl.launch.knot.KnotClient",
                "minecraftArguments": "--username ${auth_player_name}",
                "arguments": {"game": [], "jvm": ["-DFabricMcEmu= net.minecraft.client.main.Main "]}}"#,
        )
        .unwrap();
        let ctx = RuleContext::for_os("linux", "x86_64");
        let b = build_args_with_ctx(&version, &vars(), &ArgOptions::default(), &ctx);
        assert!(b.jvm.contains(&"-cp".to_string()));
        assert!(b
            .jvm
            .contains(&"-DFabricMcEmu= net.minecraft.client.main.Main ".to_string()));
        assert_eq!(b.game, vec!["--username", "Steve"]);
    }

    #[test]
    fn quick_join_parse() {
        assert_eq!(
            QuickJoin::parse("example.org"),
            Some(QuickJoin {
                host: "example.org".into(),
                port: 25565
            })
        );
        assert_eq!(QuickJoin::parse("10.0.0.2:25570").unwrap().port, 25570);
        assert_eq!(
            QuickJoin::parse("[::1]:25570").unwrap().address(),
            "[::1]:25570"
        );
        assert_eq!(QuickJoin::parse("::1").unwrap().host, "::1");
        assert!(QuickJoin::parse("host:notaport").is_none());
        assert!(QuickJoin::parse("  ").is_none());
    }

    #[test]
    fn user_args() {
        assert_eq!(
            split_user_args(r#"-Xmx4G  -Dfoo="a b" -XX:+UseG1GC"#),
            vec!["-Xmx4G", "-Dfoo=a b", "-XX:+UseG1GC"]
        );
        assert!(split_user_args("   ").is_empty());
    }
}
