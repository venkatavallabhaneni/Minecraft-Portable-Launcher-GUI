//! The version JSON format (`versions/<id>/<id>.json`) used by Mojang and by
//! every mod loader profile, including `inheritsFrom` layering.

use std::collections::{BTreeMap, HashSet};
use std::path::Path;

use serde::{Deserialize, Serialize};

use crate::manifest::VersionType;
use crate::maven::MavenCoord;
use crate::paths::LauncherPaths;
use crate::platform;
use crate::rules::{self, Rule, RuleContext};
use crate::{CoreError, Result};

/// Default repository for libraries without an explicit URL.
pub const LIBRARIES_URL: &str = "https://libraries.minecraft.net/";

#[derive(Debug, Clone, Default, PartialEq, Eq, Serialize, Deserialize)]
pub struct Artifact {
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub path: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub sha1: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub size: Option<u64>,
    #[serde(default)]
    pub url: String,
}

#[derive(Debug, Clone, Default, PartialEq, Eq, Serialize, Deserialize)]
pub struct LibraryDownloads {
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub artifact: Option<Artifact>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub classifiers: Option<BTreeMap<String, Artifact>>,
}

#[derive(Debug, Clone, Default, PartialEq, Eq, Serialize, Deserialize)]
pub struct ExtractRules {
    #[serde(default)]
    pub exclude: Vec<String>,
}

#[derive(Debug, Clone, Default, PartialEq, Eq, Serialize, Deserialize)]
pub struct Library {
    pub name: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub downloads: Option<LibraryDownloads>,
    /// Maven repository base (Fabric, Quilt, legacy Forge profiles).
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub url: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub rules: Option<Vec<Rule>>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub natives: Option<BTreeMap<String, String>>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub extract: Option<ExtractRules>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub sha1: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub size: Option<u64>,
    /// Legacy Forge: list of acceptable SHA-1s.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub checksums: Option<Vec<String>>,
}

/// A single file to fetch into `libraries/`.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct LibraryFile {
    /// Path relative to `libraries/` with `/` separators.
    pub path: String,
    /// Empty when the file is produced locally (e.g. by a Forge installer).
    pub url: String,
    pub sha1: Option<String>,
    pub size: Option<u64>,
}

impl Library {
    pub fn coord(&self) -> Option<MavenCoord> {
        self.name.parse().ok()
    }

    pub fn is_allowed(&self, ctx: &RuleContext) -> bool {
        rules::rules_allow(self.rules.as_deref(), ctx)
    }

    /// Is this an old-style natives library (`natives` map + classifiers)?
    pub fn has_native_classifiers(&self) -> bool {
        self.natives.is_some()
    }

    /// The main (classpath) artifact, if this library has one.
    pub fn artifact(&self) -> Option<LibraryFile> {
        if let Some(downloads) = &self.downloads {
            let a = downloads.artifact.as_ref()?;
            let path = match &a.path {
                Some(p) => p.clone(),
                None => self.coord()?.path(),
            };
            return Some(LibraryFile {
                path,
                url: a.url.clone(),
                sha1: a.sha1.clone(),
                size: a.size,
            });
        }
        // Old natives-only entries without a `downloads` block have no
        // classpath artifact.
        if self.natives.is_some() {
            return None;
        }
        let coord = self.coord()?;
        let path = coord.path();
        let base = self.url.as_deref().unwrap_or(LIBRARIES_URL);
        let url = if base.is_empty() {
            String::new()
        } else if base.ends_with('/') {
            format!("{base}{path}")
        } else {
            format!("{base}/{path}")
        };
        Some(LibraryFile {
            path,
            url,
            sha1: self
                .sha1
                .clone()
                .or_else(|| self.checksums.as_ref().and_then(|c| c.first().cloned())),
            size: self.size,
        })
    }

    /// Natives classifier for `ctx`, e.g. `natives-windows-64`.
    pub fn native_classifier(&self, ctx: &RuleContext) -> Option<String> {
        let natives = self.natives.as_ref()?;
        let raw = natives.get(&ctx.os_name)?;
        let bits = if ctx.os_arch == "x86" || ctx.os_arch == "arm32" {
            "32"
        } else {
            platform::arch_bits()
        };
        Some(raw.replace("${arch}", bits))
    }

    /// The natives jar to extract for `ctx` (old-style natives only).
    pub fn native_artifact(&self, ctx: &RuleContext) -> Option<LibraryFile> {
        let classifier = self.native_classifier(ctx)?;
        if let Some(a) = self
            .downloads
            .as_ref()
            .and_then(|d| d.classifiers.as_ref())
            .and_then(|c| c.get(&classifier))
        {
            let path = match &a.path {
                Some(p) => p.clone(),
                None => self.coord()?.with_classifier(&classifier).path(),
            };
            return Some(LibraryFile {
                path,
                url: a.url.clone(),
                sha1: a.sha1.clone(),
                size: a.size,
            });
        }
        let coord = self.coord()?.with_classifier(&classifier);
        let path = coord.path();
        let base = self.url.as_deref().unwrap_or(LIBRARIES_URL);
        Some(LibraryFile {
            url: format!("{}/{}", base.trim_end_matches('/'), path),
            path,
            sha1: None,
            size: None,
        })
    }

    pub fn extract_excludes(&self) -> Vec<String> {
        self.extract
            .as_ref()
            .map(|e| e.exclude.clone())
            .unwrap_or_default()
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(untagged)]
pub enum ArgValue {
    One(String),
    Many(Vec<String>),
}

impl ArgValue {
    pub fn values(&self) -> Vec<&str> {
        match self {
            ArgValue::One(s) => vec![s.as_str()],
            ArgValue::Many(v) => v.iter().map(String::as_str).collect(),
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(untagged)]
pub enum Argument {
    Plain(String),
    Conditional {
        #[serde(default, alias = "compatibilityRules")]
        rules: Vec<Rule>,
        value: ArgValue,
    },
}

#[derive(Debug, Clone, Default, PartialEq, Eq, Serialize, Deserialize)]
pub struct Arguments {
    #[serde(default)]
    pub game: Vec<Argument>,
    #[serde(default)]
    pub jvm: Vec<Argument>,
}

#[derive(Debug, Clone, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct AssetIndexRef {
    pub id: String,
    #[serde(default)]
    pub sha1: Option<String>,
    #[serde(default)]
    pub size: Option<u64>,
    #[serde(default)]
    pub total_size: Option<u64>,
    pub url: String,
}

#[derive(Debug, Clone, Default, PartialEq, Eq, Serialize, Deserialize)]
pub struct Download {
    #[serde(default)]
    pub sha1: Option<String>,
    #[serde(default)]
    pub size: Option<u64>,
    pub url: String,
}

#[derive(Debug, Clone, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct JavaVersionReq {
    #[serde(default)]
    pub component: Option<String>,
    pub major_version: u32,
}

#[derive(Debug, Clone, Default, PartialEq, Eq, Serialize, Deserialize)]
pub struct LoggingFile {
    pub id: String,
    #[serde(default)]
    pub sha1: Option<String>,
    #[serde(default)]
    pub size: Option<u64>,
    pub url: String,
}

#[derive(Debug, Clone, Default, PartialEq, Eq, Serialize, Deserialize)]
pub struct LoggingConfig {
    pub argument: String,
    pub file: LoggingFile,
    #[serde(rename = "type", default)]
    pub kind: Option<String>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize, Default)]
#[serde(rename_all = "camelCase")]
pub struct VersionJson {
    pub id: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub inherits_from: Option<String>,
    #[serde(rename = "type", default, skip_serializing_if = "Option::is_none")]
    pub kind: Option<VersionType>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub main_class: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub minecraft_arguments: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub arguments: Option<Arguments>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub asset_index: Option<AssetIndexRef>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub assets: Option<String>,
    #[serde(default, skip_serializing_if = "BTreeMap::is_empty")]
    pub downloads: BTreeMap<String, Download>,
    #[serde(default)]
    pub libraries: Vec<Library>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub java_version: Option<JavaVersionReq>,
    #[serde(default, skip_serializing_if = "BTreeMap::is_empty")]
    pub logging: BTreeMap<String, LoggingConfig>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub release_time: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub time: Option<String>,
    /// Use another version's jar as the client jar.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub jar: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub minimum_launcher_version: Option<u32>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub compliance_level: Option<u32>,
    /// Set by [`VersionJson::inherit`]: the ancestor whose
    /// `downloads.client` this version uses.
    #[serde(skip)]
    pub client_from: Option<String>,
    /// Set by [`VersionJson::inherit`]: the vanilla (root) version id.
    #[serde(skip)]
    pub base_id: Option<String>,
}

impl VersionJson {
    pub fn parse(bytes: &[u8]) -> std::result::Result<Self, serde_json::Error> {
        serde_json::from_slice(bytes)
    }

    pub fn load(path: &Path) -> Result<Self> {
        crate::read_json(path)
    }

    /// Layer `self` (a child profile) on top of `parent`.
    pub fn inherit(self, parent: VersionJson) -> VersionJson {
        let child = self;
        let mut libraries = child.libraries;
        libraries.extend(parent.libraries);

        let arguments = match (parent.arguments, child.arguments) {
            (None, None) => None,
            (Some(a), None) | (None, Some(a)) => Some(a),
            (Some(mut p), Some(c)) => {
                p.game.extend(c.game);
                p.jvm.extend(c.jvm);
                Some(p)
            }
        };

        let client_from = if child.downloads.contains_key("client") {
            Some(child.id.clone())
        } else {
            child.client_from.or(parent.client_from).or_else(|| {
                parent
                    .downloads
                    .contains_key("client")
                    .then(|| parent.id.clone())
            })
        };
        let mut downloads = parent.downloads;
        downloads.extend(child.downloads);
        let mut logging = parent.logging;
        logging.extend(child.logging);

        VersionJson {
            base_id: parent.base_id.or(Some(parent.id)),
            id: child.id,
            inherits_from: None,
            kind: child.kind.or(parent.kind),
            main_class: child.main_class.or(parent.main_class),
            minecraft_arguments: child.minecraft_arguments.or(parent.minecraft_arguments),
            arguments,
            asset_index: child.asset_index.or(parent.asset_index),
            assets: child.assets.or(parent.assets),
            downloads,
            libraries,
            java_version: child.java_version.or(parent.java_version),
            logging,
            release_time: child.release_time.or(parent.release_time),
            time: child.time.or(parent.time),
            jar: child.jar.or(parent.jar),
            minimum_launcher_version: child
                .minimum_launcher_version
                .max(parent.minimum_launcher_version),
            compliance_level: child.compliance_level.or(parent.compliance_level),
            client_from,
        }
    }

    /// The vanilla version underneath all loader layers.
    pub fn base_version(&self) -> &str {
        self.base_id.as_deref().unwrap_or(&self.id)
    }

    /// Id of the asset index (`assets` field or `assetIndex.id`).
    pub fn asset_index_id(&self) -> String {
        self.asset_index
            .as_ref()
            .map(|a| a.id.clone())
            .or_else(|| self.assets.clone())
            .unwrap_or_else(|| "legacy".to_string())
    }

    /// Id whose `versions/<id>/<id>.jar` is the client jar on the classpath.
    pub fn client_jar_id(&self) -> &str {
        self.jar.as_deref().unwrap_or(&self.id)
    }

    pub fn is_legacy_args(&self) -> bool {
        self.minecraft_arguments.is_some()
    }

    pub fn client_logging(&self) -> Option<&LoggingConfig> {
        self.logging.get("client")
    }

    /// Libraries that apply to `ctx`, de-duplicated (first wins, so a child
    /// profile overrides its parent).
    pub fn effective_libraries(&self, ctx: &RuleContext) -> Vec<&Library> {
        let mut seen = HashSet::new();
        let mut out = Vec::new();
        for lib in &self.libraries {
            if !lib.is_allowed(ctx) {
                continue;
            }
            let key = match lib.coord() {
                Some(c) => {
                    // Natives-only entries share a name with nothing on the
                    // classpath; keep them distinct.
                    if lib.natives.is_some() {
                        format!("{}#natives", c.dedupe_key())
                    } else {
                        c.dedupe_key()
                    }
                }
                None => lib.name.clone(),
            };
            if seen.insert(key) {
                out.push(lib);
            }
        }
        out
    }

    /// Does the argument list reference feature `name` anywhere?
    pub fn uses_feature(&self, name: &str) -> bool {
        let Some(args) = &self.arguments else {
            return false;
        };
        args.game.iter().chain(args.jvm.iter()).any(|a| match a {
            Argument::Plain(_) => false,
            Argument::Conditional { rules, .. } => {
                rules::referenced_features(rules).any(|f| f == name)
            }
        })
    }
}

/// A version with its `inheritsFrom` chain resolved.
#[derive(Debug, Clone)]
pub struct ResolvedVersion {
    pub merged: VersionJson,
    /// Ids from the requested version down to the root (vanilla) version.
    pub chain: Vec<String>,
}

/// Load `versions/<id>/<id>.json` and every parent it inherits from.
pub fn load_resolved(paths: &LauncherPaths, id: &str) -> Result<ResolvedVersion> {
    let mut chain = Vec::new();
    let mut jsons = Vec::new();
    let mut current = id.to_string();
    loop {
        if chain.contains(&current) {
            return Err(CoreError::Invalid(format!(
                "inheritsFrom cycle: {} -> {current}",
                chain.join(" -> ")
            )));
        }
        if chain.len() > 16 {
            return Err(CoreError::Invalid("inheritsFrom chain too deep".into()));
        }
        let json = VersionJson::load(&paths.version_json(&current))?;
        chain.push(current.clone());
        let parent = json.inherits_from.clone();
        jsons.push(json);
        match parent {
            Some(p) => current = p,
            None => break,
        }
    }
    Ok(ResolvedVersion {
        merged: merge_chain(jsons),
        chain,
    })
}

/// Merge `[child, parent, grandparent, ...]` into one version.
pub fn merge_chain(mut jsons: Vec<VersionJson>) -> VersionJson {
    let mut merged = jsons.pop().unwrap_or_default();
    if merged.downloads.contains_key("client") {
        merged.client_from = Some(merged.id.clone());
    }
    while let Some(child) = jsons.pop() {
        merged = child.inherit(merged);
    }
    merged
}

#[cfg(test)]
mod tests {
    use super::*;

    const VANILLA: &str = r#"{
        "id": "1.20.1", "type": "release", "mainClass": "net.minecraft.client.main.Main",
        "assetIndex": {"id": "5", "sha1": "a", "size": 1, "totalSize": 2, "url": "https://x/5.json"},
        "assets": "5",
        "downloads": {"client": {"sha1": "c", "size": 3, "url": "https://x/client.jar"}},
        "javaVersion": {"component": "java-runtime-gamma", "majorVersion": 17},
        "arguments": {
            "game": ["--username", "${auth_player_name}"],
            "jvm": ["-Djava.library.path=${natives_directory}", "-cp", "${classpath}"]
        },
        "libraries": [
            {"name": "org.ow2.asm:asm:9.3", "downloads": {"artifact": {"path": "org/ow2/asm/asm/9.3/asm-9.3.jar", "sha1": "s", "size": 1, "url": "https://libraries.minecraft.net/org/ow2/asm/asm/9.3/asm-9.3.jar"}}},
            {"name": "org.lwjgl:lwjgl:3.3.1", "downloads": {"artifact": {"path": "org/lwjgl/lwjgl/3.3.1/lwjgl-3.3.1.jar", "sha1": "s", "size": 1, "url": "u"}}},
            {"name": "org.lwjgl:lwjgl:3.3.1:natives-linux", "downloads": {"artifact": {"path": "org/lwjgl/lwjgl/3.3.1/lwjgl-3.3.1-natives-linux.jar", "sha1": "s", "size": 1, "url": "u"}}, "rules": [{"action": "allow", "os": {"name": "linux"}}]},
            {"name": "org.lwjgl:lwjgl:3.3.1:natives-windows", "downloads": {"artifact": {"path": "org/lwjgl/lwjgl/3.3.1/lwjgl-3.3.1-natives-windows.jar", "sha1": "s", "size": 1, "url": "u"}}, "rules": [{"action": "allow", "os": {"name": "windows"}}]}
        ],
        "releaseTime": "2023-06-12T13:25:51+00:00"
    }"#;

    const FABRIC: &str = r#"{
        "id": "fabric-loader-0.16.10-1.20.1", "inheritsFrom": "1.20.1",
        "mainClass": "net.fabricmc.loader.impl.launch.knot.KnotClient",
        "arguments": {"game": [], "jvm": ["-DFabricMcEmu= net.minecraft.client.main.Main "]},
        "libraries": [
            {"name": "org.ow2.asm:asm:9.7.1", "url": "https://maven.fabricmc.net/", "sha1": "f0ed", "size": 126093},
            {"name": "net.fabricmc:fabric-loader:0.16.10", "url": "https://maven.fabricmc.net/"}
        ]
    }"#;

    #[test]
    fn parse_vanilla() {
        let v = VersionJson::parse(VANILLA.as_bytes()).unwrap();
        assert_eq!(v.asset_index_id(), "5");
        assert_eq!(v.java_version.as_ref().unwrap().major_version, 17);
        assert_eq!(v.arguments.as_ref().unwrap().jvm.len(), 3);
        assert_eq!(v.kind, Some(VersionType::Release));
    }

    #[test]
    fn inherit_fabric() {
        let vanilla = VersionJson::parse(VANILLA.as_bytes()).unwrap();
        let fabric = VersionJson::parse(FABRIC.as_bytes()).unwrap();
        let merged = merge_chain(vec![fabric, vanilla]);
        assert_eq!(merged.id, "fabric-loader-0.16.10-1.20.1");
        assert_eq!(merged.base_version(), "1.20.1");
        assert_eq!(merged.client_from.as_deref(), Some("1.20.1"));
        assert_eq!(merged.client_jar_id(), "fabric-loader-0.16.10-1.20.1");
        assert_eq!(
            merged.main_class.as_deref(),
            Some("net.fabricmc.loader.impl.launch.knot.KnotClient")
        );
        assert_eq!(merged.asset_index_id(), "5");
        let args = merged.arguments.as_ref().unwrap();
        assert_eq!(args.jvm.len(), 4, "parent jvm args then child jvm args");
        assert!(merged.downloads.contains_key("client"));

        // Child's asm 9.7.1 overrides vanilla's 9.3; natives filtered by OS.
        let ctx = RuleContext::for_os("linux", "x86_64");
        let libs = merged.effective_libraries(&ctx);
        let names: Vec<&str> = libs.iter().map(|l| l.name.as_str()).collect();
        assert_eq!(
            names,
            vec![
                "org.ow2.asm:asm:9.7.1",
                "net.fabricmc:fabric-loader:0.16.10",
                "org.lwjgl:lwjgl:3.3.1",
                "org.lwjgl:lwjgl:3.3.1:natives-linux"
            ]
        );
        let asm = libs[0].artifact().unwrap();
        assert_eq!(
            asm.url,
            "https://maven.fabricmc.net/org/ow2/asm/asm/9.7.1/asm-9.7.1.jar"
        );
        assert_eq!(asm.sha1.as_deref(), Some("f0ed"));
    }

    #[test]
    fn old_style_natives() {
        let lib: Library = serde_json::from_str(
            r#"{"name": "org.lwjgl.lwjgl:lwjgl-platform:2.9.0",
                "downloads": {"classifiers": {
                    "natives-linux": {"path": "org/lwjgl/lwjgl/lwjgl-platform/2.9.0/lwjgl-platform-2.9.0-natives-linux.jar", "sha1": "a", "size": 1, "url": "https://l/linux.jar"},
                    "natives-windows-64": {"path": "w64.jar", "sha1": "b", "size": 2, "url": "https://l/w64.jar"}
                }},
                "natives": {"linux": "natives-linux", "windows": "natives-windows-${arch}"},
                "extract": {"exclude": ["META-INF/"]}}"#,
        )
        .unwrap();
        assert!(
            lib.artifact().is_none(),
            "natives-only library has no classpath jar"
        );
        let linux = lib
            .native_artifact(&RuleContext::for_os("linux", "x86_64"))
            .unwrap();
        assert_eq!(linux.url, "https://l/linux.jar");
        let win = lib
            .native_artifact(&RuleContext::for_os("windows", "x86_64"))
            .unwrap();
        assert_eq!(win.path, "w64.jar");
        assert!(lib
            .native_artifact(&RuleContext::for_os("osx", "x86_64"))
            .is_none());
        assert_eq!(lib.extract_excludes(), vec!["META-INF/".to_string()]);
    }

    #[test]
    fn conflicting_lwjgl_versions_resolved_by_rules() {
        let v: VersionJson = serde_json::from_str(
            r#"{"id": "b1.7.3", "libraries": [
                {"name": "org.lwjgl.lwjgl:lwjgl:2.9.0", "rules": [{"action": "allow"}, {"action": "disallow", "os": {"name": "osx", "version": "^10\\.5\\.\\d$"}}]},
                {"name": "org.lwjgl.lwjgl:lwjgl:2.9.1-nightly-20130708-debug3", "rules": [{"action": "allow", "os": {"name": "osx", "version": "^10\\.5\\.\\d$"}}]}
            ]}"#,
        )
        .unwrap();
        let ctx = RuleContext::for_os("windows", "x86_64");
        let libs = v.effective_libraries(&ctx);
        assert_eq!(libs.len(), 1);
        assert_eq!(libs[0].name, "org.lwjgl.lwjgl:lwjgl:2.9.0");
    }

    #[test]
    fn load_chain_from_disk() {
        let dir = tempfile::tempdir().unwrap();
        let paths = LauncherPaths::new(dir.path());
        for (id, json) in [
            ("1.20.1", VANILLA),
            ("fabric-loader-0.16.10-1.20.1", FABRIC),
        ] {
            std::fs::create_dir_all(paths.version_dir(id)).unwrap();
            std::fs::write(paths.version_json(id), json).unwrap();
        }
        let r = load_resolved(&paths, "fabric-loader-0.16.10-1.20.1").unwrap();
        assert_eq!(r.chain, vec!["fabric-loader-0.16.10-1.20.1", "1.20.1"]);
        assert_eq!(r.merged.base_version(), "1.20.1");
        let vanilla = load_resolved(&paths, "1.20.1").unwrap();
        assert_eq!(vanilla.merged.client_from.as_deref(), Some("1.20.1"));
        assert_eq!(vanilla.merged.base_version(), "1.20.1");
    }

    #[test]
    fn conditional_argument_shapes() {
        let a: Vec<Argument> = serde_json::from_str(
            r#"["--a", {"rules": [{"action": "allow"}], "value": "-x"}, {"rules": [], "value": ["-y", "-z"]}]"#,
        )
        .unwrap();
        assert_eq!(a.len(), 3);
        assert!(matches!(&a[0], Argument::Plain(s) if s == "--a"));
        match &a[2] {
            Argument::Conditional { value, .. } => assert_eq!(value.values(), vec!["-y", "-z"]),
            _ => panic!(),
        }
    }
}
