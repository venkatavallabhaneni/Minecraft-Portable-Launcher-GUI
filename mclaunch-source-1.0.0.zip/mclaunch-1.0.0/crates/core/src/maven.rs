//! Maven coordinates (`group:artifact:version[:classifier][@ext]`).

use std::fmt;
use std::str::FromStr;

#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct MavenCoord {
    pub group: String,
    pub artifact: String,
    pub version: String,
    pub classifier: Option<String>,
    pub extension: String,
}

impl MavenCoord {
    /// Repository-relative path, always with `/` separators.
    pub fn path(&self) -> String {
        format!(
            "{}/{}/{}/{}",
            self.group.replace('.', "/"),
            self.artifact,
            self.version,
            self.file_name()
        )
    }

    pub fn file_name(&self) -> String {
        match &self.classifier {
            Some(c) => format!(
                "{}-{}-{}.{}",
                self.artifact, self.version, c, self.extension
            ),
            None => format!("{}-{}.{}", self.artifact, self.version, self.extension),
        }
    }

    /// Identity used to de-duplicate libraries (`group:artifact[:classifier]`),
    /// ignoring the version so a child profile can override its parent.
    pub fn dedupe_key(&self) -> String {
        match &self.classifier {
            Some(c) => format!("{}:{}:{}", self.group, self.artifact, c),
            None => format!("{}:{}", self.group, self.artifact),
        }
    }

    pub fn with_classifier(&self, classifier: &str) -> Self {
        Self {
            classifier: Some(classifier.to_string()),
            ..self.clone()
        }
    }
}

impl FromStr for MavenCoord {
    type Err = String;

    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let (coords, extension) = match s.split_once('@') {
            Some((c, e)) => (c, e.to_string()),
            None => (s, "jar".to_string()),
        };
        let parts: Vec<&str> = coords.split(':').collect();
        let (group, artifact, version, classifier) = match parts.as_slice() {
            [g, a, v] => (*g, *a, *v, None),
            [g, a, v, c] => (*g, *a, *v, Some(c.to_string())),
            _ => return Err(format!("not a maven coordinate: {s}")),
        };
        if group.is_empty() || artifact.is_empty() || version.is_empty() {
            return Err(format!("not a maven coordinate: {s}"));
        }
        Ok(Self {
            group: group.to_string(),
            artifact: artifact.to_string(),
            version: version.to_string(),
            classifier,
            extension,
        })
    }
}

impl fmt::Display for MavenCoord {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}:{}:{}", self.group, self.artifact, self.version)?;
        if let Some(c) = &self.classifier {
            write!(f, ":{c}")?;
        }
        if self.extension != "jar" {
            write!(f, "@{}", self.extension)?;
        }
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn plain() {
        let c: MavenCoord = "org.lwjgl:lwjgl:3.3.1".parse().unwrap();
        assert_eq!(c.path(), "org/lwjgl/lwjgl/3.3.1/lwjgl-3.3.1.jar");
        assert_eq!(c.dedupe_key(), "org.lwjgl:lwjgl");
        assert_eq!(c.to_string(), "org.lwjgl:lwjgl:3.3.1");
    }

    #[test]
    fn classifier_and_extension() {
        let c: MavenCoord = "org.lwjgl:lwjgl:3.3.1:natives-linux".parse().unwrap();
        assert_eq!(
            c.path(),
            "org/lwjgl/lwjgl/3.3.1/lwjgl-3.3.1-natives-linux.jar"
        );
        assert_eq!(c.dedupe_key(), "org.lwjgl:lwjgl:natives-linux");
        let c: MavenCoord = "de.oceanlabs.mcp:mcp_config:1.20.1-20230612.114412@zip"
            .parse()
            .unwrap();
        assert_eq!(
            c.path(),
            "de/oceanlabs/mcp/mcp_config/1.20.1-20230612.114412/mcp_config-1.20.1-20230612.114412.zip"
        );
        assert_eq!(
            c.to_string(),
            "de.oceanlabs.mcp:mcp_config:1.20.1-20230612.114412@zip"
        );
        let n = c.with_classifier("mappings");
        assert!(n.path().ends_with("-mappings.zip"));
    }

    #[test]
    fn bad() {
        assert!("nope".parse::<MavenCoord>().is_err());
        assert!("a::b".parse::<MavenCoord>().is_err());
    }
}
