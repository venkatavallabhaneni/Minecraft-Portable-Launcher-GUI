//! Asset index files (`assets/indexes/<id>.json`).

use std::collections::BTreeMap;

use serde::{Deserialize, Serialize};

pub const RESOURCES_URL: &str = "https://resources.download.minecraft.net/";

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct AssetObject {
    pub hash: String,
    pub size: u64,
}

impl AssetObject {
    pub fn url(&self) -> String {
        format!(
            "{RESOURCES_URL}{}/{}",
            &self.hash[..2.min(self.hash.len())],
            self.hash
        )
    }
}

#[derive(Debug, Clone, Default, PartialEq, Eq, Serialize, Deserialize)]
pub struct AssetIndex {
    #[serde(default)]
    pub objects: BTreeMap<String, AssetObject>,
    /// 1.6–1.7.2: assets must be laid out by name under `assets/virtual/<id>`.
    #[serde(default, rename = "virtual")]
    pub is_virtual: bool,
    /// Pre-1.6: assets must be copied to `<game dir>/resources`.
    #[serde(default)]
    pub map_to_resources: bool,
}

impl AssetIndex {
    pub fn total_size(&self) -> u64 {
        self.objects.values().map(|o| o.size).sum()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parse_legacy_index() {
        let idx: AssetIndex = serde_json::from_str(
            r#"{"map_to_resources": true, "objects": {"sound/step/grass1.ogg": {"hash": "4c9fa63a3d6a4b4b2b7b0c1f0f4a1b5d1a2b3c4d", "size": 10}}}"#,
        )
        .unwrap();
        assert!(idx.map_to_resources);
        assert!(!idx.is_virtual);
        let o = &idx.objects["sound/step/grass1.ogg"];
        assert_eq!(
            o.url(),
            "https://resources.download.minecraft.net/4c/4c9fa63a3d6a4b4b2b7b0c1f0f4a1b5d1a2b3c4d"
        );
        assert_eq!(idx.total_size(), 10);
    }
}
