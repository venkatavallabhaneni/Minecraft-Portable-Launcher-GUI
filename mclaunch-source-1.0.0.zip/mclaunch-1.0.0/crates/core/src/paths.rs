//! The portable folder layout. Everything lives next to the executable (or in
//! `$MCLAUNCH_HOME` when set, which is handy for development and tests).

use std::path::{Path, PathBuf};

/// Environment variable that overrides the launcher root.
pub const HOME_ENV: &str = "MCLAUNCH_HOME";

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct LauncherPaths {
    pub root: PathBuf,
}

impl LauncherPaths {
    pub fn new(root: impl Into<PathBuf>) -> Self {
        Self { root: root.into() }
    }

    /// `$MCLAUNCH_HOME` if set, otherwise the folder containing the running
    /// executable.
    pub fn detect() -> std::io::Result<Self> {
        if let Some(home) = std::env::var_os(HOME_ENV).filter(|v| !v.is_empty()) {
            return Ok(Self::new(PathBuf::from(home)));
        }
        let exe = std::env::current_exe()?;
        let dir = exe
            .parent()
            .map(Path::to_path_buf)
            .unwrap_or_else(|| PathBuf::from("."));
        Ok(Self::new(dir))
    }

    /// Create every top-level folder of the layout.
    pub fn ensure_layout(&self) -> std::io::Result<()> {
        for dir in [
            self.java_dir(),
            self.java_extracted_dir(),
            self.versions_dir(),
            self.libraries_dir(),
            self.asset_indexes_dir(),
            self.asset_objects_dir(),
            self.instances_dir(),
            self.loaders_dir(),
            self.servers_dir(),
            self.integrity_dir(),
            self.logs_dir(),
            self.cache_dir(),
            self.skins_dir(),
        ] {
            std::fs::create_dir_all(dir)?;
        }
        Ok(())
    }

    pub fn config_file(&self) -> PathBuf {
        self.root.join("config.toml")
    }
    pub fn java_dir(&self) -> PathBuf {
        self.root.join("java")
    }
    pub fn java_extracted_dir(&self) -> PathBuf {
        self.java_dir().join(".extracted")
    }
    pub fn versions_dir(&self) -> PathBuf {
        self.root.join("versions")
    }
    pub fn version_dir(&self, id: &str) -> PathBuf {
        self.versions_dir().join(id)
    }
    pub fn version_json(&self, id: &str) -> PathBuf {
        self.version_dir(id).join(format!("{id}.json"))
    }
    pub fn version_jar(&self, id: &str) -> PathBuf {
        self.version_dir(id).join(format!("{id}.jar"))
    }
    /// Cached copy of Mojang's `version_manifest_v2.json`.
    pub fn manifest_cache(&self) -> PathBuf {
        self.versions_dir().join("version_manifest_v2.json")
    }
    pub fn libraries_dir(&self) -> PathBuf {
        self.root.join("libraries")
    }
    pub fn assets_dir(&self) -> PathBuf {
        self.root.join("assets")
    }
    pub fn asset_indexes_dir(&self) -> PathBuf {
        self.assets_dir().join("indexes")
    }
    pub fn asset_index(&self, id: &str) -> PathBuf {
        self.asset_indexes_dir().join(format!("{id}.json"))
    }
    pub fn asset_objects_dir(&self) -> PathBuf {
        self.assets_dir().join("objects")
    }
    pub fn asset_object(&self, hash: &str) -> PathBuf {
        let prefix = hash.get(..2).unwrap_or("00");
        self.asset_objects_dir().join(prefix).join(hash)
    }
    pub fn virtual_assets_dir(&self, index_id: &str) -> PathBuf {
        self.assets_dir().join("virtual").join(index_id)
    }
    pub fn log_configs_dir(&self) -> PathBuf {
        self.assets_dir().join("log_configs")
    }
    pub fn instances_dir(&self) -> PathBuf {
        self.root.join(mclaunch_safety::INSTANCES_DIR)
    }
    pub fn instance_dir(&self, name: &str) -> PathBuf {
        self.instances_dir().join(name)
    }
    pub fn loaders_dir(&self) -> PathBuf {
        self.root.join("loaders")
    }
    pub fn servers_dir(&self) -> PathBuf {
        self.root.join(mclaunch_safety::SERVERS_DIR)
    }
    pub fn server_dir(&self, name: &str) -> PathBuf {
        self.servers_dir().join(name)
    }
    pub fn integrity_dir(&self) -> PathBuf {
        self.root.join("integrity")
    }
    pub fn integrity_file(&self, id: &str) -> PathBuf {
        self.integrity_dir().join(format!("{id}.sha256"))
    }
    pub fn logs_dir(&self) -> PathBuf {
        self.root.join("logs")
    }
    pub fn cache_dir(&self) -> PathBuf {
        self.root.join("cache")
    }
    /// Parent of the per-launch natives folders.
    pub fn natives_root(&self) -> PathBuf {
        self.cache_dir().join("natives")
    }
    pub fn skins_dir(&self) -> PathBuf {
        self.root.join("skins")
    }

    /// Path of a file relative to the root, with `/` separators (used in the
    /// integrity manifests so they are portable between OSes).
    pub fn relative(&self, path: &Path) -> Option<String> {
        let rel = path.strip_prefix(&self.root).ok()?;
        let parts: Vec<String> = rel
            .components()
            .map(|c| c.as_os_str().to_string_lossy().into_owned())
            .collect();
        Some(parts.join("/"))
    }

    /// Inverse of [`relative`](Self::relative).
    pub fn from_relative(&self, rel: &str) -> PathBuf {
        let mut p = self.root.clone();
        for part in rel.split('/') {
            p.push(part);
        }
        p
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn layout() {
        let p = LauncherPaths::new("/mc");
        assert_eq!(
            p.version_json("1.21"),
            PathBuf::from("/mc/versions/1.21/1.21.json")
        );
        assert_eq!(
            p.asset_object("abcdef"),
            PathBuf::from("/mc/assets/objects/ab/abcdef")
        );
        assert_eq!(
            p.integrity_file("1.8.9"),
            PathBuf::from("/mc/integrity/1.8.9.sha256")
        );
        let jar = p.version_jar("1.8.9");
        let rel = p.relative(&jar).unwrap();
        assert_eq!(rel, "versions/1.8.9/1.8.9.jar");
        assert_eq!(p.from_relative(&rel), jar);
    }
}
