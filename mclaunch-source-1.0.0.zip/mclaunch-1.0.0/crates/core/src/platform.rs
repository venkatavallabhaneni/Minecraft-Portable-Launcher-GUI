//! Host platform names in Mojang's vocabulary.

use std::sync::OnceLock;

/// `windows`, `osx` or `linux` (other unixes are treated as linux).
pub fn os_name() -> &'static str {
    match std::env::consts::OS {
        "windows" => "windows",
        "macos" => "osx",
        _ => "linux",
    }
}

/// `x86_64`, `x86`, `arm64` or `arm32`.
pub fn os_arch() -> &'static str {
    match std::env::consts::ARCH {
        "x86_64" => "x86_64",
        "x86" => "x86",
        "aarch64" => "arm64",
        "arm" => "arm32",
        other => other,
    }
}

/// Pointer width as used in the `${arch}` placeholder of old natives
/// classifiers (`natives-windows-${arch}` -> `natives-windows-64`).
pub fn arch_bits() -> &'static str {
    if cfg!(target_pointer_width = "64") {
        "64"
    } else {
        "32"
    }
}

pub fn classpath_separator() -> &'static str {
    if cfg!(windows) {
        ";"
    } else {
        ":"
    }
}

/// Name of the java executable inside `bin/`.
pub fn java_exe_name() -> &'static str {
    if cfg!(windows) {
        "java.exe"
    } else {
        "java"
    }
}

/// OS version string, used by `os.version` regexes in rules.
pub fn os_version() -> &'static str {
    static VERSION: OnceLock<String> = OnceLock::new();
    VERSION.get_or_init(detect_os_version)
}

#[cfg(target_os = "linux")]
fn detect_os_version() -> String {
    std::fs::read_to_string("/proc/sys/kernel/osrelease")
        .map(|s| s.trim().to_string())
        .unwrap_or_default()
}

#[cfg(target_os = "macos")]
fn detect_os_version() -> String {
    std::process::Command::new("sw_vers")
        .arg("-productVersion")
        .output()
        .ok()
        .map(|o| String::from_utf8_lossy(&o.stdout).trim().to_string())
        .unwrap_or_default()
}

#[cfg(windows)]
fn detect_os_version() -> String {
    use std::os::windows::process::CommandExt;
    const CREATE_NO_WINDOW: u32 = 0x0800_0000;
    // "Microsoft Windows [Version 10.0.19045.4291]"
    let out = std::process::Command::new("cmd")
        .args(["/C", "ver"])
        .creation_flags(CREATE_NO_WINDOW)
        .output()
        .ok()
        .map(|o| String::from_utf8_lossy(&o.stdout).into_owned())
        .unwrap_or_default();
    out.split_whitespace()
        .last()
        .map(|v| v.trim_end_matches(']').to_string())
        .unwrap_or_default()
}

#[cfg(not(any(target_os = "linux", target_os = "macos", windows)))]
fn detect_os_version() -> String {
    String::new()
}
