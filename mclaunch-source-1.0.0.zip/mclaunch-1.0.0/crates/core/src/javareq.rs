//! Which Java major version a Minecraft version needs.

use crate::version::VersionJson;

/// Required Java major version: the JSON's `javaVersion.majorVersion` when
/// present (true for every current Mojang JSON, including future ones),
/// otherwise a fallback table.
pub fn required_java(version: &VersionJson) -> u32 {
    if let Some(j) = &version.java_version {
        return j.major_version;
    }
    fallback_java(version.base_version(), version.release_time.as_deref())
}

/// Fallback when a JSON lacks `javaVersion`:
/// ≤1.16.5 → 8, 1.17 → 16, 1.18–1.20.4 → 17, 1.20.5+ → 21.
pub fn fallback_java(id: &str, release_time: Option<&str>) -> u32 {
    if let Some((minor, patch)) = parse_release(id) {
        return match minor {
            ..=16 => 8,
            17 => 16,
            18 | 19 => 17,
            20 if patch <= 4 => 17,
            _ => 21,
        };
    }
    // Snapshots and odd ids: decide by release date.
    match release_time.and_then(|t| t.get(..10)) {
        Some(date) if date < "2021-05-01" => 8, // 21w19a moved to Java 16
        Some(date) if date < "2021-09-15" => 16, // 1.18 snapshots moved to 17
        Some(date) if date < "2024-04-03" => 17, // 24w14a moved to Java 21
        Some(_) => 21,
        None => 8,
    }
}

/// `1.20.4` -> `(20, 4)`, `1.17` -> `(17, 0)`; anything else -> `None`.
fn parse_release(id: &str) -> Option<(u32, u32)> {
    let rest = id.strip_prefix("1.")?;
    let mut parts = rest.split('.');
    let minor = parts.next()?.parse().ok()?;
    let patch = match parts.next() {
        Some(p) => p.parse().ok()?,
        None => 0,
    };
    if parts.next().is_some() {
        return None;
    }
    Some((minor, patch))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn table() {
        assert_eq!(fallback_java("1.8.9", None), 8);
        assert_eq!(fallback_java("1.16.5", None), 8);
        assert_eq!(fallback_java("1.17.1", None), 16);
        assert_eq!(fallback_java("1.18.2", None), 17);
        assert_eq!(fallback_java("1.20.4", None), 17);
        assert_eq!(fallback_java("1.20.5", None), 21);
        assert_eq!(fallback_java("1.21.4", None), 21);
        assert_eq!(
            fallback_java("b1.7.3", Some("2011-07-07T22:00:00+00:00")),
            8
        );
        assert_eq!(
            fallback_java("23w31a", Some("2023-08-01T00:00:00+00:00")),
            17
        );
        assert_eq!(fallback_java("26.1", Some("2026-03-01T00:00:00+00:00")), 21);
    }

    #[test]
    fn json_wins() {
        let v: VersionJson = serde_json::from_str(
            r#"{"id": "26.4-snapshot-3", "javaVersion": {"component": "java-runtime-epsilon", "majorVersion": 25}}"#,
        )
        .unwrap();
        assert_eq!(required_java(&v), 25);
    }
}
