//! Mojang's `version_manifest_v2.json`.

use std::fmt;

use serde::{Deserialize, Deserializer, Serialize, Serializer};

pub const MANIFEST_URL: &str = "https://piston-meta.mojang.com/mc/game/version_manifest_v2.json";

/// Version type as found in the manifest. Unknown types are preserved so
/// that new categories Mojang may add still show up and launch.
#[derive(Debug, Clone, PartialEq, Eq, Hash, Default)]
pub enum VersionType {
    #[default]
    Release,
    Snapshot,
    OldBeta,
    OldAlpha,
    Other(String),
}

impl VersionType {
    pub fn as_str(&self) -> &str {
        match self {
            VersionType::Release => "release",
            VersionType::Snapshot => "snapshot",
            VersionType::OldBeta => "old_beta",
            VersionType::OldAlpha => "old_alpha",
            VersionType::Other(s) => s,
        }
    }

    pub fn parse(s: &str) -> Self {
        match s {
            "release" => VersionType::Release,
            "snapshot" => VersionType::Snapshot,
            "old_beta" => VersionType::OldBeta,
            "old_alpha" => VersionType::OldAlpha,
            other => VersionType::Other(other.to_string()),
        }
    }

    pub fn label(&self) -> &str {
        match self {
            VersionType::Release => "Release",
            VersionType::Snapshot => "Snapshot",
            VersionType::OldBeta => "Beta",
            VersionType::OldAlpha => "Alpha",
            VersionType::Other(s) => s,
        }
    }

    pub fn is_legacy(&self) -> bool {
        matches!(self, VersionType::OldAlpha | VersionType::OldBeta)
    }
}

impl fmt::Display for VersionType {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(self.as_str())
    }
}

impl Serialize for VersionType {
    fn serialize<S: Serializer>(&self, s: S) -> Result<S::Ok, S::Error> {
        s.serialize_str(self.as_str())
    }
}

impl<'de> Deserialize<'de> for VersionType {
    fn deserialize<D: Deserializer<'de>>(d: D) -> Result<Self, D::Error> {
        let s = String::deserialize(d)?;
        Ok(VersionType::parse(&s))
    }
}

#[derive(Debug, Clone, Default, PartialEq, Eq, Serialize, Deserialize)]
pub struct Latest {
    #[serde(default)]
    pub release: String,
    #[serde(default)]
    pub snapshot: String,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ManifestEntry {
    pub id: String,
    #[serde(rename = "type", default)]
    pub kind: VersionType,
    pub url: String,
    #[serde(default)]
    pub time: String,
    #[serde(default)]
    pub release_time: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub sha1: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub compliance_level: Option<u32>,
}

impl ManifestEntry {
    /// Best-effort detection of April Fools / joke versions, which Mojang
    /// files under `snapshot` (e.g. `20w14infinite`, `3D Shareware v1.34`).
    pub fn is_april_fools(&self) -> bool {
        if self.kind != VersionType::Snapshot {
            return false;
        }
        let date = self.release_time.get(5..10).unwrap_or("");
        if date != "04-01" && date != "03-31" {
            return false;
        }
        let lower = self.id.to_lowercase();
        !(lower.contains("-pre") || lower.contains("-rc"))
    }
}

#[derive(Debug, Clone, Default, PartialEq, Eq, Serialize, Deserialize)]
pub struct VersionManifest {
    #[serde(default)]
    pub latest: Latest,
    #[serde(default)]
    pub versions: Vec<ManifestEntry>,
}

impl VersionManifest {
    pub fn get(&self, id: &str) -> Option<&ManifestEntry> {
        self.versions.iter().find(|v| v.id == id)
    }

    /// Release versions newest first.
    pub fn releases(&self) -> impl Iterator<Item = &ManifestEntry> {
        self.versions
            .iter()
            .filter(|v| v.kind == VersionType::Release)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    const SAMPLE: &str = r#"{
      "latest": {"release": "26.3", "snapshot": "26.4-snapshot-3"},
      "versions": [
        {"id": "26.4-snapshot-3", "type": "snapshot", "url": "https://x/26.4-snapshot-3.json", "time": "2026-10-06T12:54:26+00:00", "releaseTime": "2026-10-06T12:54:26+00:00", "sha1": "1f72", "complianceLevel": 1},
        {"id": "26.3", "type": "release", "url": "https://x/26.3.json", "time": "t", "releaseTime": "2026-09-01T00:00:00+00:00", "sha1": "702f", "complianceLevel": 1},
        {"id": "24w14potato", "type": "snapshot", "url": "u", "time": "t", "releaseTime": "2024-04-01T12:00:00+00:00"},
        {"id": "b1.7.3", "type": "old_beta", "url": "u", "time": "t", "releaseTime": "2011-07-07T22:00:00+00:00"},
        {"id": "rd-132211", "type": "old_alpha", "url": "u", "time": "t", "releaseTime": "2009-05-13T20:11:00+00:00"},
        {"id": "x-experimental", "type": "experiment", "url": "u", "time": "t", "releaseTime": "2021-07-13T12:00:00+00:00"}
      ]
    }"#;

    #[test]
    fn parses_all_types() {
        let m: VersionManifest = serde_json::from_str(SAMPLE).unwrap();
        assert_eq!(m.latest.release, "26.3");
        assert_eq!(m.versions.len(), 6);
        assert_eq!(m.get("b1.7.3").unwrap().kind, VersionType::OldBeta);
        assert_eq!(m.get("rd-132211").unwrap().kind, VersionType::OldAlpha);
        assert_eq!(
            m.get("x-experimental").unwrap().kind,
            VersionType::Other("experiment".into())
        );
        assert!(m.get("24w14potato").unwrap().is_april_fools());
        assert!(!m.get("26.4-snapshot-3").unwrap().is_april_fools());
        assert_eq!(m.releases().count(), 1);
        // round trip keeps unknown types
        let back: VersionManifest =
            serde_json::from_str(&serde_json::to_string(&m).unwrap()).unwrap();
        assert_eq!(back, m);
    }
}
