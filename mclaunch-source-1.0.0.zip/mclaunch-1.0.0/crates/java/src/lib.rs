//! Java runtimes for mclaunch.
//!
//! Users drop JDK/JRE archives into `java/` (`*.zip`, `*.tar.gz`, `*.tgz`).
//! Each archive is hashed with SHA-256 and extracted once into
//! `java/.extracted/<hash-prefix>/`. The real version is detected by running
//! `java -XshowSettings:properties -version`, never from the file name.

mod detect;
mod extract;

pub use detect::{detect, parse_properties, JavaInfo};

use std::collections::BTreeMap;
use std::io::Read;
use std::path::{Path, PathBuf};
use std::time::UNIX_EPOCH;

use mclaunch_core::{LauncherPaths, Progress, ProgressFn};
use mclaunch_safety::SafePath;
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};

#[derive(Debug, thiserror::Error)]
pub enum JavaError {
    #[error("I/O error on {path}: {source}")]
    Io {
        path: PathBuf,
        #[source]
        source: std::io::Error,
    },
    #[error("cannot read archive {path}: {message}")]
    Archive { path: PathBuf, message: String },
    #[error("no bin/java found inside {0}")]
    NoJavaBinary(PathBuf),
    #[error("could not run {path}: {message}")]
    Detect { path: PathBuf, message: String },
    #[error(transparent)]
    Safety(#[from] mclaunch_safety::SafetyError),
}

pub type Result<T> = std::result::Result<T, JavaError>;

pub(crate) fn io_err(path: &Path) -> impl FnOnce(std::io::Error) -> JavaError + '_ {
    move |source| JavaError::Io {
        path: path.to_path_buf(),
        source,
    }
}

/// Where a runtime came from.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum RuntimeSource {
    /// An archive in `java/`.
    Archive { file_name: String, sha256: String },
    /// Found via `JAVA_HOME` or `PATH`.
    System { origin: String },
    /// A path the user configured on an instance.
    Manual,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct JavaRuntime {
    pub source: RuntimeSource,
    /// The `java` executable.
    pub java_bin: PathBuf,
    pub info: JavaInfo,
}

impl JavaRuntime {
    pub fn major(&self) -> u32 {
        self.info.major
    }

    pub fn label(&self) -> String {
        format!(
            "Java {} ({}, {})",
            self.info.version,
            self.info.vendor,
            self.origin()
        )
    }

    pub fn origin(&self) -> String {
        match &self.source {
            RuntimeSource::Archive { file_name, .. } => file_name.clone(),
            RuntimeSource::System { origin } => origin.clone(),
            RuntimeSource::Manual => "manual".into(),
        }
    }

    pub fn sha256_short(&self) -> Option<&str> {
        match &self.source {
            RuntimeSource::Archive { sha256, .. } => sha256.get(..12),
            _ => None,
        }
    }
}

/// One line of the scan report for archives that failed.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ScanError {
    pub file_name: String,
    pub message: String,
}

#[derive(Debug, Clone, Default)]
pub struct ScanReport {
    pub runtimes: Vec<JavaRuntime>,
    pub errors: Vec<ScanError>,
    /// Archives extracted during this scan.
    pub extracted: Vec<String>,
}

/// `java/.extracted/index.json`: remembers hashes and detected versions so
/// a startup scan does not re-hash unchanged archives.
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
struct Index {
    archives: BTreeMap<String, IndexEntry>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct IndexEntry {
    size: u64,
    mtime: u64,
    sha256: String,
    java_bin: Option<PathBuf>,
    info: Option<JavaInfo>,
}

const COMPLETE_MARKER: &str = ".mclaunch-complete";

pub fn is_archive_name(name: &str) -> bool {
    let lower = name.to_ascii_lowercase();
    lower.ends_with(".zip") || lower.ends_with(".tar.gz") || lower.ends_with(".tgz")
}

pub fn sha256_file(path: &Path) -> Result<String> {
    let mut f = std::fs::File::open(path).map_err(io_err(path))?;
    let mut h = Sha256::new();
    let mut buf = vec![0u8; 1024 * 1024];
    loop {
        let n = f.read(&mut buf).map_err(io_err(path))?;
        if n == 0 {
            break;
        }
        h.update(&buf[..n]);
    }
    Ok(hex::encode(h.finalize()))
}

pub struct JavaManager {
    paths: LauncherPaths,
    safe: SafePath,
}

impl JavaManager {
    pub fn new(paths: LauncherPaths, safe: SafePath) -> Self {
        Self { paths, safe }
    }

    fn index_path(&self) -> PathBuf {
        self.paths.java_extracted_dir().join("index.json")
    }

    fn load_index(&self) -> Index {
        std::fs::read(self.index_path())
            .ok()
            .and_then(|b| serde_json::from_slice(&b).ok())
            .unwrap_or_default()
    }

    fn save_index(&self, index: &Index) -> Result<()> {
        let bytes = serde_json::to_vec_pretty(index).unwrap_or_default();
        self.safe.write(&self.index_path(), &bytes)?;
        Ok(())
    }

    /// Scan `java/` (and optionally the system) for runtimes. Blocking.
    /// `force_rehash` recomputes SHA-256 even for unchanged archives.
    pub fn scan(
        &self,
        include_system: bool,
        force_rehash: bool,
        progress: &ProgressFn,
    ) -> ScanReport {
        let mut report = ScanReport::default();
        let java_dir = self.paths.java_dir();
        let _ = std::fs::create_dir_all(self.paths.java_extracted_dir());
        let mut index = self.load_index();
        let mut archives: Vec<PathBuf> = std::fs::read_dir(&java_dir)
            .map(|rd| {
                rd.flatten()
                    .map(|e| e.path())
                    .filter(|p| p.is_file())
                    .filter(|p| {
                        p.file_name()
                            .map(|n| is_archive_name(&n.to_string_lossy()))
                            .unwrap_or(false)
                    })
                    .collect()
            })
            .unwrap_or_default();
        archives.sort();

        let total = archives.len() as u64;
        let mut keep_dirs = Vec::new();
        for (i, archive) in archives.iter().enumerate() {
            let file_name = archive
                .file_name()
                .map(|n| n.to_string_lossy().into_owned())
                .unwrap_or_default();
            progress(Progress {
                stage: format!("Java: {file_name}"),
                done: i as u64,
                total,
                ..Default::default()
            });
            match self.process_archive(archive, &file_name, &mut index, force_rehash, &mut report) {
                Ok(rt) => {
                    if let RuntimeSource::Archive { sha256, .. } = &rt.source {
                        keep_dirs.push(self.extract_dir(sha256));
                    }
                    report.runtimes.push(rt);
                }
                Err(e) => {
                    tracing::warn!(archive = %file_name, error = %e, "java archive skipped");
                    // keep a previous extraction for an archive that is still present
                    if let Some(entry) = index.archives.get(&file_name) {
                        keep_dirs.push(self.extract_dir(&entry.sha256));
                    }
                    report.errors.push(ScanError {
                        file_name,
                        message: e.to_string(),
                    });
                }
            }
        }
        index.archives.retain(|name, _| {
            archives
                .iter()
                .any(|a| a.file_name().is_some_and(|n| n.to_string_lossy() == *name))
        });
        if let Err(e) = self.save_index(&index) {
            tracing::warn!(error = %e, "could not save java index");
        }
        self.cleanup_stale(&keep_dirs);

        if include_system {
            for (origin, bin) in system_candidates() {
                if report.runtimes.iter().any(|r| same_file(&r.java_bin, &bin)) {
                    continue;
                }
                match detect(&bin) {
                    Ok(info) => report.runtimes.push(JavaRuntime {
                        source: RuntimeSource::System { origin },
                        java_bin: bin,
                        info,
                    }),
                    Err(e) => tracing::debug!(error = %e, "system java not usable"),
                }
            }
        }
        report.runtimes.sort_by(|a, b| {
            b.info
                .major
                .cmp(&a.info.major)
                .then(a.origin().cmp(&b.origin()))
        });
        progress(Progress {
            stage: "Java scan complete".into(),
            done: total,
            total,
            ..Default::default()
        });
        report
    }

    fn extract_dir(&self, sha256: &str) -> PathBuf {
        self.paths
            .java_extracted_dir()
            .join(sha256.get(..16).unwrap_or(sha256))
    }

    fn process_archive(
        &self,
        archive: &Path,
        file_name: &str,
        index: &mut Index,
        force_rehash: bool,
        report: &mut ScanReport,
    ) -> Result<JavaRuntime> {
        let meta = std::fs::metadata(archive).map_err(io_err(archive))?;
        let mtime = meta
            .modified()
            .ok()
            .and_then(|t| t.duration_since(UNIX_EPOCH).ok())
            .map(|d| d.as_secs())
            .unwrap_or(0);
        let cached = index
            .archives
            .get(file_name)
            .filter(|e| !force_rehash && e.size == meta.len() && e.mtime == mtime)
            .cloned();
        let sha256 = match &cached {
            Some(e) => e.sha256.clone(),
            None => sha256_file(archive)?,
        };
        let dir = self.extract_dir(&sha256);
        let complete = dir.join(COMPLETE_MARKER).is_file();
        if !complete {
            tracing::info!(archive = %file_name, dir = %dir.display(), "extracting java runtime");
            extract::extract_archive(&self.safe, archive, &dir)?;
            report.extracted.push(file_name.to_string());
        }
        let reuse = cached
            .as_ref()
            .filter(|e| e.sha256 == sha256 && complete)
            .and_then(|e| Some((e.java_bin.clone()?, e.info.clone()?)))
            .filter(|(bin, _)| bin.is_file());
        let (java_bin, info) = match reuse {
            Some(pair) => pair,
            None => {
                let bin =
                    find_java_binary(&dir).ok_or_else(|| JavaError::NoJavaBinary(dir.clone()))?;
                let info = detect(&bin)?;
                (bin, info)
            }
        };
        index.archives.insert(
            file_name.to_string(),
            IndexEntry {
                size: meta.len(),
                mtime,
                sha256: sha256.clone(),
                java_bin: Some(java_bin.clone()),
                info: Some(info.clone()),
            },
        );
        Ok(JavaRuntime {
            source: RuntimeSource::Archive {
                file_name: file_name.to_string(),
                sha256,
            },
            java_bin,
            info,
        })
    }

    /// Remove extraction folders whose archive is gone or changed.
    fn cleanup_stale(&self, keep: &[PathBuf]) {
        let Ok(rd) = std::fs::read_dir(self.paths.java_extracted_dir()) else {
            return;
        };
        for entry in rd.flatten() {
            let path = entry.path();
            if !path.is_dir() || keep.iter().any(|k| same_file(k, &path)) {
                continue;
            }
            tracing::info!(dir = %path.display(), "removing stale extracted runtime");
            if let Err(e) = self.safe.remove_dir_all(&path) {
                tracing::warn!(error = %e, "could not remove stale runtime");
            }
        }
    }
}

fn same_file(a: &Path, b: &Path) -> bool {
    match (std::fs::canonicalize(a), std::fs::canonicalize(b)) {
        (Ok(x), Ok(y)) => x == y,
        _ => a == b,
    }
}

/// Find `bin/java(.exe)` inside an extracted runtime (shallowest wins).
pub fn find_java_binary(dir: &Path) -> Option<PathBuf> {
    fn walk(dir: &Path, depth: usize, out: &mut Vec<(usize, PathBuf)>) {
        let candidate = dir
            .join("bin")
            .join(mclaunch_core::platform::java_exe_name());
        if candidate.is_file() {
            out.push((depth, candidate));
            return;
        }
        if depth >= 4 {
            return;
        }
        let Ok(rd) = std::fs::read_dir(dir) else {
            return;
        };
        let mut subdirs: Vec<PathBuf> = rd
            .flatten()
            .map(|e| e.path())
            .filter(|p| p.is_dir())
            .collect();
        subdirs.sort();
        for sub in subdirs {
            walk(&sub, depth + 1, out);
        }
    }
    let mut found = Vec::new();
    walk(dir, 0, &mut found);
    found.sort_by_key(|(d, _)| *d);
    found.into_iter().next().map(|(_, p)| p)
}

/// `JAVA_HOME/bin/java` and every `java` on `PATH`.
fn system_candidates() -> Vec<(String, PathBuf)> {
    let exe = mclaunch_core::platform::java_exe_name();
    let mut out = Vec::new();
    if let Some(home) = std::env::var_os("JAVA_HOME") {
        let bin = PathBuf::from(home).join("bin").join(exe);
        if bin.is_file() {
            out.push(("JAVA_HOME".to_string(), bin));
        }
    }
    if let Some(path) = std::env::var_os("PATH") {
        for dir in std::env::split_paths(&path) {
            let bin = dir.join(exe);
            if bin.is_file() {
                let real = std::fs::canonicalize(&bin).unwrap_or(bin);
                if !out.iter().any(|(_, b)| same_file(b, &real)) {
                    out.push(("PATH".to_string(), real));
                }
            }
        }
    }
    out
}

/// Result of matching a Minecraft version to a runtime.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum JavaPick<'a> {
    /// Exactly the required major version.
    Exact(&'a JavaRuntime),
    /// A newer runtime that should work (warned in the UI).
    Compatible(&'a JavaRuntime),
    /// Nothing usable; the message tells the user what to do.
    Missing(String),
}

impl<'a> JavaPick<'a> {
    pub fn runtime(&self) -> Option<&'a JavaRuntime> {
        match self {
            JavaPick::Exact(r) | JavaPick::Compatible(r) => Some(r),
            JavaPick::Missing(_) => None,
        }
    }
}

/// Message shown when no runtime matches.
pub fn missing_message(mc_version: &str, required: u32) -> String {
    format!("Minecraft {mc_version} needs Java {required} — drop a JDK {required} zip into java/")
}

/// Pick the best runtime for `required` (major version).
///
/// Java 8 versions must run on Java 8 (LaunchWrapper breaks on 9+). For 16+
/// a newer runtime is accepted if no exact match exists. Archives in `java/`
/// are preferred over system runtimes.
pub fn pick_runtime<'a>(
    runtimes: &'a [JavaRuntime],
    required: u32,
    mc_version: &str,
) -> JavaPick<'a> {
    let rank = |r: &JavaRuntime| -> (u8, String) {
        let archive = matches!(r.source, RuntimeSource::Archive { .. });
        (u8::from(archive), r.info.version.clone())
    };
    let host_arch_ok = |r: &&JavaRuntime| arch_matches_host(&r.info.arch);
    if let Some(r) = runtimes
        .iter()
        .filter(|r| r.info.major == required)
        .filter(host_arch_ok)
        .max_by_key(|r| rank(r))
    {
        return JavaPick::Exact(r);
    }
    if required >= 16 {
        if let Some(r) = runtimes
            .iter()
            .filter(|r| r.info.major > required)
            .filter(host_arch_ok)
            .min_by_key(|r| (r.info.major, std::cmp::Reverse(rank(r))))
        {
            return JavaPick::Compatible(r);
        }
    }
    JavaPick::Missing(missing_message(mc_version, required))
}

fn arch_matches_host(arch: &str) -> bool {
    if arch.is_empty() {
        return true;
    }
    let host = mclaunch_core::platform::os_arch();
    let norm = match arch {
        "amd64" | "x86_64" => "x86_64",
        "aarch64" | "arm64" => "arm64",
        "x86" | "i386" | "i686" => "x86",
        other => other,
    };
    // 32-bit Java on a 64-bit OS still runs.
    norm == host || (host == "x86_64" && norm == "x86")
}

#[cfg(test)]
mod tests {
    use super::*;

    fn rt(major: u32, version: &str, archive: bool) -> JavaRuntime {
        JavaRuntime {
            source: if archive {
                RuntimeSource::Archive {
                    file_name: format!("{major}.zip"),
                    sha256: "ab".repeat(32),
                }
            } else {
                RuntimeSource::System {
                    origin: "PATH".into(),
                }
            },
            java_bin: PathBuf::from(format!("/j/{major}/bin/java")),
            info: JavaInfo {
                version: version.into(),
                major,
                vendor: "Test".into(),
                arch: String::new(),
                java_home: PathBuf::new(),
            },
        }
    }

    #[test]
    fn picking() {
        let rts = vec![
            rt(8, "1.8.0_402", true),
            rt(17, "17.0.10", true),
            rt(21, "21.0.2", false),
            rt(21, "21.0.4", true),
        ];
        assert!(matches!(pick_runtime(&rts, 8, "1.8.9"), JavaPick::Exact(r) if r.info.major == 8));
        // archive preferred over system for the same major
        assert!(
            matches!(pick_runtime(&rts, 21, "1.21"), JavaPick::Exact(r) if r.info.version == "21.0.4")
        );
        // 16 -> 17 is acceptable
        assert!(
            matches!(pick_runtime(&rts, 16, "1.17"), JavaPick::Compatible(r) if r.info.major == 17)
        );
        // 25 missing
        match pick_runtime(&rts, 25, "26.3") {
            JavaPick::Missing(m) => assert_eq!(
                m,
                "Minecraft 26.3 needs Java 25 — drop a JDK 25 zip into java/"
            ),
            other => panic!("{other:?}"),
        }
        // 8 never falls back to newer
        let only_new = vec![rt(21, "21", true)];
        assert!(matches!(
            pick_runtime(&only_new, 8, "b1.7.3"),
            JavaPick::Missing(_)
        ));
    }

    #[test]
    fn archive_names() {
        assert!(is_archive_name(
            "OpenJDK21U-jdk_x64_windows_hotspot_21.0.4_7.zip"
        ));
        assert!(is_archive_name("jdk-17.tar.gz"));
        assert!(is_archive_name("JDK.TGZ"));
        assert!(!is_archive_name("notes.txt"));
    }

    #[test]
    fn find_binary_prefers_shallowest() {
        let dir = tempfile::tempdir().unwrap();
        let exe = mclaunch_core::platform::java_exe_name();
        let deep = dir.path().join("jdk-21/Contents/Home/bin");
        std::fs::create_dir_all(&deep).unwrap();
        std::fs::write(deep.join(exe), b"").unwrap();
        assert_eq!(find_java_binary(dir.path()).unwrap(), deep.join(exe));
        let shallow = dir.path().join("a/bin");
        std::fs::create_dir_all(&shallow).unwrap();
        std::fs::write(shallow.join(exe), b"").unwrap();
        assert_eq!(find_java_binary(dir.path()).unwrap(), shallow.join(exe));
    }
}
