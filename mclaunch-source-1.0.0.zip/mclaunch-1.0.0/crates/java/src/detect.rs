//! Detect a runtime's real version by running it.

use std::collections::BTreeMap;
use std::io::Read;
use std::path::{Path, PathBuf};
use std::process::{Command, Stdio};
use std::time::{Duration, Instant};

use serde::{Deserialize, Serialize};

use crate::{JavaError, Result};

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct JavaInfo {
    /// `java.version`, e.g. `21.0.4` or `1.8.0_402`.
    pub version: String,
    /// Major version from `java.specification.version` (`1.8` -> 8).
    pub major: u32,
    pub vendor: String,
    /// `os.arch`, e.g. `amd64`, `aarch64`.
    pub arch: String,
    pub java_home: PathBuf,
}

/// Parse the `-XshowSettings:properties` block into key/value pairs.
pub fn parse_properties(output: &str) -> BTreeMap<String, String> {
    let mut map = BTreeMap::new();
    for line in output.lines() {
        // Continuation lines of multi-value properties have no " = ".
        if let Some((k, v)) = line.split_once(" = ") {
            let key = k.trim();
            if !key.is_empty() && !key.contains(' ') {
                map.insert(key.to_string(), v.trim().to_string());
            }
        }
    }
    map
}

/// `1.8` -> 8, `17` -> 17, `21.0.1` -> 21.
pub fn parse_major(spec: &str) -> Option<u32> {
    let mut parts = spec.split(['.', '_', '-', '+']);
    let first: u32 = parts.next()?.parse().ok()?;
    if first == 1 {
        parts.next()?.parse().ok()
    } else {
        Some(first)
    }
}

pub fn info_from_properties(props: &BTreeMap<String, String>) -> Option<JavaInfo> {
    let version = props.get("java.version")?.clone();
    let major = props
        .get("java.specification.version")
        .and_then(|s| parse_major(s))
        .or_else(|| parse_major(&version))?;
    Some(JavaInfo {
        version,
        major,
        vendor: props
            .get("java.vendor")
            .or_else(|| props.get("java.vm.vendor"))
            .cloned()
            .unwrap_or_else(|| "unknown".into()),
        arch: props.get("os.arch").cloned().unwrap_or_default(),
        java_home: props
            .get("java.home")
            .map(PathBuf::from)
            .unwrap_or_default(),
    })
}

/// Run `java -XshowSettings:properties -version` (20 s timeout).
pub fn detect(java_bin: &Path) -> Result<JavaInfo> {
    let fail = |message: String| JavaError::Detect {
        path: java_bin.to_path_buf(),
        message,
    };
    let mut cmd = Command::new(java_bin);
    cmd.args(["-XshowSettings:properties", "-version"])
        .stdin(Stdio::null())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped());
    #[cfg(windows)]
    {
        use std::os::windows::process::CommandExt;
        cmd.creation_flags(0x0800_0000); // CREATE_NO_WINDOW
    }
    let mut child = cmd.spawn().map_err(|e| fail(e.to_string()))?;
    let mut stderr = child
        .stderr
        .take()
        .ok_or_else(|| fail("no stderr".into()))?;
    let mut stdout = child
        .stdout
        .take()
        .ok_or_else(|| fail("no stdout".into()))?;
    let err_reader = std::thread::spawn(move || {
        let mut s = String::new();
        let _ = stderr.read_to_string(&mut s);
        s
    });
    let out_reader = std::thread::spawn(move || {
        let mut s = String::new();
        let _ = stdout.read_to_string(&mut s);
        s
    });
    let deadline = Instant::now() + Duration::from_secs(20);
    loop {
        match child.try_wait() {
            Ok(Some(_)) => break,
            Ok(None) if Instant::now() < deadline => std::thread::sleep(Duration::from_millis(30)),
            Ok(None) => {
                let _ = child.kill();
                let _ = child.wait();
                return Err(fail("timed out".into()));
            }
            Err(e) => return Err(fail(e.to_string())),
        }
    }
    let text = format!(
        "{}\n{}",
        err_reader.join().unwrap_or_default(),
        out_reader.join().unwrap_or_default()
    );
    let props = parse_properties(&text);
    info_from_properties(&props).ok_or_else(|| fail("could not read java.version".into()))
}

#[cfg(test)]
mod tests {
    use super::*;

    const SAMPLE: &str = "Property settings:
    file.encoding = UTF-8
    java.class.path = 
    java.home = /opt/jdk-21.0.4+7
    java.library.path = /usr/java/packages/lib
        /usr/lib64
        /lib64
    java.specification.version = 21
    java.vendor = Eclipse Adoptium
    java.version = 21.0.4
    os.arch = amd64

openjdk version \"21.0.4\" 2024-07-16 LTS
";

    #[test]
    fn parses_modern() {
        let info = info_from_properties(&parse_properties(SAMPLE)).unwrap();
        assert_eq!(info.version, "21.0.4");
        assert_eq!(info.major, 21);
        assert_eq!(info.vendor, "Eclipse Adoptium");
        assert_eq!(info.arch, "amd64");
        assert_eq!(info.java_home, PathBuf::from("/opt/jdk-21.0.4+7"));
    }

    #[test]
    fn parses_java8() {
        let s = "    java.specification.version = 1.8\n    java.version = 1.8.0_402\n    java.vendor = Temurin\n";
        let info = info_from_properties(&parse_properties(s)).unwrap();
        assert_eq!(info.major, 8);
        assert_eq!(info.version, "1.8.0_402");
    }

    #[test]
    fn majors() {
        assert_eq!(parse_major("1.8"), Some(8));
        assert_eq!(parse_major("1.8.0_402"), Some(8));
        assert_eq!(parse_major("17"), Some(17));
        assert_eq!(parse_major("25-ea"), Some(25));
        assert_eq!(parse_major("x"), None);
    }

    #[test]
    fn detects_system_java_if_present() {
        let Some(home) = std::env::var_os("JAVA_HOME")
            .map(PathBuf::from)
            .or_else(|| {
                let p = PathBuf::from("/usr/lib/jvm/java-21-openjdk-amd64");
                p.exists().then_some(p)
            })
        else {
            return;
        };
        let bin = home
            .join("bin")
            .join(mclaunch_core::platform::java_exe_name());
        if !bin.is_file() {
            return;
        }
        let info = detect(&bin).unwrap();
        assert!(info.major >= 8);
    }
}
