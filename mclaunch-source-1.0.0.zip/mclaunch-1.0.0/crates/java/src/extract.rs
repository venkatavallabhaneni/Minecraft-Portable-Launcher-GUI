//! Safe extraction of runtime archives (no zip-slip, executable bits kept).

use std::fs::File;
use std::io::BufReader;
use std::path::Path;

use mclaunch_safety::SafePath;

use crate::{io_err, JavaError, Result, COMPLETE_MARKER};

/// Extract `archive` into `dest` atomically: unpack into a temp sibling,
/// then rename. `dest` is replaced if it exists (launcher-managed folder).
pub fn extract_archive(safe: &SafePath, archive: &Path, dest: &Path) -> Result<()> {
    let parent = dest
        .parent()
        .ok_or_else(|| JavaError::NoJavaBinary(dest.to_path_buf()))?;
    std::fs::create_dir_all(parent).map_err(io_err(parent))?;
    let tmp = parent.join(format!(
        ".tmp-{}-{}",
        dest.file_name()
            .map(|n| n.to_string_lossy().into_owned())
            .unwrap_or_default(),
        std::process::id()
    ));
    safe.remove_dir_all(&tmp)?;
    std::fs::create_dir_all(&tmp).map_err(io_err(&tmp))?;

    let name = archive.to_string_lossy().to_ascii_lowercase();
    let result = if name.ends_with(".zip") {
        extract_zip(archive, &tmp)
    } else {
        extract_tar_gz(archive, &tmp)
    };
    if let Err(e) = result {
        let _ = safe.remove_dir_all(&tmp);
        return Err(e);
    }
    mark_executables(&tmp);
    std::fs::write(
        tmp.join(COMPLETE_MARKER),
        archive.to_string_lossy().as_bytes(),
    )
    .map_err(io_err(&tmp))?;
    safe.remove_dir_all(dest)?;
    safe.rename(&tmp, dest)?;
    Ok(())
}

fn extract_zip(archive: &Path, dest: &Path) -> Result<()> {
    let bad = |message: String| JavaError::Archive {
        path: archive.to_path_buf(),
        message,
    };
    let file = File::open(archive).map_err(io_err(archive))?;
    let mut zip = zip::ZipArchive::new(BufReader::new(file)).map_err(|e| bad(e.to_string()))?;
    for i in 0..zip.len() {
        let mut entry = zip.by_index(i).map_err(|e| bad(e.to_string()))?;
        // `enclosed_name` rejects absolute paths and `..` (zip-slip).
        let Some(rel) = entry.enclosed_name() else {
            tracing::warn!(name = entry.name(), "skipping unsafe zip entry");
            continue;
        };
        let out = dest.join(rel);
        if entry.is_dir() {
            std::fs::create_dir_all(&out).map_err(io_err(&out))?;
            continue;
        }
        if let Some(p) = out.parent() {
            std::fs::create_dir_all(p).map_err(io_err(p))?;
        }
        let mut f = File::create(&out).map_err(io_err(&out))?;
        std::io::copy(&mut entry, &mut f).map_err(io_err(&out))?;
        #[cfg(unix)]
        if let Some(mode) = entry.unix_mode() {
            use std::os::unix::fs::PermissionsExt;
            let _ = std::fs::set_permissions(&out, std::fs::Permissions::from_mode(mode & 0o777));
        }
    }
    Ok(())
}

fn extract_tar_gz(archive: &Path, dest: &Path) -> Result<()> {
    let file = File::open(archive).map_err(io_err(archive))?;
    let gz = flate2::read::GzDecoder::new(BufReader::new(file));
    let mut tar = tar::Archive::new(gz);
    tar.set_preserve_permissions(true);
    // `unpack` refuses entries that would escape `dest`.
    tar.unpack(dest).map_err(|e| JavaError::Archive {
        path: archive.to_path_buf(),
        message: e.to_string(),
    })
}

/// Zips created on Windows carry no unix modes: make `bin/*` and helper
/// binaries executable.
#[cfg(unix)]
fn mark_executables(root: &Path) {
    use std::os::unix::fs::PermissionsExt;
    fn walk(dir: &Path) {
        let Ok(rd) = std::fs::read_dir(dir) else {
            return;
        };
        for e in rd.flatten() {
            let p = e.path();
            let Ok(ft) = e.file_type() else { continue };
            if ft.is_dir() {
                walk(&p);
            } else if ft.is_file() {
                let in_bin = p
                    .parent()
                    .and_then(|d| d.file_name())
                    .is_some_and(|n| n == "bin");
                let helper = p
                    .file_name()
                    .is_some_and(|n| n == "jspawnhelper" || n == "jexec");
                if in_bin || helper {
                    if let Ok(meta) = std::fs::metadata(&p) {
                        let mut perm = meta.permissions();
                        perm.set_mode(perm.mode() | 0o755);
                        let _ = std::fs::set_permissions(&p, perm);
                    }
                }
            }
        }
    }
    walk(root);
}

#[cfg(not(unix))]
fn mark_executables(_root: &Path) {}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;

    #[test]
    fn zip_extraction_skips_traversal_and_marks_bin() {
        let dir = tempfile::tempdir().unwrap();
        let safe = SafePath::new(dir.path()).unwrap();
        let root = safe.root().to_path_buf();
        let archive = root.join("java/test.zip");
        std::fs::create_dir_all(archive.parent().unwrap()).unwrap();
        {
            let f = File::create(&archive).unwrap();
            let mut z = zip::ZipWriter::new(f);
            let opts = zip::write::SimpleFileOptions::default();
            z.start_file("jdk-21/bin/java", opts).unwrap();
            z.write_all(b"#!/bin/sh\n").unwrap();
            z.start_file("../../evil.txt", opts).unwrap();
            z.write_all(b"evil").unwrap();
            z.finish().unwrap();
        }
        let dest = root.join("java/.extracted/abc");
        extract_archive(&safe, &archive, &dest).unwrap();
        let bin = dest.join("jdk-21/bin/java");
        assert!(bin.is_file());
        assert!(dest.join(COMPLETE_MARKER).is_file());
        assert!(!root.join("evil.txt").exists());
        assert!(!dir.path().join("evil.txt").exists());
        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt;
            assert!(std::fs::metadata(&bin).unwrap().permissions().mode() & 0o111 != 0);
        }
        // re-extract replaces cleanly
        extract_archive(&safe, &archive, &dest).unwrap();
        assert!(bin.is_file());
    }
}
