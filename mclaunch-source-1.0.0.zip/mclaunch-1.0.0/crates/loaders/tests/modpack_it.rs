//! Modpack installs against the real Modrinth and CurseForge services.
//! Network; ignored by default:
//! `cargo test -p mclaunch-loaders --test modpack_it -- --ignored --test-threads=1`
//!
//! With `MCLAUNCH_IT_ROOT` set, that launcher root is used (and kept) and
//! the Modrinth pack is installed completely, Minecraft and Fabric
//! included; otherwise a temporary root is used and the game install is
//! skipped.

use std::io::Write;
use std::path::{Path, PathBuf};
use std::sync::Arc;

use mclaunch_core::{InstanceConfig, LauncherPaths, LoaderKind, Progress, ProgressFn};
use mclaunch_download::{Http, Installer};
use mclaunch_loaders::modpack::{self, PackFormat};
use mclaunch_loaders::{modrinth, Loaders};
use mclaunch_safety::SafePath;

struct Root {
    _tmp: Option<tempfile::TempDir>,
    paths: LauncherPaths,
    safe: SafePath,
    loaders: Loaders,
    full: bool,
}

fn root() -> Root {
    let (tmp, dir) = match std::env::var_os("MCLAUNCH_IT_ROOT") {
        Some(d) => (None, PathBuf::from(d)),
        None => {
            let t = tempfile::tempdir().unwrap();
            let d = t.path().to_path_buf();
            (Some(t), d)
        }
    };
    let full = tmp.is_none();
    let safe = SafePath::new(&dir).unwrap();
    let paths = LauncherPaths::new(safe.root());
    paths.ensure_layout().unwrap();
    let loaders = Loaders::new(Installer::new(
        paths.clone(),
        safe.clone(),
        Http::new(false).unwrap(),
        16,
    ));
    Root {
        _tmp: tmp,
        paths,
        safe,
        loaders,
        full,
    }
}

/// Prints stage changes and download totals.
fn progress() -> ProgressFn {
    let last = std::sync::Mutex::new(String::new());
    Arc::new(move |p: Progress| {
        let mut l = last.lock().unwrap();
        if *l != p.stage {
            eprintln!("  .. {}", p.stage);
            *l = p.stage.clone();
        }
        if p.total > 0 && p.done == p.total {
            eprintln!("  .. {}/{} files, {} bytes", p.done, p.total, p.bytes_done);
        }
    })
}

async fn fetch(r: &Root, url: &str, name: &str) -> PathBuf {
    let dest = r.paths.cache_dir().join("it").join(name);
    r.loaders.fetch_file(url, &dest, None).await.unwrap();
    dest
}

fn zip_file(path: &Path, entries: &[(String, Vec<u8>)]) {
    let mut z = zip::ZipWriter::new(std::fs::File::create(path).unwrap());
    for (name, data) in entries {
        z.start_file(name.as_str(), zip::write::SimpleFileOptions::default())
            .unwrap();
        z.write_all(data).unwrap();
    }
    z.finish().unwrap();
}

fn mods_in(dir: &Path) -> Vec<String> {
    let mut v: Vec<String> = std::fs::read_dir(dir.join("mods"))
        .map(|rd| {
            rd.flatten()
                .map(|e| e.file_name().to_string_lossy().into_owned())
                .collect()
        })
        .unwrap_or_default();
    v.sort();
    v
}

#[tokio::test]
#[ignore = "network"]
async fn modrinth_pack() {
    let r = root();
    let l = &r.loaders;
    let versions = modrinth::project_versions(l, "fabulously-optimized", "fabric", "1.20.1")
        .await
        .unwrap();
    let v = versions
        .iter()
        .find(|v| v.version_number == "5.4.1")
        .or(versions.first())
        .unwrap();
    let file = v.primary_file().unwrap();
    let src = fetch(&r, &file.url, &file.filename).await;

    let pack = modpack::read_pack(&src, None).unwrap();
    eprintln!("{} {:?}: {} files, notes {:?}", pack.name, pack.version, pack.files.len(), pack.notes);
    assert_eq!(pack.format, PackFormat::Modrinth);
    assert_eq!(pack.mc_version.as_deref(), Some("1.20.1"));
    assert_eq!(pack.loader, LoaderKind::Fabric);
    assert!(pack.files.len() > 20);
    assert!(pack.files.iter().all(|f| f.sha512.is_some()));

    let started = std::time::Instant::now();
    let plan = modpack::plan(l, &pack, None, &progress()).await.unwrap();
    let plan = modpack::download(l, plan, &progress()).await.unwrap();
    eprintln!("downloaded in {:.1}s", started.elapsed().as_secs_f32());
    assert!(plan.manual.is_empty(), "{:?}", plan.manual);

    let mc = pack.mc_version.clone().unwrap();
    let loader_version = modpack::loader_version(l, &pack, &mc).await.unwrap();
    assert_eq!(loader_version, pack.loader_version);
    let mut cfg = InstanceConfig::new(
        &mclaunch_core::instance::unique_name(&r.paths, &modpack::instance_name(&pack.name)),
        &mc,
        modpack::suggested_memory_mb(&pack, 2048),
    );
    cfg.loader = pack.loader;
    cfg.loader_version = loader_version.clone();
    if r.full {
        let installed = l
            .install_client(
                mclaunch_loaders::Software::Fabric,
                &mc,
                loader_version.as_deref().unwrap(),
                None,
                &progress(),
            )
            .await
            .unwrap();
        cfg.version_id = installed.version_id;
    }
    let report = modpack::create_instance(&r.paths, &r.safe, &pack, &plan, &cfg).unwrap();
    let mods = mods_in(&report.dir);
    eprintln!("instance {} -> {} mods, {} overrides", cfg.name, mods.len(), report.overrides);
    assert_eq!(report.added, plan.downloads.len());
    assert!(report.overrides > 0, "Fabulously Optimized ships configs");
    assert!(mods.iter().any(|m| m.starts_with("sodium")), "{mods:?}");
    assert!(report.dir.join("config").is_dir());
    assert_eq!(cfg.max_memory_mb, 4096);
    let saved = InstanceConfig::load(&report.dir).unwrap();
    assert_eq!(saved.loader, LoaderKind::Fabric);

    // Reinstall offline from the cache.
    l.http().set_offline(true);
    let plan = modpack::plan(l, &pack, None, &progress()).await.unwrap();
    modpack::download(l, plan, &progress()).await.unwrap();
    l.http().set_offline(false);
}

#[tokio::test]
#[ignore = "network"]
async fn curseforge_pack_without_key() {
    let r = root();
    let l = &r.loaders;
    // Two real files (JEI, Waystones) plus a file id that does not exist.
    let manifest = serde_json::json!({
        "minecraft": {"version": "1.20.1", "modLoaders": [{"id": "forge-47.2.0", "primary": true}]},
        "manifestType": "minecraftModpack", "manifestVersion": 1,
        "name": "IT CurseForge Pack", "version": "1.0", "author": "mclaunch",
        "files": [
            {"projectID": 238222, "fileID": 4593548, "required": true},
            {"projectID": 245755, "fileID": 8969754, "required": true},
            {"projectID": 238222, "fileID": 1, "required": true}
        ],
        "overrides": "overrides"
    });
    let src = r.paths.cache_dir().join("it/cf-pack.zip");
    std::fs::create_dir_all(src.parent().unwrap()).unwrap();
    zip_file(
        &src,
        &[
            ("manifest.json".into(), manifest.to_string().into_bytes()),
            ("overrides/config/jei/jei-client.ini".into(), b"[x]".to_vec()),
        ],
    );
    let pack = modpack::read_pack(&src, None).unwrap();
    assert_eq!(pack.format, PackFormat::CurseForge);
    assert_eq!(pack.loader, LoaderKind::Forge);
    assert_eq!(pack.curseforge.len(), 3);

    let plan = modpack::plan(l, &pack, None, &progress()).await.unwrap();
    eprintln!("downloads {:?}", plan.downloads.iter().map(|d| &d.file_name).collect::<Vec<_>>());
    eprintln!("manual {:?}", plan.manual.iter().map(|m| (&m.name, &m.reason)).collect::<Vec<_>>());
    assert_eq!(plan.downloads.len(), 2);
    assert_eq!(plan.manual.len(), 1, "the bogus file id cannot be resolved");
    assert!(plan.manual[0].url.contains("curseforge.com"));
    let plan = modpack::download(l, plan, &progress()).await.unwrap();
    for d in &plan.downloads {
        let len = std::fs::metadata(&d.cache).unwrap().len();
        assert_eq!(Some(len), d.size, "{}", d.file_name);
    }
    let cfg = InstanceConfig::new("IT CurseForge Pack", "1.20.1", 4096);
    let report = modpack::create_instance(&r.paths, &r.safe, &pack, &plan, &cfg);
    let report = match report {
        Err(e) if e.to_string().contains("already exists") && r.full => return,
        other => other.unwrap(),
    };
    let mods = mods_in(&report.dir);
    assert!(mods.iter().any(|m| m.starts_with("jei-1.18.2")), "{mods:?}");
    assert!(report.dir.join("config/jei/jei-client.ini").is_file());
    let record = modpack::load_record(&report.dir).unwrap();
    assert_eq!(record.manual.len(), 1);
}

#[tokio::test]
#[ignore = "network"]
async fn plain_zip_fetches_missing_fabric_api() {
    let r = root();
    let l = &r.loaders;
    let mut entries = Vec::new();
    // Mod Menu bundles the Fabric API modules it needs; Continuity needs
    // Fabric API; Zoomify needs Fabric Language Kotlin and YACL.
    for (project, loader) in [
        ("modmenu", "fabric"),
        ("continuity", "fabric"),
        ("zoomify", "fabric"),
    ] {
        let vs = modrinth::project_versions(l, project, loader, "1.20.1")
            .await
            .unwrap();
        let f = modrinth::best(&vs).unwrap().primary_file().unwrap().clone();
        let path = fetch(&r, &f.url, &f.filename).await;
        entries.push((
            format!("Plain Pack/.minecraft/mods/{}", f.filename),
            std::fs::read(path).unwrap(),
        ));
    }
    entries.push(("Plain Pack/.minecraft/options.txt".into(), b"renderDistance:8".to_vec()));
    let src = r.paths.cache_dir().join("it/Plain Pack.zip");
    zip_file(&src, &entries);

    assert_eq!(modpack::sniff(&src), Some(PackFormat::Generic));
    let pack = modpack::read_pack(&src, None).unwrap();
    eprintln!("notes {:#?}", pack.notes);
    assert_eq!(pack.mc_version.as_deref(), Some("1.20.1"));
    assert_eq!(pack.loader, LoaderKind::Fabric);
    let missing = pack.missing_deps(LoaderKind::Fabric);
    eprintln!("missing {missing:?}");
    assert!(missing.contains(&"fabric-api".to_string()), "{missing:?}");
    assert!(
        !missing.iter().any(|m| m.starts_with("fabric-screen")),
        "nested in Mod Menu"
    );

    let plan = modpack::plan(l, &pack, None, &progress()).await.unwrap();
    eprintln!("plan notes {:#?}", plan.notes);
    let names: Vec<&str> = plan.downloads.iter().map(|d| d.file_name.as_str()).collect();
    eprintln!("adding {names:?}");
    for want in ["fabric-api", "fabric-language-kotlin", "yet_another_config_lib"] {
        assert!(names.iter().any(|n| n.starts_with(want)), "{want} in {names:?}");
    }
    let plan = modpack::download(l, plan, &progress()).await.unwrap();

    let version = modpack::loader_version(l, &pack, "1.20.1").await.unwrap();
    eprintln!("Fabric loader {version:?}");
    assert!(version.is_some());
    let cfg = InstanceConfig::new(
        &mclaunch_core::instance::unique_name(&r.paths, "Plain Pack"),
        "1.20.1",
        4096,
    );
    let report = modpack::create_instance(&r.paths, &r.safe, &pack, &plan, &cfg).unwrap();
    let mods = mods_in(&report.dir);
    assert_eq!(mods.len(), 3 + plan.downloads.len(), "{mods:?}");
    assert!(report.dir.join("options.txt").is_file());
}

#[tokio::test]
#[ignore = "network"]
async fn plain_zip_detects_forge() {
    let r = root();
    let l = &r.loaders;
    let vs = modrinth::project_versions(l, "jei", "forge", "1.20.1")
        .await
        .unwrap();
    let f = modrinth::best(&vs).unwrap().primary_file().unwrap().clone();
    let jar = fetch(&r, &f.url, &f.filename).await;
    let src = r.paths.cache_dir().join("it/forge-pack.zip");
    zip_file(
        &src,
        &[(format!("mods/{}", f.filename), std::fs::read(jar).unwrap())],
    );
    let pack = modpack::read_pack(&src, None).unwrap();
    eprintln!("notes {:#?}", pack.notes);
    assert_eq!(pack.loader, LoaderKind::Forge);
    assert_eq!(pack.mc_version.as_deref(), Some("1.20.1"));
    let version = modpack::loader_version(l, &pack, "1.20.1")
        .await
        .unwrap()
        .unwrap();
    eprintln!("Forge {version} (mods need >= {:?})", pack.loader_min);
    assert!(version.starts_with("1.20.1-47."));
}
