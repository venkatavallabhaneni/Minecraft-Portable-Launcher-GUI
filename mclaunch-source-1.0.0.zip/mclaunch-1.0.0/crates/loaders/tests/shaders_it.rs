//! Resolve and download the one-click shader stacks from Modrinth into a
//! temporary instance. Network; ignored by default:
//! `cargo test -p mclaunch-loaders --test shaders_it -- --ignored`

use mclaunch_core::progress::noop_progress;
use mclaunch_core::{LauncherPaths, LoaderKind};
use mclaunch_download::{Http, Installer};
use mclaunch_loaders::{shaders, Loaders};
use mclaunch_safety::SafePath;

async fn enable(loader: LoaderKind, mc: &str) -> shaders::EnableReport {
    let dir = tempfile::tempdir().unwrap();
    let safe = SafePath::new(dir.path()).unwrap();
    let paths = LauncherPaths::new(safe.root());
    paths.ensure_layout().unwrap();
    let l = Loaders::new(Installer::new(
        paths.clone(),
        safe,
        Http::new(false).unwrap(),
        8,
    ));
    let inst = paths.instance_dir("shaders");
    std::fs::create_dir_all(inst.join("mods")).unwrap();
    let r = shaders::enable(&l, loader, mc, &inst, &noop_progress())
        .await
        .unwrap();
    eprintln!("{loader:?} {mc}: {} -> {:?}", r.engine, r.added);
    assert!(r.config_created);
    assert!(r.added.len() >= 2);
    let st = shaders::status(&inst, loader);
    assert_eq!(st.engine.as_deref(), Some(r.engine.as_str()));
    assert_eq!(st.enabled, Some(true));
    // second run adds nothing and keeps the config
    let again = shaders::enable(&l, loader, mc, &inst, &noop_progress())
        .await
        .unwrap();
    assert!(again.added.is_empty());
    assert!(!again.config_created);
    r
}

#[tokio::test]
#[ignore = "network"]
async fn fabric_iris() {
    assert_eq!(enable(LoaderKind::Fabric, "1.21.4").await.engine, "Iris");
}

#[tokio::test]
#[ignore = "network"]
async fn neoforge_stack() {
    enable(LoaderKind::NeoForge, "1.21.1").await;
}

#[tokio::test]
#[ignore = "network"]
async fn forge_oculus() {
    assert_eq!(enable(LoaderKind::Forge, "1.20.1").await.engine, "Oculus");
}

#[tokio::test]
#[ignore = "network"]
async fn vanilla_needs_optifine() {
    let dir = tempfile::tempdir().unwrap();
    let safe = SafePath::new(dir.path()).unwrap();
    let paths = LauncherPaths::new(safe.root());
    let l = Loaders::new(Installer::new(
        paths.clone(),
        safe,
        Http::new(true).unwrap(),
        1,
    ));
    let err = shaders::enable(
        &l,
        LoaderKind::Vanilla,
        "1.21.4",
        &paths.instance_dir("v"),
        &noop_progress(),
    )
    .await
    .unwrap_err();
    assert!(err.to_string().contains("OptiFine"));
}
