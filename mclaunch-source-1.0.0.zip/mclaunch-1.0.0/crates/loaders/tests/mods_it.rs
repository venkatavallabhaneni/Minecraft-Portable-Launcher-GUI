//! Mod search / install / update / global sync against the real Modrinth
//! and CurseForge services. Network; ignored by default:
//! `cargo test -p mclaunch-loaders --test mods_it -- --ignored --test-threads=1`

use mclaunch_core::progress::noop_progress;
use mclaunch_core::{LauncherPaths, LoaderKind};
use mclaunch_download::{Http, Installer};
use mclaunch_loaders::mods::{self, ProjectRef, Source, Target};
use mclaunch_loaders::{modrinth, Loaders};
use mclaunch_safety::SafePath;

struct Root {
    _d: tempfile::TempDir,
    paths: LauncherPaths,
    safe: SafePath,
    l: Loaders,
}

fn root() -> Root {
    let d = tempfile::tempdir().unwrap();
    let safe = SafePath::new(d.path()).unwrap();
    let paths = LauncherPaths::new(safe.root());
    paths.ensure_layout().unwrap();
    let l = Loaders::new(Installer::new(
        paths.clone(),
        safe.clone(),
        Http::new(false).unwrap(),
        8,
    ));
    Root { _d: d, paths, safe, l }
}

fn target(r: &Root, name: &str, loader: LoaderKind, mc: &str) -> Target {
    let dir = r.paths.instance_dir(name);
    std::fs::create_dir_all(dir.join("mods")).unwrap();
    Target {
        dir,
        loader,
        mc: mc.into(),
    }
}

#[tokio::test]
#[ignore = "network"]
async fn modrinth_search_and_install_with_dependencies() {
    let r = root();
    let t = target(&r, "Fab", LoaderKind::Fabric, "1.20.1");
    let hits = mods::search(&r.l, None, Source::Modrinth, "zoomify", Some((t.loader, &t.mc)))
        .await
        .unwrap();
    let hit = hits
        .iter()
        .find(|h| h.project.title.to_lowercase().starts_with("zoomify"))
        .unwrap_or_else(|| panic!("{hits:?}"));
    let rep = mods::install(&r.l, None, &hit.project, &t, false, &noop_progress())
        .await
        .unwrap();
    eprintln!("{rep:?}");
    assert_eq!(rep.installed[0], hit.project.title);
    assert!(rep.installed.len() >= 3, "Zoomify needs YACL and Kotlin: {rep:?}");
    let list = mods::list_installed(&t.dir);
    assert_eq!(list.len(), rep.installed.len());
    assert!(list.iter().all(|m| m.source() == Source::Modrinth));
    // A second install finds everything present.
    let again = mods::install(&r.l, None, &hit.project, &t, false, &noop_progress())
        .await
        .unwrap();
    assert!(again.installed.is_empty());

    // Forge instance: no Fabric-only result.
    let forge = target(&r, "Forge", LoaderKind::Forge, "1.20.1");
    let err = mods::install(&r.l, None, &hit.project, &forge, false, &noop_progress())
        .await
        .unwrap_err();
    assert!(err.to_string().contains("no version"), "{err}");
}

#[tokio::test]
#[ignore = "network"]
async fn curseforge_install_by_id_without_key() {
    let r = root();
    let t = target(&r, "Neo", LoaderKind::NeoForge, "1.21.1");
    // Waystones requires Balm.
    let p = ProjectRef {
        source: Source::CurseForge,
        id: "245755".into(),
        title: String::new(),
    };
    let rep = mods::install(&r.l, None, &p, &t, false, &noop_progress())
        .await
        .unwrap();
    eprintln!("{rep:?}");
    let list = mods::list_installed(&t.dir);
    let files: Vec<&str> = list.iter().map(|m| m.file.as_str()).collect();
    assert!(files.iter().any(|f| f.starts_with("waystones-neoforge-1.21.1")), "{files:?}");
    assert!(files.iter().any(|f| f.starts_with("balm-neoforge-1.21.1")), "{files:?}");
    assert!(list.iter().all(|m| m.source() == Source::CurseForge));
}

#[tokio::test]
#[ignore = "network"]
async fn update_an_old_jar() {
    let r = root();
    let t = target(&r, "Old", LoaderKind::Fabric, "1.20.1");
    let versions = modrinth::project_versions(&r.l, "sodium", "fabric", "1.20.1")
        .await
        .unwrap();
    let old = versions.last().unwrap().primary_file().unwrap().clone();
    // Downloads never write into mods/ directly: fetch, then add.
    let cached = r.paths.cache_dir().join(&old.filename);
    r.l.fetch_file(&old.url, &cached, old.hashes.sha1.clone())
        .await
        .unwrap();
    let jar = t.mods_dir().join(&old.filename);
    r.safe.copy_new(&cached, &jar).unwrap();
    let list = mods::list_installed(&t.dir);
    let updates = mods::check_updates(&r.l, &t, &list).await.unwrap();
    eprintln!("{} -> {:?}", old.filename, updates.iter().map(|u| &u.to.version).collect::<Vec<_>>());
    assert_eq!(updates.len(), 1);
    mods::apply_update(&r.l, &t, &updates[0]).await.unwrap();
    let list = mods::list_installed(&t.dir);
    assert_eq!(list.len(), 1);
    assert_eq!(list[0].file, updates[0].to.file_name);
    assert!(!jar.exists(), "old jar went to the recycle bin");
}

#[tokio::test]
#[ignore = "network"]
async fn global_modrinth_mod_follows_each_instance() {
    let r = root();
    let p = ProjectRef {
        source: Source::Modrinth,
        id: "AANobbMI".into(), // Sodium
        title: "Sodium".into(),
    };
    mods::add_global(&r.safe, &r.paths, &p).unwrap();
    let fab20 = target(&r, "Fabric 1.20.1", LoaderKind::Fabric, "1.20.1");
    let fab21 = target(&r, "Fabric 1.21.1", LoaderKind::Fabric, "1.21.1");
    for t in [&fab20, &fab21] {
        let rep = mods::sync_global(&r.l, None, &r.paths, t, &noop_progress()).await;
        eprintln!("{}: {rep:?}", t.mc);
        assert_eq!(rep.added, ["Sodium"]);
    }
    let a = mods::list_installed(&fab20.dir);
    let b = mods::list_installed(&fab21.dir);
    assert_ne!(a[0].file, b[0].file, "a different Sodium build for each version");
    assert!(a[0].record.as_ref().unwrap().global);
}

#[tokio::test]
#[ignore = "network"]
async fn pick_and_install_an_older_version() {
    let r = root();
    let sodium = ProjectRef {
        source: Source::Modrinth,
        id: "AANobbMI".into(),
        title: "Sodium".into(),
    };
    let all = mods::list_versions(&r.l, None, &sodium).await.unwrap();
    eprintln!("Sodium: {} versions", all.len());
    let older: Vec<_> = all
        .iter()
        .filter(|v| v.game_versions.iter().any(|g| g == "1.20.1") && v.loaders.contains(&LoaderKind::Fabric))
        .collect();
    assert!(older.len() > 3);
    let pick = older[older.len() - 1]; // the oldest for 1.20.1
    let t = target(&r, "Pinned", LoaderKind::Fabric, "1.20.1");
    let rep = mods::install_version(&r.l, None, pick, &t, &noop_progress())
        .await
        .unwrap();
    eprintln!("{} -> {rep:?}", pick.file.version);
    let list = mods::list_installed(&t.dir);
    assert_eq!(list[0].file, pick.file.file_name);
    // The same version again is refused; another one replaces it.
    let err = mods::install_version(&r.l, None, pick, &t, &noop_progress())
        .await
        .unwrap_err();
    assert!(err.to_string().contains("already installed"), "{err}");
    mods::install_version(&r.l, None, older[0], &t, &noop_progress())
        .await
        .unwrap();
    let list = mods::list_installed(&t.dir);
    assert_eq!(list.len(), 1, "old jar replaced: {list:?}");
    assert_eq!(list[0].file, older[0].file.file_name);

    // CurseForge without a key: Waystones' versions with loaders parsed,
    // and a pinned install pulls in Balm.
    let ways = ProjectRef {
        source: Source::CurseForge,
        id: "245755".into(),
        title: String::new(),
    };
    let cf = mods::list_versions(&r.l, None, &ways).await.unwrap();
    let pick = cf
        .iter()
        .find(|v| v.game_versions.iter().any(|g| g == "1.20.1") && v.loaders.contains(&LoaderKind::Forge))
        .expect("a Forge 1.20.1 build");
    eprintln!("Waystones {} versions; picked {}", cf.len(), pick.file.file_name);
    let t = target(&r, "Forge", LoaderKind::Forge, "1.20.1");
    let rep = mods::install_version(&r.l, None, pick, &t, &noop_progress())
        .await
        .unwrap();
    eprintln!("{rep:?}");
    assert!(rep.installed.iter().any(|n| n.contains("Balm")), "{rep:?}");
}
