//! Forge and NeoForge.
//!
//! * Modern installers (Forge 1.12.2+ and every NeoForge) are run headless
//!   with `--installClient <launcher root>`; our folder layout is the same
//!   as `.minecraft`, so the installer writes straight into it.
//! * Legacy installers (Forge ≤1.12.1, `install_profile.json` with
//!   `versionInfo`) are installed by hand: the embedded version JSON is
//!   written to `versions/` and the universal jar copied into `libraries/`.

use std::path::Path;
use std::time::Duration;

use mclaunch_core::maven::MavenCoord;
use mclaunch_core::{Progress, ProgressFn};
use serde::Deserialize;

use crate::{read_zip_entry, version_cmp, LoaderError, LoaderVersion, Loaders, Result};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ForgeFlavor {
    Forge,
    NeoForge,
}

const FORGE_METADATA: &str =
    "https://maven.minecraftforge.net/net/minecraftforge/forge/maven-metadata.xml";
const FORGE_PROMOTIONS: &str =
    "https://files.minecraftforge.net/net/minecraftforge/forge/promotions_slim.json";
const NEO_VERSIONS: &str =
    "https://maven.neoforged.net/api/maven/versions/releases/net/neoforged/neoforge";
const NEO_LEGACY_VERSIONS: &str =
    "https://maven.neoforged.net/api/maven/versions/releases/net/neoforged/forge";

/// Shown in the UI: Forge asks automated installers to mention support.
pub const FORGE_SUPPORT_URL: &str = "https://www.patreon.com/LexManos/";

impl ForgeFlavor {
    fn dir(self) -> &'static str {
        match self {
            ForgeFlavor::Forge => "forge",
            ForgeFlavor::NeoForge => "neoforge",
        }
    }
}

/// Minecraft version a NeoForge version targets:
/// `21.1.200` -> `1.21.1`, `20.4.237` -> `1.20.4`, `21.0.5-beta` -> `1.21`,
/// `26.3.0.76` -> `26.3`, `26.1.2.5` -> `26.1.2`.
pub fn neo_mc_version(v: &str) -> Option<String> {
    let core = v.split(['-', '+']).next()?;
    let parts: Vec<&str> = core.split('.').collect();
    if parts.len() < 3 {
        return None;
    }
    let major: u32 = parts[0].parse().ok()?;
    let minor: u32 = parts[1].parse().ok()?;
    if major >= 25 {
        // Year-based Minecraft versions: A.B[.C].build
        let patch: u32 = if parts.len() >= 4 {
            parts[2].parse().ok()?
        } else {
            0
        };
        return Some(if patch == 0 {
            format!("{major}.{minor}")
        } else {
            format!("{major}.{minor}.{patch}")
        });
    }
    if major < 20 {
        return None;
    }
    Some(if minor == 0 {
        format!("1.{major}")
    } else {
        format!("1.{major}.{minor}")
    })
}

#[derive(Debug, Deserialize)]
struct NeoVersions {
    #[serde(default)]
    versions: Vec<String>,
}

#[derive(Debug, Deserialize)]
struct Promotions {
    #[serde(default)]
    promos: std::collections::BTreeMap<String, String>,
}

fn parse_maven_versions(xml: &str) -> Vec<String> {
    let re = regex::Regex::new(r"<version>([^<]+)</version>").expect("valid regex");
    re.captures_iter(xml)
        .map(|c| c[1].trim().to_string())
        .collect()
}

pub async fn versions(
    l: &Loaders,
    flavor: ForgeFlavor,
    mc: &str,
) -> Result<(Vec<LoaderVersion>, bool)> {
    let dir = l.cache_dir(flavor.dir());
    let mut out: Vec<LoaderVersion>;
    let cached;
    match flavor {
        ForgeFlavor::Forge => {
            let (xml, c) = l
                .cached_get(FORGE_METADATA, &dir.join("maven-metadata.xml"))
                .await?;
            cached = c;
            let prefix = format!("{mc}-");
            out = parse_maven_versions(&String::from_utf8_lossy(&xml))
                .into_iter()
                .filter(|v| v.starts_with(&prefix))
                .map(|v| LoaderVersion::new(v, true))
                .collect();
            if let Ok((promos, _)) = l
                .cached_json::<Promotions>(FORGE_PROMOTIONS, &dir.join("promotions_slim.json"))
                .await
            {
                let rec = promos.promos.get(&format!("{mc}-recommended"));
                for v in &mut out {
                    let short = v.version.trim_start_matches(&prefix);
                    if rec.is_some_and(|r| short == r || short.starts_with(&format!("{r}-"))) {
                        v.recommended = true;
                    }
                }
            }
        }
        ForgeFlavor::NeoForge => {
            if mc == "1.20.1" {
                let (list, c) = l
                    .cached_json::<NeoVersions>(
                        NEO_LEGACY_VERSIONS,
                        &dir.join("versions-forge.json"),
                    )
                    .await?;
                cached = c;
                out = list
                    .versions
                    .into_iter()
                    .filter(|v| v.starts_with("1.20.1-"))
                    .map(|v| LoaderVersion::new(v, true))
                    .collect();
            } else {
                let (list, c) = l
                    .cached_json::<NeoVersions>(NEO_VERSIONS, &dir.join("versions-neoforge.json"))
                    .await?;
                cached = c;
                out = list
                    .versions
                    .into_iter()
                    .filter(|v| neo_mc_version(v).as_deref() == Some(mc))
                    .map(|v| {
                        let stable = !v.contains("beta") && !v.contains("alpha");
                        LoaderVersion::new(v, stable)
                    })
                    .collect();
            }
        }
    }
    out.sort_by(|a, b| version_cmp(&b.version, &a.version));
    Ok((out, cached))
}

fn installer_url(flavor: ForgeFlavor, version: &str) -> String {
    match flavor {
        ForgeFlavor::Forge => format!(
            "https://maven.minecraftforge.net/net/minecraftforge/forge/{version}/forge-{version}-installer.jar"
        ),
        ForgeFlavor::NeoForge if version.starts_with("1.20.1-") => format!(
            "https://maven.neoforged.net/releases/net/neoforged/forge/{version}/forge-{version}-installer.jar"
        ),
        ForgeFlavor::NeoForge => format!(
            "https://maven.neoforged.net/releases/net/neoforged/neoforge/{version}/neoforge-{version}-installer.jar"
        ),
    }
}

#[derive(Debug, Deserialize)]
struct LegacyInstall {
    target: String,
    path: String,
    #[serde(rename = "filePath")]
    file_path: String,
    #[serde(default)]
    minecraft: Option<String>,
}

/// Install Forge/NeoForge `version` for `mc`. Returns the new version id.
pub async fn install(
    l: &Loaders,
    flavor: ForgeFlavor,
    mc: &str,
    version: &str,
    java: &Path,
    progress: &ProgressFn,
) -> Result<String> {
    if !mclaunch_safety::is_plain_name(version) {
        return Err(LoaderError::Failed(format!("bad version '{version}'")));
    }
    let dir = l.cache_dir(flavor.dir());
    l.safe().create_dir_all(&dir)?;
    let url = installer_url(flavor, version);
    let file_name = url
        .rsplit('/')
        .next()
        .unwrap_or("installer.jar")
        .to_string();
    let jar = dir.join(&file_name);
    progress(Progress::stage(format!("Downloading {file_name}")));
    l.fetch_file(&url, &jar, None).await?;

    let profile = read_zip_entry(&jar, "install_profile.json")?
        .ok_or_else(|| LoaderError::Failed(format!("{file_name} has no install_profile.json")))?;
    let profile: serde_json::Value =
        serde_json::from_slice(&profile).map_err(|e| LoaderError::Parse {
            what: file_name.clone(),
            message: e.to_string(),
        })?;

    if profile.get("versionInfo").is_some() {
        return install_legacy(l, &jar, &profile, mc).await;
    }

    // Modern installer. It insists on a launcher_profiles.json.
    let profiles = l.paths().root.join("launcher_profiles.json");
    if !profiles.exists() {
        l.safe().create_new(&profiles, br#"{"profiles":{}}"#)?;
    }
    let id = read_zip_entry(&jar, "version.json")?
        .and_then(|b| serde_json::from_slice::<serde_json::Value>(&b).ok())
        .and_then(|v| v.get("id").and_then(|s| s.as_str()).map(str::to_string))
        .ok_or_else(|| LoaderError::Failed(format!("{file_name} has no version.json")))?;
    if !mclaunch_safety::is_plain_name(&id) {
        return Err(LoaderError::Failed(format!("bad version id '{id}'")));
    }
    let label = match flavor {
        ForgeFlavor::Forge => "Forge installer",
        ForgeFlavor::NeoForge => "NeoForge installer",
    };
    prefetch_libraries(l, &jar, &profile, progress).await;
    let args = vec![
        "-jar".to_string(),
        jar.to_string_lossy().into_owned(),
        "--installClient".to_string(),
        l.paths().root.to_string_lossy().into_owned(),
    ];
    crate::run_java(
        java,
        &args,
        &dir,
        label,
        progress,
        Duration::from_secs(30 * 60),
    )
    .await?;
    if !l.paths().version_json(&id).is_file() {
        return Err(LoaderError::Failed(format!(
            "{label} finished but versions/{id}/{id}.json is missing"
        )));
    }
    tracing::info!(%id, "forge-style loader installed");
    Ok(id)
}

/// Download every library the installer will need with our own downloader
/// (parallel, retries, mirrors) so the installer finds them already present.
/// Failures are ignored here; the installer retries them itself.
async fn prefetch_libraries(
    l: &Loaders,
    jar: &Path,
    profile: &serde_json::Value,
    progress: &ProgressFn,
) {
    let mut libs: Vec<mclaunch_core::Library> = Vec::new();
    if let Some(list) = profile.get("libraries") {
        if let Ok(v) = serde_json::from_value::<Vec<mclaunch_core::Library>>(list.clone()) {
            libs.extend(v);
        }
    }
    if let Ok(Some(bytes)) = read_zip_entry(jar, "version.json") {
        if let Ok(v) = serde_json::from_slice::<mclaunch_core::VersionJson>(&bytes) {
            libs.extend(v.libraries);
        }
    }
    let tasks: Vec<_> = libs
        .iter()
        .filter_map(|lib| lib.artifact())
        .filter(|a| !a.url.is_empty())
        .map(|a| mclaunch_download::install::library_task(l.paths(), &a))
        .collect();
    if tasks.is_empty() {
        return;
    }
    let summary = l
        .installer
        .downloader()
        .run(tasks, "Downloading installer libraries", progress)
        .await;
    if !summary.is_ok() {
        tracing::warn!("{}", summary.failure_text());
    }
}

/// Install a Forge/NeoForge *server* into `dir` with the official
/// installer (`--installServer`). Works for legacy and modern installers.
pub async fn install_server(
    l: &Loaders,
    flavor: ForgeFlavor,
    version: &str,
    dir: &Path,
    java: &Path,
    progress: &ProgressFn,
) -> Result<()> {
    if !mclaunch_safety::is_plain_name(version) {
        return Err(LoaderError::Failed(format!("bad version '{version}'")));
    }
    let cache = l.cache_dir(flavor.dir());
    l.safe().create_dir_all(&cache)?;
    let url = installer_url(flavor, version);
    let file_name = url
        .rsplit('/')
        .next()
        .unwrap_or("installer.jar")
        .to_string();
    let jar = cache.join(&file_name);
    progress(Progress::stage(format!("Downloading {file_name}")));
    l.fetch_file(&url, &jar, None).await?;
    l.safe().create_dir_all(dir)?;
    let args = vec![
        "-jar".to_string(),
        jar.to_string_lossy().into_owned(),
        "--installServer".to_string(),
        dir.to_string_lossy().into_owned(),
    ];
    crate::run_java(
        java,
        &args,
        dir,
        "Server installer",
        progress,
        Duration::from_secs(30 * 60),
    )
    .await?;
    Ok(())
}

async fn install_legacy(
    l: &Loaders,
    jar: &Path,
    profile: &serde_json::Value,
    mc: &str,
) -> Result<String> {
    let install: LegacyInstall =
        serde_json::from_value(profile["install"].clone()).map_err(|e| LoaderError::Parse {
            what: "install_profile.json".into(),
            message: e.to_string(),
        })?;
    let id = install.target.clone();
    if !mclaunch_safety::is_plain_name(&id) {
        return Err(LoaderError::Failed(format!("bad version id '{id}'")));
    }
    let mut info = profile["versionInfo"].clone();
    // Very old profiles do not inherit; make them layer on vanilla.
    let base = install.minecraft.clone().unwrap_or_else(|| mc.to_string());
    if info.get("inheritsFrom").is_none() {
        info["inheritsFrom"] = serde_json::Value::String(base.clone());
    }
    if info.get("jar").is_none() {
        info["jar"] = serde_json::Value::String(base);
    }
    let coord: MavenCoord = install.path.parse().map_err(LoaderError::Failed)?;
    let universal = read_zip_entry(jar, &install.file_path)?
        .ok_or_else(|| LoaderError::Failed(format!("installer lacks {}", install.file_path)))?;
    let lib_path = l.paths().libraries_dir().join(coord.path());
    l.safe().write(&lib_path, &universal)?;
    let bytes = serde_json::to_vec_pretty(&info).map_err(|e| LoaderError::Failed(e.to_string()))?;
    l.safe().write(&l.paths().version_json(&id), &bytes)?;
    tracing::info!(%id, "legacy forge installed");
    Ok(id)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn neo_mapping() {
        assert_eq!(neo_mc_version("21.1.200").as_deref(), Some("1.21.1"));
        assert_eq!(neo_mc_version("20.4.237").as_deref(), Some("1.20.4"));
        assert_eq!(neo_mc_version("21.0.5-beta").as_deref(), Some("1.21"));
        assert_eq!(neo_mc_version("26.3.0.76").as_deref(), Some("26.3"));
        assert_eq!(neo_mc_version("26.3.0.69-beta").as_deref(), Some("26.3"));
        assert_eq!(neo_mc_version("26.1.2.5").as_deref(), Some("26.1.2"));
        assert_eq!(neo_mc_version("0.25w14craftmine.3-beta"), None);
    }

    #[test]
    fn maven_xml() {
        let xml = "<metadata><versioning><versions><version>1.21-51.0.33</version>\n<version>1.20.1-47.2.0</version></versions></versioning></metadata>";
        assert_eq!(
            parse_maven_versions(xml),
            vec!["1.21-51.0.33", "1.20.1-47.2.0"]
        );
    }

    #[test]
    fn urls() {
        assert!(installer_url(ForgeFlavor::Forge, "1.20.1-47.2.0")
            .ends_with("/forge/1.20.1-47.2.0/forge-1.20.1-47.2.0-installer.jar"));
        assert!(installer_url(ForgeFlavor::NeoForge, "21.1.200")
            .ends_with("/neoforge/21.1.200/neoforge-21.1.200-installer.jar"));
        assert!(installer_url(ForgeFlavor::NeoForge, "1.20.1-47.1.106")
            .contains("/net/neoforged/forge/"));
    }
}
