//! One-click shader support.
//!
//! * Fabric / Quilt  -> Sodium + Iris
//! * NeoForge        -> Sodium + Iris where they exist, else Embeddium + Oculus
//! * Forge           -> Embeddium + Oculus
//! * Vanilla         -> OptiFine (user-imported; see `optifine.rs`)
//!
//! Mods are added to `mods/` with create-only writes (never overwriting) and
//! the shader config is only *created* when missing: `mods/` and `config/`
//! are user data, so nothing that already exists is touched.

use std::path::Path;

use mclaunch_core::{LoaderKind, Progress, ProgressFn};
use mclaunch_safety::SafetyError;

use crate::modrinth::{self, MrVersion};
use crate::{LoaderError, Loaders, Result};

/// Mod stacks to try, in order: `(display name, [modrinth projects])`.
fn stacks(loader: LoaderKind) -> Vec<(&'static str, Vec<&'static str>)> {
    match loader {
        LoaderKind::Fabric | LoaderKind::Quilt => vec![("Iris", vec!["sodium", "iris"])],
        LoaderKind::NeoForge => vec![
            ("Iris", vec!["sodium", "iris"]),
            ("Oculus", vec!["embeddium", "oculus"]),
        ],
        LoaderKind::Forge => vec![("Oculus", vec!["embeddium", "oculus"])],
        LoaderKind::Vanilla | LoaderKind::OptiFine => Vec::new(),
    }
}

/// Modrinth loader tags to query for an instance loader.
fn loader_tags(loader: LoaderKind) -> &'static [&'static str] {
    match loader {
        LoaderKind::Fabric => &["fabric"],
        LoaderKind::Quilt => &["quilt", "fabric"],
        LoaderKind::NeoForge => &["neoforge"],
        LoaderKind::Forge => &["forge"],
        _ => &[],
    }
}

#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct EnableReport {
    /// "Iris", "Oculus" or "OptiFine".
    pub engine: String,
    /// Files added to `mods/`.
    pub added: Vec<String>,
    /// Files that were already present.
    pub already: Vec<String>,
    /// Shader config created (it did not exist yet).
    pub config_created: bool,
}

async fn resolve(l: &Loaders, project: &str, tags: &[&str], mc: &str) -> Result<Option<MrVersion>> {
    for tag in tags {
        let versions = modrinth::project_versions(l, project, tag, mc).await?;
        if let Some(v) = modrinth::best(&versions) {
            return Ok(Some(v.clone()));
        }
    }
    Ok(None)
}

/// Install the shader stack for `loader` into `instance_dir/mods`.
pub async fn enable(
    l: &Loaders,
    loader: LoaderKind,
    mc: &str,
    instance_dir: &Path,
    progress: &ProgressFn,
) -> Result<EnableReport> {
    match loader {
        LoaderKind::OptiFine => {
            return Ok(EnableReport {
                engine: "OptiFine".into(),
                ..Default::default()
            })
        }
        LoaderKind::Vanilla => {
            return Err(LoaderError::Unsupported(format!(
                "Vanilla needs OptiFine for shaders: download OptiFine for {mc} from optifine.net, \
                 import it on the Loaders tab and install it (or switch this instance to Fabric for Iris)."
            )))
        }
        _ => {}
    }
    let tags = loader_tags(loader);
    let mods_dir = instance_dir.join("mods");
    'stacks: for (engine, projects) in stacks(loader) {
        progress(Progress::stage(format!("Looking up {engine} for {mc}")));
        let mut picked = Vec::new();
        for project in &projects {
            match resolve(l, project, tags, mc).await? {
                Some(v) => picked.push(v),
                None => continue 'stacks,
            }
        }
        // Required dependencies (one level is enough for these mods).
        let mut deps = Vec::new();
        for v in &picked {
            for d in v
                .dependencies
                .iter()
                .filter(|d| d.dependency_type == "required")
            {
                let Some(pid) = &d.project_id else { continue };
                if picked
                    .iter()
                    .chain(deps.iter())
                    .any(|p: &MrVersion| &p.project_id == pid)
                {
                    continue;
                }
                if let Some(dep) = resolve(l, pid, tags, mc).await? {
                    deps.push(dep);
                }
            }
        }
        picked.extend(deps);
        let mut report = EnableReport {
            engine: engine.to_string(),
            ..Default::default()
        };
        for (i, v) in picked.iter().enumerate() {
            progress(Progress {
                stage: format!("Adding {}", v.version_number),
                done: i as u64,
                total: picked.len() as u64,
                ..Default::default()
            });
            let (dest, added) = modrinth::install_into(l, v, &mods_dir).await?;
            let name = dest
                .file_name()
                .map(|n| n.to_string_lossy().into_owned())
                .unwrap_or_default();
            if added {
                report.added.push(name);
            } else {
                report.already.push(name);
            }
        }
        report.config_created = create_shader_config(l, engine, instance_dir)?;
        return Ok(report);
    }
    Err(LoaderError::Unsupported(format!(
        "No shader mods are published for {} on Minecraft {mc} yet",
        loader.label()
    )))
}

fn config_file(engine: &str) -> &'static str {
    if engine == "Oculus" {
        "oculus.properties"
    } else {
        "iris.properties"
    }
}

/// Create `config/iris.properties` (or oculus) only if missing, turning
/// shaders on with the first pack in `shaderpacks/`.
fn create_shader_config(l: &Loaders, engine: &str, instance_dir: &Path) -> Result<bool> {
    let path = instance_dir.join("config").join(config_file(engine));
    if path.exists() {
        return Ok(false);
    }
    let mut text =
        String::from("# Created by mclaunch when shaders were enabled\nenableShaders=true\n");
    if let Some(pack) = shader_packs(instance_dir).first() {
        text.push_str(&format!("shaderPack={pack}\n"));
    }
    match l.safe().create_new(&path, text.as_bytes()) {
        Ok(()) => Ok(true),
        Err(SafetyError::AlreadyExists(_)) => Ok(false),
        Err(e) => Err(e.into()),
    }
}

/// Shader packs (zips and folders) in `shaderpacks/`, sorted.
pub fn shader_packs(instance_dir: &Path) -> Vec<String> {
    let mut packs: Vec<String> = std::fs::read_dir(instance_dir.join("shaderpacks"))
        .map(|rd| {
            rd.flatten()
                .filter(|e| {
                    let p = e.path();
                    p.is_dir() || p.extension().is_some_and(|x| x.eq_ignore_ascii_case("zip"))
                })
                .map(|e| e.file_name().to_string_lossy().into_owned())
                .filter(|n| !n.starts_with('.'))
                .collect()
        })
        .unwrap_or_default();
    packs.sort_by_key(|p| p.to_lowercase());
    packs
}

#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct ShaderStatus {
    /// Shader engine detected in `mods/` or from the loader.
    pub engine: Option<String>,
    /// From the engine's config, when present.
    pub enabled: Option<bool>,
    pub pack: Option<String>,
    pub packs: Vec<String>,
}

impl ShaderStatus {
    /// "Iris ON (BSL_v8.2.zip)"
    pub fn summary(&self) -> String {
        let Some(engine) = &self.engine else {
            return if self.packs.is_empty() {
                "not set up".into()
            } else {
                format!("{} pack(s), no shader mod yet", self.packs.len())
            };
        };
        let state = match self.enabled {
            Some(true) => " ON",
            Some(false) => " OFF",
            None => "",
        };
        match &self.pack {
            Some(p) => format!("{engine}{state} ({p})"),
            None => format!("{engine}{state}"),
        }
    }
}

fn read_props(path: &Path) -> Vec<(String, String)> {
    std::fs::read_to_string(path)
        .map(|t| {
            t.lines()
                .filter(|l| !l.trim_start().starts_with('#'))
                .filter_map(|l| l.split_once('='))
                .map(|(k, v)| (k.trim().to_string(), v.trim().to_string()))
                .collect()
        })
        .unwrap_or_default()
}

/// Read-only look at an instance's shader setup.
pub fn status(instance_dir: &Path, loader: LoaderKind) -> ShaderStatus {
    let packs = shader_packs(instance_dir);
    let mods: Vec<String> = std::fs::read_dir(instance_dir.join("mods"))
        .map(|rd| {
            rd.flatten()
                .map(|e| e.file_name().to_string_lossy().to_lowercase())
                .filter(|n| n.ends_with(".jar"))
                .collect()
        })
        .unwrap_or_default();
    let engine = if loader == LoaderKind::OptiFine || mods.iter().any(|m| m.contains("optifine")) {
        Some("OptiFine")
    } else if mods.iter().any(|m| m.starts_with("oculus")) {
        Some("Oculus")
    } else if mods.iter().any(|m| m.starts_with("iris")) {
        Some("Iris")
    } else {
        None
    };
    let mut st = ShaderStatus {
        engine: engine.map(str::to_string),
        packs,
        ..Default::default()
    };
    match engine {
        Some("OptiFine") => {
            let props = read_props(&instance_dir.join("optionsshaders.txt"));
            if let Some((_, v)) = props.iter().find(|(k, _)| k == "shaderPack") {
                st.enabled = Some(v != "OFF" && !v.is_empty());
                st.pack = (v != "OFF" && !v.is_empty()).then(|| v.clone());
            }
        }
        Some(e) => {
            let props = read_props(&instance_dir.join("config").join(config_file(e)));
            st.enabled = props
                .iter()
                .find(|(k, _)| k == "enableShaders")
                .map(|(_, v)| v == "true");
            st.pack = props
                .iter()
                .find(|(k, _)| k == "shaderPack")
                .map(|(_, v)| v.clone())
                .filter(|v| !v.is_empty());
        }
        None => {}
    }
    st
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn status_reads_iris_config() {
        let dir = tempfile::tempdir().unwrap();
        let d = dir.path();
        std::fs::create_dir_all(d.join("mods")).unwrap();
        std::fs::create_dir_all(d.join("config")).unwrap();
        std::fs::create_dir_all(d.join("shaderpacks")).unwrap();
        std::fs::write(d.join("shaderpacks/BSL_v8.2.zip"), b"").unwrap();
        std::fs::write(d.join("shaderpacks/readme.txt"), b"").unwrap();
        assert_eq!(
            status(d, LoaderKind::Fabric).summary(),
            "1 pack(s), no shader mod yet"
        );
        std::fs::write(d.join("mods/iris-fabric-1.8.8+mc1.21.4.jar"), b"").unwrap();
        std::fs::write(
            d.join("config/iris.properties"),
            "enableShaders=true\nshaderPack=BSL_v8.2.zip\n",
        )
        .unwrap();
        let st = status(d, LoaderKind::Fabric);
        assert_eq!(st.summary(), "Iris ON (BSL_v8.2.zip)");
        assert_eq!(st.packs, vec!["BSL_v8.2.zip"]);
    }

    #[test]
    fn optifine_status() {
        let dir = tempfile::tempdir().unwrap();
        let d = dir.path();
        std::fs::write(d.join("optionsshaders.txt"), "shaderPack=OFF\n").unwrap();
        let st = status(d, LoaderKind::OptiFine);
        assert_eq!(st.summary(), "OptiFine OFF");
    }

    #[test]
    fn stacks_per_loader() {
        assert_eq!(stacks(LoaderKind::Fabric)[0].1, vec!["sodium", "iris"]);
        assert_eq!(stacks(LoaderKind::Forge)[0].1, vec!["embeddium", "oculus"]);
        assert_eq!(stacks(LoaderKind::NeoForge).len(), 2);
        assert!(stacks(LoaderKind::Vanilla).is_empty());
    }

    #[test]
    fn config_created_only_once() {
        let dir = tempfile::tempdir().unwrap();
        let safe = mclaunch_safety::SafePath::new(dir.path()).unwrap();
        let paths = mclaunch_core::LauncherPaths::new(safe.root());
        let installer = mclaunch_download::Installer::new(
            paths.clone(),
            safe.clone(),
            mclaunch_download::Http::new(true).unwrap(),
            1,
        );
        let l = Loaders::new(installer);
        let inst = paths.instance_dir("x");
        std::fs::create_dir_all(inst.join("shaderpacks")).unwrap();
        std::fs::write(inst.join("shaderpacks/Complementary.zip"), b"").unwrap();
        assert!(create_shader_config(&l, "Iris", &inst).unwrap());
        let text = std::fs::read_to_string(inst.join("config/iris.properties")).unwrap();
        assert!(text.contains("shaderPack=Complementary.zip"));
        std::fs::write(inst.join("config/iris.properties"), "enableShaders=false\n").unwrap();
        assert!(!create_shader_config(&l, "Iris", &inst).unwrap());
        assert_eq!(
            std::fs::read_to_string(inst.join("config/iris.properties")).unwrap(),
            "enableShaders=false\n",
            "user config must never be overwritten"
        );
    }
}
