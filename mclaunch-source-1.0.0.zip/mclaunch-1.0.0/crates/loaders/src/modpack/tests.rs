use std::collections::HashSet;
use std::io::Write;

use mclaunch_core::{InstanceConfig, LauncherPaths, LoaderKind};
use mclaunch_safety::SafePath;

use super::*;

fn zip_bytes(entries: &[(&str, &[u8])]) -> Vec<u8> {
    let mut buf = std::io::Cursor::new(Vec::new());
    {
        let mut z = zip::ZipWriter::new(&mut buf);
        for (name, data) in entries {
            if name.ends_with('/') {
                z.add_directory(*name, zip::write::SimpleFileOptions::default())
                    .unwrap();
            } else {
                z.start_file(*name, zip::write::SimpleFileOptions::default())
                    .unwrap();
                z.write_all(data).unwrap();
            }
        }
        z.finish().unwrap();
    }
    buf.into_inner()
}

fn write_zip(dir: &Path, name: &str, entries: &[(&str, &[u8])]) -> PathBuf {
    let p = dir.join(name);
    std::fs::write(&p, zip_bytes(entries)).unwrap();
    p
}

fn fabric_jar(id: &str, mc: &str, deps: &[&str]) -> Vec<u8> {
    let mut depends = format!(r#""minecraft": "{mc}", "fabricloader": ">=0.15""#);
    for d in deps {
        depends.push_str(&format!(r#", "{d}": "*""#));
    }
    let json = format!(r#"{{"schemaVersion": 1, "id": "{id}", "depends": {{{depends}}}}}"#);
    zip_bytes(&[("fabric.mod.json", json.as_bytes())])
}

const MRPACK_INDEX: &str = r#"{
  "formatVersion": 1, "game": "minecraft", "versionId": "2.1.0", "name": "Test Pack",
  "summary": "Small test pack",
  "files": [
    {"path": "mods/sodium.jar", "hashes": {"sha1": "aa", "sha512": "bb"}, "env": {"client": "required", "server": "unsupported"},
     "downloads": ["https://cdn.modrinth.com/data/AANobbMI/versions/x/sodium.jar"], "fileSize": 10},
    {"path": "mods/server-only.jar", "hashes": {"sha1": "cc"}, "env": {"client": "unsupported", "server": "required"},
     "downloads": ["https://cdn.modrinth.com/x.jar"], "fileSize": 1},
    {"path": "mods/elsewhere.jar", "hashes": {"sha1": "dd"}, "downloads": ["https://example.com/elsewhere.jar"], "fileSize": 5},
    {"path": "../../evil.jar", "hashes": {"sha1": "ee"}, "downloads": ["https://cdn.modrinth.com/evil.jar"]}
  ],
  "dependencies": {"minecraft": "1.20.1", "fabric-loader": "0.15.11"}
}"#;

#[test]
fn reads_mrpack() {
    let d = tempfile::tempdir().unwrap();
    let p = write_zip(
        d.path(),
        "test.mrpack",
        &[
            ("modrinth.index.json", MRPACK_INDEX.as_bytes()),
            ("overrides/config/a.txt", b"o"),
            ("client-overrides/config/a.txt", b"c"),
        ],
    );
    assert_eq!(sniff(&p), Some(PackFormat::Modrinth));
    let info = read_pack(&p, None).unwrap();
    assert_eq!(info.format, PackFormat::Modrinth);
    assert_eq!(info.name, "Test Pack");
    assert_eq!(info.version.as_deref(), Some("2.1.0"));
    assert_eq!(info.mc_version.as_deref(), Some("1.20.1"));
    assert_eq!(info.loader, LoaderKind::Fabric);
    assert_eq!(info.loader_version.as_deref(), Some("0.15.11"));
    assert_eq!(info.files.len(), 1, "server-only and unsafe paths skipped");
    assert_eq!(info.files[0].path, "mods/sodium.jar");
    assert_eq!(info.files[0].sha512.as_deref(), Some("bb"));
    assert_eq!(info.manual.len(), 1, "non-allowed host goes to the manual list");
    assert_eq!(info.manual[0].folder, "mods");
    assert_eq!(info.overrides, ["client-overrides/", "overrides/"]);
}

#[test]
fn reads_curseforge_in_a_wrapper_folder() {
    let d = tempfile::tempdir().unwrap();
    let manifest = r#"{
      "minecraft": {"version": "1.20.1", "modLoaders": [{"id": "forge-47.2.0", "primary": true}]},
      "manifestType": "minecraftModpack", "manifestVersion": 1,
      "name": "CF Pack", "version": "1.0", "author": "someone",
      "files": [{"projectID": 238222, "fileID": 4593548, "required": true},
                {"projectID": 1, "fileID": 2, "required": false},
                {"projectID": 238222, "fileID": 4593548, "required": true}],
      "overrides": "overrides"
    }"#;
    let p = write_zip(
        d.path(),
        "cf.zip",
        &[
            ("CF Pack/manifest.json", manifest.as_bytes()),
            ("CF Pack/overrides/config/x.toml", b"x"),
        ],
    );
    assert_eq!(sniff(&p), Some(PackFormat::CurseForge));
    let info = read_pack(&p, None).unwrap();
    assert_eq!(info.format, PackFormat::CurseForge);
    assert_eq!(info.name, "CF Pack");
    assert_eq!(info.author.as_deref(), Some("someone"));
    assert_eq!(info.loader, LoaderKind::Forge);
    assert_eq!(info.loader_version.as_deref(), Some("47.2.0"));
    assert_eq!(
        info.curseforge,
        [CfRef {
            project_id: 238222,
            file_id: 4593548
        }]
    );
    assert_eq!(info.overrides, ["CF Pack/overrides/"]);
    assert!(info.notes.iter().any(|n| n.contains("1 optional")));
}

#[test]
fn reads_multimc_export() {
    let d = tempfile::tempdir().unwrap();
    let mmc = r#"{"components": [
        {"uid": "org.lwjgl3", "version": "3.3.1"},
        {"uid": "net.minecraft", "version": "1.21.1"},
        {"uid": "net.neoforged", "version": "21.1.200"}], "formatVersion": 1}"#;
    let p = write_zip(
        d.path(),
        "export.zip",
        &[
            ("mmc-pack.json", mmc.as_bytes()),
            ("instance.cfg", b"InstanceType=OneSix\nname=My Neo Pack\n"),
            (".minecraft/mods/a.jar", b"jar"),
            (".minecraft/options.txt", b"fov:1"),
        ],
    );
    let info = read_pack(&p, None).unwrap();
    assert_eq!(info.format, PackFormat::MultiMc);
    assert_eq!(info.name, "My Neo Pack");
    assert_eq!(info.mc_version.as_deref(), Some("1.21.1"));
    assert_eq!(info.loader, LoaderKind::NeoForge);
    assert_eq!(info.loader_version.as_deref(), Some("21.1.200"));
    assert_eq!(info.overrides, [".minecraft/"]);
    assert_eq!(info.bundled_mods, 1);
}

#[test]
fn detects_plain_fabric_zip() {
    let d = tempfile::tempdir().unwrap();
    let a = fabric_jar("alpha", "~1.20.1", &["fabric-api", "cloth-config"]);
    let b = fabric_jar("beta", ">=1.20 <1.21", &["fabric-api-base"]);
    let api = zip_bytes(&[
        ("fabric.mod.json", br#"{"id": "fabric-api", "depends": {"minecraft": "1.20.1"}}"#),
        (
            "META-INF/jars/base.jar",
            &zip_bytes(&[("fabric.mod.json", br#"{"id": "fabric-api-base"}"#)]),
        ),
    ]);
    let p = write_zip(
        d.path(),
        "My Pack.zip",
        &[
            ("My Pack/mods/alpha-1.0+mc1.20.1.jar", &a),
            ("My Pack/mods/beta.jar", &b),
            ("My Pack/mods/fabric-api-0.92.jar", &api),
            ("My Pack/config/alpha.json", b"{}"),
            ("My Pack/instance.toml", b"jvm_args = \"-javaagent:evil.jar\""),
        ],
    );
    assert_eq!(sniff(&p), Some(PackFormat::Generic));
    let known: HashSet<String> = ["1.20", "1.20.1", "1.21"].map(String::from).into();
    let info = read_pack(&p, Some(&known)).unwrap();
    assert_eq!(info.format, PackFormat::Generic);
    assert_eq!(info.name, "My Pack");
    assert_eq!(info.mc_version.as_deref(), Some("1.20.1"));
    assert_eq!(info.loader, LoaderKind::Fabric);
    assert_eq!(info.bundled_mods, 3);
    assert_eq!(info.overrides, ["My Pack/"]);
    // fabric-api-base comes from the nested jar; cloth-config is missing.
    assert_eq!(info.missing_deps(LoaderKind::Fabric), ["cloth-config"]);
}

#[test]
fn detects_forge_and_neoforge_jars() {
    let forge = zip_bytes(&[(
        "META-INF/mods.toml",
        br#"modLoader="javafml"
loaderVersion="[47,)"
[[mods]]
modId="jei"
[[dependencies.jei]]
modId="forge"
mandatory=true
versionRange="[47.1.3,)"
[[dependencies.jei]]
modId="minecraft"
mandatory=true
versionRange="[1.20.1,1.20.2)"
[[dependencies.jei]]
modId="curios"
mandatory=true
versionRange="[5,)"
"#,
    )]);
    let m = scan_jar(&forge, "jei-1.20.1-forge-15.2.0.jar");
    assert_eq!(m.loaders, [LoaderKind::Forge]);
    assert_eq!(m.ids, ["jei"]);
    assert_eq!(m.forge_min.as_deref(), Some("47.1.3"));
    assert!(m.depends.contains(&(LoaderKind::Forge, "curios".into())));
    let det = scan::detect(&[m], None);
    assert_eq!(det.mc.as_deref(), Some("1.20.1"));
    assert_eq!(det.loader, LoaderKind::Forge);
    assert_eq!(det.loader_min.as_deref(), Some("47.1.3"));

    let neo = zip_bytes(&[(
        "META-INF/neoforge.mods.toml",
        br#"[[mods]]
modId="neo_mod"
[[dependencies.neo_mod]]
modId="minecraft"
type="required"
versionRange="[1.21.1]"
"#,
    )]);
    let m = scan_jar(&neo, "neo_mod.jar");
    assert_eq!(m.loaders, [LoaderKind::NeoForge]);
    assert_eq!(m.mc, [("1.21.1".to_string(), 3)]);
    let provided = m.ids.iter().cloned().collect();
    assert!(
        scan::missing(&provided, &m.depends, LoaderKind::NeoForge).is_empty(),
        "minecraft is not a missing mod"
    );
}

#[test]
fn loader_versions() {
    let list = |vs: &[(&str, bool, bool)]| -> Vec<LoaderVersion> {
        vs.iter()
            .map(|(v, stable, rec)| LoaderVersion {
                version: v.to_string(),
                stable: *stable,
                recommended: *rec,
            })
            .collect()
    };
    let forge = list(&[
        ("1.20.1-47.3.0", true, false),
        ("1.20.1-47.2.0", true, true),
        ("1.20.1-47.1.0", true, false),
    ]);
    let pick = |l: &[LoaderVersion], k, mc, w, m| pick_loader_version(l, k, mc, w, m);
    assert_eq!(
        pick(&forge, LoaderKind::Forge, "1.20.1", Some("47.1.0"), None).as_deref(),
        Some("1.20.1-47.1.0")
    );
    assert_eq!(
        pick(&forge, LoaderKind::Forge, "1.20.1", None, None).as_deref(),
        Some("1.20.1-47.2.0"),
        "recommended"
    );
    assert_eq!(
        pick(&forge, LoaderKind::Forge, "1.20.1", None, Some("47.2.5")).as_deref(),
        Some("1.20.1-47.3.0"),
        "recommended is too old for the mods"
    );
    assert_eq!(
        pick(&[], LoaderKind::Forge, "1.20.1", Some("47.9.9"), None).as_deref(),
        Some("1.20.1-47.9.9"),
        "offline: build the id"
    );
    let legacy = list(&[("1.7.10-10.13.4.1614-1.7.10", true, true)]);
    assert_eq!(
        pick(&legacy, LoaderKind::Forge, "1.7.10", Some("10.13.4.1614"), None).as_deref(),
        Some("1.7.10-10.13.4.1614-1.7.10")
    );
    assert_eq!(
        pick(&[], LoaderKind::NeoForge, "1.20.1", Some("47.1.84"), None).as_deref(),
        Some("1.20.1-47.1.84")
    );
    assert_eq!(
        pick(&[], LoaderKind::NeoForge, "1.21.1", Some("21.1.200"), None).as_deref(),
        Some("21.1.200")
    );
    let fabric = list(&[("0.16.0-beta", false, false), ("0.15.11", true, false)]);
    assert_eq!(
        pick(&fabric, LoaderKind::Fabric, "1.20.1", None, None).as_deref(),
        Some("0.15.11")
    );
}

#[test]
fn rel_paths() {
    assert_eq!(clean_rel_path("mods/a.jar").as_deref(), Some("mods/a.jar"));
    assert_eq!(clean_rel_path("./mods//a.jar").as_deref(), Some("mods/a.jar"));
    assert_eq!(clean_rel_path("mods\\a.jar").as_deref(), Some("mods/a.jar"));
    assert_eq!(clean_rel_path("../a.jar"), None);
    assert_eq!(clean_rel_path("mods/../../a.jar"), None);
    assert_eq!(clean_rel_path("/etc/passwd"), None);
    assert_eq!(clean_rel_path("C:/x.jar"), None);
    assert_eq!(clean_rel_path(""), None);
}

#[test]
fn names_and_urls() {
    assert_eq!(instance_name("All the Mods 9: To the Sky"), "All the Mods 9 To the Sky");
    assert_eq!(instance_name("  ..hidden  "), "hidden");
    assert_eq!(instance_name("???"), "Modpack");
    assert_eq!(
        curseforge::cdn_url(4593548, "jei 1.18.2+x.jar"),
        "https://mediafilez.forgecdn.net/files/4593/548/jei%201.18.2%2Bx.jar"
    );
}

struct Root {
    _dir: tempfile::TempDir,
    paths: LauncherPaths,
    safe: SafePath,
}

fn root() -> Root {
    let dir = tempfile::tempdir().unwrap();
    let safe = SafePath::new(dir.path()).unwrap();
    let paths = LauncherPaths::new(safe.root());
    Root {
        _dir: dir,
        paths,
        safe,
    }
}

#[test]
fn creates_instance_with_override_precedence() {
    let r = root();
    let src = write_zip(
        r.safe.root(),
        "pack.mrpack",
        &[
            ("modrinth.index.json", MRPACK_INDEX.as_bytes()),
            ("overrides/config/a.txt", b"overrides"),
            ("client-overrides/config/a.txt", b"client"),
            ("overrides/mods/sodium.jar", b"bundled"),
            ("overrides/options.txt", b"fov:1"),
            ("overrides/instance.toml", b"jvm_args = \"-javaagent:evil.jar\""),
            ("overrides/../escape.txt", b"no"),
        ],
    );
    let info = read_pack(&src, None).unwrap();
    let cache = r.paths.loaders_dir().join("modpacks/files/x");
    std::fs::create_dir_all(&cache).unwrap();
    std::fs::write(cache.join("sodium.jar"), b"downloaded").unwrap();
    std::fs::write(cache.join("shader.zip"), zip_bytes(&[("shaders/final.fsh", b"x")])).unwrap();
    let planned = |file: &str, dest: Option<&str>| Planned {
        label: file.into(),
        urls: vec![],
        sha1: None,
        sha512: None,
        size: None,
        cache: cache.join(file),
        dest: dest.map(str::to_string),
        file_name: file.into(),
        page: None,
    };
    let plan = Plan {
        downloads: vec![
            planned("sodium.jar", Some("mods/sodium.jar")),
            planned("shader.zip", None),
        ],
        manual: info.manual.clone(),
        notes: vec![],
    };
    let mut cfg = InstanceConfig::new("Test Pack", "1.20.1", 4096);
    cfg.loader = LoaderKind::Fabric;
    let report = create_instance(&r.paths, &r.safe, &info, &plan, &cfg).unwrap();
    let dir = r.paths.instance_dir("Test Pack");
    assert_eq!(std::fs::read(dir.join("config/a.txt")).unwrap(), b"client");
    assert_eq!(std::fs::read(dir.join("mods/sodium.jar")).unwrap(), b"bundled");
    assert_eq!(std::fs::read(dir.join("options.txt")).unwrap(), b"fov:1");
    assert!(dir.join("shaderpacks/shader.zip").is_file(), "classified by contents");
    assert!(!r.safe.root().join("instances/escape.txt").exists());
    assert_eq!(report.added, 1);
    assert_eq!(report.overrides, 3);
    let saved = InstanceConfig::load(&dir).unwrap();
    assert_eq!(saved.loader, LoaderKind::Fabric);
    assert!(!saved.jvm_args.contains("javaagent"));
    let record = load_record(&dir).unwrap();
    assert_eq!(record.name, "Test Pack");
    assert_eq!(record.manual.len(), 1);

    // Never into an existing instance.
    let err = create_instance(&r.paths, &r.safe, &info, &plan, &cfg).unwrap_err();
    assert!(err.to_string().contains("already exists"));
    assert_eq!(std::fs::read(dir.join("config/a.txt")).unwrap(), b"client");
}

#[test]
fn picks_up_manual_downloads() {
    let r = root();
    let dir = r.paths.instance_dir("P");
    std::fs::create_dir_all(dir.join("mods")).unwrap();
    let good = b"the real jar";
    let manual = |name: &str, sha1: &str| ManualFile {
        name: name.into(),
        file_name: Some(name.into()),
        folder: "mods".into(),
        url: "https://example.com".into(),
        reason: "restricted".into(),
        sha1: Some(sha1.into()),
        size: None,
    };
    let record = PackRecord {
        name: "P".into(),
        manual: vec![
            manual("Good.jar", &mclaunch_download::hash::sha1_bytes(good)),
            manual("bad.jar", "0000"),
            manual("absent.jar", "1111"),
        ],
        ..Default::default()
    };
    save_record(&r.safe, &dir, &record).unwrap();
    let downloads = tempfile::tempdir().unwrap();
    std::fs::write(downloads.path().join("good.jar"), good).unwrap();
    std::fs::write(downloads.path().join("bad.jar"), b"tampered").unwrap();
    let (added, still) =
        add_manual_files(&r.safe, &dir, &[downloads.path().to_path_buf()]).unwrap();
    assert_eq!(added, ["Good.jar"]);
    assert_eq!(still.len(), 2);
    assert_eq!(std::fs::read(dir.join("mods/Good.jar")).unwrap(), good);
    assert!(!dir.join("mods/bad.jar").exists(), "hash mismatch is not imported");
    assert_eq!(load_record(&dir).unwrap().manual.len(), 2);
}

#[test]
fn not_a_modpack() {
    let d = tempfile::tempdir().unwrap();
    let p = write_zip(d.path(), "rp.zip", &[("pack.mcmeta", b"{}"), ("assets/x", b"x")]);
    assert_eq!(sniff(&p), None);
    assert!(read_pack(&p, None).is_err());
}

#[tokio::test]
async fn cancel_token() {
    let c = Cancel::default();
    let c2 = c.clone();
    let waiter = tokio::spawn(async move { c2.cancelled().await });
    tokio::task::yield_now().await;
    c.cancel();
    tokio::time::timeout(std::time::Duration::from_secs(2), waiter)
        .await
        .unwrap()
        .unwrap();
    assert!(c.is_cancelled());
    c.cancelled().await; // already cancelled: returns at once
}
