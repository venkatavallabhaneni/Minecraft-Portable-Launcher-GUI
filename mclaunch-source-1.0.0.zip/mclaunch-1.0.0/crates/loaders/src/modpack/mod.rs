//! Modpack installer: Modrinth (`.mrpack`), CurseForge (zip with a
//! `manifest.json`), MultiMC/Prism exports and plain zips of a `.minecraft`
//! folder.
//!
//! The work is split so the app can install the game and loader (which needs
//! a Java runtime) in between:
//!
//! 1. [`read_pack`] (blocking) detects the format, Minecraft version and
//!    loader.
//! 2. [`plan`] resolves every remote file: CurseForge lookups, and for plain
//!    zips any missing required mods (via Modrinth).
//! 3. [`download`] fetches them [`PARALLEL_DOWNLOADS`] at a time into
//!    `loaders/modpacks/files/` with size and SHA-1/SHA-512 checks and
//!    retries. The cache makes a reinstall work offline.
//! 4. [`create_instance`] (blocking) builds a brand-new instance folder:
//!    overrides, then the downloaded files, then `instance.toml`.
//!
//! Nothing is ever written into an existing instance.

pub mod curseforge;
mod read;
mod scan;

use std::collections::BTreeSet;
use std::io::Read;
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;

use mclaunch_core::{InstanceConfig, LauncherPaths, LoaderKind, Progress, ProgressFn};
use mclaunch_download::{DownloadTask, Downloader};
use mclaunch_safety::{SafePath, SafetyError};
use serde::{Deserialize, Serialize};

use crate::{io_err, modrinth, LoaderError, LoaderVersion, Loaders, Result, Software};

pub use read::{read_pack, sniff};
pub use scan::{scan_jar, ModMeta};

/// Modpack files are downloaded this many at a time.
pub const PARALLEL_DOWNLOADS: usize = 8;
/// Written into the new instance: where it came from and what is still
/// missing.
pub const RECORD_FILE: &str = "modpack.json";

#[derive(Debug, Clone, Copy, PartialEq, Eq, Default, Serialize, Deserialize)]
pub enum PackFormat {
    Modrinth,
    CurseForge,
    MultiMc,
    #[default]
    Generic,
}

impl PackFormat {
    pub fn label(self) -> &'static str {
        match self {
            PackFormat::Modrinth => "Modrinth",
            PackFormat::CurseForge => "CurseForge",
            PackFormat::MultiMc => "MultiMC / Prism",
            PackFormat::Generic => "Plain zip",
        }
    }
}

/// A file listed by the pack with its download location.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct RemoteFile {
    /// Destination inside the instance (`mods/x.jar`), `/`-separated.
    pub path: String,
    pub urls: Vec<String>,
    pub sha1: Option<String>,
    pub sha512: Option<String>,
    pub size: Option<u64>,
}

/// A CurseForge file reference from `manifest.json`.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct CfRef {
    pub project_id: u64,
    pub file_id: u64,
}

/// A file the launcher may not, or could not, download. The user downloads
/// it in a browser and the launcher picks it up from a folder.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ManualFile {
    /// Project or file name for display.
    pub name: String,
    /// Expected file name, when known.
    pub file_name: Option<String>,
    /// Folder inside the instance (`mods`, `resourcepacks`, ...).
    pub folder: String,
    /// Page to open in the browser.
    pub url: String,
    pub reason: String,
    pub sha1: Option<String>,
    pub size: Option<u64>,
}

/// What [`read_pack`] found.
#[derive(Debug, Clone, Default)]
pub struct PackInfo {
    pub source: PathBuf,
    pub format: PackFormat,
    pub name: String,
    pub version: Option<String>,
    pub author: Option<String>,
    pub summary: Option<String>,
    pub mc_version: Option<String>,
    pub loader: LoaderKind,
    /// Exact loader version from the pack (none for plain zips).
    pub loader_version: Option<String>,
    /// Lowest loader version the bundled mods accept (plain zips).
    pub loader_min: Option<String>,
    /// Detection details and warnings for the UI.
    pub notes: Vec<String>,
    pub files: Vec<RemoteFile>,
    pub curseforge: Vec<CfRef>,
    /// Known up front (e.g. a host the `.mrpack` format does not allow).
    pub manual: Vec<ManualFile>,
    /// Zip folders copied into the instance, highest precedence first.
    pub overrides: Vec<String>,
    pub bundled_mods: usize,
    /// Mod ids present in the bundled mods (plain zips).
    pub provided: BTreeSet<String>,
    /// Required mod ids of the bundled mods, per loader (plain zips).
    pub requires: Vec<(LoaderKind, String)>,
}

impl PackInfo {
    /// Required mods that are not in the pack, for `loader`.
    pub fn missing_deps(&self, loader: LoaderKind) -> Vec<String> {
        scan::missing(&self.provided, &self.requires, loader)
    }

    /// Number of files that will be downloaded (before CurseForge lookups).
    pub fn remote_count(&self) -> usize {
        self.files.len() + self.curseforge.len()
    }
}

/// Cooperative cancellation for a modpack install.
#[derive(Clone, Default)]
pub struct Cancel(Arc<(AtomicBool, tokio::sync::Notify)>);

impl Cancel {
    pub fn cancel(&self) {
        self.0 .0.store(true, Ordering::SeqCst);
        self.0 .1.notify_waiters();
    }

    pub fn is_cancelled(&self) -> bool {
        self.0 .0.load(Ordering::SeqCst)
    }

    /// Resolves once [`cancel`](Self::cancel) has been called.
    pub async fn cancelled(&self) {
        let notified = self.0 .1.notified();
        tokio::pin!(notified);
        notified.as_mut().enable();
        if self.is_cancelled() {
            return;
        }
        notified.await;
    }
}

/// One download of a [`Plan`].
#[derive(Debug, Clone)]
pub struct Planned {
    pub label: String,
    pub urls: Vec<String>,
    pub sha1: Option<String>,
    pub sha512: Option<String>,
    pub size: Option<u64>,
    /// Where the file is cached.
    pub cache: PathBuf,
    /// Destination inside the instance; `None` decides from the contents
    /// (CurseForge files whose category is unknown).
    pub dest: Option<String>,
    pub file_name: String,
    /// Shown if the download is refused.
    pub page: Option<String>,
}

#[derive(Debug, Clone, Default)]
pub struct Plan {
    pub downloads: Vec<Planned>,
    pub manual: Vec<ManualFile>,
    pub notes: Vec<String>,
}

/// Result of [`create_instance`].
#[derive(Debug, Clone, Default)]
pub struct CreateReport {
    pub dir: PathBuf,
    /// Downloaded files placed in the instance.
    pub added: usize,
    /// Files copied from the pack's override folders.
    pub overrides: usize,
}

/// Saved as [`RECORD_FILE`] in the instance.
#[derive(Debug, Clone, Default, PartialEq, Serialize, Deserialize)]
#[serde(default)]
pub struct PackRecord {
    pub format: PackFormat,
    pub name: String,
    pub version: Option<String>,
    pub source: String,
    pub manual: Vec<ManualFile>,
}

pub fn load_record(instance_dir: &Path) -> Option<PackRecord> {
    let bytes = std::fs::read(instance_dir.join(RECORD_FILE)).ok()?;
    serde_json::from_slice(&bytes).ok()
}

fn save_record(safe: &SafePath, instance_dir: &Path, record: &PackRecord) -> Result<()> {
    let json = serde_json::to_vec_pretty(record).map_err(|e| LoaderError::Failed(e.to_string()))?;
    safe.write(&instance_dir.join(RECORD_FILE), &json)?;
    Ok(())
}

/// `a/b/c.jar` with only plain components, or `None` for anything that
/// could escape the instance folder.
pub fn clean_rel_path(path: &str) -> Option<String> {
    let parts: Vec<&str> = path
        .split(['/', '\\'])
        .filter(|p| !p.is_empty() && *p != ".")
        .collect();
    if parts.is_empty()
        || path.starts_with(['/', '\\'])
        || parts.iter().any(|p| !mclaunch_safety::is_plain_name(p))
    {
        return None;
    }
    Some(parts.join("/"))
}

fn join_rel(dir: &Path, rel: &str) -> PathBuf {
    let mut p = dir.to_path_buf();
    for part in rel.split('/') {
        p.push(part);
    }
    p
}

/// File-name-safe cache key.
fn key(s: &str) -> String {
    s.chars()
        .map(|c| {
            if c.is_ascii_alphanumeric() || c == '.' || c == '-' {
                c
            } else {
                '_'
            }
        })
        .collect()
}

fn files_cache(l: &Loaders) -> PathBuf {
    l.cache_dir("modpacks").join("files")
}

/// Turn the pack's file list into downloads: CurseForge lookups and, for
/// plain zips, required mods missing from the pack (from Modrinth).
pub async fn plan(
    l: &Loaders,
    pack: &PackInfo,
    curseforge_key: Option<&str>,
    progress: &ProgressFn,
) -> Result<Plan> {
    let cache = files_cache(l);
    let mut plan = Plan {
        manual: pack.manual.clone(),
        ..Default::default()
    };
    for f in &pack.files {
        let file_name = f.path.rsplit('/').next().unwrap_or(&f.path).to_string();
        let dir = f
            .sha1
            .clone()
            .or_else(|| f.sha512.as_ref().map(|s| s.chars().take(40).collect()))
            .unwrap_or_else(|| key(&f.path));
        plan.downloads.push(Planned {
            label: file_name.clone(),
            urls: f.urls.clone(),
            sha1: f.sha1.clone(),
            sha512: f.sha512.clone(),
            size: f.size,
            cache: cache.join(dir).join(&file_name),
            dest: Some(f.path.clone()),
            file_name,
            page: None,
        });
    }

    if !pack.curseforge.is_empty() {
        progress(Progress::stage(format!(
            "Looking up {} CurseForge files",
            pack.curseforge.len()
        )));
        let res = curseforge::resolve(l, &pack.curseforge, curseforge_key).await;
        plan.notes.extend(res.notes);
        plan.manual.extend(res.manual);
        for r in res.files {
            match r.url.clone() {
                Some(url) => plan.downloads.push(Planned {
                    label: r.display_name(),
                    urls: std::iter::once(url).chain(r.mirrors.clone()).collect(),
                    sha1: r.sha1.clone(),
                    sha512: None,
                    size: r.size,
                    cache: cache.join(format!("cf-{}", r.file_id)).join(&r.file_name),
                    dest: r.folder().map(|f| format!("{f}/{}", r.file_name)),
                    file_name: r.file_name.clone(),
                    page: Some(r.page.clone()),
                }),
                None => plan.manual.push(r.manual(
                    "the author does not allow downloads from other apps",
                )),
            }
        }
    }

    if pack.format == PackFormat::Generic {
        if let Some(mc) = &pack.mc_version {
            add_missing_deps(l, pack, mc, &mut plan, progress).await;
        }
    }
    Ok(plan)
}

/// Modrinth slugs for common library mods whose id differs.
fn modrinth_slugs(id: &str) -> Vec<String> {
    let known = match id {
        "fabric" | "fabric_api" => Some("fabric-api"),
        "cloth-config2" | "cloth_config" | "cloth-config" => Some("cloth-config"),
        "architectury" => Some("architectury-api"),
        "kotlinforforge" => Some("kotlin-for-forge"),
        "yet_another_config_lib_v3" | "yet-another-config-lib" | "yacl" => Some("yacl"),
        "owo" => Some("owo-lib"),
        "balm-fabric" | "balm-forge" | "balm-neoforge" => Some("balm"),
        "puzzleslib" => Some("puzzles-lib"),
        "forgeconfigapiport" => Some("forge-config-api-port"),
        "resourcefullib" => Some("resourceful-lib"),
        "cardinal-components" => Some("cardinal-components-api"),
        "fabric-language-kotlin" => Some("fabric-language-kotlin"),
        "qsl" | "quilted_fabric_api" => Some("qsl"),
        _ => None,
    };
    // Fabric API modules (`fabric-screen-api-v1`, …) all come from Fabric API.
    let fabric_module = (id.starts_with("fabric-") || id.starts_with("fabric_"))
        && !id.starts_with("fabric-language-");
    let known = known.or(fabric_module.then_some("fabric-api"));
    let mut out: Vec<String> = known.map(str::to_string).into_iter().collect();
    for s in [id.to_string(), id.replace('_', "-")] {
        if !out.contains(&s) {
            out.push(s);
        }
    }
    out
}

fn modrinth_loader(kind: LoaderKind) -> Option<&'static str> {
    Some(match kind {
        LoaderKind::Fabric => "fabric",
        LoaderKind::Quilt => "quilt",
        LoaderKind::Forge => "forge",
        LoaderKind::NeoForge => "neoforge",
        _ => return None,
    })
}

async fn add_missing_deps(
    l: &Loaders,
    pack: &PackInfo,
    mc: &str,
    plan: &mut Plan,
    progress: &ProgressFn,
) {
    let missing = pack.missing_deps(pack.loader);
    let Some(loader) = modrinth_loader(pack.loader) else {
        return;
    };
    // Quilt loads Fabric mods too.
    let loaders: &[&str] = if loader == "quilt" {
        &["quilt", "fabric"]
    } else {
        &[loader]
    };
    // Several missing ids can come from one project (Fabric API modules).
    let mut added: Vec<(String, Vec<String>)> = Vec::new();
    let mut not_found = Vec::new();
    for id in missing {
        let slugs = modrinth_slugs(&id);
        if let Some((_, ids)) = added.iter_mut().find(|(s, _)| slugs.contains(s)) {
            ids.push(id);
            continue;
        }
        progress(Progress::stage(format!("Looking for required mod {id}")));
        let mut found = None;
        'search: for slug in &slugs {
            for ld in loaders {
                if let Ok(versions) = modrinth::project_versions(l, slug, ld, mc).await {
                    if let Some(v) = modrinth::best(&versions) {
                        found = Some((slug.clone(), v.clone()));
                        break 'search;
                    }
                }
            }
        }
        let file = found
            .as_ref()
            .and_then(|(slug, v)| Some((slug, v.primary_file()?)));
        match file {
            Some((slug, file)) if mclaunch_safety::is_plain_name(&file.filename) => {
                added.push((slug.clone(), vec![id]));
                plan.downloads.push(Planned {
                    label: file.filename.clone(),
                    urls: vec![file.url.clone()],
                    sha1: file.hashes.sha1.clone(),
                    sha512: None,
                    size: file.size,
                    cache: l.cache_dir("modrinth").join("files").join(&file.filename),
                    dest: Some(format!("mods/{}", file.filename)),
                    file_name: file.filename.clone(),
                    page: None,
                });
            }
            _ => not_found.push(id),
        }
    }
    for (slug, ids) in added {
        plan.notes.push(format!(
            "Added {slug} from Modrinth (required by the pack: {})",
            ids.join(", ")
        ));
    }
    for id in not_found {
        plan.notes.push(format!(
            "Required mod \"{id}\" is not in the pack and was not found on Modrinth; add it to mods/ yourself"
        ));
    }
}

/// Is this downloader error an HTTP 4xx (the server refused the file)?
fn refused(message: &str) -> bool {
    message.starts_with("HTTP 4")
}

/// Download every planned file, [`PARALLEL_DOWNLOADS`] at a time, with
/// size and hash checks and retries. Files the server refuses (HTTP 4xx)
/// move to the manual list; any other failure is an error (the cache keeps
/// what was downloaded, so a retry resumes).
pub async fn download(l: &Loaders, mut plan: Plan, progress: &ProgressFn) -> Result<Plan> {
    let downloader = Downloader::new(l.http().clone(), l.safe().clone(), PARALLEL_DOWNLOADS);
    let tasks: Vec<DownloadTask> = plan
        .downloads
        .iter()
        .map(|p| {
            let mut urls = p.urls.iter();
            let mut t = DownloadTask::new(urls.next().cloned().unwrap_or_default(), &p.cache)
                .sha1(p.sha1.clone())
                .sha512(p.sha512.clone())
                .size(p.size);
            for m in urls {
                t = t.mirror(m.clone());
            }
            t
        })
        .collect();
    let total = tasks.len();
    let summary = downloader
        .run(tasks, &format!("Downloading modpack files ({total})"), progress)
        .await;
    if summary.is_ok() {
        return Ok(plan);
    }
    if summary.failed.iter().any(|(_, e)| !refused(e)) {
        return Err(LoaderError::Failed(summary.failure_text()));
    }
    let failed: Vec<&PathBuf> = summary.failed.iter().map(|(p, _)| p).collect();
    let (bad, ok): (Vec<Planned>, Vec<Planned>) = plan
        .downloads
        .into_iter()
        .partition(|p| failed.contains(&&p.cache));
    plan.downloads = ok;
    for p in bad {
        let folder = p
            .dest
            .as_deref()
            .and_then(|d| d.rsplit_once('/').map(|(f, _)| f.to_string()))
            .unwrap_or_else(|| "mods".into());
        plan.manual.push(ManualFile {
            name: p.label.clone(),
            file_name: Some(p.file_name.clone()),
            folder,
            url: p
                .page
                .clone()
                .unwrap_or_else(|| p.urls.first().cloned().unwrap_or_default()),
            reason: "the download server refused the file".into(),
            sha1: p.sha1.clone(),
            size: p.size,
        });
    }
    Ok(plan)
}

/// The installed loader version to use for this pack.
pub async fn loader_version(l: &Loaders, pack: &PackInfo, mc: &str) -> Result<Option<String>> {
    let Some(software) = software(pack.loader) else {
        return Ok(None);
    };
    let list = match l.versions(software, mc).await {
        Ok((list, _)) => list,
        Err(e) if pack.loader_version.is_some() => {
            tracing::debug!(error = %e, "loader list unavailable; using the pack's version");
            Vec::new()
        }
        Err(e) => return Err(e),
    };
    pick_loader_version(
        &list,
        pack.loader,
        mc,
        pack.loader_version.as_deref(),
        pack.loader_min.as_deref(),
    )
    .map(Some)
    .ok_or_else(|| {
        LoaderError::Failed(format!(
            "{} is not available for Minecraft {mc}",
            pack.loader.label()
        ))
    })
}

pub fn software(kind: LoaderKind) -> Option<Software> {
    Some(match kind {
        LoaderKind::Fabric => Software::Fabric,
        LoaderKind::Quilt => Software::Quilt,
        LoaderKind::Forge => Software::Forge,
        LoaderKind::NeoForge => Software::NeoForge,
        _ => return None,
    })
}

/// Match a pack's loader version (`47.2.0`) against our version ids
/// (`1.20.1-47.2.0`, `1.7.10-10.13.4.1614-1.7.10`), or choose one: the
/// recommended, else the newest stable at or above `min`.
pub fn pick_loader_version(
    list: &[LoaderVersion],
    kind: LoaderKind,
    mc: &str,
    wanted: Option<&str>,
    min: Option<&str>,
) -> Option<String> {
    use std::cmp::Ordering;
    if let Some(w) = wanted {
        let prefixed = format!("{mc}-{w}");
        let found = list.iter().find(|v| {
            v.version == w
                || v.version == prefixed
                || v.version.starts_with(&format!("{prefixed}-"))
        });
        return Some(match found {
            Some(v) => v.version.clone(),
            None => match kind {
                LoaderKind::Forge if !w.starts_with(&format!("{mc}-")) => prefixed,
                LoaderKind::NeoForge if mc == "1.20.1" && !w.starts_with("1.20.1-") => prefixed,
                _ => w.to_string(),
            },
        });
    }
    let short = |v: &str| {
        v.strip_prefix(&format!("{mc}-"))
            .unwrap_or(v)
            .to_string()
    };
    let ok_min = |v: &LoaderVersion| {
        min.is_none_or(|m| crate::version_cmp(&short(&v.version), m) != Ordering::Less)
    };
    list.iter()
        .find(|v| v.recommended && ok_min(v))
        .or_else(|| list.iter().find(|v| v.stable && ok_min(v)))
        .or_else(|| list.iter().find(|v| ok_min(v)))
        .or(list.first())
        .map(|v| v.version.clone())
}

/// Folder for a downloaded file whose category is unknown.
pub fn folder_for(path: &Path) -> &'static str {
    let name = path
        .file_name()
        .map(|n| n.to_string_lossy().to_lowercase())
        .unwrap_or_default();
    if !name.ends_with(".zip") {
        return "mods";
    }
    let Ok(entries) = crate::zip_entry_names(path) else {
        return "mods";
    };
    if entries
        .iter()
        .any(|e| e.starts_with("shaders/") || e.split('/').nth(1) == Some("shaders"))
    {
        "shaderpacks"
    } else if entries.iter().any(|e| e == "pack.mcmeta") {
        "resourcepacks"
    } else {
        "mods"
    }
}

/// Names never taken from a pack's overrides (they are ours).
const RESERVED_FILES: &[&str] = &[mclaunch_core::instance::INSTANCE_FILE, RECORD_FILE];

/// Build the instance folder `instances/<cfg.name>`, which must not exist
/// yet. On failure the half-built folder goes to the recycle bin.
pub fn create_instance(
    paths: &LauncherPaths,
    safe: &SafePath,
    pack: &PackInfo,
    plan: &Plan,
    cfg: &InstanceConfig,
) -> Result<CreateReport> {
    let dir = cfg.dir(paths);
    if dir.exists() {
        return Err(LoaderError::Failed(format!(
            "an instance named \"{}\" already exists",
            cfg.name
        )));
    }
    safe.create_dir_all(&dir)?;
    match fill_instance(paths, safe, pack, plan, cfg, &dir) {
        Ok(report) => Ok(report),
        Err(e) => {
            if let Err(t) = safe.trash_instance(&cfg.name, &cfg.name) {
                tracing::warn!(error = %t, "could not clean up the half-built instance");
            }
            Err(e)
        }
    }
}

fn fill_instance(
    paths: &LauncherPaths,
    safe: &SafePath,
    pack: &PackInfo,
    plan: &Plan,
    cfg: &InstanceConfig,
    dir: &Path,
) -> Result<CreateReport> {
    let mut report = CreateReport {
        dir: dir.to_path_buf(),
        ..Default::default()
    };
    // Overrides first, highest precedence first: create-only writes mean
    // the first copy of a path wins.
    report.overrides = extract_overrides(safe, &pack.source, &pack.overrides, dir)?;
    for p in &plan.downloads {
        let rel = match &p.dest {
            Some(d) => d.clone(),
            None => format!("{}/{}", folder_for(&p.cache), p.file_name),
        };
        let Some(rel) = clean_rel_path(&rel) else {
            tracing::warn!(path = rel, "skipping unsafe path");
            continue;
        };
        match safe.copy_new(&p.cache, &join_rel(dir, &rel)) {
            Ok(_) => report.added += 1,
            Err(SafetyError::AlreadyExists(_)) => {
                tracing::debug!(path = rel, "kept the pack's override");
            }
            Err(e) => return Err(e.into()),
        }
    }
    let record = PackRecord {
        format: pack.format,
        name: pack.name.clone(),
        version: pack.version.clone(),
        source: pack
            .source
            .file_name()
            .map(|n| n.to_string_lossy().into_owned())
            .unwrap_or_default(),
        manual: plan.manual.clone(),
    };
    save_record(safe, dir, &record)?;
    // Last: once instance.toml exists the launcher lists the instance.
    cfg.save(paths, safe)?;
    Ok(report)
}

/// Copy every file below the given zip folders into `dir` (create-only).
fn extract_overrides(
    safe: &SafePath,
    archive: &Path,
    prefixes: &[String],
    dir: &Path,
) -> Result<usize> {
    if prefixes.is_empty() {
        return Ok(0);
    }
    let file = std::fs::File::open(archive).map_err(io_err(archive))?;
    let mut zip =
        zip::ZipArchive::new(std::io::BufReader::new(file)).map_err(|e| LoaderError::Parse {
            what: archive.display().to_string(),
            message: e.to_string(),
        })?;
    let mut count = 0;
    for prefix in prefixes {
        for i in 0..zip.len() {
            let mut entry = zip.by_index(i).map_err(|e| LoaderError::Parse {
                what: archive.display().to_string(),
                message: e.to_string(),
            })?;
            if entry.is_dir() {
                continue;
            }
            let Some(rest) = entry.name().strip_prefix(prefix.as_str()) else {
                continue;
            };
            let Some(rel) = clean_rel_path(rest) else {
                tracing::warn!(entry = entry.name(), "skipping unsafe path in pack");
                continue;
            };
            if RESERVED_FILES.contains(&rel.as_str()) {
                continue;
            }
            let target = join_rel(dir, &rel);
            match safe.create_new_from(&target, &mut entry) {
                Ok(_) => count += 1,
                Err(SafetyError::AlreadyExists(_)) => {}
                Err(e) => return Err(e.into()),
            }
        }
    }
    Ok(count)
}

/// Look for manually downloaded files in `search_dirs` and add the ones
/// found (checked against size/SHA-1 when known) to the instance. Returns
/// the names added; the record keeps what is still missing.
pub fn add_manual_files(
    safe: &SafePath,
    instance_dir: &Path,
    search_dirs: &[PathBuf],
) -> Result<(Vec<String>, Vec<ManualFile>)> {
    let Some(mut record) = load_record(instance_dir) else {
        return Ok((Vec::new(), Vec::new()));
    };
    let mut added = Vec::new();
    let mut still = Vec::new();
    for m in std::mem::take(&mut record.manual) {
        let found = m.file_name.as_deref().and_then(|name| {
            search_dirs.iter().find_map(|d| find_file(d, name, &m))
        });
        let Some(src) = found else {
            still.push(m);
            continue;
        };
        let name = m.file_name.clone().unwrap_or_default();
        let folder = clean_rel_path(&m.folder).unwrap_or_else(|| "mods".into());
        let dest = join_rel(instance_dir, &folder).join(&name);
        match safe.copy_new(&src, &dest) {
            Ok(_) | Err(SafetyError::AlreadyExists(_)) => added.push(name),
            Err(e) => return Err(e.into()),
        }
    }
    record.manual = still.clone();
    save_record(safe, instance_dir, &record)?;
    Ok((added, still))
}

fn find_file(dir: &Path, name: &str, m: &ManualFile) -> Option<PathBuf> {
    let lower = name.to_lowercase();
    let candidate = std::fs::read_dir(dir).ok()?.flatten().find_map(|e| {
        let n = e.file_name().to_string_lossy().to_lowercase();
        (n == lower && e.path().is_file()).then(|| e.path())
    })?;
    let size_ok = m
        .size
        .is_none_or(|s| std::fs::metadata(&candidate).is_ok_and(|md| md.len() == s));
    let sha_ok = m.sha1.as_deref().is_none_or(|want| {
        mclaunch_download::hash::sha1_file(&candidate).is_ok_and(|got| got.eq_ignore_ascii_case(want))
    });
    (size_ok && sha_ok).then_some(candidate)
}

/// Default memory for a pack: modded packs get at least 4 GB, big ones 6.
pub fn suggested_memory_mb(pack: &PackInfo, default_mb: u32) -> u32 {
    let mods = pack.remote_count() + pack.bundled_mods;
    let want = match (pack.loader, mods) {
        (LoaderKind::Vanilla, _) => 0,
        (_, n) if n > 150 => 6144,
        _ => 4096,
    };
    default_mb.max(want)
}

/// A usable instance folder name from a pack name.
pub fn instance_name(pack_name: &str) -> String {
    const BAD: &[char] = &['/', '\\', ':', '*', '?', '"', '<', '>', '|'];
    let cleaned: String = pack_name
        .chars()
        .map(|c| if BAD.contains(&c) || c.is_control() { ' ' } else { c })
        .collect();
    let mut name = cleaned.split_whitespace().collect::<Vec<_>>().join(" ");
    name = name.trim_start_matches('.').trim().to_string();
    if name.chars().count() > 48 {
        name = name.chars().take(48).collect::<String>().trim().to_string();
    }
    if mclaunch_core::instance::validate_name(&name).is_err() {
        "Modpack".into()
    } else {
        name
    }
}

pub(crate) fn read_entry_limited(entry: &mut impl Read, limit: u64) -> std::io::Result<Vec<u8>> {
    let mut buf = Vec::new();
    entry.take(limit).read_to_end(&mut buf)?;
    Ok(buf)
}

#[cfg(test)]
mod tests;
