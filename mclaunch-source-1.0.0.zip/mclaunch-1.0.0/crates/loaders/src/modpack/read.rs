//! Format detection and parsing of modpack archives.

use std::collections::{BTreeMap, HashSet};
use std::io::{Read, Seek};
use std::path::Path;

use mclaunch_core::LoaderKind;
use serde::Deserialize;

use super::{
    clean_rel_path, read_entry_limited, scan, CfRef, ManualFile, PackFormat, PackInfo, RemoteFile,
};
use crate::{io_err, LoaderError, Result};

/// Hosts a `.mrpack` may download from (Modrinth's format rules).
const MRPACK_HOSTS: &[&str] = &[
    "cdn.modrinth.com",
    "github.com",
    "raw.githubusercontent.com",
    "gitlab.com",
];

/// Biggest metadata file we read into memory.
const META_LIMIT: u64 = 16 * 1024 * 1024;
/// Biggest bundled mod jar we open to read its metadata.
const JAR_LIMIT: u64 = 256 * 1024 * 1024;

type Zip = zip::ZipArchive<std::io::BufReader<std::fs::File>>;

fn parse_err(path: &Path, e: impl std::fmt::Display) -> LoaderError {
    LoaderError::Parse {
        what: path.display().to_string(),
        message: e.to_string(),
    }
}

fn open(path: &Path) -> Result<Zip> {
    let file = std::fs::File::open(path).map_err(io_err(path))?;
    zip::ZipArchive::new(std::io::BufReader::new(file)).map_err(|e| parse_err(path, e))
}

fn read_text<R: Read + Seek>(zip: &mut zip::ZipArchive<R>, name: &str) -> Option<Vec<u8>> {
    let mut entry = zip.by_name(name).ok()?;
    read_entry_limited(&mut entry, META_LIMIT).ok()
}

/// Folder that wraps the whole archive (`MyPack/…`), repeated up to twice.
fn wrapper_prefix(names: &[String]) -> String {
    let mut prefix = String::new();
    for _ in 0..2 {
        let below: Vec<&str> = names
            .iter()
            .filter_map(|n| n.strip_prefix(prefix.as_str()))
            .filter(|n| !n.is_empty())
            .collect();
        let Some(first) = below.first().and_then(|n| n.split_once('/')).map(|(d, _)| d) else {
            break;
        };
        let wrapped = below
            .iter()
            .all(|n| n.split_once('/').is_some_and(|(d, _)| d == first));
        // Never treat a game folder as a wrapper.
        if !wrapped || [".minecraft", "minecraft", "mods", "overrides"].contains(&first) {
            break;
        }
        prefix = format!("{prefix}{first}/");
    }
    prefix
}

/// The game folder of a plain/MultiMC zip: `.minecraft/`, `minecraft/` or
/// the archive root (after the wrapper), if it looks like one.
fn game_root(names: &[String], prefix: &str) -> Option<String> {
    let looks_like_game = |root: &str| {
        names.iter().any(|n| {
            n.strip_prefix(root).is_some_and(|rest| {
                (rest.starts_with("mods/") && rest.to_ascii_lowercase().ends_with(".jar"))
                    || ["config/", "resourcepacks/", "shaderpacks/", "saves/"]
                        .iter()
                        .any(|d| rest.starts_with(d))
            })
        })
    };
    [".minecraft/", "minecraft/", ""]
        .iter()
        .map(|sub| format!("{prefix}{sub}"))
        .find(|root| looks_like_game(root))
}

/// Cheap format check for dropped files (no jar scanning).
pub fn sniff(path: &Path) -> Option<PackFormat> {
    let mut zip = open(path).ok()?;
    let names: Vec<String> = zip.file_names().map(str::to_string).collect();
    let prefix = wrapper_prefix(&names);
    let has = |n: &str| names.iter().any(|e| *e == format!("{prefix}{n}"));
    if has("modrinth.index.json") {
        return Some(PackFormat::Modrinth);
    }
    if has("manifest.json") {
        if let Some(bytes) = read_text(&mut zip, &format!("{prefix}manifest.json")) {
            if serde_json::from_slice::<CfManifest>(&bytes).is_ok() {
                return Some(PackFormat::CurseForge);
            }
        }
    }
    if has("mmc-pack.json") {
        return Some(PackFormat::MultiMc);
    }
    let mods = game_root(&names, &prefix)?;
    // A plain zip needs mods (anything else is more likely a resource pack).
    names
        .iter()
        .any(|n| {
            n.strip_prefix(mods.as_str())
                .is_some_and(|r| r.starts_with("mods/") && r.to_ascii_lowercase().ends_with(".jar"))
        })
        .then_some(PackFormat::Generic)
}

/// Read a modpack archive. `known` (release ids from the version list)
/// filters guesses of the Minecraft version for plain zips.
pub fn read_pack(path: &Path, known: Option<&HashSet<String>>) -> Result<PackInfo> {
    let mut zip = open(path)?;
    let names: Vec<String> = zip.file_names().map(str::to_string).collect();
    let prefix = wrapper_prefix(&names);
    let stem = path
        .file_stem()
        .map(|s| s.to_string_lossy().into_owned())
        .unwrap_or_else(|| "Modpack".into());
    let mut info = PackInfo {
        source: path.to_path_buf(),
        name: stem,
        ..Default::default()
    };

    if let Some(bytes) = read_text(&mut zip, &format!("{prefix}modrinth.index.json")) {
        parse_mrpack(&bytes, &prefix, &mut info).map_err(|e| parse_err(path, e))?;
    } else if let Some(cf) = read_text(&mut zip, &format!("{prefix}manifest.json"))
        .and_then(|b| serde_json::from_slice::<CfManifest>(&b).ok())
    {
        parse_curseforge(cf, &prefix, &mut info).map_err(|e| parse_err(path, e))?;
    } else if let Some(bytes) = read_text(&mut zip, &format!("{prefix}mmc-pack.json")) {
        let cfg = read_text(&mut zip, &format!("{prefix}instance.cfg"));
        let root = game_root(&names, &prefix).unwrap_or_else(|| format!("{prefix}.minecraft/"));
        parse_mmc(&bytes, cfg.as_deref(), &root, &mut info).map_err(|e| parse_err(path, e))?;
        info.bundled_mods = count_jars(&names, &root);
    } else if let Some(root) = game_root(&names, &prefix) {
        info.format = PackFormat::Generic;
        info.overrides = vec![root.clone()];
        scan_generic(&mut zip, &names, &root, known, &mut info)?;
    } else {
        return Err(LoaderError::Unsupported(format!(
            "{} is not a modpack: no modrinth.index.json, CurseForge manifest.json, mmc-pack.json or mods/ folder",
            path.display()
        )));
    }

    let override_files = names
        .iter()
        .filter(|n| !n.ends_with('/'))
        .filter(|n| info.overrides.iter().any(|o| n.starts_with(o.as_str())))
        .count();
    if override_files > 0 {
        info.notes.push(format!(
            "{override_files} file(s) bundled in the pack (configs, mods, resource packs…)"
        ));
    }
    if info.mc_version.is_none() {
        info.notes
            .push("Could not detect the Minecraft version; choose it below.".into());
    }
    Ok(info)
}

fn count_jars(names: &[String], root: &str) -> usize {
    names
        .iter()
        .filter_map(|n| n.strip_prefix(root)?.strip_prefix("mods/"))
        .filter(|r| !r.contains('/') && r.to_ascii_lowercase().ends_with(".jar"))
        .count()
}

// ------------------------------------------------------------- Modrinth

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
struct MrIndex {
    #[serde(default)]
    format_version: u32,
    #[serde(default)]
    game: String,
    #[serde(default)]
    version_id: Option<String>,
    #[serde(default)]
    name: Option<String>,
    #[serde(default)]
    summary: Option<String>,
    #[serde(default)]
    files: Vec<MrIndexFile>,
    #[serde(default)]
    dependencies: BTreeMap<String, String>,
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
struct MrIndexFile {
    path: String,
    #[serde(default)]
    hashes: BTreeMap<String, String>,
    #[serde(default)]
    env: Option<MrEnv>,
    #[serde(default)]
    downloads: Vec<String>,
    #[serde(default)]
    file_size: Option<u64>,
}

#[derive(Debug, Deserialize)]
struct MrEnv {
    #[serde(default)]
    client: String,
}

fn host(url: &str) -> Option<String> {
    let rest = url.strip_prefix("https://")?;
    let host = rest.split(['/', '?', '#']).next()?;
    let host = host.rsplit('@').next()?.split(':').next()?;
    Some(host.to_ascii_lowercase())
}

fn parse_mrpack(bytes: &[u8], prefix: &str, info: &mut PackInfo) -> std::result::Result<(), String> {
    let index: MrIndex = serde_json::from_slice(bytes).map_err(|e| e.to_string())?;
    if index.format_version != 1 {
        return Err(format!(
            "unsupported .mrpack format version {}",
            index.format_version
        ));
    }
    if index.game != "minecraft" {
        return Err(format!("this pack is for \"{}\", not Minecraft", index.game));
    }
    info.format = PackFormat::Modrinth;
    if let Some(n) = index.name.filter(|n| !n.trim().is_empty()) {
        info.name = n;
    }
    info.version = index.version_id;
    info.summary = index.summary;
    info.mc_version = index.dependencies.get("minecraft").cloned();
    if info.mc_version.is_none() {
        return Err("the pack does not say which Minecraft version it needs".into());
    }
    for (dep, kind) in [
        ("fabric-loader", LoaderKind::Fabric),
        ("quilt-loader", LoaderKind::Quilt),
        ("forge", LoaderKind::Forge),
        ("neoforge", LoaderKind::NeoForge),
    ] {
        if let Some(v) = index.dependencies.get(dep) {
            info.loader = kind;
            info.loader_version = Some(v.clone());
        }
    }
    let mut skipped = 0;
    for f in index.files {
        if f.env.as_ref().is_some_and(|e| e.client == "unsupported") {
            skipped += 1;
            continue;
        }
        let Some(path) = clean_rel_path(&f.path) else {
            info.notes
                .push(format!("Skipped {}: unsafe path", f.path));
            continue;
        };
        let file_name = path.rsplit('/').next().unwrap_or(&path).to_string();
        let (allowed, other): (Vec<String>, Vec<String>) = f
            .downloads
            .into_iter()
            .partition(|u| host(u).is_some_and(|h| MRPACK_HOSTS.contains(&h.as_str())));
        let sha1 = f.hashes.get("sha1").cloned();
        if allowed.is_empty() {
            info.manual.push(ManualFile {
                name: file_name.clone(),
                file_name: Some(file_name),
                folder: path
                    .rsplit_once('/')
                    .map(|(d, _)| d.to_string())
                    .unwrap_or_default(),
                url: other.first().cloned().unwrap_or_default(),
                reason: "its download host is not allowed in .mrpack files".into(),
                sha1,
                size: f.file_size,
            });
            continue;
        }
        info.files.push(RemoteFile {
            path,
            urls: allowed,
            sha1,
            sha512: f.hashes.get("sha512").cloned(),
            size: f.file_size,
        });
    }
    if skipped > 0 {
        info.notes
            .push(format!("{skipped} server-only file(s) skipped"));
    }
    // client-overrides win over overrides.
    info.overrides = vec![
        format!("{prefix}client-overrides/"),
        format!("{prefix}overrides/"),
    ];
    Ok(())
}

// ----------------------------------------------------------- CurseForge

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
struct CfManifest {
    minecraft: CfMinecraft,
    #[serde(default)]
    manifest_type: Option<String>,
    #[serde(default)]
    name: Option<String>,
    #[serde(default)]
    version: Option<String>,
    #[serde(default)]
    author: Option<String>,
    #[serde(default)]
    files: Vec<CfManifestFile>,
    #[serde(default)]
    overrides: Option<String>,
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
struct CfMinecraft {
    version: String,
    #[serde(default)]
    mod_loaders: Vec<CfModLoader>,
}

#[derive(Debug, Deserialize)]
struct CfModLoader {
    id: String,
    #[serde(default)]
    primary: bool,
}

#[derive(Debug, Deserialize)]
struct CfManifestFile {
    #[serde(rename = "projectID")]
    project_id: u64,
    #[serde(rename = "fileID")]
    file_id: u64,
    #[serde(default = "yes")]
    required: bool,
}

fn yes() -> bool {
    true
}

/// `forge-47.2.0` -> (Forge, `47.2.0`).
pub(crate) fn cf_loader(id: &str) -> Option<(LoaderKind, String)> {
    let (name, version) = id.split_once('-')?;
    let kind = match name.to_ascii_lowercase().as_str() {
        "forge" => LoaderKind::Forge,
        "neoforge" => LoaderKind::NeoForge,
        "fabric" => LoaderKind::Fabric,
        "quilt" => LoaderKind::Quilt,
        _ => return None,
    };
    Some((kind, version.to_string()))
}

fn parse_curseforge(
    cf: CfManifest,
    prefix: &str,
    info: &mut PackInfo,
) -> std::result::Result<(), String> {
    if cf
        .manifest_type
        .as_deref()
        .is_some_and(|t| t != "minecraftModpack")
    {
        return Err(format!(
            "unsupported CurseForge manifest type {}",
            cf.manifest_type.unwrap_or_default()
        ));
    }
    info.format = PackFormat::CurseForge;
    if let Some(n) = cf.name.filter(|n| !n.trim().is_empty()) {
        info.name = n;
    }
    info.version = cf.version;
    info.author = cf.author;
    info.mc_version = Some(cf.minecraft.version.clone());
    let loader = cf
        .minecraft
        .mod_loaders
        .iter()
        .find(|l| l.primary)
        .or(cf.minecraft.mod_loaders.first());
    if let Some(l) = loader {
        let (kind, version) =
            cf_loader(&l.id).ok_or_else(|| format!("unknown mod loader {}", l.id))?;
        info.loader = kind;
        info.loader_version = Some(version);
    }
    let optional = cf.files.iter().filter(|f| !f.required).count();
    let mut seen = HashSet::new();
    info.curseforge = cf
        .files
        .iter()
        .filter(|f| f.required)
        .map(|f| CfRef {
            project_id: f.project_id,
            file_id: f.file_id,
        })
        .filter(|r| seen.insert(*r))
        .collect();
    if optional > 0 {
        info.notes
            .push(format!("{optional} optional file(s) not installed"));
    }
    let overrides = cf.overrides.unwrap_or_else(|| "overrides".into());
    let overrides = clean_rel_path(&overrides).ok_or("unsafe overrides folder")?;
    info.overrides = vec![format!("{prefix}{overrides}/")];
    Ok(())
}

// ---------------------------------------------------------- MultiMC/Prism

#[derive(Debug, Deserialize)]
struct MmcPack {
    #[serde(default)]
    components: Vec<MmcComponent>,
}

#[derive(Debug, Deserialize)]
struct MmcComponent {
    uid: String,
    #[serde(default)]
    version: Option<String>,
}

fn parse_mmc(
    bytes: &[u8],
    instance_cfg: Option<&[u8]>,
    root: &str,
    info: &mut PackInfo,
) -> std::result::Result<(), String> {
    let pack: MmcPack = serde_json::from_slice(bytes).map_err(|e| e.to_string())?;
    info.format = PackFormat::MultiMc;
    for c in pack.components {
        let kind = match c.uid.as_str() {
            "net.minecraft" => {
                info.mc_version = c.version;
                continue;
            }
            "net.minecraftforge" => LoaderKind::Forge,
            "net.neoforged" => LoaderKind::NeoForge,
            "net.fabricmc.fabric-loader" => LoaderKind::Fabric,
            "org.quiltmc.quilt-loader" => LoaderKind::Quilt,
            _ => continue,
        };
        info.loader = kind;
        info.loader_version = c.version;
    }
    if let Some(cfg) = instance_cfg {
        let text = String::from_utf8_lossy(cfg);
        if let Some(name) = text
            .lines()
            .find_map(|l| l.strip_prefix("name="))
            .map(str::trim)
            .filter(|n| !n.is_empty())
        {
            info.name = name.to_string();
        }
    }
    info.overrides = vec![root.to_string()];
    Ok(())
}

// ------------------------------------------------------------ Plain zip

fn scan_generic(
    zip: &mut Zip,
    names: &[String],
    root: &str,
    known: Option<&HashSet<String>>,
    info: &mut PackInfo,
) -> Result<()> {
    let mods_dir = format!("{root}mods/");
    let mut metas = Vec::new();
    for name in names {
        let Some(file) = name.strip_prefix(mods_dir.as_str()) else {
            continue;
        };
        if file.contains('/') || !file.to_ascii_lowercase().ends_with(".jar") {
            continue;
        }
        let Ok(mut entry) = zip.by_name(name) else {
            continue;
        };
        if entry.size() > JAR_LIMIT {
            continue;
        }
        let Ok(bytes) = read_entry_limited(&mut entry, JAR_LIMIT) else {
            continue;
        };
        metas.push(scan::scan_jar(&bytes, file));
    }
    info.bundled_mods = metas.len();
    let d = scan::detect(&metas, known);
    info.mc_version = d.mc.clone();
    info.loader = d.loader;
    info.loader_min = d.loader_min.clone();
    for m in &metas {
        info.provided.extend(m.ids.iter().cloned());
        info.requires.extend(m.depends.iter().cloned());
    }
    if let Some(mc) = &d.mc {
        info.notes.push(format!(
            "Minecraft {mc} detected from {} of {} mod(s)",
            d.mc_mods,
            metas.len()
        ));
    }
    if d.loader != LoaderKind::Vanilla {
        info.notes.push(format!(
            "{} detected from {} mod(s); the recommended loader version will be installed",
            d.loader.label(),
            d.loader_mods
        ));
    } else if !metas.is_empty() {
        info.notes
            .push("Could not detect the mod loader; choose it below.".into());
    }
    let missing = info.missing_deps(info.loader);
    if !missing.is_empty() {
        info.notes.push(format!(
            "Missing required mod(s) will be fetched from Modrinth: {}",
            missing.join(", ")
        ));
    }
    Ok(())
}
