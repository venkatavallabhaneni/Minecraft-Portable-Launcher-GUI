//! CurseForge file lookups for `manifest.json` packs.
//!
//! * With an API key (Settings) the official API is used: it gives SHA-1
//!   hashes, the project category, and `downloadUrl: null` when the author
//!   does not allow third-party downloads. Those files go to the manual list.
//! * Without a key, the public website endpoints give the file name and size,
//!   and the download goes through the website's redirect to the CDN.
//!
//! Lookups are cached in `loaders/modpacks/curseforge/` so a reinstall works
//! offline.

use std::collections::HashMap;

use futures::StreamExt;
use serde::{Deserialize, Serialize};

use super::{CfRef, ManualFile, PARALLEL_DOWNLOADS};
use crate::Loaders;

const API: &str = "https://api.curseforge.com/v1";
const SITE_API: &str = "https://www.curseforge.com/api/v1";

/// A resolved CurseForge file.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct CfFile {
    pub project_id: u64,
    pub file_id: u64,
    pub file_name: String,
    pub size: Option<u64>,
    pub sha1: Option<String>,
    /// `None` when the author does not allow third-party downloads.
    pub url: Option<String>,
    pub mirrors: Vec<String>,
    /// CurseForge category (6 mods, 12 resource packs, 6552 shaders).
    pub class_id: Option<u32>,
    pub project_name: Option<String>,
    /// Page to open for a manual download.
    pub page: String,
}

impl CfFile {
    pub fn display_name(&self) -> String {
        self.project_name
            .clone()
            .unwrap_or_else(|| self.file_name.clone())
    }

    /// Instance folder by category; `None` = decide from the contents.
    pub fn folder(&self) -> Option<&'static str> {
        match self.class_id? {
            6 => Some("mods"),
            12 => Some("resourcepacks"),
            6552 => Some("shaderpacks"),
            _ => None,
        }
    }

    pub fn manual(&self, reason: &str) -> ManualFile {
        ManualFile {
            name: self.display_name(),
            file_name: Some(self.file_name.clone()),
            folder: self.folder().unwrap_or("mods").to_string(),
            url: self.page.clone(),
            reason: reason.to_string(),
            sha1: self.sha1.clone(),
            size: self.size,
        }
    }
}

#[derive(Debug, Default)]
pub struct Resolved {
    pub files: Vec<CfFile>,
    pub manual: Vec<ManualFile>,
    pub notes: Vec<String>,
}

fn project_page(project_id: u64) -> String {
    format!("https://www.curseforge.com/projects/{project_id}")
}

/// CDN path: `files/4593/548/jei.jar` (no zero padding).
pub fn cdn_url(file_id: u64, file_name: &str) -> String {
    let encoded: String = file_name
        .bytes()
        .map(|b| {
            if b.is_ascii_alphanumeric() || b"-._~".contains(&b) {
                (b as char).to_string()
            } else {
                format!("%{b:02X}")
            }
        })
        .collect();
    format!(
        "https://mediafilez.forgecdn.net/files/{}/{}/{encoded}",
        file_id / 1000,
        file_id % 1000
    )
}

fn unresolved(r: &CfRef, reason: String) -> ManualFile {
    ManualFile {
        name: format!("CurseForge project {} (file {})", r.project_id, r.file_id),
        file_name: None,
        folder: "mods".into(),
        url: project_page(r.project_id),
        reason,
        sha1: None,
        size: None,
    }
}

/// Resolve every reference. Never fails as a whole: files that cannot be
/// resolved come back in `manual`.
pub async fn resolve(l: &Loaders, refs: &[CfRef], api_key: Option<&str>) -> Resolved {
    let cache_dir = l.cache_dir("modpacks").join("curseforge");
    let cache_path = |r: &CfRef| cache_dir.join(format!("{}.json", r.file_id));
    let mut out = Resolved::default();
    let mut todo = Vec::new();
    for r in refs {
        let cached = std::fs::read(cache_path(r))
            .ok()
            .and_then(|b| serde_json::from_slice::<CfFile>(&b).ok());
        match cached {
            // A keyed lookup is authoritative; a keyless one is refreshed
            // when a key is available.
            Some(f) if l.http().is_offline() || api_key.is_none() || f.sha1.is_some() => {
                out.files.push(f)
            }
            _ => todo.push(*r),
        }
    }
    if todo.is_empty() {
        return out;
    }
    if l.http().is_offline() {
        for r in &todo {
            out.manual
                .push(unresolved(r, "offline mode is on and it is not cached".into()));
        }
        return out;
    }

    let mut fetched = None;
    if let Some(key) = api_key.filter(|k| !k.trim().is_empty()) {
        match with_key(l, &todo, key.trim()).await {
            Ok(files) => fetched = Some(files),
            Err(e) => out.notes.push(format!(
                "CurseForge API key not usable ({e}); using the public website instead"
            )),
        }
    }
    let files = match fetched {
        Some(f) => f,
        None => keyless(l, &todo).await,
    };
    for r in &todo {
        match files.get(&r.file_id) {
            Some(Ok(f)) => {
                if let Ok(json) = serde_json::to_vec(f) {
                    let _ = l.safe().write(&cache_path(r), &json);
                }
                out.files.push(f.clone());
            }
            Some(Err(e)) => out.manual.push(unresolved(r, e.clone())),
            None => out
                .manual
                .push(unresolved(r, "CurseForge did not return this file".into())),
        }
    }
    out
}

#[derive(Debug, Deserialize)]
struct Data<T> {
    data: T,
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
struct ApiFile {
    id: u64,
    mod_id: u64,
    file_name: String,
    #[serde(default)]
    file_length: Option<u64>,
    #[serde(default)]
    download_url: Option<String>,
    #[serde(default)]
    hashes: Vec<ApiHash>,
}

#[derive(Debug, Deserialize)]
struct ApiHash {
    value: String,
    algo: u32,
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
struct ApiMod {
    id: u64,
    name: String,
    #[serde(default)]
    class_id: Option<u32>,
    #[serde(default)]
    links: Option<ApiLinks>,
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
struct ApiLinks {
    #[serde(default)]
    website_url: Option<String>,
}

async fn post<T: serde::de::DeserializeOwned>(
    l: &Loaders,
    url: &str,
    key: &str,
    body: serde_json::Value,
) -> Result<T, String> {
    let resp = l
        .http()
        .client()
        .post(url)
        .header("x-api-key", key)
        .header("accept", "application/json")
        .json(&body)
        .send()
        .await
        .map_err(|e| e.to_string())?;
    let status = resp.status();
    if !status.is_success() {
        return Err(format!("HTTP {}", status.as_u16()));
    }
    resp.json::<T>().await.map_err(|e| e.to_string())
}

type Lookup = HashMap<u64, Result<CfFile, String>>;

async fn with_key(l: &Loaders, refs: &[CfRef], key: &str) -> Result<Lookup, String> {
    let mut files = Vec::new();
    for chunk in refs.chunks(500) {
        let ids: Vec<u64> = chunk.iter().map(|r| r.file_id).collect();
        let d: Data<Vec<ApiFile>> = post(
            l,
            &format!("{API}/mods/files"),
            key,
            serde_json::json!({ "fileIds": ids }),
        )
        .await?;
        files.extend(d.data);
    }
    let mut mod_ids: Vec<u64> = files.iter().map(|f| f.mod_id).collect();
    mod_ids.sort_unstable();
    mod_ids.dedup();
    let mut mods = HashMap::new();
    for chunk in mod_ids.chunks(500) {
        let d: Data<Vec<ApiMod>> = post(
            l,
            &format!("{API}/mods"),
            key,
            serde_json::json!({ "modIds": chunk }),
        )
        .await?;
        mods.extend(d.data.into_iter().map(|m| (m.id, m)));
    }
    let mut out = Lookup::new();
    for f in files {
        if !mclaunch_safety::is_plain_name(&f.file_name) {
            out.insert(f.id, Err(format!("bad file name {}", f.file_name)));
            continue;
        }
        let m = mods.get(&f.mod_id);
        let page = m
            .and_then(|m| m.links.as_ref()?.website_url.clone())
            .map(|w| format!("{}/files/{}", w.trim_end_matches('/'), f.id))
            .unwrap_or_else(|| project_page(f.mod_id));
        let sha1 = f
            .hashes
            .iter()
            .find(|h| h.algo == 1)
            .map(|h| h.value.to_ascii_lowercase());
        let cdn = cdn_url(f.id, &f.file_name);
        out.insert(
            f.id,
            Ok(CfFile {
                project_id: f.mod_id,
                file_id: f.id,
                size: f.file_length.filter(|s| *s > 0),
                sha1,
                mirrors: if f.download_url.is_some() {
                    vec![cdn]
                } else {
                    Vec::new()
                },
                url: f.download_url,
                class_id: m.and_then(|m| m.class_id),
                project_name: m.map(|m| m.name.clone()),
                page,
                file_name: f.file_name,
            }),
        );
    }
    Ok(out)
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
struct SiteFile {
    file_name: String,
    #[serde(default)]
    file_length: Option<u64>,
}

async fn keyless(l: &Loaders, refs: &[CfRef]) -> Lookup {
    futures::stream::iter(refs.iter().copied())
        .map(|r| async move {
            let url = format!("{SITE_API}/mods/{}/files/{}", r.project_id, r.file_id);
            let res = match l.http().get_json::<Data<Option<SiteFile>>>(&url).await {
                Ok(Data { data: None }) => {
                    Err("CurseForge has no such file (it may have been removed)".to_string())
                }
                Ok(Data { data: Some(f) }) if mclaunch_safety::is_plain_name(&f.file_name) => {
                    Ok(CfFile {
                        project_id: r.project_id,
                        file_id: r.file_id,
                        size: f.file_length.filter(|s| *s > 0),
                        sha1: None,
                        url: Some(format!("{url}/download")),
                        mirrors: vec![cdn_url(r.file_id, &f.file_name)],
                        class_id: None,
                        project_name: None,
                        page: project_page(r.project_id),
                        file_name: f.file_name,
                    })
                }
                Ok(Data { data: Some(f) }) => Err(format!("bad file name {}", f.file_name)),
                Err(mclaunch_download::DownloadError::Status { status, .. }) => {
                    Err(format!("CurseForge refused the lookup (HTTP {status})"))
                }
                Err(e) => Err(format!("lookup failed: {e}")),
            };
            (r.file_id, res)
        })
        .buffer_unordered(PARALLEL_DOWNLOADS)
        .collect()
        .await
}
