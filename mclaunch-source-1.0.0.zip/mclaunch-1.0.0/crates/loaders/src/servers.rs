//! Server software sources: PaperMC (Paper, Folia) via the Fill v3 API,
//! Purpur, Spigot (BuildTools), Fabric server launcher jars.

use serde::Deserialize;

use crate::{LoaderError, LoaderVersion, Loaders, Result, Software};

const FILL: &str = "https://fill.papermc.io/v3/projects";
const PURPUR: &str = "https://api.purpurmc.org/v2/purpur";
pub const BUILDTOOLS_URL: &str =
    "https://hub.spigotmc.org/jenkins/job/BuildTools/lastSuccessfulBuild/artifact/target/BuildTools.jar";

/// A downloadable server jar.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ServerJar {
    pub url: String,
    pub file_name: String,
    pub sha256: Option<String>,
    pub size: Option<u64>,
}

fn project(software: Software) -> &'static str {
    match software {
        Software::Folia => "folia",
        _ => "paper",
    }
}

#[derive(Debug, Deserialize)]
struct FillProject {
    #[serde(default)]
    versions: std::collections::BTreeMap<String, Vec<String>>,
}

#[derive(Debug, Deserialize)]
struct PurpurProject {
    #[serde(default)]
    versions: Vec<String>,
}

/// Is `mc` available for Paper / Folia / Purpur? (One entry: "latest".)
pub async fn paper_like_versions(
    l: &Loaders,
    software: Software,
    mc: &str,
) -> Result<(Vec<LoaderVersion>, bool)> {
    let (available, cached) = match software {
        Software::Purpur => {
            let (p, c): (PurpurProject, bool) = l
                .cached_json(PURPUR, &l.cache_dir("purpur").join("versions.json"))
                .await?;
            (p.versions.iter().any(|v| v == mc), c)
        }
        _ => {
            let name = project(software);
            let (p, c): (FillProject, bool) = l
                .cached_json(
                    &format!("{FILL}/{name}"),
                    &l.cache_dir(name).join("versions.json"),
                )
                .await?;
            (p.versions.values().flatten().any(|v| v == mc), c)
        }
    };
    let list = if available {
        vec![LoaderVersion::new("latest build", true)]
    } else {
        Vec::new()
    };
    Ok((list, cached))
}

/// Spigot builds exist for `mc` when BuildTools has a recipe for it.
pub async fn spigot_available(l: &Loaders, mc: &str) -> Result<(Vec<LoaderVersion>, bool)> {
    if !mc
        .chars()
        .all(|c| c.is_ascii_alphanumeric() || c == '.' || c == '-')
    {
        return Ok((Vec::new(), false));
    }
    let url = format!("https://hub.spigotmc.org/versions/{mc}.json");
    let cache = l.cache_dir("spigot").join(format!("{mc}.json"));
    match l.cached_get(&url, &cache).await {
        Ok((_, cached)) => Ok((vec![LoaderVersion::new("BuildTools", true)], cached)),
        Err(LoaderError::Download(mclaunch_download::DownloadError::Status {
            status: 404,
            ..
        })) => Ok((Vec::new(), false)),
        Err(e) => Err(e),
    }
}

#[derive(Debug, Deserialize)]
struct FillDownload {
    name: String,
    url: String,
    #[serde(default)]
    size: Option<u64>,
    #[serde(default)]
    checksums: std::collections::BTreeMap<String, String>,
}

#[derive(Debug, Deserialize)]
struct FillBuild {
    downloads: std::collections::BTreeMap<String, FillDownload>,
}

#[derive(Debug, Deserialize)]
struct PurpurLatest {
    build: String,
}

/// Latest Paper / Folia / Purpur jar for `mc`.
pub async fn paper_like_jar(l: &Loaders, software: Software, mc: &str) -> Result<ServerJar> {
    match software {
        Software::Purpur => {
            let latest: PurpurLatest = l.http().get_json(&format!("{PURPUR}/{mc}/latest")).await?;
            Ok(ServerJar {
                url: format!("{PURPUR}/{mc}/{}/download", latest.build),
                file_name: format!("purpur-{mc}-{}.jar", latest.build),
                sha256: None,
                size: None,
            })
        }
        Software::Paper | Software::Folia => {
            let name = project(software);
            let build: FillBuild = l
                .http()
                .get_json(&format!("{FILL}/{name}/versions/{mc}/builds/latest"))
                .await?;
            let dl = build
                .downloads
                .into_iter()
                .find(|(k, _)| k == "server:default")
                .map(|(_, v)| v)
                .ok_or_else(|| {
                    LoaderError::Failed(format!("no server download for {name} {mc}"))
                })?;
            Ok(ServerJar {
                url: dl.url,
                file_name: dl.name,
                sha256: dl.checksums.get("sha256").cloned(),
                size: dl.size,
            })
        }
        other => Err(LoaderError::Unsupported(format!(
            "{} has no direct jar",
            other.label()
        ))),
    }
}

#[derive(Debug, Deserialize)]
struct FabricInstaller {
    version: String,
    #[serde(default)]
    stable: bool,
}

/// Fabric's server launcher jar (downloads the server on first start).
pub async fn fabric_server_jar(l: &Loaders, mc: &str, loader: &str) -> Result<ServerJar> {
    let (installers, _): (Vec<FabricInstaller>, bool) = l
        .cached_json(
            "https://meta.fabricmc.net/v2/versions/installer",
            &l.cache_dir("fabric").join("installers.json"),
        )
        .await?;
    let installer = installers
        .iter()
        .find(|i| i.stable)
        .or_else(|| installers.first())
        .ok_or_else(|| LoaderError::Failed("no Fabric installer versions".into()))?;
    Ok(ServerJar {
        url: format!(
            "https://meta.fabricmc.net/v2/versions/loader/{mc}/{loader}/{}/server/jar",
            installer.version
        ),
        file_name: format!(
            "fabric-server-mc.{mc}-loader.{loader}-launcher.{}.jar",
            installer.version
        ),
        sha256: None,
        size: None,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn fill_parsing() {
        let p: FillProject = serde_json::from_str(
            r#"{"project": {"id": "paper"}, "versions": {"1.21": ["1.21.4", "1.21.3"], "26.3": ["26.3"]}}"#,
        )
        .unwrap();
        assert!(p.versions.values().flatten().any(|v| v == "1.21.4"));
        let b: FillBuild = serde_json::from_str(
            r#"{"id": 232, "downloads": {"server:default": {"name": "paper-1.21.4-232.jar", "checksums": {"sha256": "5ee4"}, "size": 51437498, "url": "https://fill-data.papermc.io/x.jar"}}}"#,
        )
        .unwrap();
        assert_eq!(b.downloads["server:default"].checksums["sha256"], "5ee4");
    }
}
