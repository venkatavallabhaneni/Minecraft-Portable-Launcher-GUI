//! OptiFine. Its licence forbids redistribution, so the user downloads the
//! jar from optifine.net and imports it; we never fetch it ourselves.
//!
//! * Vanilla: build a version profile that runs OptiFine through
//!   LaunchWrapper (`--tweakClass optifine.OptiFineTweaker`), like the
//!   official installer does, using OptiFine's own `optifine.Patcher`.
//! * Forge / Fabric: the jar is simply added to the instance's `mods/`
//!   (Fabric additionally needs OptiFabric, which the user adds).

use std::path::{Path, PathBuf};
use std::time::Duration;

use mclaunch_core::{LauncherPaths, Progress, ProgressFn};
use mclaunch_safety::{SafePath, SafetyError};

use crate::{read_zip_entry, zip_entry_names, LoaderError, LoaderVersion, Loaders, Result};

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct OptiFineInfo {
    pub mc: String,
    /// e.g. `HD_U_I6` or `HD_U_I7_pre1`
    pub edition: String,
    pub file_name: String,
}

/// Parse `OptiFine_1.20.1_HD_U_I6.jar` / `preview_OptiFine_1.21.4_HD_U_J3_pre5.jar`.
pub fn parse_name(file_name: &str) -> Option<OptiFineInfo> {
    let stem = file_name.strip_suffix(".jar")?;
    let stem = stem.strip_prefix("preview_").unwrap_or(stem);
    let rest = stem.strip_prefix("OptiFine_")?;
    let idx = rest.find("_HD")?;
    let mc = &rest[..idx];
    let edition = &rest[idx + 1..];
    if mc.is_empty() || edition.is_empty() {
        return None;
    }
    Some(OptiFineInfo {
        mc: mc.to_string(),
        edition: edition.to_string(),
        file_name: file_name.to_string(),
    })
}

pub fn optifine_dir(paths: &LauncherPaths) -> PathBuf {
    paths.loaders_dir().join("optifine")
}

/// Imported OptiFine jars.
pub fn imported(paths: &LauncherPaths) -> Vec<(PathBuf, OptiFineInfo)> {
    let mut out: Vec<(PathBuf, OptiFineInfo)> = std::fs::read_dir(optifine_dir(paths))
        .map(|rd| {
            rd.flatten()
                .filter_map(|e| {
                    let name = e.file_name().to_string_lossy().into_owned();
                    parse_name(&name).map(|i| (e.path(), i))
                })
                .collect()
        })
        .unwrap_or_default();
    out.sort_by(|a, b| b.1.file_name.cmp(&a.1.file_name));
    out
}

pub fn imported_for(paths: &LauncherPaths, mc: &str) -> Vec<LoaderVersion> {
    imported(paths)
        .into_iter()
        .filter(|(_, i)| i.mc == mc)
        .map(|(_, i)| LoaderVersion::new(i.edition.clone(), !i.edition.contains("pre")))
        .collect()
}

pub fn find_imported(paths: &LauncherPaths, mc: &str, edition: &str) -> Option<PathBuf> {
    imported(paths)
        .into_iter()
        .find(|(_, i)| i.mc == mc && i.edition == edition)
        .map(|(p, _)| p)
}

/// Copy a user-provided OptiFine jar into `loaders/optifine/`.
pub fn import(paths: &LauncherPaths, safe: &SafePath, src: &Path) -> Result<OptiFineInfo> {
    let file_name = src
        .file_name()
        .map(|n| n.to_string_lossy().into_owned())
        .unwrap_or_default();
    let info = parse_name(&file_name).ok_or_else(|| {
        LoaderError::Failed(format!(
            "{file_name} does not look like an OptiFine jar (expected OptiFine_<mc>_HD_….jar)"
        ))
    })?;
    let names = zip_entry_names(src)?;
    if !names
        .iter()
        .any(|n| n.starts_with("optifine/") || n.starts_with("net/optifine/"))
    {
        return Err(LoaderError::Failed(format!(
            "{file_name} does not contain OptiFine classes"
        )));
    }
    let dest = optifine_dir(paths).join(&file_name);
    match safe.copy_new(src, &dest) {
        Ok(_) | Err(SafetyError::AlreadyExists(_)) => Ok(info),
        Err(e) => Err(e.into()),
    }
}

/// Is `mc` 1.13 or newer (OptiFine ships `launchwrapper-of` from then on)?
fn is_modern(mc: &str) -> bool {
    match mc.strip_prefix("1.") {
        Some(rest) => rest
            .split('.')
            .next()
            .and_then(|m| m.parse::<u32>().ok())
            .is_some_and(|m| m >= 13),
        None => true,
    }
}

/// Create the `<mc>-OptiFine_<edition>` version profile for vanilla.
pub async fn install_vanilla(
    l: &Loaders,
    jar: &Path,
    java: Option<&Path>,
    progress: &ProgressFn,
) -> Result<String> {
    let file_name = jar
        .file_name()
        .map(|n| n.to_string_lossy().into_owned())
        .unwrap_or_default();
    let info = parse_name(&file_name)
        .ok_or_else(|| LoaderError::Failed(format!("{file_name} is not an OptiFine jar")))?;
    let mc = &info.mc;
    let id = format!("{mc}-OptiFine_{}", info.edition);
    let lib_ver = format!("{mc}_{}", info.edition);
    let paths = l.paths();
    let lib = paths.libraries_dir().join(format!(
        "optifine/OptiFine/{lib_ver}/OptiFine-{lib_ver}.jar"
    ));
    let vanilla = paths.version_jar(mc);
    if !vanilla.is_file() {
        return Err(LoaderError::Failed(format!(
            "Minecraft {mc} is not installed"
        )));
    }

    // 1. Patch with OptiFine's own patcher; fall back to the jar as-is.
    let mut patched = false;
    if let Some(java) = java {
        progress(Progress::stage("Patching OptiFine"));
        let tmp = optifine_dir(paths).join(format!(".{lib_ver}.patched.jar"));
        l.safe().remove_file(&tmp)?;
        let args = vec![
            "-cp".to_string(),
            jar.to_string_lossy().into_owned(),
            "optifine.Patcher".to_string(),
            vanilla.to_string_lossy().into_owned(),
            jar.to_string_lossy().into_owned(),
            tmp.to_string_lossy().into_owned(),
        ];
        match crate::run_java(
            java,
            &args,
            &optifine_dir(paths),
            "OptiFine patcher",
            progress,
            Duration::from_secs(600),
        )
        .await
        {
            Ok(_) if tmp.is_file() => {
                l.safe().rename(&tmp, &lib)?;
                patched = true;
            }
            Ok(_) => tracing::warn!("OptiFine patcher produced no output; using the jar as-is"),
            Err(e) => tracing::warn!(error = %e, "OptiFine patcher failed; using the jar as-is"),
        }
    }
    if !patched {
        l.safe().copy_file(jar, &lib)?;
    }

    // 2. LaunchWrapper.
    let launchwrapper = if is_modern(mc) {
        let version = read_zip_entry(jar, "launchwrapper-of.txt")?
            .map(|b| String::from_utf8_lossy(&b).trim().to_string())
            .filter(|v| !v.is_empty());
        let embedded = match version {
            Some(v) => Some(v),
            None => zip_entry_names(jar)?.iter().find_map(|n| {
                n.strip_prefix("launchwrapper-of-")
                    .and_then(|r| r.strip_suffix(".jar"))
                    .map(str::to_string)
            }),
        };
        match embedded {
            Some(v) => {
                let bytes = read_zip_entry(jar, &format!("launchwrapper-of-{v}.jar"))?
                    .ok_or_else(|| LoaderError::Failed("launchwrapper-of jar missing".into()))?;
                let dest = paths.libraries_dir().join(format!(
                    "optifine/launchwrapper-of/{v}/launchwrapper-of-{v}.jar"
                ));
                l.safe().write(&dest, &bytes)?;
                serde_json::json!({"name": format!("optifine:launchwrapper-of:{v}"), "url": ""})
            }
            None => serde_json::json!({"name": "net.minecraft:launchwrapper:1.12"}),
        }
    } else {
        serde_json::json!({"name": "net.minecraft:launchwrapper:1.12"})
    };

    // 3. Profile JSON.
    let parent = mclaunch_core::VersionJson::load(&paths.version_json(mc))?;
    let optifine_lib =
        serde_json::json!({"name": format!("optifine:OptiFine:{lib_ver}"), "url": ""});
    let mut profile = serde_json::json!({
        "id": id,
        "inheritsFrom": mc,
        "type": "release",
        "mainClass": "net.minecraft.launchwrapper.Launch",
        "libraries": [optifine_lib, launchwrapper],
    });
    match parent.minecraft_arguments {
        Some(args) => {
            profile["minecraftArguments"] =
                serde_json::Value::String(format!("{args} --tweakClass optifine.OptiFineTweaker"));
        }
        None => {
            profile["arguments"] = serde_json::json!({
                "game": ["--tweakClass", "optifine.OptiFineTweaker"],
                "jvm": []
            });
        }
    }
    let bytes =
        serde_json::to_vec_pretty(&profile).map_err(|e| LoaderError::Failed(e.to_string()))?;
    l.safe().write(&paths.version_json(&id), &bytes)?;
    tracing::info!(%id, patched, "OptiFine profile installed");
    Ok(id)
}

/// Add the OptiFine jar to an instance's `mods/` (Forge, or Fabric with
/// OptiFabric). Never overwrites an existing file.
pub fn add_to_mods(safe: &SafePath, instance_dir: &Path, jar: &Path) -> Result<PathBuf> {
    let name = jar
        .file_name()
        .ok_or_else(|| LoaderError::Failed("bad jar path".into()))?;
    let dest = instance_dir.join("mods").join(name);
    match safe.copy_new(jar, &dest) {
        Ok(_) | Err(SafetyError::AlreadyExists(_)) => Ok(dest),
        Err(e) => Err(e.into()),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn names() {
        let i = parse_name("OptiFine_1.20.1_HD_U_I6.jar").unwrap();
        assert_eq!(i.mc, "1.20.1");
        assert_eq!(i.edition, "HD_U_I6");
        let i = parse_name("preview_OptiFine_1.21.4_HD_U_J3_pre5.jar").unwrap();
        assert_eq!(i.mc, "1.21.4");
        assert_eq!(i.edition, "HD_U_J3_pre5");
        assert!(parse_name("sodium-fabric-0.6.jar").is_none());
        assert!(parse_name("OptiFine_.jar").is_none());
    }

    #[test]
    fn modern_check() {
        assert!(!is_modern("1.12.2"));
        assert!(!is_modern("1.8.9"));
        assert!(is_modern("1.13"));
        assert!(is_modern("1.21.4"));
        assert!(is_modern("26.1"));
    }
}
