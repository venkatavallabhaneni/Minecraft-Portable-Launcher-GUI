//! Mod management for an instance: search and install from Modrinth or
//! CurseForge (with required dependencies), import jars from the computer,
//! list / enable / disable / remove / update installed mods, and a
//! launcher-wide "global" mod list that is added to every compatible
//! instance before it launches.
//!
//! `mods/` is user data, so the only changes made to existing files there
//! are renames that never replace anything (`x.jar` <-> `x.jar.disabled`)
//! and moving a file to the recycle bin when the user removes it.
//!
//! What the launcher installed is remembered in `<instance>/mclaunch-mods.json`
//! (source, project and version), so titles, updates and global mods work.

use std::collections::{HashSet, VecDeque};
use std::path::{Path, PathBuf};

use futures::StreamExt;
use mclaunch_core::{InstanceConfig, LauncherPaths, LoaderKind, Progress, ProgressFn};
use mclaunch_download::{hash, DownloadTask, Downloader};
use mclaunch_safety::{SafePath, SafetyError};
use serde::{Deserialize, Serialize};

use crate::modpack::{curseforge::cdn_url, scan_jar, ModMeta, PARALLEL_DOWNLOADS};
use crate::{modrinth, url_encode, LoaderError, Loaders, Result};

/// Per-instance record of launcher-installed mods.
pub const INDEX_FILE: &str = "mclaunch-mods.json";
/// Launcher-wide global mods (local jars and the list itself).
pub const GLOBAL_DIR: &str = "global-mods";
const GLOBAL_INDEX: &str = "global.json";
/// How deep required dependencies are followed.
const MAX_DEPTH: usize = 4;

const CF_API: &str = "https://api.curseforge.com/v1";
const CF_SITE: &str = "https://www.curseforge.com/api/v1";

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Default, Serialize, Deserialize)]
pub enum Source {
    Modrinth,
    CurseForge,
    #[default]
    Local,
}

impl Source {
    pub fn label(self) -> &'static str {
        match self {
            Source::Modrinth => "Modrinth",
            Source::CurseForge => "CurseForge",
            Source::Local => "Local",
        }
    }
}

/// A mod project on Modrinth or CurseForge.
#[derive(Debug, Clone, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct ProjectRef {
    pub source: Source,
    /// Modrinth project id/slug, or CurseForge project id.
    pub id: String,
    pub title: String,
}

/// One launcher-installed file, keyed by its file name without `.disabled`.
#[derive(Debug, Clone, PartialEq, Eq, Default, Serialize, Deserialize)]
#[serde(default)]
pub struct ModRecord {
    pub file: String,
    pub source: Source,
    pub project_id: String,
    /// Modrinth version id or CurseForge file id.
    pub version_id: String,
    pub title: String,
    pub version: String,
    /// Added from the global mod list.
    pub global: bool,
    /// Installed as a dependency of another mod.
    pub dependency: bool,
}

#[derive(Debug, Default, Serialize, Deserialize)]
#[serde(default)]
struct Index {
    mods: Vec<ModRecord>,
}

fn base_name(file: &str) -> &str {
    file.strip_suffix(".disabled").unwrap_or(file)
}

pub fn load_index(instance_dir: &Path) -> Vec<ModRecord> {
    std::fs::read(instance_dir.join(INDEX_FILE))
        .ok()
        .and_then(|b| serde_json::from_slice::<Index>(&b).ok())
        .map(|i| i.mods)
        .unwrap_or_default()
}

fn save_index(safe: &SafePath, instance_dir: &Path, mods: &[ModRecord]) -> Result<()> {
    let json = serde_json::to_vec_pretty(&Index {
        mods: mods.to_vec(),
    })
    .map_err(|e| LoaderError::Failed(e.to_string()))?;
    safe.write(&instance_dir.join(INDEX_FILE), &json)?;
    Ok(())
}

/// Where mods go and which versions fit.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Target {
    pub dir: PathBuf,
    pub loader: LoaderKind,
    pub mc: String,
}

impl Target {
    pub fn for_instance(paths: &LauncherPaths, cfg: &InstanceConfig) -> Self {
        Self {
            dir: cfg.dir(paths),
            loader: cfg.loader,
            mc: cfg.mc_version.clone(),
        }
    }

    pub fn mods_dir(&self) -> PathBuf {
        self.dir.join("mods")
    }
}

// ------------------------------------------------------------- listing

/// A jar in an instance's `mods/` folder.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct InstalledMod {
    /// Current file name (ends in `.disabled` when disabled).
    pub file: String,
    pub enabled: bool,
    pub name: String,
    pub version: String,
    pub loaders: Vec<LoaderKind>,
    pub sha1: String,
    pub size: u64,
    pub record: Option<ModRecord>,
}

impl InstalledMod {
    pub fn source(&self) -> Source {
        self.record.as_ref().map(|r| r.source).unwrap_or_default()
    }
}

fn is_mod_file(name: &str) -> bool {
    let lower = name.to_ascii_lowercase();
    lower.ends_with(".jar") || lower.ends_with(".jar.disabled")
}

/// Every mod jar of an instance (blocking: reads each jar's metadata).
pub fn list_installed(instance_dir: &Path) -> Vec<InstalledMod> {
    let records = load_index(instance_dir);
    let Ok(entries) = std::fs::read_dir(instance_dir.join("mods")) else {
        return Vec::new();
    };
    let mut out: Vec<InstalledMod> = entries
        .flatten()
        .filter(|e| e.path().is_file())
        .filter_map(|e| {
            let file = e.file_name().to_string_lossy().into_owned();
            if !is_mod_file(&file) {
                return None;
            }
            let bytes = std::fs::read(e.path()).ok()?;
            let meta = scan_jar(&bytes, base_name(&file));
            let record = records.iter().find(|r| r.file == base_name(&file)).cloned();
            let name = record
                .as_ref()
                .map(|r| r.title.clone())
                .filter(|t| !t.is_empty())
                .or(meta.name.clone())
                .unwrap_or_else(|| base_name(&file).trim_end_matches(".jar").to_string());
            Some(InstalledMod {
                enabled: !file.ends_with(".disabled"),
                name,
                version: meta
                    .version
                    .clone()
                    .or_else(|| record.as_ref().map(|r| r.version.clone()))
                    .unwrap_or_default(),
                loaders: meta.loaders.clone(),
                sha1: hash::sha1_bytes(&bytes),
                size: bytes.len() as u64,
                record,
                file,
            })
        })
        .collect();
    out.sort_by_key(|m| m.name.to_lowercase());
    out
}

/// Enable (`x.jar.disabled` -> `x.jar`) or disable a mod. Returns the new
/// file name.
pub fn set_enabled(
    safe: &SafePath,
    instance_dir: &Path,
    file: &str,
    enabled: bool,
) -> Result<String> {
    let path = instance_dir.join("mods").join(file);
    let disabled = file.ends_with(".disabled");
    let new = match (enabled, disabled) {
        (true, true) => base_name(file).to_string(),
        (false, false) => format!("{file}.disabled"),
        _ => return Ok(file.to_string()),
    };
    safe.rename_sibling(&path, &new)?;
    Ok(new)
}

/// Move a mod to the recycle bin and forget it.
pub fn remove(safe: &SafePath, instance_dir: &Path, file: &str) -> Result<()> {
    safe.trash_file(&instance_dir.join("mods").join(file))?;
    let mut records = load_index(instance_dir);
    records.retain(|r| r.file != base_name(file));
    save_index(safe, instance_dir, &records)
}

/// Copy jars from the computer into the instance. Returns, per file, the
/// added name or an error.
pub fn import_local(
    safe: &SafePath,
    instance_dir: &Path,
    files: &[PathBuf],
) -> Vec<(String, std::result::Result<String, String>)> {
    let mut records = load_index(instance_dir);
    let mut out = Vec::new();
    for f in files {
        let name = f
            .file_name()
            .map(|n| n.to_string_lossy().into_owned())
            .unwrap_or_default();
        let res = (|| -> std::result::Result<String, String> {
            if !name.to_ascii_lowercase().ends_with(".jar") {
                return Err("not a .jar file".into());
            }
            let bytes = std::fs::read(f).map_err(|e| e.to_string())?;
            let meta = scan_jar(&bytes, &name);
            if meta.loaders.is_empty() {
                return Err("not a Minecraft mod (no mod metadata in the jar)".into());
            }
            match safe.copy_new(f, &instance_dir.join("mods").join(&name)) {
                Ok(_) => {}
                Err(SafetyError::AlreadyExists(_)) => {
                    return Err("a file with this name is already in mods/".into())
                }
                Err(e) => return Err(e.to_string()),
            }
            records.retain(|r| r.file != name);
            records.push(ModRecord {
                file: name.clone(),
                source: Source::Local,
                title: meta.name.clone().unwrap_or_default(),
                version: meta.version.clone().unwrap_or_default(),
                ..Default::default()
            });
            Ok(meta.name.unwrap_or_else(|| name.clone()))
        })();
        out.push((name, res));
    }
    if let Err(e) = save_index(safe, instance_dir, &records) {
        tracing::warn!(error = %e, "could not save the mod index");
    }
    out
}

// ------------------------------------------------------------- search

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct SearchHit {
    pub project: ProjectRef,
    pub author: String,
    pub description: String,
    pub downloads: u64,
    pub page: String,
}

fn modrinth_loaders(kind: LoaderKind) -> &'static [&'static str] {
    match kind {
        LoaderKind::Fabric => &["fabric"],
        LoaderKind::Quilt => &["quilt", "fabric"],
        LoaderKind::Forge => &["forge"],
        LoaderKind::NeoForge => &["neoforge"],
        _ => &[],
    }
}

/// CurseForge `modLoaderType` ids.
fn cf_loader_types(kind: LoaderKind) -> &'static [u32] {
    match kind {
        LoaderKind::Forge => &[1],
        LoaderKind::Fabric => &[4],
        LoaderKind::Quilt => &[5, 4],
        LoaderKind::NeoForge => &[6],
        _ => &[],
    }
}

/// Loader names as CurseForge lists them in a file's `gameVersions`.
fn cf_loader_labels(kind: LoaderKind) -> &'static [&'static str] {
    match kind {
        LoaderKind::Forge => &["Forge"],
        LoaderKind::Fabric => &["Fabric"],
        LoaderKind::Quilt => &["Quilt", "Fabric"],
        LoaderKind::NeoForge => &["NeoForge"],
        _ => &[],
    }
}

#[derive(Debug, Deserialize)]
struct MrSearch {
    hits: Vec<MrHit>,
}

#[derive(Debug, Deserialize)]
struct MrHit {
    project_id: String,
    #[serde(default)]
    slug: String,
    title: String,
    #[serde(default)]
    author: String,
    #[serde(default)]
    description: String,
    #[serde(default)]
    downloads: u64,
}

/// Search mods. `filter` limits results to a loader and Minecraft version.
/// CurseForge search needs an API key.
pub async fn search(
    l: &Loaders,
    curseforge_key: Option<&str>,
    source: Source,
    query: &str,
    filter: Option<(LoaderKind, &str)>,
) -> Result<Vec<SearchHit>> {
    match source {
        Source::Modrinth => {
            let mut facets: Vec<Vec<String>> = vec![vec!["project_type:mod".into()]];
            if let Some((loader, mc)) = filter {
                let names = modrinth_loaders(loader);
                if !names.is_empty() {
                    facets.push(names.iter().map(|n| format!("categories:{n}")).collect());
                }
                facets.push(vec![format!("versions:{mc}")]);
            }
            let facets = serde_json::to_string(&facets).unwrap_or_default();
            let url = format!(
                "{}/search?query={}&limit=30&index=relevance&facets={}",
                modrinth::API,
                url_encode(query.trim()),
                url_encode(&facets)
            );
            let res: MrSearch = l.http().get_json(&url).await?;
            Ok(res
                .hits
                .into_iter()
                .map(|h| SearchHit {
                    page: format!("https://modrinth.com/mod/{}", h.slug),
                    project: ProjectRef {
                        source: Source::Modrinth,
                        id: h.project_id,
                        title: h.title,
                    },
                    author: h.author,
                    description: h.description,
                    downloads: h.downloads,
                })
                .collect())
        }
        Source::CurseForge => {
            let key = curseforge_key.filter(|k| !k.trim().is_empty()).ok_or_else(|| {
                LoaderError::Unsupported(
                    "CurseForge search needs an API key (Settings → Network). Without one, install by project ID.".into(),
                )
            })?;
            let mut url = format!(
                "{CF_API}/mods/search?gameId=432&classId=6&sortField=2&sortOrder=desc&pageSize=30&searchFilter={}",
                url_encode(query.trim())
            );
            if let Some((loader, mc)) = filter {
                url.push_str(&format!("&gameVersion={}", url_encode(mc)));
                if let Some(t) = cf_loader_types(loader).first() {
                    url.push_str(&format!("&modLoaderType={t}"));
                }
            }
            let res: CfData<Vec<CfMod>> = cf_get(l, key, &url).await?;
            Ok(res
                .data
                .into_iter()
                .map(|m| SearchHit {
                    page: m
                        .links
                        .as_ref()
                        .and_then(|x| x.website_url.clone())
                        .unwrap_or_else(|| format!("https://www.curseforge.com/projects/{}", m.id)),
                    author: m.authors.first().map(|a| a.name.clone()).unwrap_or_default(),
                    description: m.summary,
                    downloads: m.download_count as u64,
                    project: ProjectRef {
                        source: Source::CurseForge,
                        id: m.id.to_string(),
                        title: m.name,
                    },
                })
                .collect())
        }
        Source::Local => Ok(Vec::new()),
    }
}

// ----------------------------------------------------------- CurseForge

#[derive(Debug, Deserialize)]
struct CfData<T> {
    data: T,
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
struct CfMod {
    id: u64,
    name: String,
    #[serde(default)]
    summary: String,
    #[serde(default)]
    download_count: f64,
    #[serde(default)]
    authors: Vec<CfAuthor>,
    #[serde(default)]
    links: Option<CfLinks>,
}

#[derive(Debug, Deserialize)]
struct CfAuthor {
    name: String,
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
struct CfLinks {
    #[serde(default)]
    website_url: Option<String>,
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
struct CfFile {
    id: u64,
    #[serde(default)]
    display_name: String,
    file_name: String,
    #[serde(default)]
    file_length: Option<u64>,
    #[serde(default)]
    download_url: Option<String>,
    #[serde(default)]
    hashes: Vec<CfHash>,
    #[serde(default)]
    dependencies: Vec<CfDep>,
    #[serde(default)]
    release_type: u32,
    #[serde(default)]
    game_versions: Vec<String>,
}

#[derive(Debug, Deserialize)]
struct CfHash {
    value: String,
    algo: u32,
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
struct CfDep {
    mod_id: u64,
    relation_type: u32,
}

#[derive(Debug, Deserialize)]
struct CfSiteDep {
    id: u64,
    #[serde(default)]
    name: String,
    #[serde(rename = "type", default)]
    kind: String,
}

async fn cf_get<T: serde::de::DeserializeOwned>(l: &Loaders, key: &str, url: &str) -> Result<T> {
    if l.http().is_offline() {
        return Err(mclaunch_download::DownloadError::Offline(url.to_string()).into());
    }
    let resp = l
        .http()
        .client()
        .get(url)
        .header("x-api-key", key.trim())
        .header("accept", "application/json")
        .send()
        .await
        .map_err(|e| LoaderError::Failed(format!("CurseForge: {e}")))?;
    let status = resp.status();
    if !status.is_success() {
        return Err(LoaderError::Failed(format!(
            "CurseForge API answered HTTP {}{}",
            status.as_u16(),
            if status.as_u16() == 403 {
                " — the API key was rejected (Settings → Network → Test key)"
            } else {
                ""
            }
        )));
    }
    resp.json::<T>()
        .await
        .map_err(|e| LoaderError::Failed(format!("CurseForge: {e}")))
}

/// Check a CurseForge API key with a harmless request (the Minecraft game
/// entry). Returns a description of the key that was sent.
pub async fn test_curseforge_key(l: &Loaders, key: &str) -> Result<String> {
    let shown = mask_key(key);
    cf_get::<serde_json::Value>(l, key, &format!("{CF_API}/games/432"))
        .await
        .map(|_| format!("The CurseForge API key works ({shown})"))
        .map_err(|e| LoaderError::Failed(format!("{e}. Key sent: {shown}")))
}

/// `$2a$…xyz (60 characters)`: enough to compare with the real key.
pub fn mask_key(key: &str) -> String {
    let n = key.chars().count();
    if n <= 8 {
        return format!("{n} characters");
    }
    let head: String = key.chars().take(4).collect();
    let tail: String = key.chars().skip(n - 3).collect();
    format!("{head}…{tail}, {n} characters")
}

/// Newest release (else newest file) that fits.
fn pick_cf(files: Vec<CfFile>) -> Option<CfFile> {
    let release = files.iter().position(|f| f.release_type == 1);
    let mut files = files;
    match release {
        Some(i) => Some(files.swap_remove(i)),
        None => files.into_iter().next(),
    }
}

// --------------------------------------------------------- resolution

/// A concrete file to install.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ModFile {
    pub project: ProjectRef,
    pub version_id: String,
    pub version: String,
    pub file_name: String,
    /// Empty when the author does not allow downloads from other apps.
    pub urls: Vec<String>,
    pub sha1: Option<String>,
    pub size: Option<u64>,
    pub deps: Vec<ProjectRef>,
    pub page: String,
}

/// The best file of `project` for the target's loader and Minecraft
/// version, or `None` if there is none.
pub async fn resolve(
    l: &Loaders,
    curseforge_key: Option<&str>,
    project: &ProjectRef,
    target: &Target,
) -> Result<Option<ModFile>> {
    match project.source {
        Source::Modrinth => resolve_modrinth(l, project, target).await,
        Source::CurseForge => {
            let id: u64 = project.id.trim().parse().map_err(|_| {
                LoaderError::Failed(format!("\"{}\" is not a CurseForge project ID", project.id))
            })?;
            match curseforge_key.filter(|k| !k.trim().is_empty()) {
                Some(key) => resolve_cf_key(l, key, id, project, target).await,
                None => resolve_cf_site(l, id, project, target).await,
            }
        }
        Source::Local => Ok(None),
    }
}

async fn resolve_modrinth(
    l: &Loaders,
    project: &ProjectRef,
    target: &Target,
) -> Result<Option<ModFile>> {
    let mut found = None;
    for ld in modrinth_loaders(target.loader) {
        let versions = modrinth::project_versions(l, &project.id, ld, &target.mc).await?;
        if let Some(v) = modrinth::best(&versions) {
            found = Some(v.clone());
            break;
        }
    }
    let Some(v) = found else { return Ok(None) };
    let Some(file) = v.primary_file() else {
        return Ok(None);
    };
    if !mclaunch_safety::is_plain_name(&file.filename) {
        return Err(LoaderError::Failed(format!("bad file name {}", file.filename)));
    }
    let title = if project.title.is_empty() {
        modrinth::project(l, &v.project_id)
            .await
            .map(|p| p.title)
            .unwrap_or_else(|_| file.filename.clone())
    } else {
        project.title.clone()
    };
    Ok(Some(ModFile {
        project: ProjectRef {
            source: Source::Modrinth,
            id: v.project_id.clone(),
            title,
        },
        version_id: v.id.clone(),
        version: v.version_number.clone(),
        file_name: file.filename.clone(),
        urls: vec![file.url.clone()],
        sha1: file.hashes.sha1.clone(),
        size: file.size,
        deps: v
            .dependencies
            .iter()
            .filter(|d| d.dependency_type == "required")
            .filter_map(|d| d.project_id.clone())
            .map(|id| ProjectRef {
                source: Source::Modrinth,
                id,
                title: String::new(),
            })
            .collect(),
        page: format!("https://modrinth.com/mod/{}", v.project_id),
    }))
}

async fn resolve_cf_key(
    l: &Loaders,
    key: &str,
    id: u64,
    project: &ProjectRef,
    target: &Target,
) -> Result<Option<ModFile>> {
    let mut found = None;
    for t in cf_loader_types(target.loader) {
        let url = format!(
            "{CF_API}/mods/{id}/files?gameVersion={}&modLoaderType={t}&pageSize=50",
            url_encode(&target.mc)
        );
        let files: CfData<Vec<CfFile>> = cf_get(l, key, &url).await?;
        if let Some(f) = pick_cf(files.data) {
            found = Some(f);
            break;
        }
    }
    let Some(f) = found else { return Ok(None) };
    let info: Option<CfMod> = cf_get::<CfData<CfMod>>(l, key, &format!("{CF_API}/mods/{id}"))
        .await
        .ok()
        .map(|d| d.data);
    let page = info
        .as_ref()
        .and_then(|m| m.links.as_ref()?.website_url.clone())
        .map(|w| format!("{}/files/{}", w.trim_end_matches('/'), f.id))
        .unwrap_or_else(|| format!("https://www.curseforge.com/projects/{id}"));
    let title = info
        .map(|m| m.name)
        .filter(|_| project.title.is_empty())
        .unwrap_or_else(|| project.title.clone());
    cf_file(id, title, f, page, |deps| {
        deps.iter()
            .filter(|d| d.relation_type == 3)
            .map(|d| ProjectRef {
                source: Source::CurseForge,
                id: d.mod_id.to_string(),
                title: String::new(),
            })
            .collect()
    })
}

async fn resolve_cf_site(
    l: &Loaders,
    id: u64,
    project: &ProjectRef,
    target: &Target,
) -> Result<Option<ModFile>> {
    let labels = cf_loader_labels(target.loader);
    let fits = |f: &CfFile| {
        f.game_versions.contains(&target.mc)
            && labels.iter().any(|l| f.game_versions.iter().any(|v| v == l))
    };
    // The website ignores version filters; page through newest first.
    let mut found = None;
    for page in 0..10 {
        let url = format!("{CF_SITE}/mods/{id}/files?pageIndex={page}&pageSize=50");
        let files: CfData<Vec<CfFile>> = l.http().get_json(&url).await?;
        let last = files.data.len() < 50;
        let fitting: Vec<CfFile> = files.data.into_iter().filter(|f| fits(f)).collect();
        if let Some(f) = pick_cf(fitting) {
            found = Some(f);
            break;
        }
        if last {
            break;
        }
    }
    let Some(f) = found else { return Ok(None) };
    let deps = cf_site_deps(l, id, f.id).await;
    let title = if project.title.is_empty() {
        f.display_name.clone()
    } else {
        project.title.clone()
    };
    let download = format!("{CF_SITE}/mods/{id}/files/{}/download", f.id);
    let page = format!("https://www.curseforge.com/projects/{id}");
    let mut m = cf_file(id, title, f, page, |_| Vec::new())?;
    if let Some(m) = &mut m {
        m.urls.insert(0, download);
        m.deps = deps;
    }
    Ok(m)
}

/// Required dependencies of a CurseForge file, from the public website.
async fn cf_site_deps(l: &Loaders, id: u64, file_id: u64) -> Vec<ProjectRef> {
    l.http()
        .get_json::<CfData<Vec<CfSiteDep>>>(&format!(
            "{CF_SITE}/mods/{id}/files/{file_id}/dependencies"
        ))
        .await
        .map(|d| {
            d.data
                .into_iter()
                .filter(|d| d.kind == "RequiredDependency")
                .map(|d| ProjectRef {
                    source: Source::CurseForge,
                    id: d.id.to_string(),
                    title: d.name,
                })
                .collect()
        })
        .unwrap_or_default()
}

// ------------------------------------------------------- version lists

/// One published version of a mod, with what it runs on.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ModVersion {
    pub file: ModFile,
    /// Minecraft versions, as published (`1.20.1`, `1.21`, …).
    pub game_versions: Vec<String>,
    pub loaders: Vec<LoaderKind>,
    /// A release (not beta/alpha).
    pub release: bool,
}

fn loader_from_name(name: &str) -> Option<LoaderKind> {
    Some(match name.to_ascii_lowercase().as_str() {
        "fabric" => LoaderKind::Fabric,
        "quilt" => LoaderKind::Quilt,
        "forge" => LoaderKind::Forge,
        "neoforge" => LoaderKind::NeoForge,
        _ => return None,
    })
}

/// `1.20.1`, `1.21`, `26.1`: Minecraft versions among CurseForge's tags.
fn looks_like_mc(v: &str) -> bool {
    v.split('.').count() >= 2 && v.split('.').all(|p| !p.is_empty() && p.chars().all(|c| c.is_ascii_digit()))
}

/// Every version of a mod (newest first), for the version picker.
pub async fn list_versions(
    l: &Loaders,
    curseforge_key: Option<&str>,
    project: &ProjectRef,
) -> Result<Vec<ModVersion>> {
    match project.source {
        Source::Modrinth => {
            let url = format!("{}/project/{}/version", modrinth::API, project.id);
            let cache = l
                .cache_dir("modrinth")
                .join(format!("all-versions-{}.json", url_encode(&project.id)));
            let (versions, _): (Vec<modrinth::MrVersion>, bool) = l.cached_json(&url, &cache).await?;
            Ok(versions
                .into_iter()
                .filter_map(|v| {
                    let file = v.primary_file()?.clone();
                    if !mclaunch_safety::is_plain_name(&file.filename) {
                        return None;
                    }
                    let mut loaders: Vec<LoaderKind> =
                        v.loaders.iter().filter_map(|n| loader_from_name(n)).collect();
                    loaders.dedup();
                    Some(ModVersion {
                        release: v.version_type == "release",
                        game_versions: v.game_versions.clone(),
                        loaders,
                        file: ModFile {
                            project: ProjectRef {
                                source: Source::Modrinth,
                                id: v.project_id.clone(),
                                title: project.title.clone(),
                            },
                            version_id: v.id.clone(),
                            version: v.version_number.clone(),
                            file_name: file.filename.clone(),
                            urls: vec![file.url.clone()],
                            sha1: file.hashes.sha1.clone(),
                            size: file.size,
                            deps: v
                                .dependencies
                                .iter()
                                .filter(|d| d.dependency_type == "required")
                                .filter_map(|d| d.project_id.clone())
                                .map(|id| ProjectRef {
                                    source: Source::Modrinth,
                                    id,
                                    title: String::new(),
                                })
                                .collect(),
                            page: format!("https://modrinth.com/mod/{}", v.project_id),
                        },
                    })
                })
                .collect())
        }
        Source::CurseForge => {
            let id: u64 = project.id.trim().parse().map_err(|_| {
                LoaderError::Failed(format!("\"{}\" is not a CurseForge project ID", project.id))
            })?;
            let key = curseforge_key.filter(|k| !k.trim().is_empty());
            let mut files = Vec::new();
            for page in 0..10u32 {
                let batch: Vec<CfFile> = match key {
                    Some(k) => {
                        cf_get::<CfData<Vec<CfFile>>>(
                            l,
                            k,
                            &format!("{CF_API}/mods/{id}/files?pageSize=50&index={}", page * 50),
                        )
                        .await?
                        .data
                    }
                    None => {
                        l.http()
                            .get_json::<CfData<Vec<CfFile>>>(&format!(
                                "{CF_SITE}/mods/{id}/files?pageIndex={page}&pageSize=50"
                            ))
                            .await?
                            .data
                    }
                };
                let last = batch.len() < 50;
                files.extend(batch);
                if last {
                    break;
                }
            }
            let page = format!("https://www.curseforge.com/projects/{id}");
            let mut out = Vec::new();
            for f in files {
                let game_versions: Vec<String> =
                    f.game_versions.iter().filter(|v| looks_like_mc(v)).cloned().collect();
                let mut loaders: Vec<LoaderKind> =
                    f.game_versions.iter().filter_map(|v| loader_from_name(v)).collect();
                loaders.dedup();
                let release = f.release_type == 1;
                let file_id = f.id;
                let title = if project.title.is_empty() { f.display_name.clone() } else { project.title.clone() };
                let Ok(Some(mut file)) = cf_file(id, title, f, page.clone(), |deps| {
                    deps.iter()
                        .filter(|d| d.relation_type == 3)
                        .map(|d| ProjectRef {
                            source: Source::CurseForge,
                            id: d.mod_id.to_string(),
                            title: String::new(),
                        })
                        .collect()
                }) else {
                    continue;
                };
                if key.is_none() {
                    // The website gives no download URL; use its redirect.
                    file.urls = vec![
                        format!("{CF_SITE}/mods/{id}/files/{file_id}/download"),
                        cdn_url(file_id, &file.file_name),
                    ];
                }
                out.push(ModVersion {
                    file,
                    game_versions,
                    loaders,
                    release,
                });
            }
            Ok(out)
        }
        Source::Local => Ok(Vec::new()),
    }
}

fn cf_file(
    id: u64,
    title: String,
    f: CfFile,
    page: String,
    deps: impl FnOnce(&[CfDep]) -> Vec<ProjectRef>,
) -> Result<Option<ModFile>> {
    if !mclaunch_safety::is_plain_name(&f.file_name) {
        return Err(LoaderError::Failed(format!("bad file name {}", f.file_name)));
    }
    let mut urls: Vec<String> = f.download_url.clone().into_iter().collect();
    if !urls.is_empty() {
        urls.push(cdn_url(f.id, &f.file_name));
    }
    Ok(Some(ModFile {
        project: ProjectRef {
            source: Source::CurseForge,
            id: id.to_string(),
            title,
        },
        version_id: f.id.to_string(),
        version: f.display_name.clone(),
        sha1: f
            .hashes
            .iter()
            .find(|h| h.algo == 1)
            .map(|h| h.value.to_ascii_lowercase()),
        size: f.file_length.filter(|s| *s > 0),
        deps: deps(&f.dependencies),
        urls,
        page,
        file_name: f.file_name,
    }))
}

// ------------------------------------------------------------ install

#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct InstallReport {
    /// Titles installed (the mod first, then dependencies).
    pub installed: Vec<String>,
    /// Already present.
    pub already: Vec<String>,
    pub notes: Vec<String>,
}

fn cache_path(l: &Loaders, f: &ModFile) -> PathBuf {
    let src = match f.project.source {
        Source::Modrinth => "modrinth",
        Source::CurseForge => "curseforge",
        Source::Local => "local",
    };
    l.cache_dir("mods")
        .join(src)
        .join(url_encode(&f.version_id))
        .join(&f.file_name)
}

/// Install `project` and its required dependencies into the target.
pub async fn install(
    l: &Loaders,
    curseforge_key: Option<&str>,
    project: &ProjectRef,
    target: &Target,
    global: bool,
    progress: &ProgressFn,
) -> Result<InstallReport> {
    install_inner(l, curseforge_key, project, None, target, global, progress).await
}

/// Install a specific version (from [`list_versions`]) and the required
/// dependencies, resolved for the target's Minecraft version and loader.
pub async fn install_version(
    l: &Loaders,
    curseforge_key: Option<&str>,
    version: &ModVersion,
    target: &Target,
    progress: &ProgressFn,
) -> Result<InstallReport> {
    let mut file = version.file.clone();
    if file.project.source == Source::CurseForge
        && curseforge_key.is_none_or(|k| k.trim().is_empty())
        && file.deps.is_empty()
    {
        if let (Ok(id), Ok(fid)) = (file.project.id.parse(), file.version_id.parse()) {
            file.deps = cf_site_deps(l, id, fid).await;
        }
    }
    let project = file.project.clone();
    install_inner(l, curseforge_key, &project, Some(file), target, false, progress).await
}

async fn install_inner(
    l: &Loaders,
    curseforge_key: Option<&str>,
    project: &ProjectRef,
    mut pinned: Option<ModFile>,
    target: &Target,
    global: bool,
    progress: &ProgressFn,
) -> Result<InstallReport> {
    if !target.loader.uses_mods_folder() {
        return Err(LoaderError::Unsupported(format!(
            "{} instances don't load mods; install Fabric, Quilt, Forge or NeoForge first",
            target.loader.label()
        )));
    }
    let mut records = load_index(&target.dir);
    let present: HashSet<(Source, String)> = records
        .iter()
        .map(|r| (r.source, r.project_id.clone()))
        .collect();
    let mut report = InstallReport::default();
    let mut seen = HashSet::new();
    let mut queue = VecDeque::from([(project.clone(), 0usize)]);
    let mut plan: Vec<(ModFile, bool)> = Vec::new();
    let mut replace: Option<ModRecord> = None;
    while let Some((p, depth)) = queue.pop_front() {
        if !seen.insert((p.source, p.id.clone())) {
            continue;
        }
        let main = depth == 0;
        if present.contains(&(p.source, p.id.clone())) {
            let title = if p.title.is_empty() { p.id.clone() } else { p.title.clone() };
            if !(main && pinned.is_some()) {
                report.already.push(title);
                continue;
            }
            // A chosen version replaces the installed one (below).
            replace = records
                .iter()
                .find(|r| r.source == p.source && r.project_id == p.id)
                .cloned();
        }
        if main {
            if let Some(file) = pinned.take() {
                if file.urls.is_empty() {
                    return Err(LoaderError::Failed(format!(
                        "{}'s author doesn't allow downloads from other apps; download {} from {} and use Import",
                        file.project.title, file.file_name, file.page
                    )));
                }
                if depth < MAX_DEPTH {
                    for d in &file.deps {
                        queue.push_back((d.clone(), depth + 1));
                    }
                }
                plan.push((file, false));
                continue;
            }
        }
        progress(Progress::stage(format!(
            "Finding {} for Minecraft {}",
            if p.title.is_empty() { &p.id } else { &p.title },
            target.mc
        )));
        let file = match resolve(l, curseforge_key, &p, target).await {
            Ok(f) => f,
            Err(e) if !main => {
                report.notes.push(format!("Dependency {}: {e}", p.id));
                continue;
            }
            Err(e) => return Err(e),
        };
        let Some(file) = file else {
            let msg = format!(
                "{} has no version for Minecraft {} with {}",
                if p.title.is_empty() { &p.id } else { &p.title },
                target.mc,
                target.loader.label()
            );
            if main {
                return Err(LoaderError::Unsupported(msg));
            }
            report.notes.push(format!("Required dependency: {msg}"));
            continue;
        };
        if file.urls.is_empty() {
            let msg = format!(
                "{}'s author doesn't allow downloads from other apps; download {} from {} and use Import",
                file.project.title, file.file_name, file.page
            );
            if main {
                return Err(LoaderError::Failed(msg));
            }
            report.notes.push(msg);
            continue;
        }
        if depth < MAX_DEPTH {
            for d in &file.deps {
                queue.push_back((d.clone(), depth + 1));
            }
        }
        plan.push((file, !main));
    }

    let tasks: Vec<DownloadTask> = plan
        .iter()
        .map(|(f, _)| {
            let mut t = DownloadTask::new(f.urls[0].clone(), cache_path(l, f))
                .sha1(f.sha1.clone())
                .size(f.size);
            for m in &f.urls[1..] {
                t = t.mirror(m.clone());
            }
            t
        })
        .collect();
    if !tasks.is_empty() {
        let summary = Downloader::new(l.http().clone(), l.safe().clone(), PARALLEL_DOWNLOADS)
            .run(tasks, "Downloading mods", progress)
            .await;
        if !summary.is_ok() {
            return Err(LoaderError::Failed(summary.failure_text()));
        }
    }
    // Switching versions: the old jar goes to the recycle bin first (a
    // disabled one stays disabled).
    let mut keep_disabled = false;
    if let (Some(old), Some((new, _))) = (&replace, plan.first()) {
        let enabled = target.mods_dir().join(&old.file);
        let disabled = target.mods_dir().join(format!("{}.disabled", old.file));
        if old.file == new.file_name && enabled.is_file() {
            return Err(LoaderError::Failed(format!(
                "{} {} is already installed",
                new.project.title, new.version
            )));
        }
        for path in [&enabled, &disabled] {
            if path.is_file() {
                keep_disabled = path == &disabled;
                l.safe().trash_file(path)?;
            }
        }
        records.retain(|r| r.file != old.file);
    }
    for (i, (mut f, dependency)) in plan.into_iter().enumerate() {
        // Keyless CurseForge lookups only know the file name; use the
        // mod's own name from the jar.
        if f.project.title.is_empty() || f.project.title.ends_with(".jar") {
            if let Some(name) = std::fs::read(cache_path(l, &f))
                .ok()
                .and_then(|b| scan_jar(&b, &f.file_name).name)
            {
                f.project.title = name;
            }
        }
        let dest = if i == 0 && keep_disabled {
            target.mods_dir().join(format!("{}.disabled", f.file_name))
        } else {
            target.mods_dir().join(&f.file_name)
        };
        let disabled = target.mods_dir().join(format!("{}.disabled", f.file_name));
        if disabled.exists() && !(i == 0 && keep_disabled) {
            report.already.push(f.project.title.clone());
            continue;
        }
        match l.safe().copy_new(&cache_path(l, &f), &dest) {
            Ok(_) => report.installed.push(f.project.title.clone()),
            Err(SafetyError::AlreadyExists(_)) => report.already.push(f.project.title.clone()),
            Err(e) => return Err(e.into()),
        }
        records.retain(|r| r.file != f.file_name);
        records.push(ModRecord {
            file: f.file_name.clone(),
            source: f.project.source,
            project_id: f.project.id.clone(),
            version_id: f.version_id.clone(),
            title: f.project.title.clone(),
            version: f.version.clone(),
            global,
            dependency,
        });
    }
    save_index(l.safe(), &target.dir, &records)?;
    Ok(report)
}

// ------------------------------------------------------------ updates

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Update {
    /// Current file name.
    pub file: String,
    pub title: String,
    pub from: String,
    pub to: ModFile,
}

/// Newer versions of installed mods, found on Modrinth by file hash (works
/// for jars from anywhere that are also published on Modrinth).
pub async fn check_updates(
    l: &Loaders,
    target: &Target,
    mods: &[InstalledMod],
) -> Result<Vec<Update>> {
    if mods.is_empty() {
        return Ok(Vec::new());
    }
    if l.http().is_offline() {
        return Err(mclaunch_download::DownloadError::Offline("Modrinth".into()).into());
    }
    let body = serde_json::json!({
        "hashes": mods.iter().map(|m| m.sha1.clone()).collect::<Vec<_>>(),
        "algorithm": "sha1",
        "loaders": modrinth_loaders(target.loader),
        "game_versions": [target.mc],
    });
    let resp = l
        .http()
        .client()
        .post(format!("{}/version_files/update", modrinth::API))
        .json(&body)
        .send()
        .await
        .map_err(|e| LoaderError::Failed(format!("Modrinth: {e}")))?;
    if !resp.status().is_success() {
        return Err(LoaderError::Failed(format!(
            "Modrinth answered HTTP {}",
            resp.status().as_u16()
        )));
    }
    let latest: std::collections::HashMap<String, modrinth::MrVersion> = resp
        .json()
        .await
        .map_err(|e| LoaderError::Failed(format!("Modrinth: {e}")))?;
    let mut out = Vec::new();
    for m in mods {
        let Some(v) = latest.get(&m.sha1) else { continue };
        let Some(file) = v.primary_file() else { continue };
        if file.hashes.sha1.as_deref() == Some(m.sha1.as_str())
            || !mclaunch_safety::is_plain_name(&file.filename)
        {
            continue;
        }
        out.push(Update {
            file: m.file.clone(),
            title: m.name.clone(),
            from: m.version.clone(),
            to: ModFile {
                project: ProjectRef {
                    source: Source::Modrinth,
                    id: v.project_id.clone(),
                    title: m.name.clone(),
                },
                version_id: v.id.clone(),
                version: v.version_number.clone(),
                file_name: file.filename.clone(),
                urls: vec![file.url.clone()],
                sha1: file.hashes.sha1.clone(),
                size: file.size,
                deps: Vec::new(),
                page: format!("https://modrinth.com/mod/{}", v.project_id),
            },
        });
    }
    Ok(out)
}

/// Install the new file, then move the old one to the recycle bin. A
/// disabled mod stays disabled.
pub async fn apply_update(l: &Loaders, target: &Target, update: &Update) -> Result<()> {
    let f = &update.to;
    let cache = cache_path(l, f);
    let task = DownloadTask::new(f.urls[0].clone(), &cache)
        .sha1(f.sha1.clone())
        .size(f.size);
    let summary = Downloader::new(l.http().clone(), l.safe().clone(), PARALLEL_DOWNLOADS)
        .run(vec![task], "Downloading update", &mclaunch_core::progress::noop_progress())
        .await;
    if !summary.is_ok() {
        return Err(LoaderError::Failed(summary.failure_text()));
    }
    let disabled = update.file.ends_with(".disabled");
    let new_name = if disabled {
        format!("{}.disabled", f.file_name)
    } else {
        f.file_name.clone()
    };
    let old = target.mods_dir().join(&update.file);
    let new = target.mods_dir().join(&new_name);
    if new_name == update.file {
        l.safe().trash_file(&old)?;
        l.safe().copy_new(&cache, &new)?;
    } else {
        l.safe().copy_new(&cache, &new)?;
        l.safe().trash_file(&old)?;
    }
    let mut records = load_index(&target.dir);
    let prev = records
        .iter()
        .position(|r| r.file == base_name(&update.file))
        .map(|i| records.remove(i));
    records.push(ModRecord {
        file: f.file_name.clone(),
        source: Source::Modrinth,
        project_id: f.project.id.clone(),
        version_id: f.version_id.clone(),
        title: prev
            .as_ref()
            .map(|p| p.title.clone())
            .filter(|t| !t.is_empty())
            .unwrap_or_else(|| update.title.clone()),
        version: f.version.clone(),
        global: prev.as_ref().is_some_and(|p| p.global),
        dependency: prev.as_ref().is_some_and(|p| p.dependency),
    });
    save_index(l.safe(), &target.dir, &records)
}

// ------------------------------------------------------------- global

/// An entry of the global mod list.
#[derive(Debug, Clone, PartialEq, Eq, Default, Serialize, Deserialize)]
#[serde(default)]
pub struct GlobalMod {
    pub source: Source,
    /// Project id (Modrinth/CurseForge) or jar file name (local).
    pub id: String,
    pub title: String,
    pub enabled: bool,
}

#[derive(Debug, Default, Serialize, Deserialize)]
#[serde(default)]
struct GlobalIndex {
    mods: Vec<GlobalMod>,
}

pub fn global_dir(paths: &LauncherPaths) -> PathBuf {
    paths.root.join(GLOBAL_DIR)
}

pub fn load_global(paths: &LauncherPaths) -> Vec<GlobalMod> {
    std::fs::read(global_dir(paths).join(GLOBAL_INDEX))
        .ok()
        .and_then(|b| serde_json::from_slice::<GlobalIndex>(&b).ok())
        .map(|i| i.mods)
        .unwrap_or_default()
}

fn save_global(safe: &SafePath, paths: &LauncherPaths, mods: &[GlobalMod]) -> Result<()> {
    let json = serde_json::to_vec_pretty(&GlobalIndex {
        mods: mods.to_vec(),
    })
    .map_err(|e| LoaderError::Failed(e.to_string()))?;
    safe.write(&global_dir(paths).join(GLOBAL_INDEX), &json)?;
    Ok(())
}

/// Add a Modrinth/CurseForge project to the global list. `false` if it was
/// already there.
pub fn add_global(safe: &SafePath, paths: &LauncherPaths, project: &ProjectRef) -> Result<bool> {
    let mut list = load_global(paths);
    if list
        .iter()
        .any(|g| g.source == project.source && g.id == project.id)
    {
        return Ok(false);
    }
    list.push(GlobalMod {
        source: project.source,
        id: project.id.clone(),
        title: project.title.clone(),
        enabled: true,
    });
    save_global(safe, paths, &list)?;
    Ok(true)
}

/// Copy jars from the computer into the global list.
pub fn import_global(
    safe: &SafePath,
    paths: &LauncherPaths,
    files: &[PathBuf],
) -> Vec<(String, std::result::Result<String, String>)> {
    let mut list = load_global(paths);
    let mut out = Vec::new();
    for f in files {
        let name = f
            .file_name()
            .map(|n| n.to_string_lossy().into_owned())
            .unwrap_or_default();
        let res = (|| -> std::result::Result<String, String> {
            if !name.to_ascii_lowercase().ends_with(".jar") {
                return Err("not a .jar file".into());
            }
            let bytes = std::fs::read(f).map_err(|e| e.to_string())?;
            let meta = scan_jar(&bytes, &name);
            if meta.loaders.is_empty() {
                return Err("not a Minecraft mod (no mod metadata in the jar)".into());
            }
            match safe.copy_new(f, &global_dir(paths).join(&name)) {
                Ok(_) | Err(SafetyError::AlreadyExists(_)) => {}
                Err(e) => return Err(e.to_string()),
            }
            let title = meta.name.clone().unwrap_or_else(|| name.clone());
            if !list.iter().any(|g| g.source == Source::Local && g.id == name) {
                list.push(GlobalMod {
                    source: Source::Local,
                    id: name.clone(),
                    title: title.clone(),
                    enabled: true,
                });
            }
            Ok(title)
        })();
        out.push((name, res));
    }
    if let Err(e) = save_global(safe, paths, &list) {
        tracing::warn!(error = %e, "could not save the global mod list");
    }
    out
}

pub fn set_global_enabled(
    safe: &SafePath,
    paths: &LauncherPaths,
    source: Source,
    id: &str,
    enabled: bool,
) -> Result<()> {
    let mut list = load_global(paths);
    for g in list.iter_mut().filter(|g| g.source == source && g.id == id) {
        g.enabled = enabled;
    }
    save_global(safe, paths, &list)
}

/// Remove from the global list (a local jar goes to the recycle bin).
/// Instances keep their copy, disabled at their next launch.
pub fn remove_global(safe: &SafePath, paths: &LauncherPaths, source: Source, id: &str) -> Result<()> {
    let mut list = load_global(paths);
    list.retain(|g| !(g.source == source && g.id == id));
    if source == Source::Local && mclaunch_safety::is_plain_name(id) {
        let jar = global_dir(paths).join(id);
        if jar.is_file() {
            safe.trash_file(&jar)?;
        }
    }
    save_global(safe, paths, &list)
}

/// Does a local jar fit the loader and Minecraft version?
fn jar_fits(meta: &ModMeta, loader: LoaderKind, mc: &str) -> bool {
    let loader_ok = meta.loaders.contains(&loader)
        || (loader == LoaderKind::Quilt && meta.loaders.contains(&LoaderKind::Fabric));
    let exact: Vec<&str> = meta
        .mc
        .iter()
        .filter(|(_, w)| *w >= 3)
        .map(|(v, _)| v.as_str())
        .collect();
    loader_ok && (exact.is_empty() || exact.contains(&mc))
}

#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct SyncReport {
    pub added: Vec<String>,
    pub disabled: Vec<String>,
    pub notes: Vec<String>,
}

/// Bring the global mods into an instance: add the enabled ones that fit
/// (resolving the right version for its Minecraft and loader), re-enable
/// ones that were switched back on, and disable copies of global mods that
/// were removed or switched off. Problems become notes; this never fails
/// a launch.
pub async fn sync_global(
    l: &Loaders,
    curseforge_key: Option<&str>,
    paths: &LauncherPaths,
    target: &Target,
    progress: &ProgressFn,
) -> SyncReport {
    let mut report = SyncReport::default();
    if !target.loader.uses_mods_folder() {
        return report;
    }
    let globals = load_global(paths);
    let enabled = |source: Source, id: &str| {
        globals
            .iter()
            .any(|g| g.enabled && g.source == source && g.id == id)
    };
    let mods_dir = target.mods_dir();

    // Copies of global mods that were switched off or removed.
    for r in load_index(&target.dir) {
        if !r.global || r.dependency {
            continue;
        }
        let id = if r.source == Source::Local { &r.file } else { &r.project_id };
        let on = enabled(r.source, id);
        let (file, other) = if on {
            (format!("{}.disabled", r.file), r.file.clone())
        } else {
            (r.file.clone(), format!("{}.disabled", r.file))
        };
        if mods_dir.join(&file).is_file() && !mods_dir.join(&other).exists() {
            match l.safe().rename_sibling(&mods_dir.join(&file), &other) {
                Ok(_) if !on => report.disabled.push(r.title.clone()),
                Ok(_) => report.added.push(r.title.clone()),
                Err(e) => report.notes.push(format!("{}: {e}", r.title)),
            }
        }
    }

    for g in globals.iter().filter(|g| g.enabled) {
        let records = load_index(&target.dir);
        let have = records.iter().any(|r| {
            r.source == g.source
                && (if g.source == Source::Local { r.file == g.id } else { r.project_id == g.id })
        });
        if have {
            continue;
        }
        match g.source {
            Source::Local => {
                let jar = global_dir(paths).join(&g.id);
                let Ok(bytes) = std::fs::read(&jar) else {
                    report.notes.push(format!("{}: the jar is missing from {GLOBAL_DIR}/", g.title));
                    continue;
                };
                if !jar_fits(&scan_jar(&bytes, &g.id), target.loader, &target.mc) {
                    continue;
                }
                match l.safe().copy_new(&jar, &mods_dir.join(&g.id)) {
                    Ok(_) | Err(SafetyError::AlreadyExists(_)) => {}
                    Err(e) => {
                        report.notes.push(format!("{}: {e}", g.title));
                        continue;
                    }
                }
                let mut records = records;
                records.push(ModRecord {
                    file: g.id.clone(),
                    source: Source::Local,
                    title: g.title.clone(),
                    global: true,
                    ..Default::default()
                });
                if let Err(e) = save_index(l.safe(), &target.dir, &records) {
                    report.notes.push(e.to_string());
                }
                report.added.push(g.title.clone());
            }
            source => {
                let project = ProjectRef {
                    source,
                    id: g.id.clone(),
                    title: g.title.clone(),
                };
                match install(l, curseforge_key, &project, target, true, progress).await {
                    Ok(r) => {
                        report.added.extend(r.installed);
                        report.notes.extend(r.notes);
                    }
                    Err(LoaderError::Unsupported(_)) => {} // no version for this instance
                    Err(e) => report.notes.push(format!("{}: {e}", g.title)),
                }
            }
        }
    }
    report
}

/// Sync the global mods into every modded instance that uses them, 4 at a
/// time ("Apply to instances now").
pub async fn sync_global_all(
    l: &Loaders,
    curseforge_key: Option<&str>,
    paths: &LauncherPaths,
    instances: &[InstanceConfig],
    progress: &ProgressFn,
) -> Vec<(String, SyncReport)> {
    let targets: Vec<(String, Target)> = instances
        .iter()
        .filter(|i| i.loader.uses_mods_folder() && i.global_mods)
        .map(|i| (i.name.clone(), Target::for_instance(paths, i)))
        .collect();
    futures::stream::iter(targets.into_iter().map(|(name, t)| async move {
        let report = sync_global(l, curseforge_key, paths, &t, progress).await;
        (name, report)
    }))
    .buffer_unordered(4)
    .collect()
    .await
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;

    fn jar(fabric_json: &str) -> Vec<u8> {
        let mut buf = std::io::Cursor::new(Vec::new());
        {
            let mut z = zip::ZipWriter::new(&mut buf);
            z.start_file("fabric.mod.json", zip::write::SimpleFileOptions::default())
                .unwrap();
            z.write_all(fabric_json.as_bytes()).unwrap();
            z.finish().unwrap();
        }
        buf.into_inner()
    }

    struct Root {
        _d: tempfile::TempDir,
        paths: LauncherPaths,
        safe: SafePath,
    }

    fn root() -> Root {
        let d = tempfile::tempdir().unwrap();
        let safe = SafePath::new(d.path()).unwrap();
        let paths = LauncherPaths::new(safe.root());
        Root { _d: d, paths, safe }
    }

    #[test]
    fn list_toggle_remove_import() {
        let r = root();
        let dir = r.paths.instance_dir("A");
        std::fs::create_dir_all(dir.join("mods")).unwrap();
        let src = r.safe.root().join("sodium.jar");
        std::fs::write(
            &src,
            jar(r#"{"id": "sodium", "name": "Sodium", "version": "0.5.8", "depends": {"minecraft": "1.20.1"}}"#),
        )
        .unwrap();
        let junk = r.safe.root().join("notes.txt");
        std::fs::write(&junk, b"x").unwrap();
        let res = import_local(&r.safe, &dir, &[src.clone(), junk]);
        assert_eq!(res[0].1.as_deref(), Ok("Sodium"));
        assert!(res[1].1.is_err());
        // Same file again: never overwritten.
        assert!(import_local(&r.safe, &dir, &[src]).remove(0).1.is_err());

        let list = list_installed(&dir);
        assert_eq!(list.len(), 1);
        assert_eq!(list[0].name, "Sodium");
        assert_eq!(list[0].version, "0.5.8");
        assert!(list[0].enabled);
        assert_eq!(list[0].source(), Source::Local);

        let new = set_enabled(&r.safe, &dir, "sodium.jar", false).unwrap();
        assert_eq!(new, "sodium.jar.disabled");
        let list = list_installed(&dir);
        assert!(!list[0].enabled);
        assert_eq!(list[0].name, "Sodium", "record still matches");
        assert_eq!(
            set_enabled(&r.safe, &dir, &new, true).unwrap(),
            "sodium.jar"
        );
        assert!(dir.join("mods/sodium.jar").is_file());
    }

    #[test]
    fn global_list() {
        let r = root();
        let p = ProjectRef {
            source: Source::Modrinth,
            id: "AANobbMI".into(),
            title: "Sodium".into(),
        };
        assert!(add_global(&r.safe, &r.paths, &p).unwrap());
        assert!(!add_global(&r.safe, &r.paths, &p).unwrap());
        set_global_enabled(&r.safe, &r.paths, Source::Modrinth, "AANobbMI", false).unwrap();
        let list = load_global(&r.paths);
        assert_eq!(list.len(), 1);
        assert!(!list[0].enabled);
        remove_global(&r.safe, &r.paths, Source::Modrinth, "AANobbMI").unwrap();
        assert!(load_global(&r.paths).is_empty());
    }

    #[tokio::test]
    async fn sync_local_global_mods() {
        let r = root();
        let l = Loaders::new(mclaunch_download::Installer::new(
            r.paths.clone(),
            r.safe.clone(),
            mclaunch_download::Http::new(true).unwrap(),
            4,
        ));
        let gdir = r.safe.root().join("downloads");
        std::fs::create_dir_all(&gdir).unwrap();
        std::fs::write(
            gdir.join("zoom.jar"),
            jar(r#"{"id": "zoom", "name": "Zoom", "depends": {"minecraft": "1.20.1"}}"#),
        )
        .unwrap();
        std::fs::write(
            gdir.join("old.jar"),
            jar(r#"{"id": "old", "name": "Old", "depends": {"minecraft": "1.16.5"}}"#),
        )
        .unwrap();
        let res = import_global(&r.safe, &r.paths, &[gdir.join("zoom.jar"), gdir.join("old.jar")]);
        assert!(res.iter().all(|(_, r)| r.is_ok()));

        let dir = r.paths.instance_dir("F");
        std::fs::create_dir_all(dir.join("mods")).unwrap();
        let t = Target {
            dir: dir.clone(),
            loader: LoaderKind::Fabric,
            mc: "1.20.1".into(),
        };
        let noop = mclaunch_core::progress::noop_progress();
        let rep = sync_global(&l, None, &r.paths, &t, &noop).await;
        assert_eq!(rep.added, ["Zoom"], "the 1.16.5 mod does not fit");
        assert!(dir.join("mods/zoom.jar").is_file());

        // Switched off globally: disabled in the instance, not deleted.
        set_global_enabled(&r.safe, &r.paths, Source::Local, "zoom.jar", false).unwrap();
        let rep = sync_global(&l, None, &r.paths, &t, &noop).await;
        assert_eq!(rep.disabled, ["Zoom"]);
        assert!(dir.join("mods/zoom.jar.disabled").is_file());
        // And back on.
        set_global_enabled(&r.safe, &r.paths, Source::Local, "zoom.jar", true).unwrap();
        sync_global(&l, None, &r.paths, &t, &noop).await;
        assert!(dir.join("mods/zoom.jar").is_file());

        // Instances with the opt-out or without a mod loader are skipped.
        let vanilla = Target {
            loader: LoaderKind::Vanilla,
            ..t.clone()
        };
        assert_eq!(
            sync_global(&l, None, &r.paths, &vanilla, &noop).await,
            SyncReport::default()
        );
    }
}
