//! Fabric and Quilt: both publish ready-made profile JSONs (with
//! `inheritsFrom`) through their meta APIs.

use serde::Deserialize;

use crate::{LoaderError, LoaderVersion, Loaders, Result};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum MetaLoader {
    Fabric,
    Quilt,
}

impl MetaLoader {
    fn base(self) -> &'static str {
        match self {
            MetaLoader::Fabric => "https://meta.fabricmc.net/v2",
            MetaLoader::Quilt => "https://meta.quiltmc.org/v3",
        }
    }

    fn dir(self) -> &'static str {
        match self {
            MetaLoader::Fabric => "fabric",
            MetaLoader::Quilt => "quilt",
        }
    }
}

#[derive(Debug, Deserialize)]
struct LoaderEntry {
    loader: LoaderInfo,
}

#[derive(Debug, Deserialize)]
struct LoaderInfo {
    version: String,
    #[serde(default)]
    stable: Option<bool>,
}

fn safe_key(s: &str) -> String {
    s.chars()
        .map(|c| {
            if c.is_ascii_alphanumeric() || c == '.' || c == '-' {
                c
            } else {
                '_'
            }
        })
        .collect()
}

/// Loader versions for `mc` (newest first). Empty when unsupported.
pub async fn versions(
    l: &Loaders,
    which: MetaLoader,
    mc: &str,
) -> Result<(Vec<LoaderVersion>, bool)> {
    let url = format!("{}/versions/loader/{mc}", which.base());
    let cache = l
        .cache_dir(which.dir())
        .join(format!("loader-{}.json", safe_key(mc)));
    let (entries, cached): (Vec<LoaderEntry>, bool) = match l.cached_json(&url, &cache).await {
        Ok(v) => v,
        // The meta API answers 400 for unknown game versions.
        Err(LoaderError::Download(mclaunch_download::DownloadError::Status {
            status: 400 | 404,
            ..
        })) => return Ok((Vec::new(), false)),
        Err(e) => return Err(e),
    };
    let list = entries
        .into_iter()
        .map(|e| {
            // Quilt has no `stable` flag; betas carry "beta" in the version.
            let stable = e.loader.stable.unwrap_or_else(|| {
                !e.loader.version.contains("beta") && !e.loader.version.contains("pre")
            });
            LoaderVersion::new(e.loader.version, stable)
        })
        .collect();
    Ok((list, cached))
}

/// Fetch the profile JSON and write it to `versions/<id>/<id>.json`.
pub async fn install(l: &Loaders, which: MetaLoader, mc: &str, loader: &str) -> Result<String> {
    let url = format!(
        "{}/versions/loader/{mc}/{loader}/profile/json",
        which.base()
    );
    let cache = l.cache_dir(which.dir()).join(format!(
        "profile-{}-{}.json",
        safe_key(mc),
        safe_key(loader)
    ));
    let (bytes, _) = l.cached_get(&url, &cache).await?;
    let profile: mclaunch_core::VersionJson =
        serde_json::from_slice(&bytes).map_err(|e| LoaderError::Parse {
            what: url.clone(),
            message: e.to_string(),
        })?;
    if profile.id.is_empty() || !mclaunch_safety::is_plain_name(&profile.id) {
        return Err(LoaderError::Parse {
            what: url,
            message: format!("bad profile id '{}'", profile.id),
        });
    }
    let id = profile.id.clone();
    l.safe().write(&l.paths().version_json(&id), &bytes)?;
    tracing::info!(%id, "loader profile installed");
    Ok(id)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parse_entries() {
        let fabric: Vec<LoaderEntry> = serde_json::from_str(
            r#"[{"loader": {"separator": ".", "build": 5, "maven": "net.fabricmc:fabric-loader:0.19.5", "version": "0.19.5", "stable": true}, "intermediary": {}}]"#,
        )
        .unwrap();
        assert_eq!(fabric[0].loader.version, "0.19.5");
        let quilt: Vec<LoaderEntry> = serde_json::from_str(
            r#"[{"loader": {"maven": "org.quiltmc:quilt-loader:0.20.0-beta.9", "version": "0.20.0-beta.9", "build": 9}}]"#,
        )
        .unwrap();
        assert_eq!(quilt[0].loader.stable, None);
        assert_eq!(safe_key("1.21.4"), "1.21.4");
        assert_eq!(safe_key("a/b"), "a_b");
    }
}
