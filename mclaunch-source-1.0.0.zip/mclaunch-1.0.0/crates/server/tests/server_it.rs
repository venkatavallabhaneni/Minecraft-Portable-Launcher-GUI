//! Install and run real servers (headless). Network + Java; ignored by default:
//! `MCLAUNCH_IT_ROOT=/dir cargo test -p mclaunch-server --test server_it -- --ignored --test-threads=1`

use std::path::PathBuf;
use std::sync::{Arc, Mutex};
use std::time::Duration;

use mclaunch_core::progress::noop_progress;
use mclaunch_core::LauncherPaths;
use mclaunch_download::{Http, Installer};
use mclaunch_java::{JavaManager, JavaPick};
use mclaunch_loaders::Loaders;
use mclaunch_safety::SafePath;
use mclaunch_server::{ServerConfig, ServerKind};

fn root() -> PathBuf {
    std::env::var_os("MCLAUNCH_IT_ROOT")
        .map(PathBuf::from)
        .unwrap_or_else(|| PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("../../target/it-root"))
}

async fn install_and_run(kind: ServerKind, mc: &str, loader: Option<&str>) {
    let r = root();
    LauncherPaths::new(&r).ensure_layout().unwrap();
    let safe = SafePath::new(&r).unwrap();
    let paths = LauncherPaths::new(safe.root());
    let installer = Installer::new(paths.clone(), safe.clone(), Http::new(false).unwrap(), 16);
    let loaders = Loaders::new(installer.clone());
    let resolved = installer.ensure_json_chain(mc, None).await.unwrap();
    let required = mclaunch_core::javareq::required_java(&resolved.merged);
    let runtimes = JavaManager::new(paths.clone(), safe.clone())
        .scan(true, false, &noop_progress())
        .runtimes;
    let java = match mclaunch_java::pick_runtime(&runtimes, required, mc) {
        JavaPick::Exact(r) | JavaPick::Compatible(r) => r.java_bin.clone(),
        JavaPick::Missing(m) => panic!("{m}"),
    };
    let mut cfg = ServerConfig {
        name: format!("it-{}-{}", kind.label().to_lowercase(), mc),
        kind,
        mc_version: mc.into(),
        loader_version: loader.map(str::to_string),
        ram_mb: 1536,
        ..Default::default()
    };
    let spec = mclaunch_server::install(&loaders, &cfg, Some(&java), &noop_progress())
        .await
        .unwrap();
    cfg.launch = Some(spec);
    cfg.save(&paths, &safe).unwrap();
    let dir = cfg.dir(&paths);
    let mut props = mclaunch_server::read_properties(&dir);
    assert!(
        !props.online_mode(),
        "local servers default to online-mode=false"
    );
    props.set("server-port", "25599");
    props.set("level-type", "minecraft\\:flat");
    mclaunch_server::write_properties(&safe, &dir, &props).unwrap();
    mclaunch_server::set_eula(&safe, &dir, true).unwrap();

    let lines: Arc<Mutex<Vec<String>>> = Arc::default();
    let l2 = lines.clone();
    let stop = Arc::new(tokio::sync::Notify::new());
    let (tx, rx) = tokio::sync::mpsc::unbounded_channel();
    let task = tokio::spawn(mclaunch_server::run(
        cfg.clone(),
        dir.clone(),
        java,
        Arc::new(move |l| l2.lock().unwrap().push(l)),
        rx,
        stop.clone(),
    ));
    let mut done = false;
    for _ in 0..360 {
        tokio::time::sleep(Duration::from_millis(500)).await;
        if lines.lock().unwrap().iter().any(|l| l.contains("Done (")) {
            done = true;
            break;
        }
        if task.is_finished() {
            break;
        }
    }
    if done {
        tx.send("say hello from mclaunch".into()).unwrap();
        tokio::time::sleep(Duration::from_secs(1)).await;
    }
    stop.notify_one();
    let code = task.await.unwrap().unwrap();
    let log = lines.lock().unwrap().join("\n");
    assert!(done, "server never finished starting:\n{log}");
    assert!(
        log.contains("hello from mclaunch"),
        "console command not delivered:\n{log}"
    );
    eprintln!(
        "{} {mc}: started and stopped cleanly (exit {code:?})",
        kind.label()
    );
}

#[tokio::test(flavor = "multi_thread")]
#[ignore = "network + Java"]
async fn vanilla_server() {
    install_and_run(ServerKind::Vanilla, "1.21.4", None).await;
}

#[tokio::test(flavor = "multi_thread")]
#[ignore = "network + Java"]
async fn paper_server() {
    install_and_run(ServerKind::Paper, "1.21.4", None).await;
}

#[tokio::test(flavor = "multi_thread")]
#[ignore = "network + Java"]
async fn fabric_server() {
    install_and_run(ServerKind::Fabric, "1.21.4", Some("0.16.10")).await;
}
