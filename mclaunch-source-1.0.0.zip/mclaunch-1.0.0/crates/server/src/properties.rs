//! `server.properties` editing that keeps comments and key order.

#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct ServerProperties {
    lines: Vec<String>,
}

/// Defaults for a new local server. `online-mode=false` because offline
/// profiles cannot authenticate; the UI warns that this is for LAN/private
/// use only.
pub const DEFAULTS: &[(&str, &str)] = &[
    ("motd", "A mclaunch server"),
    ("server-port", "25565"),
    ("online-mode", "false"),
    ("max-players", "10"),
    ("gamemode", "survival"),
    ("difficulty", "normal"),
    ("pvp", "true"),
    ("white-list", "false"),
    ("view-distance", "10"),
    ("spawn-protection", "16"),
    ("allow-flight", "false"),
    ("enable-command-block", "false"),
    ("level-name", "world"),
    ("level-seed", ""),
];

impl ServerProperties {
    pub fn parse(text: &str) -> Self {
        Self {
            lines: text.lines().map(str::to_string).collect(),
        }
    }

    pub fn with_defaults() -> Self {
        let mut p = Self::parse("#Minecraft server properties\n#Created by mclaunch\n");
        for (k, v) in DEFAULTS {
            p.set(k, v);
        }
        p
    }

    fn key_of(line: &str) -> Option<&str> {
        let t = line.trim_start();
        if t.starts_with('#') || t.starts_with('!') {
            return None;
        }
        t.split_once('=').map(|(k, _)| k.trim())
    }

    pub fn get(&self, key: &str) -> Option<&str> {
        self.lines.iter().find_map(|l| {
            (Self::key_of(l) == Some(key)).then(|| l.split_once('=').map(|(_, v)| v).unwrap_or(""))
        })
    }

    pub fn set(&mut self, key: &str, value: &str) {
        let value = value.replace(['\n', '\r'], " ");
        let line = format!("{key}={value}");
        match self.lines.iter_mut().find(|l| Self::key_of(l) == Some(key)) {
            Some(l) => *l = line,
            None => self.lines.push(line),
        }
    }

    pub fn port(&self) -> u16 {
        self.get("server-port")
            .and_then(|p| p.trim().parse().ok())
            .unwrap_or(25565)
    }

    pub fn online_mode(&self) -> bool {
        self.get("online-mode")
            .map(|v| v.trim() == "true")
            .unwrap_or(true)
    }

    pub fn to_text(&self) -> String {
        let mut s = self.lines.join("\n");
        s.push('\n');
        s
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn roundtrip_keeps_comments_and_order() {
        let text = "#Minecraft server properties\n#Mon Oct 13\nmotd=Hello\nserver-port=25570\nonline-mode=true\n";
        let mut p = ServerProperties::parse(text);
        assert_eq!(p.get("motd"), Some("Hello"));
        assert_eq!(p.port(), 25570);
        assert!(p.online_mode());
        p.set("online-mode", "false");
        p.set("max-players", "4");
        assert_eq!(
            p.to_text(),
            "#Minecraft server properties\n#Mon Oct 13\nmotd=Hello\nserver-port=25570\nonline-mode=false\nmax-players=4\n"
        );
    }

    #[test]
    fn defaults_are_offline() {
        let p = ServerProperties::with_defaults();
        assert!(!p.online_mode());
        assert_eq!(p.port(), 25565);
        let mut p = p;
        p.set("motd", "line\nbreak");
        assert_eq!(p.get("motd"), Some("line break"));
    }
}
