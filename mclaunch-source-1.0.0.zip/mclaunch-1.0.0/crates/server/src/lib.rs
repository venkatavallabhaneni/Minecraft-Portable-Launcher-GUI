//! Local servers in `servers/<name>/`: install vanilla, Paper, Purpur,
//! Folia, Spigot (BuildTools), Fabric, Forge or NeoForge; accept the EULA
//! only when the user ticks the box; run with a live console.

pub mod properties;

use std::path::{Path, PathBuf};
use std::process::Stdio;
use std::sync::Arc;
use std::time::Duration;

use mclaunch_core::{LauncherPaths, Progress, ProgressFn};
use mclaunch_download::DownloadTask;
use mclaunch_loaders::{forge, servers as sources, Loaders, Software};
use mclaunch_safety::{SafePath, SafetyError};
use serde::{Deserialize, Serialize};
use tokio::io::{AsyncBufReadExt, AsyncWriteExt, BufReader};
use tokio::sync::{mpsc, Notify};

pub use properties::ServerProperties;

pub const CONFIG_FILE: &str = "mclaunch-server.toml";

#[derive(Debug, thiserror::Error)]
pub enum ServerError {
    #[error("{0}")]
    Failed(String),
    #[error("I/O error on {path}: {source}")]
    Io {
        path: PathBuf,
        #[source]
        source: std::io::Error,
    },
    #[error(transparent)]
    Loader(#[from] mclaunch_loaders::LoaderError),
    #[error(transparent)]
    Download(#[from] mclaunch_download::DownloadError),
    #[error(transparent)]
    Safety(#[from] SafetyError),
    #[error(transparent)]
    Core(#[from] mclaunch_core::CoreError),
}

pub type Result<T> = std::result::Result<T, ServerError>;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize, Default)]
#[serde(rename_all = "lowercase")]
pub enum ServerKind {
    #[default]
    Vanilla,
    Paper,
    Purpur,
    Folia,
    Spigot,
    Fabric,
    Forge,
    NeoForge,
}

impl ServerKind {
    pub const ALL: [ServerKind; 8] = [
        ServerKind::Vanilla,
        ServerKind::Paper,
        ServerKind::Purpur,
        ServerKind::Folia,
        ServerKind::Spigot,
        ServerKind::Fabric,
        ServerKind::Forge,
        ServerKind::NeoForge,
    ];

    pub fn label(self) -> &'static str {
        match self {
            ServerKind::Vanilla => "Vanilla",
            ServerKind::Paper => "Paper",
            ServerKind::Purpur => "Purpur",
            ServerKind::Folia => "Folia",
            ServerKind::Spigot => "Spigot",
            ServerKind::Fabric => "Fabric",
            ServerKind::Forge => "Forge",
            ServerKind::NeoForge => "NeoForge",
        }
    }

    /// Kinds that need a loader version picked.
    pub fn software(self) -> Option<Software> {
        Some(match self {
            ServerKind::Fabric => Software::Fabric,
            ServerKind::Forge => Software::Forge,
            ServerKind::NeoForge => Software::NeoForge,
            ServerKind::Paper => Software::Paper,
            ServerKind::Purpur => Software::Purpur,
            ServerKind::Folia => Software::Folia,
            ServerKind::Spigot => Software::Spigot,
            ServerKind::Vanilla => return None,
        })
    }

    pub fn needs_loader_version(self) -> bool {
        matches!(
            self,
            ServerKind::Fabric | ServerKind::Forge | ServerKind::NeoForge
        )
    }
}

/// How to start the server process.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase", tag = "type", content = "path")]
pub enum LaunchSpec {
    /// `java -jar <file> nogui`
    Jar(String),
    /// Modern Forge/NeoForge: `java @<args file> nogui`
    ArgsFile(String),
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(default)]
pub struct ServerConfig {
    pub name: String,
    pub kind: ServerKind,
    pub mc_version: String,
    pub loader_version: Option<String>,
    pub ram_mb: u32,
    pub java_override: Option<String>,
    pub launch: Option<LaunchSpec>,
    pub created: Option<chrono::DateTime<chrono::Utc>>,
}

impl Default for ServerConfig {
    fn default() -> Self {
        Self {
            name: String::new(),
            kind: ServerKind::Vanilla,
            mc_version: String::new(),
            loader_version: None,
            ram_mb: 2048,
            java_override: None,
            launch: None,
            created: None,
        }
    }
}

impl ServerConfig {
    pub fn dir(&self, paths: &LauncherPaths) -> PathBuf {
        paths.server_dir(&self.name)
    }

    pub fn save(&self, paths: &LauncherPaths, safe: &SafePath) -> Result<()> {
        mclaunch_core::instance::validate_name(&self.name).map_err(ServerError::Failed)?;
        let text = toml::to_string_pretty(self).map_err(|e| ServerError::Failed(e.to_string()))?;
        safe.write(&self.dir(paths).join(CONFIG_FILE), text.as_bytes())?;
        Ok(())
    }

    pub fn load(dir: &Path) -> Result<Self> {
        let path = dir.join(CONFIG_FILE);
        let text = std::fs::read_to_string(&path).map_err(|source| ServerError::Io {
            path: path.clone(),
            source,
        })?;
        let mut cfg: ServerConfig =
            toml::from_str(&text).map_err(|e| ServerError::Failed(e.to_string()))?;
        if let Some(n) = dir.file_name() {
            cfg.name = n.to_string_lossy().into_owned();
        }
        Ok(cfg)
    }

    pub fn is_installed(&self, paths: &LauncherPaths) -> bool {
        match &self.launch {
            Some(LaunchSpec::Jar(f)) | Some(LaunchSpec::ArgsFile(f)) => {
                self.dir(paths).join(f).is_file()
            }
            None => false,
        }
    }
}

pub fn list_servers(paths: &LauncherPaths) -> Vec<ServerConfig> {
    let mut out: Vec<ServerConfig> = std::fs::read_dir(paths.servers_dir())
        .map(|rd| {
            rd.flatten()
                .filter(|e| e.path().join(CONFIG_FILE).is_file())
                .filter_map(|e| ServerConfig::load(&e.path()).ok())
                .collect()
        })
        .unwrap_or_default();
    out.sort_by_key(|s| s.name.to_lowercase());
    out
}

/// `eula.txt` says `eula=true`.
pub fn eula_accepted(dir: &Path) -> bool {
    std::fs::read_to_string(dir.join("eula.txt"))
        .map(|t| t.lines().any(|l| l.trim() == "eula=true"))
        .unwrap_or(false)
}

/// Record the user's EULA decision. Only called when the user ticks the box.
pub fn set_eula(safe: &SafePath, dir: &Path, accepted: bool) -> Result<()> {
    let text = format!(
        "#By changing the setting below to TRUE you are indicating your agreement to the Minecraft EULA (https://aka.ms/MinecraftEULA).\n#Set by the user in mclaunch on {}\neula={accepted}\n",
        chrono::Utc::now().to_rfc3339()
    );
    safe.write(&dir.join("eula.txt"), text.as_bytes())?;
    Ok(())
}

pub fn read_properties(dir: &Path) -> ServerProperties {
    std::fs::read_to_string(dir.join("server.properties"))
        .map(|t| ServerProperties::parse(&t))
        .unwrap_or_else(|_| ServerProperties::with_defaults())
}

pub fn write_properties(safe: &SafePath, dir: &Path, props: &ServerProperties) -> Result<()> {
    safe.write(&dir.join("server.properties"), props.to_text().as_bytes())?;
    Ok(())
}

async fn download_verified(l: &Loaders, jar: &sources::ServerJar, cache: &Path) -> Result<()> {
    let task = DownloadTask::new(&jar.url, cache).size(jar.size);
    let s = l
        .installer
        .downloader()
        .run(
            vec![task],
            "Downloading server",
            &mclaunch_core::progress::noop_progress(),
        )
        .await;
    if !s.is_ok() {
        return Err(ServerError::Failed(s.failure_text()));
    }
    if let Some(expected) = &jar.sha256 {
        let p = cache.to_path_buf();
        let got = tokio::task::spawn_blocking(move || mclaunch_download::hash::sha256_file(&p))
            .await
            .map_err(|e| ServerError::Failed(e.to_string()))?
            .map_err(|source| ServerError::Io {
                path: cache.to_path_buf(),
                source,
            })?;
        if !got.eq_ignore_ascii_case(expected) {
            l.safe().remove_file(cache)?;
            return Err(ServerError::Failed(format!(
                "{} failed SHA-256 verification",
                jar.file_name
            )));
        }
    }
    Ok(())
}

/// Download the vanilla server jar of `mc` into `dest` (cached in loaders/).
async fn vanilla_server_jar(l: &Loaders, mc: &str, dest: &Path) -> Result<()> {
    let resolved = l.installer.ensure_json_chain(mc, None).await?;
    let dl = resolved
        .merged
        .downloads
        .get("server")
        .ok_or_else(|| {
            ServerError::Failed(format!("Minecraft {mc} has no official server download"))
        })?
        .clone();
    let cache = l.cache_dir("vanilla-server").join(format!("{mc}.jar"));
    let task = DownloadTask::new(&dl.url, &cache)
        .sha1(dl.sha1.clone())
        .size(dl.size);
    let s = l
        .installer
        .downloader()
        .run(
            vec![task],
            "Downloading server",
            &mclaunch_core::progress::noop_progress(),
        )
        .await;
    if !s.is_ok() {
        return Err(ServerError::Failed(s.failure_text()));
    }
    l.safe().copy_file(&cache, dest)?;
    Ok(())
}

/// Install (or reinstall) the server software. Returns how to launch it.
/// Never touches worlds or plugins: only jars, libraries and run scripts.
pub async fn install(
    l: &Loaders,
    cfg: &ServerConfig,
    java: Option<&Path>,
    progress: &ProgressFn,
) -> Result<LaunchSpec> {
    let dir = cfg.dir(l.paths());
    l.safe().create_dir_all(&dir)?;
    let mc = cfg.mc_version.as_str();
    let spec = match cfg.kind {
        ServerKind::Vanilla => {
            progress(Progress::stage(format!(
                "Downloading Minecraft {mc} server"
            )));
            vanilla_server_jar(l, mc, &dir.join("server.jar")).await?;
            LaunchSpec::Jar("server.jar".into())
        }
        ServerKind::Paper | ServerKind::Purpur | ServerKind::Folia => {
            let software = cfg.kind.software().unwrap_or(Software::Paper);
            progress(Progress::stage(format!(
                "Looking up the latest {} build",
                cfg.kind.label()
            )));
            let jar = sources::paper_like_jar(l, software, mc).await?;
            if !mclaunch_safety::is_plain_name(&jar.file_name) {
                return Err(ServerError::Failed("bad file name from API".into()));
            }
            let cache = l
                .cache_dir(&cfg.kind.label().to_lowercase())
                .join(&jar.file_name);
            progress(Progress::stage(format!("Downloading {}", jar.file_name)));
            download_verified(l, &jar, &cache).await?;
            l.safe().copy_file(&cache, &dir.join(&jar.file_name))?;
            LaunchSpec::Jar(jar.file_name)
        }
        ServerKind::Spigot => {
            let java =
                java.ok_or_else(|| ServerError::Failed("Spigot's BuildTools needs Java".into()))?;
            let tools = l.cache_dir("spigot").join("BuildTools.jar");
            progress(Progress::stage("Downloading BuildTools"));
            l.fetch_file(sources::BUILDTOOLS_URL, &tools, None).await?;
            let work = l.cache_dir("spigot").join("work");
            l.safe().create_dir_all(&work)?;
            let args = vec![
                "-jar".to_string(),
                tools.to_string_lossy().into_owned(),
                "--rev".into(),
                mc.to_string(),
                "--output-dir".into(),
                dir.to_string_lossy().into_owned(),
            ];
            mclaunch_loaders::run_java(
                java,
                &args,
                &work,
                "BuildTools",
                progress,
                Duration::from_secs(60 * 60),
            )
            .await?;
            let jar = format!("spigot-{mc}.jar");
            if !dir.join(&jar).is_file() {
                return Err(ServerError::Failed(format!(
                    "BuildTools did not produce {jar}"
                )));
            }
            LaunchSpec::Jar(jar)
        }
        ServerKind::Fabric => {
            let loader = cfg
                .loader_version
                .as_deref()
                .ok_or_else(|| ServerError::Failed("choose a Fabric loader version".into()))?;
            // Pre-place the vanilla server so the Fabric launcher needs no network.
            vanilla_server_jar(l, mc, &dir.join("server.jar")).await?;
            let jar = sources::fabric_server_jar(l, mc, loader).await?;
            let cache = l.cache_dir("fabric").join("server").join(&jar.file_name);
            progress(Progress::stage("Downloading the Fabric server launcher"));
            download_verified(l, &jar, &cache).await?;
            l.safe()
                .copy_file(&cache, &dir.join("fabric-server-launch.jar"))?;
            LaunchSpec::Jar("fabric-server-launch.jar".into())
        }
        ServerKind::Forge | ServerKind::NeoForge => {
            let java =
                java.ok_or_else(|| ServerError::Failed("the installer needs Java".into()))?;
            let version = cfg
                .loader_version
                .as_deref()
                .ok_or_else(|| ServerError::Failed("choose a loader version".into()))?;
            let flavor = if cfg.kind == ServerKind::Forge {
                forge::ForgeFlavor::Forge
            } else {
                forge::ForgeFlavor::NeoForge
            };
            forge::install_server(l, flavor, version, &dir, java, progress).await?;
            detect_forge_launch(&dir).ok_or_else(|| {
                ServerError::Failed(
                    "the installer finished but no server jar or args file was found".into(),
                )
            })?
        }
    };
    if !dir.join("server.properties").exists() {
        l.safe().create_new(
            &dir.join("server.properties"),
            ServerProperties::with_defaults().to_text().as_bytes(),
        )?;
    }
    Ok(spec)
}

/// After a Forge/NeoForge server install: the args file (1.17+) or the jar.
pub fn detect_forge_launch(dir: &Path) -> Option<LaunchSpec> {
    let args_name = if cfg!(windows) {
        "win_args.txt"
    } else {
        "unix_args.txt"
    };
    for base in [
        "libraries/net/minecraftforge/forge",
        "libraries/net/neoforged/neoforge",
        "libraries/net/neoforged/forge",
    ] {
        if let Ok(rd) = std::fs::read_dir(dir.join(base)) {
            for e in rd.flatten() {
                let f = e.path().join(args_name);
                if f.is_file() {
                    let rel = f
                        .strip_prefix(dir)
                        .ok()?
                        .to_string_lossy()
                        .replace('\\', "/");
                    return Some(LaunchSpec::ArgsFile(rel));
                }
            }
        }
    }
    let mut jars: Vec<String> = std::fs::read_dir(dir)
        .ok()?
        .flatten()
        .map(|e| e.file_name().to_string_lossy().into_owned())
        .filter(|n| {
            n.ends_with(".jar")
                && (n.starts_with("forge-") || n.starts_with("neoforge-"))
                && !n.contains("installer")
        })
        .collect();
    jars.sort();
    jars.pop().map(LaunchSpec::Jar)
}

/// Command line (after `java`) for a server.
pub fn command_args(cfg: &ServerConfig) -> Result<Vec<String>> {
    let mut args = vec![
        format!("-Xmx{}M", cfg.ram_mb.max(512)),
        format!("-Xms{}M", (cfg.ram_mb / 2).max(512)),
        "-Dlog4j2.formatMsgNoLookups=true".to_string(),
    ];
    match &cfg.launch {
        Some(LaunchSpec::Jar(f)) => {
            args.push("-jar".into());
            args.push(f.clone());
        }
        Some(LaunchSpec::ArgsFile(f)) => args.push(format!("@{f}")),
        None => {
            return Err(ServerError::Failed(format!(
                "{} is not installed yet",
                cfg.name
            )))
        }
    }
    args.push("nogui".into());
    Ok(args)
}

/// Run the server until it exits. Lines typed in the console arrive on
/// `stdin`; `stop` asks it to shut down cleanly (`stop` command, then kill
/// after 30 s).
pub async fn run(
    cfg: ServerConfig,
    dir: PathBuf,
    java: PathBuf,
    on_line: Arc<dyn Fn(String) + Send + Sync>,
    mut stdin: mpsc::UnboundedReceiver<String>,
    stop: Arc<Notify>,
) -> Result<Option<i32>> {
    let args = command_args(&cfg)?;
    if !eula_accepted(&dir) {
        return Err(ServerError::Failed(
            "Accept the Minecraft EULA first".into(),
        ));
    }
    on_line(format!(
        "[mclaunch] starting {} with {}",
        cfg.name,
        java.display()
    ));
    let mut cmd = tokio::process::Command::new(&java);
    cmd.args(&args)
        .current_dir(&dir)
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped());
    #[cfg(windows)]
    cmd.creation_flags(0x0800_0000);
    let mut child = cmd
        .spawn()
        .map_err(|e| ServerError::Failed(format!("could not start Java: {e}")))?;
    let mut child_in = child.stdin.take();
    for stream in [
        child
            .stdout
            .take()
            .map(|s| Box::new(s) as Box<dyn tokio::io::AsyncRead + Unpin + Send>),
        child
            .stderr
            .take()
            .map(|s| Box::new(s) as Box<dyn tokio::io::AsyncRead + Unpin + Send>),
    ]
    .into_iter()
    .flatten()
    {
        let on_line = on_line.clone();
        tokio::spawn(async move {
            let mut lines = BufReader::new(stream).lines();
            while let Ok(Some(l)) = lines.next_line().await {
                on_line(l);
            }
        });
    }
    let status = loop {
        tokio::select! {
            s = child.wait() => break s,
            line = stdin.recv() => {
                if let (Some(line), Some(w)) = (line, child_in.as_mut()) {
                    let _ = w.write_all(format!("{line}\n").as_bytes()).await;
                    let _ = w.flush().await;
                }
            }
            _ = stop.notified() => {
                on_line("[mclaunch] stopping (sending 'stop')".into());
                if let Some(w) = child_in.as_mut() {
                    let _ = w.write_all(b"stop\n").await;
                    let _ = w.flush().await;
                }
                match tokio::time::timeout(Duration::from_secs(30), child.wait()).await {
                    Ok(s) => break s,
                    Err(_) => {
                        on_line("[mclaunch] server did not stop in 30 s; killing it".into());
                        let _ = child.start_kill();
                        break child.wait().await;
                    }
                }
            }
        }
    };
    let code = status.ok().and_then(|s| s.code());
    on_line(format!(
        "[mclaunch] server exited ({})",
        code.map(|c| c.to_string())
            .unwrap_or_else(|| "signal".into())
    ));
    Ok(code)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn config_roundtrip_and_eula() {
        let dir = tempfile::tempdir().unwrap();
        let safe = SafePath::new(dir.path()).unwrap();
        let paths = LauncherPaths::new(safe.root());
        let cfg = ServerConfig {
            name: "Lobby".into(),
            kind: ServerKind::Paper,
            mc_version: "1.21.4".into(),
            launch: Some(LaunchSpec::Jar("paper-1.21.4-232.jar".into())),
            ..Default::default()
        };
        cfg.save(&paths, &safe).unwrap();
        let list = list_servers(&paths);
        assert_eq!(list.len(), 1);
        assert_eq!(list[0].kind, ServerKind::Paper);
        assert_eq!(list[0].launch, cfg.launch);
        let sdir = cfg.dir(&paths);
        assert!(!eula_accepted(&sdir));
        set_eula(&safe, &sdir, true).unwrap();
        assert!(eula_accepted(&sdir));
        let args = command_args(&list[0]).unwrap();
        assert_eq!(
            &args[args.len() - 3..],
            ["-jar", "paper-1.21.4-232.jar", "nogui"]
        );
    }

    #[test]
    fn forge_launch_detection() {
        let dir = tempfile::tempdir().unwrap();
        let d = dir.path();
        assert!(detect_forge_launch(d).is_none());
        std::fs::write(d.join("forge-1.12.2-14.23.5.2859.jar"), b"").unwrap();
        std::fs::write(d.join("forge-1.12.2-14.23.5.2859-installer.jar"), b"").unwrap();
        assert_eq!(
            detect_forge_launch(d),
            Some(LaunchSpec::Jar("forge-1.12.2-14.23.5.2859.jar".into()))
        );
        let args = d.join("libraries/net/neoforged/neoforge/21.1.200");
        std::fs::create_dir_all(&args).unwrap();
        let name = if cfg!(windows) {
            "win_args.txt"
        } else {
            "unix_args.txt"
        };
        std::fs::write(args.join(name), b"").unwrap();
        assert_eq!(
            detect_forge_launch(d),
            Some(LaunchSpec::ArgsFile(format!(
                "libraries/net/neoforged/neoforge/21.1.200/{name}"
            )))
        );
    }

    #[test]
    fn worlds_are_protected() {
        let dir = tempfile::tempdir().unwrap();
        let safe = SafePath::new(dir.path()).unwrap();
        let world = safe.root().join("servers/Lobby/world/level.dat");
        std::fs::create_dir_all(world.parent().unwrap()).unwrap();
        std::fs::write(&world, b"x").unwrap();
        assert!(safe.remove_file(&world).is_err());
        assert!(safe.trash_server("Lobby", "lobby").is_err());
    }
}
