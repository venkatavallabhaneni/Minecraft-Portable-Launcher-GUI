//! LAN world discovery. Minecraft clients that "Open to LAN" multicast
//! `[MOTD]<motd>[/MOTD][AD]<port>[/AD]` to 224.0.2.60:4445 every ~1.5 s; we
//! listen on the same group (with address reuse so the game's own listener
//! keeps working) and keep a list of games seen recently.

use std::collections::BTreeMap;
use std::net::{Ipv4Addr, SocketAddr, SocketAddrV4};
use std::sync::Arc;
use std::time::{Duration, Instant};

use socket2::{Domain, Protocol, Socket, Type};
use tokio::net::UdpSocket;
use tokio::sync::Notify;

pub const MULTICAST_GROUP: Ipv4Addr = Ipv4Addr::new(224, 0, 2, 60);
pub const PORT: u16 = 4445;
/// Games not heard from for this long disappear from the list.
pub const EXPIRY: Duration = Duration::from_secs(6);

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct LanGame {
    /// World description with `§` formatting codes removed.
    pub motd: String,
    pub host: String,
    pub port: u16,
    pub last_seen: Instant,
}

impl LanGame {
    pub fn address(&self) -> String {
        format!("{}:{}", self.host, self.port)
    }
}

/// Remove Minecraft `§x` formatting codes.
pub fn strip_formatting(s: &str) -> String {
    let mut out = String::with_capacity(s.len());
    let mut chars = s.chars();
    while let Some(c) = chars.next() {
        if c == '§' {
            chars.next();
        } else {
            out.push(c);
        }
    }
    out
}

/// Parse a LAN ping. Returns `(motd, ad)` where `ad` is usually the port,
/// sometimes `host:port`.
pub fn parse_ping(data: &[u8]) -> Option<(String, String)> {
    let text = String::from_utf8_lossy(data);
    let motd = between(&text, "[MOTD]", "[/MOTD]")?;
    let ad = between(&text, "[AD]", "[/AD]")?;
    Some((strip_formatting(motd), ad.trim().to_string()))
}

fn between<'a>(s: &'a str, open: &str, close: &str) -> Option<&'a str> {
    let start = s.find(open)? + open.len();
    let end = s[start..].find(close)? + start;
    Some(&s[start..end])
}

/// Build a ping (used by tests and handy for debugging).
pub fn encode_ping(motd: &str, port: u16) -> Vec<u8> {
    format!("[MOTD]{motd}[/MOTD][AD]{port}[/AD]").into_bytes()
}

/// Resolve the game address from the packet source and its `[AD]` field.
pub fn game_from_ping(src: SocketAddr, motd: String, ad: &str) -> Option<LanGame> {
    let (host, port) = match ad.rsplit_once(':') {
        Some((h, p)) => (h.to_string(), p.parse().ok()?),
        None => (src.ip().to_string(), ad.parse().ok()?),
    };
    if port == 0 {
        return None;
    }
    Some(LanGame {
        motd,
        host,
        port,
        last_seen: Instant::now(),
    })
}

fn bind() -> std::io::Result<UdpSocket> {
    let socket = Socket::new(Domain::IPV4, Type::DGRAM, Some(Protocol::UDP))?;
    socket.set_reuse_address(true)?;
    #[cfg(all(unix, not(target_os = "solaris"), not(target_os = "illumos")))]
    socket.set_reuse_port(true)?;
    socket.bind(&SocketAddrV4::new(Ipv4Addr::UNSPECIFIED, PORT).into())?;
    socket.join_multicast_v4(&MULTICAST_GROUP, &Ipv4Addr::UNSPECIFIED)?;
    socket.set_nonblocking(true)?;
    UdpSocket::from_std(socket.into())
}

/// Listen until `stop` is notified, calling `on_change` with the current
/// list whenever a game appears, changes or expires.
pub async fn listen(
    on_change: impl Fn(Vec<LanGame>) + Send + Sync + 'static,
    stop: Arc<Notify>,
) -> std::io::Result<()> {
    let socket = bind()?;
    tracing::info!("listening for LAN games on {MULTICAST_GROUP}:{PORT}");
    let mut games: BTreeMap<(String, u16), LanGame> = BTreeMap::new();
    let mut buf = [0u8; 1024];
    let mut tick = tokio::time::interval(Duration::from_secs(1));
    loop {
        tokio::select! {
            _ = stop.notified() => return Ok(()),
            _ = tick.tick() => {
                let before = games.len();
                games.retain(|_, g| g.last_seen.elapsed() < EXPIRY);
                // Refresh every second while anything is listed ("seen Ns ago").
                if before != 0 {
                    on_change(games.values().cloned().collect());
                }
            }
            res = socket.recv_from(&mut buf) => {
                let Ok((n, src)) = res else { continue };
                let Some((motd, ad)) = parse_ping(&buf[..n]) else { continue };
                let Some(game) = game_from_ping(src, motd, &ad) else { continue };
                let key = (game.host.clone(), game.port);
                let changed = games.get(&key).is_none_or(|g| g.motd != game.motd);
                games.insert(key, game);
                if changed {
                    on_change(games.values().cloned().collect());
                }
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn ping_roundtrip() {
        let p = encode_ping("§aSteve - My World", 51234);
        let (motd, ad) = parse_ping(&p).unwrap();
        assert_eq!(motd, "Steve - My World");
        assert_eq!(ad, "51234");
        let src: SocketAddr = "192.168.1.20:4445".parse().unwrap();
        let g = game_from_ping(src, motd, &ad).unwrap();
        assert_eq!(g.address(), "192.168.1.20:51234");
        assert!(parse_ping(b"garbage").is_none());
        assert!(game_from_ping(src, "x".into(), "notaport").is_none());
        let g = game_from_ping(src, "x".into(), "10.0.0.5:25565").unwrap();
        assert_eq!(g.address(), "10.0.0.5:25565");
    }

    #[test]
    fn formatting_codes() {
        assert_eq!(strip_formatting("§l§6Gold§r world"), "Gold world");
        assert_eq!(strip_formatting("plain"), "plain");
    }

    /// Sends a ping to the multicast group and expects to hear it back.
    /// Ignored because CI sandboxes often block multicast.
    #[tokio::test]
    #[ignore = "needs multicast networking"]
    async fn hears_its_own_ping() {
        let found = Arc::new(std::sync::Mutex::new(Vec::new()));
        let f2 = found.clone();
        let stop = Arc::new(Notify::new());
        let s2 = stop.clone();
        let task = tokio::spawn(listen(move |g| *f2.lock().unwrap() = g, s2));
        tokio::time::sleep(Duration::from_millis(300)).await;
        let sender = std::net::UdpSocket::bind("0.0.0.0:0").unwrap();
        sender.set_multicast_loop_v4(true).unwrap();
        for _ in 0..5 {
            sender
                .send_to(&encode_ping("Test World", 40000), (MULTICAST_GROUP, PORT))
                .unwrap();
            tokio::time::sleep(Duration::from_millis(200)).await;
        }
        stop.notify_one();
        task.await.unwrap().unwrap();
        let games = found.lock().unwrap();
        assert!(
            games
                .iter()
                .any(|g| g.port == 40000 && g.motd == "Test World"),
            "{games:?}"
        );
    }
}
