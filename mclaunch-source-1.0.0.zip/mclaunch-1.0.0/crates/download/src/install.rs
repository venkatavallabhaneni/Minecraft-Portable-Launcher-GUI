//! Install / verify / repair of game versions.

use std::collections::{BTreeSet, HashSet};
use std::path::{Path, PathBuf};

use mclaunch_core::assets::AssetIndex;
use mclaunch_core::manifest::{VersionManifest, VersionType, MANIFEST_URL};
use mclaunch_core::progress::noop_progress;
use mclaunch_core::version::{self, LibraryFile, ResolvedVersion, VersionJson};
use mclaunch_core::{LauncherPaths, Progress, ProgressFn, RuleContext};
use mclaunch_safety::SafePath;

use crate::downloader::{DownloadTask, Downloader};
use crate::hash;
use crate::http::Http;
use crate::integrity::{IntegrityManifest, VerifyReport};
use crate::{DownloadError, Result};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ManifestSource {
    Network,
    Cache,
}

#[derive(Debug, Clone, Default)]
pub struct InstallReport {
    pub version: String,
    pub files: usize,
    pub downloaded: usize,
    pub copied: usize,
    pub skipped: usize,
    pub bytes: u64,
}

#[derive(Debug, Clone, Default)]
pub struct RepairReport {
    pub version: String,
    pub before: VerifyReport,
    pub redownloaded: usize,
    pub failed: Vec<(PathBuf, String)>,
    /// Files whose upstream content changed (new Mojang SHA-1) and whose
    /// SHA-256 record was refreshed.
    pub updated_records: usize,
    pub after: VerifyReport,
    /// No manifest existed, so a full install was performed.
    pub reinstalled: bool,
}

impl RepairReport {
    pub fn summary(&self) -> String {
        if self.reinstalled {
            return format!("Reinstalled {}: {}", self.version, self.after.summary());
        }
        if self.before.is_ok() {
            return format!("Nothing to repair: {}", self.after.summary());
        }
        let mut s = format!(
            "Repaired {} file(s) ({} missing, {} corrupt before). After: {}",
            self.redownloaded,
            self.before.missing.len(),
            self.before.corrupt.len(),
            self.after.summary()
        );
        if !self.failed.is_empty() {
            s.push_str(&format!(" — {} could not be repaired", self.failed.len()));
        }
        s
    }
}

/// Everything a version needs on disk.
#[derive(Debug, Clone)]
pub struct Plan {
    pub resolved: ResolvedVersion,
    pub tasks: Vec<DownloadTask>,
    pub asset_index: Option<(String, AssetIndex)>,
    /// Files recorded in the integrity manifest that are not download tasks
    /// (version JSONs, asset index).
    pub extra_files: Vec<PathBuf>,
}

/// A version present in `versions/`.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct InstalledVersion {
    pub id: String,
    pub inherits_from: Option<String>,
    pub kind: Option<VersionType>,
    pub has_integrity: bool,
}

/// Rewrite dead or insecure repository URLs found in old profiles.
pub fn fix_url(url: &str) -> String {
    let url = url
        .replace(
            "http://files.minecraftforge.net/maven/",
            "https://maven.minecraftforge.net/",
        )
        .replace(
            "https://files.minecraftforge.net/maven/",
            "https://maven.minecraftforge.net/",
        );
    match url.strip_prefix("http://") {
        Some(rest) => format!("https://{rest}"),
        None => url,
    }
}

pub fn library_task(paths: &LauncherPaths, file: &LibraryFile) -> DownloadTask {
    let dest = paths
        .libraries_dir()
        .join(file.path.replace('/', std::path::MAIN_SEPARATOR_STR));
    let mut task = DownloadTask::new(fix_url(&file.url), dest)
        .sha1(file.sha1.clone())
        .size(file.size);
    if !file.url.is_empty() && !file.url.contains("libraries.minecraft.net") {
        task = task
            .mirror(format!("https://repo1.maven.org/maven2/{}", file.path))
            .mirror(format!("{}{}", version::LIBRARIES_URL, file.path));
    }
    task
}

/// Copy asset objects to `target/<name>` (legacy virtual / resources
/// layouts). Never overwrites a file of the right size.
pub fn copy_assets_to(
    paths: &LauncherPaths,
    safe: &SafePath,
    index: &AssetIndex,
    target: &Path,
) -> Result<usize> {
    let mut copied = 0;
    for (name, obj) in &index.objects {
        if name.split('/').any(|p| p == ".." || p.is_empty()) {
            tracing::warn!(name, "skipping unsafe asset name");
            continue;
        }
        let dest = target.join(name.replace('/', std::path::MAIN_SEPARATOR_STR));
        if std::fs::metadata(&dest)
            .map(|m| m.len() == obj.size)
            .unwrap_or(false)
        {
            continue;
        }
        let src = paths.asset_object(&obj.hash);
        if !src.is_file() {
            continue;
        }
        if dest.exists() {
            safe.copy_file(&src, &dest)?;
        } else {
            safe.copy_new(&src, &dest)?;
        }
        copied += 1;
    }
    Ok(copied)
}

pub fn installed_versions(paths: &LauncherPaths) -> Vec<InstalledVersion> {
    let mut out = Vec::new();
    let Ok(entries) = std::fs::read_dir(paths.versions_dir()) else {
        return out;
    };
    for entry in entries.flatten() {
        let id = entry.file_name().to_string_lossy().into_owned();
        let json = paths.version_json(&id);
        if !json.is_file() {
            continue;
        }
        let parsed = VersionJson::load(&json).ok();
        out.push(InstalledVersion {
            has_integrity: paths.integrity_file(&id).is_file(),
            inherits_from: parsed.as_ref().and_then(|v| v.inherits_from.clone()),
            kind: parsed.and_then(|v| v.kind),
            id,
        });
    }
    out.sort_by(|a, b| a.id.cmp(&b.id));
    out
}

#[derive(Clone)]
pub struct Installer {
    pub paths: LauncherPaths,
    pub safe: SafePath,
    pub http: Http,
    pub threads: usize,
}

impl Installer {
    pub fn new(paths: LauncherPaths, safe: SafePath, http: Http, threads: usize) -> Self {
        Self {
            paths,
            safe,
            http,
            threads,
        }
    }

    pub fn downloader(&self) -> Downloader {
        Downloader::new(self.http.clone(), self.safe.clone(), self.threads)
    }

    pub fn load_cached_manifest(&self) -> Option<VersionManifest> {
        mclaunch_core::read_json(&self.paths.manifest_cache()).ok()
    }

    /// Fetch Mojang's manifest (caching it), or fall back to the cache.
    pub async fn fetch_manifest(&self) -> Result<(VersionManifest, ManifestSource)> {
        if !self.http.is_offline() {
            match self.http.get_bytes(MANIFEST_URL).await {
                Ok(bytes) => match serde_json::from_slice::<VersionManifest>(&bytes) {
                    Ok(m) => {
                        self.safe.write(&self.paths.manifest_cache(), &bytes)?;
                        return Ok((m, ManifestSource::Network));
                    }
                    Err(e) => tracing::warn!(error = %e, "manifest from network is invalid"),
                },
                Err(e) => tracing::warn!(error = %e, "manifest fetch failed; using cache"),
            }
        }
        self.load_cached_manifest()
            .map(|m| (m, ManifestSource::Cache))
            .ok_or_else(|| DownloadError::Offline("the version list".into()))
    }

    /// Make sure `versions/<id>/<id>.json` and every parent exist (vanilla
    /// JSONs are fetched from Mojang and checked against the manifest SHA-1).
    pub async fn ensure_json_chain(
        &self,
        id: &str,
        manifest: Option<&VersionManifest>,
    ) -> Result<ResolvedVersion> {
        let mut fetched: Option<VersionManifest> = None;
        let mut current = id.to_string();
        for _ in 0..16 {
            let path = self.paths.version_json(&current);
            let exists = path.is_file();
            let mut entry = manifest
                .or(fetched.as_ref())
                .and_then(|m| m.get(&current))
                .cloned();
            if !exists && entry.is_none() && manifest.is_none() && fetched.is_none() {
                fetched = Some(self.fetch_manifest().await?.0);
                entry = fetched.as_ref().and_then(|m| m.get(&current)).cloned();
            }
            let stale = exists
                && !self.http.is_offline()
                && entry
                    .as_ref()
                    .and_then(|e| e.sha1.as_deref())
                    .is_some_and(|sha| !hash::file_matches(&path, None, Some(sha)));
            if !exists || stale {
                let Some(e) = entry else {
                    return Err(DownloadError::Other(format!(
                        "version '{current}' is not installed and is not in Mojang's version list"
                    )));
                };
                let task = DownloadTask::new(&e.url, &path).sha1(e.sha1.clone());
                let s = self
                    .downloader()
                    .run(vec![task], "Fetching version info", &noop_progress())
                    .await;
                if !s.is_ok() {
                    if exists {
                        tracing::warn!(id = %current, "could not refresh version JSON; keeping local copy");
                    } else {
                        return Err(DownloadError::Other(s.failure_text()));
                    }
                }
            }
            let json = VersionJson::load(&path)?;
            match json.inherits_from {
                Some(parent) => current = parent,
                None => break,
            }
        }
        Ok(version::load_resolved(&self.paths, id)?)
    }

    async fn ensure_asset_index(&self, v: &VersionJson) -> Result<Option<(String, AssetIndex)>> {
        let Some(r) = &v.asset_index else {
            return Ok(None);
        };
        let path = self.paths.asset_index(&r.id);
        let task = DownloadTask::new(&r.url, &path)
            .sha1(r.sha1.clone())
            .size(r.size);
        let s = self
            .downloader()
            .run(vec![task], "Fetching asset index", &noop_progress())
            .await;
        if !s.is_ok() {
            return Err(DownloadError::Other(s.failure_text()));
        }
        let index: AssetIndex = mclaunch_core::read_json(&path)?;
        Ok(Some((r.id.clone(), index)))
    }

    /// Work out every file `resolved` needs.
    pub async fn plan(&self, resolved: ResolvedVersion) -> Result<Plan> {
        let paths = &self.paths;
        let v = &resolved.merged;
        let ctx = RuleContext::current();
        let mut tasks = Vec::new();

        let jar_id = v.client_jar_id().to_string();
        let jar_path = paths.version_jar(&jar_id);
        match v.downloads.get("client") {
            Some(client) => {
                let local = v
                    .client_from
                    .as_ref()
                    .filter(|from| **from != jar_id)
                    .map(|from| paths.version_jar(from));
                tasks.push(
                    DownloadTask::new(&client.url, &jar_path)
                        .sha1(client.sha1.clone())
                        .size(client.size)
                        .local_source(local),
                );
            }
            None => tasks.push(DownloadTask::new("", &jar_path)),
        }

        for lib in v.effective_libraries(&ctx) {
            if let Some(a) = lib.artifact() {
                tasks.push(library_task(paths, &a));
            }
            if let Some(n) = lib.native_artifact(&ctx) {
                tasks.push(library_task(paths, &n));
            }
        }

        if let Some(log) = v.client_logging() {
            tasks.push(
                DownloadTask::new(&log.file.url, paths.log_configs_dir().join(&log.file.id))
                    .sha1(log.file.sha1.clone())
                    .size(log.file.size),
            );
        }

        let mut extra_files: Vec<PathBuf> = resolved
            .chain
            .iter()
            .map(|id| paths.version_json(id))
            .collect();
        let asset_index = self.ensure_asset_index(v).await?;
        if let Some((id, index)) = &asset_index {
            extra_files.push(paths.asset_index(id));
            for obj in index.objects.values() {
                tasks.push(
                    DownloadTask::new(obj.url(), paths.asset_object(&obj.hash))
                        .sha1(Some(obj.hash.clone()))
                        .size(Some(obj.size)),
                );
            }
        }

        Ok(Plan {
            resolved,
            tasks,
            asset_index,
            extra_files,
        })
    }

    /// Download everything for `id`, verifying Mojang's SHA-1 and size, then
    /// record a SHA-256 manifest in `integrity/<id>.sha256`.
    pub async fn install(&self, id: &str, progress: &ProgressFn) -> Result<InstallReport> {
        progress(Progress::stage(format!("Preparing {id}")));
        let resolved = self.ensure_json_chain(id, None).await?;
        let plan = self.plan(resolved).await?;
        let summary = self
            .downloader()
            .run(plan.tasks.clone(), &format!("Downloading {id}"), progress)
            .await;
        if !summary.is_ok() {
            return Err(DownloadError::Other(summary.failure_text()));
        }
        if let Some((index_id, index)) = &plan.asset_index {
            if index.is_virtual {
                progress(Progress::stage("Preparing legacy assets"));
                let (paths, safe, index, target) = (
                    self.paths.clone(),
                    self.safe.clone(),
                    index.clone(),
                    self.paths.virtual_assets_dir(index_id),
                );
                tokio::task::spawn_blocking(move || copy_assets_to(&paths, &safe, &index, &target))
                    .await
                    .map_err(|e| DownloadError::Other(e.to_string()))??;
            }
        }
        let files = plan_files(&plan);
        let count = files.len();
        let manifest = IntegrityManifest::build(&self.paths, id, files, progress).await?;
        manifest.save(&self.paths, &self.safe)?;
        tracing::info!(
            version = id,
            files = count,
            downloaded = summary.downloaded,
            "installed"
        );
        Ok(InstallReport {
            version: id.to_string(),
            files: count,
            downloaded: summary.downloaded,
            copied: summary.copied,
            skipped: summary.skipped,
            bytes: summary.bytes_downloaded,
        })
    }

    /// Re-hash every file against the stored SHA-256 manifest.
    pub async fn verify(&self, id: &str, progress: &ProgressFn) -> Result<VerifyReport> {
        let manifest = IntegrityManifest::load(&self.paths, id)?.ok_or_else(|| {
            DownloadError::Other(format!(
                "{id} has no integrity manifest yet; install it first"
            ))
        })?;
        Ok(manifest.verify(&self.paths, progress).await)
    }

    /// Re-download only missing/corrupt files, then re-verify with SHA-256.
    pub async fn repair(&self, id: &str, progress: &ProgressFn) -> Result<RepairReport> {
        let Some(mut manifest) = IntegrityManifest::load(&self.paths, id)? else {
            self.install(id, progress).await?;
            let after = self.verify(id, progress).await?;
            return Ok(RepairReport {
                version: id.to_string(),
                after,
                reinstalled: true,
                ..Default::default()
            });
        };
        let before = manifest.verify(&self.paths, progress).await;
        if before.is_ok() {
            return Ok(RepairReport {
                version: id.to_string(),
                after: before.clone(),
                before,
                ..Default::default()
            });
        }
        let bad: HashSet<String> = before.bad().cloned().collect();
        progress(Progress::stage(format!("Repairing {} file(s)", bad.len())));

        // Re-fetches missing/corrupt vanilla JSONs and the asset index.
        let resolved = self.ensure_json_chain(id, None).await?;
        let plan = self.plan(resolved).await?;
        let tasks: Vec<DownloadTask> = plan
            .tasks
            .into_iter()
            .filter(|t| {
                self.paths
                    .relative(&t.dest)
                    .is_some_and(|rel| bad.contains(&rel))
            })
            .collect();
        let repaired: HashSet<String> = tasks
            .iter()
            .filter_map(|t| self.paths.relative(&t.dest))
            .collect();
        let summary = self.downloader().run(tasks, "Repairing", progress).await;
        let failed_rel: HashSet<String> = summary
            .failed
            .iter()
            .filter_map(|(p, _)| self.paths.relative(p))
            .collect();

        let mut after = manifest.verify(&self.paths, progress).await;
        // A re-downloaded file that passed Mojang's SHA-1 but differs from our
        // old SHA-256 record means the upstream file changed: refresh it.
        let mut updated = 0;
        for rel in after.corrupt.clone() {
            if repaired.contains(&rel) && !failed_rel.contains(&rel) {
                let path = self.paths.from_relative(&rel);
                if let Ok(sha) = hash::sha256_file(&path) {
                    manifest.entries.insert(rel, sha);
                    updated += 1;
                }
            }
        }
        // JSONs/index that were re-fetched (not download tasks).
        for rel in after.corrupt.clone() {
            if !repaired.contains(&rel) && rel.ends_with(".json") {
                let path = self.paths.from_relative(&rel);
                if let Ok(sha) = hash::sha256_file(&path) {
                    manifest.entries.insert(rel, sha);
                    updated += 1;
                }
            }
        }
        if updated > 0 {
            manifest.save(&self.paths, &self.safe)?;
            after = manifest.verify(&self.paths, progress).await;
        }
        Ok(RepairReport {
            version: id.to_string(),
            redownloaded: summary.downloaded + summary.copied,
            failed: summary.failed,
            updated_records: updated,
            before,
            after,
            reinstalled: false,
        })
    }

    /// Ensure `id` is launchable without blocking on the network when the
    /// local copy is intact:
    /// * manifest present and SHA-256 OK -> ready, no network used
    /// * files missing/corrupt -> repair (needs network)
    /// * never installed -> install (needs network)
    pub async fn ensure_ready(&self, id: &str, progress: &ProgressFn) -> Result<VerifyReport> {
        if IntegrityManifest::load(&self.paths, id)?.is_some() {
            let report = self.verify(id, progress).await?;
            if report.is_ok() {
                return Ok(report);
            }
            if self.http.is_offline() {
                return Err(DownloadError::Other(format!(
                    "{id}: {} — offline, cannot repair. Turn off offline mode and press Repair.",
                    report.summary()
                )));
            }
            let r = self.repair(id, progress).await?;
            if r.after.is_ok() {
                return Ok(r.after);
            }
            return Err(DownloadError::Other(r.summary()));
        }
        self.install(id, progress).await?;
        self.verify(id, progress).await
    }
}

fn plan_files(plan: &Plan) -> Vec<PathBuf> {
    let mut set: BTreeSet<PathBuf> = plan.tasks.iter().map(|t| t.dest.clone()).collect();
    set.extend(plan.extra_files.iter().cloned());
    set.into_iter().collect()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn url_fixes() {
        assert_eq!(
            fix_url("http://files.minecraftforge.net/maven/net/minecraftforge/forge/x.jar"),
            "https://maven.minecraftforge.net/net/minecraftforge/forge/x.jar"
        );
        assert_eq!(fix_url("http://example.org/a"), "https://example.org/a");
        assert_eq!(fix_url(""), "");
    }

    #[test]
    fn library_tasks_get_mirrors() {
        let paths = LauncherPaths::new("/mc");
        let t = library_task(
            &paths,
            &LibraryFile {
                path: "net/fabricmc/fabric-loader/0.16.10/fabric-loader-0.16.10.jar".into(),
                url: "https://maven.fabricmc.net/net/fabricmc/fabric-loader/0.16.10/fabric-loader-0.16.10.jar".into(),
                sha1: None,
                size: None,
            },
        );
        assert_eq!(t.mirrors.len(), 2);
        assert!(t.dest.ends_with("fabric-loader-0.16.10.jar"));
        let t = library_task(
            &paths,
            &LibraryFile {
                path: "a/b/1/b-1.jar".into(),
                url: "https://libraries.minecraft.net/a/b/1/b-1.jar".into(),
                sha1: Some("x".into()),
                size: Some(1),
            },
        );
        assert!(t.mirrors.is_empty());
    }

    #[test]
    fn copy_assets_skips_unsafe_names() {
        let dir = tempfile::tempdir().unwrap();
        let safe = SafePath::new(dir.path()).unwrap();
        let paths = LauncherPaths::new(safe.root());
        let hash = "a9993e364706816aba3e25717850c26c9cd0d89d";
        let obj = paths.asset_object(hash);
        std::fs::create_dir_all(obj.parent().unwrap()).unwrap();
        std::fs::write(&obj, b"abc").unwrap();
        let index: AssetIndex = serde_json::from_str(&format!(
            r#"{{"map_to_resources": true, "objects": {{
                "sound/a.ogg": {{"hash": "{hash}", "size": 3}},
                "../../evil": {{"hash": "{hash}", "size": 3}}}}}}"#
        ))
        .unwrap();
        let target = paths.instance_dir("x").join("resources");
        assert_eq!(copy_assets_to(&paths, &safe, &index, &target).unwrap(), 1);
        assert_eq!(
            std::fs::read(target.join("sound").join("a.ogg")).unwrap(),
            b"abc"
        );
        assert_eq!(copy_assets_to(&paths, &safe, &index, &target).unwrap(), 0);
    }

    /// Full install of a real old version. Run with
    /// `cargo test -p mclaunch-download -- --ignored install_b173`.
    #[tokio::test]
    #[ignore = "network"]
    async fn install_b173_verify_and_repair() {
        let dir = tempfile::tempdir().unwrap();
        let safe = SafePath::new(dir.path()).unwrap();
        let paths = LauncherPaths::new(safe.root());
        paths.ensure_layout().unwrap();
        let inst = Installer::new(paths.clone(), safe, Http::new(false).unwrap(), 16);
        let r = inst.install("b1.7.3", &noop_progress()).await.unwrap();
        assert!(r.files > 10);
        let v = inst.verify("b1.7.3", &noop_progress()).await.unwrap();
        assert!(v.is_ok(), "{v:?}");
        // corrupt the client jar and delete a library
        std::fs::write(paths.version_jar("b1.7.3"), b"broken").unwrap();
        let lib =
            paths.from_relative("libraries/net/minecraft/launchwrapper/1.5/launchwrapper-1.5.jar");
        std::fs::remove_file(&lib).unwrap();
        let v = inst.verify("b1.7.3", &noop_progress()).await.unwrap();
        assert_eq!(v.corrupt.len(), 1);
        assert_eq!(v.missing.len(), 1);
        let rep = inst.repair("b1.7.3", &noop_progress()).await.unwrap();
        assert_eq!(rep.redownloaded, 2, "{}", rep.summary());
        assert!(rep.after.is_ok(), "{}", rep.summary());
        // offline launch readiness
        inst.http.set_offline(true);
        assert!(inst
            .ensure_ready("b1.7.3", &noop_progress())
            .await
            .unwrap()
            .is_ok());
    }
}
