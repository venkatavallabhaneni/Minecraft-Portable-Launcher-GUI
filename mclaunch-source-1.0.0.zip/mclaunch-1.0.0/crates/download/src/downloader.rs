//! Parallel, resumable downloader with retry/backoff and SHA-1 + size
//! verification. Writes go through the `SafePath` guard.

use std::collections::HashSet;
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::Mutex;
use std::time::{Duration, Instant};

use futures::StreamExt;
use mclaunch_core::{Progress, ProgressFn};
use mclaunch_safety::SafePath;
use tokio::io::AsyncWriteExt;

use crate::hash;
use crate::http::Http;
use crate::{io_err, DownloadError, Result};

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct DownloadTask {
    /// Primary URL; empty when the file can only be produced locally.
    pub url: String,
    /// Fallback URLs tried in order after `url` fails.
    pub mirrors: Vec<String>,
    pub dest: PathBuf,
    pub sha1: Option<String>,
    /// Checked in addition to the SHA-1 (Modrinth packs list both).
    pub sha512: Option<String>,
    pub size: Option<u64>,
    /// An already-downloaded identical file to copy instead of downloading
    /// (e.g. the vanilla jar for a loader profile).
    pub local_source: Option<PathBuf>,
}

impl DownloadTask {
    pub fn new(url: impl Into<String>, dest: impl Into<PathBuf>) -> Self {
        Self {
            url: url.into(),
            mirrors: Vec::new(),
            dest: dest.into(),
            sha1: None,
            sha512: None,
            size: None,
            local_source: None,
        }
    }

    pub fn sha1(mut self, sha1: Option<String>) -> Self {
        self.sha1 = sha1.filter(|s| !s.is_empty());
        self
    }

    pub fn sha512(mut self, sha512: Option<String>) -> Self {
        self.sha512 = sha512.filter(|s| !s.is_empty());
        self
    }

    pub fn size(mut self, size: Option<u64>) -> Self {
        self.size = size.filter(|s| *s > 0);
        self
    }

    pub fn mirror(mut self, url: impl Into<String>) -> Self {
        self.mirrors.push(url.into());
        self
    }

    pub fn local_source(mut self, path: Option<PathBuf>) -> Self {
        self.local_source = path;
        self
    }
}

#[derive(Debug, Clone, Default)]
pub struct DownloadSummary {
    pub total: usize,
    pub downloaded: usize,
    pub copied: usize,
    pub skipped: usize,
    pub bytes_downloaded: u64,
    pub failed: Vec<(PathBuf, String)>,
}

impl DownloadSummary {
    pub fn is_ok(&self) -> bool {
        self.failed.is_empty()
    }

    /// Short description of the failures for error messages.
    pub fn failure_text(&self) -> String {
        let mut s = format!("{} file(s) failed", self.failed.len());
        for (path, err) in self.failed.iter().take(5) {
            s.push_str(&format!("\n  {}: {err}", path.display()));
        }
        if self.failed.len() > 5 {
            s.push_str(&format!("\n  ... and {} more", self.failed.len() - 5));
        }
        s
    }
}

enum Outcome {
    Skipped,
    Copied,
    Downloaded(u64),
}

struct Reporter<'a> {
    progress: &'a ProgressFn,
    stage: &'a str,
    total: u64,
    bytes_total: u64,
    done: AtomicU64,
    bytes: AtomicU64,
    last: Mutex<Instant>,
}

impl Reporter<'_> {
    fn add_bytes(&self, n: u64) {
        self.bytes.fetch_add(n, Ordering::Relaxed);
        self.tick(false);
    }

    fn sub_bytes(&self, n: u64) {
        let mut cur = self.bytes.load(Ordering::Relaxed);
        while let Err(actual) = self.bytes.compare_exchange_weak(
            cur,
            cur.saturating_sub(n),
            Ordering::Relaxed,
            Ordering::Relaxed,
        ) {
            cur = actual;
        }
    }

    fn file_done(&self) {
        self.done.fetch_add(1, Ordering::Relaxed);
        self.tick(false);
    }

    fn tick(&self, force: bool) {
        {
            let mut last = self.last.lock().unwrap_or_else(|e| e.into_inner());
            if !force && last.elapsed() < Duration::from_millis(100) {
                return;
            }
            *last = Instant::now();
        }
        (self.progress)(Progress {
            stage: self.stage.to_string(),
            done: self.done.load(Ordering::Relaxed),
            total: self.total,
            bytes_done: self.bytes.load(Ordering::Relaxed).min(self.bytes_total),
            bytes_total: self.bytes_total,
        });
    }
}

pub fn part_path(dest: &Path) -> PathBuf {
    let mut name = dest
        .file_name()
        .map(|n| n.to_os_string())
        .unwrap_or_default();
    name.push(".part");
    dest.with_file_name(name)
}

#[derive(Clone)]
pub struct Downloader {
    http: Http,
    safe: SafePath,
    concurrency: usize,
    retries: u32,
}

impl Downloader {
    pub fn new(http: Http, safe: SafePath, concurrency: usize) -> Self {
        Self {
            http,
            safe,
            concurrency: concurrency.clamp(1, 64),
            retries: 4,
        }
    }

    pub fn http(&self) -> &Http {
        &self.http
    }

    /// Download every task, `concurrency` at a time. Never panics on
    /// individual failures; they are collected in the summary.
    pub async fn run(
        &self,
        tasks: Vec<DownloadTask>,
        stage: &str,
        progress: &ProgressFn,
    ) -> DownloadSummary {
        // The same asset object can be listed under several names.
        let mut seen = HashSet::new();
        let tasks: Vec<DownloadTask> = tasks
            .into_iter()
            .filter(|t| seen.insert(t.dest.clone()))
            .collect();

        let reporter = Reporter {
            progress,
            stage,
            total: tasks.len() as u64,
            bytes_total: tasks.iter().filter_map(|t| t.size).sum(),
            done: AtomicU64::new(0),
            bytes: AtomicU64::new(0),
            last: Mutex::new(Instant::now() - Duration::from_secs(1)),
        };
        reporter.tick(true);

        let results: Vec<(PathBuf, Option<u64>, Result<Outcome>)> =
            futures::stream::iter(tasks.into_iter().map(|task| {
                let reporter = &reporter;
                async move {
                    let res = self.fetch(&task, reporter).await;
                    (task.dest, task.size, res)
                }
            }))
            .buffer_unordered(self.concurrency)
            .collect()
            .await;

        let mut summary = DownloadSummary {
            total: results.len(),
            ..Default::default()
        };
        for (dest, _size, res) in results {
            match res {
                Ok(Outcome::Skipped) => summary.skipped += 1,
                Ok(Outcome::Copied) => summary.copied += 1,
                Ok(Outcome::Downloaded(n)) => {
                    summary.downloaded += 1;
                    summary.bytes_downloaded += n;
                }
                Err(e) => {
                    tracing::warn!(path = %dest.display(), error = %e, "download failed");
                    summary.failed.push((dest, e.to_string()));
                }
            }
        }
        reporter.tick(true);
        summary
    }

    async fn fetch(&self, task: &DownloadTask, rep: &Reporter<'_>) -> Result<Outcome> {
        let outcome = self.fetch_inner(task, rep).await;
        if matches!(outcome, Ok(Outcome::Skipped) | Ok(Outcome::Copied)) {
            rep.add_bytes(task.size.unwrap_or(0));
        }
        rep.file_done();
        outcome
    }

    async fn fetch_inner(&self, task: &DownloadTask, rep: &Reporter<'_>) -> Result<Outcome> {
        let (dest, size, sha1, sha512) = (
            task.dest.clone(),
            task.size,
            task.sha1.clone(),
            task.sha512.clone(),
        );
        let valid = tokio::task::spawn_blocking(move || {
            hash::file_matches(&dest, size, sha1.as_deref())
                && sha512.is_none_or(|want| {
                    hash::sha512_file(&dest).is_ok_and(|got| got.eq_ignore_ascii_case(&want))
                })
        })
        .await
        .unwrap_or(false);
        if valid {
            return Ok(Outcome::Skipped);
        }
        self.safe.check_modify(&task.dest)?;

        if let Some(src) = &task.local_source {
            let (src2, sha1) = (src.clone(), task.sha1.clone());
            let ok = tokio::task::spawn_blocking(move || {
                hash::file_matches(&src2, size, sha1.as_deref())
            })
            .await
            .unwrap_or(false);
            if ok {
                self.safe.copy_file(src, &task.dest)?;
                return Ok(Outcome::Copied);
            }
        }

        if task.url.is_empty() {
            return Err(DownloadError::Missing(task.dest.clone()));
        }
        if self.http.is_offline() {
            return Err(DownloadError::Offline(task.url.clone()));
        }

        let mut last_err = None;
        for url in std::iter::once(&task.url).chain(task.mirrors.iter()) {
            for attempt in 0..self.retries {
                match self.fetch_once(url, task, rep).await {
                    Ok(n) => return Ok(Outcome::Downloaded(n)),
                    Err(e) => {
                        let retry = is_retryable(&e);
                        tracing::debug!(url, attempt, error = %e, retry, "download attempt failed");
                        last_err = Some(e);
                        if !retry {
                            break;
                        }
                        let backoff = Duration::from_millis(500 * (1 << attempt.min(4)));
                        tokio::time::sleep(backoff).await;
                    }
                }
            }
        }
        Err(last_err.unwrap_or_else(|| DownloadError::Missing(task.dest.clone())))
    }

    async fn fetch_once(&self, url: &str, task: &DownloadTask, rep: &Reporter<'_>) -> Result<u64> {
        let part = part_path(&task.dest);
        self.safe.check_modify(&part)?;
        if let Some(parent) = part.parent() {
            tokio::fs::create_dir_all(parent)
                .await
                .map_err(io_err(parent))?;
        }

        let mut existing = tokio::fs::metadata(&part)
            .await
            .map(|m| m.len())
            .unwrap_or(0);
        if let Some(size) = task.size {
            if existing >= size {
                self.safe.remove_file(&part)?;
                existing = 0;
            }
        }

        let mut req = self.http.client().get(url);
        if existing > 0 {
            req = req.header(reqwest::header::RANGE, format!("bytes={existing}-"));
        }
        let resp = req.send().await.map_err(|source| DownloadError::Network {
            url: url.to_string(),
            source,
        })?;
        let status = resp.status();
        let append = if status == reqwest::StatusCode::PARTIAL_CONTENT && existing > 0 {
            true
        } else if status.is_success() {
            existing = 0;
            false
        } else {
            if status == reqwest::StatusCode::RANGE_NOT_SATISFIABLE {
                self.safe.remove_file(&part)?;
            }
            return Err(DownloadError::Status {
                url: url.to_string(),
                status: status.as_u16(),
            });
        };

        let mut file = if append {
            tokio::fs::OpenOptions::new()
                .append(true)
                .open(&part)
                .await
                .map_err(io_err(&part))?
        } else {
            tokio::fs::File::create(&part)
                .await
                .map_err(io_err(&part))?
        };
        rep.add_bytes(existing);

        let mut written = existing;
        let mut stream = resp.bytes_stream();
        let result: Result<()> = async {
            while let Some(chunk) = stream.next().await {
                let chunk = chunk.map_err(|source| DownloadError::Network {
                    url: url.to_string(),
                    source,
                })?;
                file.write_all(&chunk).await.map_err(io_err(&part))?;
                written += chunk.len() as u64;
                rep.add_bytes(chunk.len() as u64);
            }
            file.flush().await.map_err(io_err(&part))?;
            Ok(())
        }
        .await;
        drop(file);
        if let Err(e) = result {
            // Keep the partial file for resume; undo progress accounting.
            rep.sub_bytes(written);
            return Err(e);
        }

        let actual = tokio::fs::metadata(&part)
            .await
            .map_err(io_err(&part))?
            .len();
        if let Some(expected) = task.size {
            if actual != expected {
                self.safe.remove_file(&part)?;
                rep.sub_bytes(written);
                return Err(DownloadError::Size {
                    path: task.dest.clone(),
                    expected,
                    actual,
                });
            }
        }
        if let Some(expected) = &task.sha1 {
            let p = part.clone();
            let got = tokio::task::spawn_blocking(move || hash::sha1_file(&p))
                .await
                .map_err(|e| DownloadError::Other(e.to_string()))?
                .map_err(io_err(&part))?;
            if !got.eq_ignore_ascii_case(expected) {
                self.safe.remove_file(&part)?;
                rep.sub_bytes(written);
                return Err(DownloadError::Checksum {
                    path: task.dest.clone(),
                    expected: expected.clone(),
                    actual: got,
                });
            }
        }
        if let Some(expected) = &task.sha512 {
            let p = part.clone();
            let got = tokio::task::spawn_blocking(move || hash::sha512_file(&p))
                .await
                .map_err(|e| DownloadError::Other(e.to_string()))?
                .map_err(io_err(&part))?;
            if !got.eq_ignore_ascii_case(expected) {
                self.safe.remove_file(&part)?;
                rep.sub_bytes(written);
                return Err(DownloadError::Checksum {
                    path: task.dest.clone(),
                    expected: expected.clone(),
                    actual: got,
                });
            }
        }
        self.safe.rename(&part, &task.dest)?;
        Ok(actual)
    }
}

fn is_retryable(e: &DownloadError) -> bool {
    match e {
        DownloadError::Network { .. }
        | DownloadError::Checksum { .. }
        | DownloadError::Size { .. } => true,
        DownloadError::Status { status, .. } => *status >= 500 || *status == 429 || *status == 408,
        _ => false,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use mclaunch_core::progress::noop_progress;

    #[tokio::test]
    async fn skips_valid_files_and_copies_local_sources() {
        let dir = tempfile::tempdir().unwrap();
        let safe = SafePath::new(dir.path()).unwrap();
        let root = safe.root().to_path_buf();
        let src = root.join("versions/1.0/1.0.jar");
        std::fs::create_dir_all(src.parent().unwrap()).unwrap();
        std::fs::write(&src, b"abc").unwrap();
        let sha1 = hash::sha1_bytes(b"abc");

        let dl = Downloader::new(Http::new(true).unwrap(), safe, 4);
        let tasks = vec![
            DownloadTask::new("https://invalid.example/1.0.jar", &src)
                .sha1(Some(sha1.clone()))
                .size(Some(3)),
            DownloadTask::new(
                "https://invalid.example/1.0.jar",
                root.join("versions/fabric/fabric.jar"),
            )
            .sha1(Some(sha1.clone()))
            .size(Some(3))
            .local_source(Some(src.clone())),
            DownloadTask::new(
                "https://invalid.example/x.jar",
                root.join("libraries/x.jar"),
            ),
            DownloadTask::new("", root.join("libraries/generated.jar")),
        ];
        let s = dl.run(tasks, "test", &noop_progress()).await;
        assert_eq!(s.total, 4);
        assert_eq!(s.skipped, 1);
        assert_eq!(s.copied, 1);
        assert_eq!(s.failed.len(), 2, "offline + missing: {:?}", s.failed);
        assert_eq!(
            std::fs::read(root.join("versions/fabric/fabric.jar")).unwrap(),
            b"abc"
        );
    }

    #[tokio::test]
    async fn refuses_to_download_into_protected_folders() {
        let dir = tempfile::tempdir().unwrap();
        let safe = SafePath::new(dir.path()).unwrap();
        let root = safe.root().to_path_buf();
        let save = root.join("instances/a/saves/w/level.dat");
        std::fs::create_dir_all(save.parent().unwrap()).unwrap();
        std::fs::write(&save, b"precious").unwrap();
        let dl = Downloader::new(Http::new(false).unwrap(), safe, 1);
        let s = dl
            .run(
                vec![DownloadTask::new("https://invalid.example/x", &save).size(Some(1))],
                "t",
                &noop_progress(),
            )
            .await;
        assert_eq!(s.failed.len(), 1);
        assert!(s.failed[0].1.contains("protected"));
        assert_eq!(std::fs::read(&save).unwrap(), b"precious");
    }

    #[test]
    fn part_names() {
        assert_eq!(
            part_path(Path::new("/a/b.jar")),
            PathBuf::from("/a/b.jar.part")
        );
    }
}
