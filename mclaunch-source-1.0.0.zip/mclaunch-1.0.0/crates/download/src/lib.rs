//! Networking and file integrity for mclaunch: an HTTP client that respects
//! offline mode, a parallel resumable downloader that verifies Mojang's SHA-1
//! and size, SHA-256 integrity manifests, and the install / verify / repair
//! workflows for game versions.

pub mod downloader;
pub mod hash;
pub mod http;
pub mod install;
pub mod integrity;

pub use downloader::{DownloadSummary, DownloadTask, Downloader};
pub use http::Http;
pub use install::{InstallReport, Installer, ManifestSource, RepairReport};
pub use integrity::{IntegrityManifest, VerifyReport};

use std::path::PathBuf;

#[derive(Debug, thiserror::Error)]
pub enum DownloadError {
    #[error("offline mode is on (or no network) and {0} is not cached")]
    Offline(String),
    #[error("HTTP {status} for {url}")]
    Status { url: String, status: u16 },
    #[error("network error for {url}: {source}")]
    Network {
        url: String,
        #[source]
        source: reqwest::Error,
    },
    #[error("I/O error on {path}: {source}")]
    Io {
        path: PathBuf,
        #[source]
        source: std::io::Error,
    },
    #[error("{path}: expected hash {expected}, got {actual}")]
    Checksum {
        path: PathBuf,
        expected: String,
        actual: String,
    },
    #[error("{path}: expected {expected} bytes, got {actual}")]
    Size {
        path: PathBuf,
        expected: u64,
        actual: u64,
    },
    #[error("{0} is missing and has no download URL")]
    Missing(PathBuf),
    #[error("invalid JSON from {url}: {source}")]
    Json {
        url: String,
        #[source]
        source: serde_json::Error,
    },
    #[error(transparent)]
    Safety(#[from] mclaunch_safety::SafetyError),
    #[error(transparent)]
    Core(#[from] mclaunch_core::CoreError),
    #[error("{0}")]
    Other(String),
}

pub type Result<T> = std::result::Result<T, DownloadError>;

pub(crate) fn io_err(path: &std::path::Path) -> impl FnOnce(std::io::Error) -> DownloadError + '_ {
    move |source| DownloadError::Io {
        path: path.to_path_buf(),
        source,
    }
}
