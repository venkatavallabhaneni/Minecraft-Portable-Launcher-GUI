//! Streaming SHA-1 / SHA-256 of files.

use std::io::Read;
use std::path::Path;

use sha1::Sha1;
use sha2::{Digest, Sha256, Sha512};

fn hash_file<D: Digest>(path: &Path) -> std::io::Result<String> {
    let mut file = std::fs::File::open(path)?;
    let mut hasher = D::new();
    let mut buf = vec![0u8; 256 * 1024];
    loop {
        let n = file.read(&mut buf)?;
        if n == 0 {
            break;
        }
        hasher.update(&buf[..n]);
    }
    Ok(hex::encode(hasher.finalize()))
}

pub fn sha1_file(path: &Path) -> std::io::Result<String> {
    hash_file::<Sha1>(path)
}

pub fn sha256_file(path: &Path) -> std::io::Result<String> {
    hash_file::<Sha256>(path)
}

pub fn sha512_file(path: &Path) -> std::io::Result<String> {
    hash_file::<Sha512>(path)
}

pub fn sha1_bytes(bytes: &[u8]) -> String {
    hex::encode(Sha1::digest(bytes))
}

pub fn sha256_bytes(bytes: &[u8]) -> String {
    hex::encode(Sha256::digest(bytes))
}

/// Does the file at `path` match the expected size and SHA-1 (when given)?
pub fn file_matches(path: &Path, size: Option<u64>, sha1: Option<&str>) -> bool {
    let Ok(meta) = std::fs::metadata(path) else {
        return false;
    };
    if !meta.is_file() {
        return false;
    }
    if let Some(size) = size {
        if meta.len() != size {
            return false;
        }
    }
    match sha1 {
        Some(expected) => sha1_file(path)
            .map(|h| h.eq_ignore_ascii_case(expected))
            .unwrap_or(false),
        None => true,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn known_hashes() {
        assert_eq!(
            sha1_bytes(b"abc"),
            "a9993e364706816aba3e25717850c26c9cd0d89d"
        );
        assert_eq!(
            sha256_bytes(b"abc"),
            "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"
        );
        let dir = tempfile::tempdir().unwrap();
        let p = dir.path().join("f");
        std::fs::write(&p, b"abc").unwrap();
        assert_eq!(sha256_file(&p).unwrap(), sha256_bytes(b"abc"));
        assert!(file_matches(
            &p,
            Some(3),
            Some("A9993E364706816ABA3E25717850C26C9CD0D89D")
        ));
        assert!(!file_matches(&p, Some(4), None));
        assert!(sha512_file(&p).unwrap().starts_with("ddaf35a193617aba"));
        assert!(!file_matches(&dir.path().join("missing"), None, None));
    }
}
