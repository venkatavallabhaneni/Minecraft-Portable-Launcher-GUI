//! Shared HTTP client. Every network access in the launcher goes through
//! here so that offline mode is enforced in one place.

use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;
use std::time::Duration;

use serde::de::DeserializeOwned;

use crate::{DownloadError, Result};

#[derive(Clone)]
pub struct Http {
    client: reqwest::Client,
    offline: Arc<AtomicBool>,
}

impl std::fmt::Debug for Http {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("Http")
            .field("offline", &self.is_offline())
            .finish()
    }
}

impl Http {
    pub fn new(offline: bool) -> Result<Self> {
        let client = reqwest::Client::builder()
            .user_agent(mclaunch_core::USER_AGENT)
            .connect_timeout(Duration::from_secs(10))
            .read_timeout(Duration::from_secs(30))
            .pool_max_idle_per_host(32)
            .build()
            .map_err(|e| DownloadError::Other(format!("cannot create HTTP client: {e}")))?;
        Ok(Self {
            client,
            offline: Arc::new(AtomicBool::new(offline)),
        })
    }

    pub fn client(&self) -> &reqwest::Client {
        &self.client
    }

    pub fn is_offline(&self) -> bool {
        self.offline.load(Ordering::Relaxed)
    }

    pub fn set_offline(&self, offline: bool) {
        self.offline.store(offline, Ordering::Relaxed);
    }

    fn guard(&self, url: &str) -> Result<()> {
        if self.is_offline() {
            Err(DownloadError::Offline(url.to_string()))
        } else {
            Ok(())
        }
    }

    /// GET returning the response after checking the status.
    pub async fn get(&self, url: &str) -> Result<reqwest::Response> {
        self.guard(url)?;
        let resp = self
            .client
            .get(url)
            .send()
            .await
            .map_err(|source| DownloadError::Network {
                url: url.to_string(),
                source,
            })?;
        let status = resp.status();
        if !status.is_success() {
            return Err(DownloadError::Status {
                url: url.to_string(),
                status: status.as_u16(),
            });
        }
        Ok(resp)
    }

    pub async fn get_bytes(&self, url: &str) -> Result<Vec<u8>> {
        let resp = self.get(url).await?;
        resp.bytes()
            .await
            .map(|b| b.to_vec())
            .map_err(|source| DownloadError::Network {
                url: url.to_string(),
                source,
            })
    }

    pub async fn get_text(&self, url: &str) -> Result<String> {
        let bytes = self.get_bytes(url).await?;
        Ok(String::from_utf8_lossy(&bytes).into_owned())
    }

    pub async fn get_json<T: DeserializeOwned>(&self, url: &str) -> Result<T> {
        let bytes = self.get_bytes(url).await?;
        serde_json::from_slice(&bytes).map_err(|source| DownloadError::Json {
            url: url.to_string(),
            source,
        })
    }

    /// Quick reachability probe used to decide whether to try the network.
    pub async fn probe(&self, url: &str) -> bool {
        if self.is_offline() {
            return false;
        }
        matches!(
            tokio::time::timeout(Duration::from_secs(5), self.client.head(url).send()).await,
            Ok(Ok(_))
        )
    }
}
