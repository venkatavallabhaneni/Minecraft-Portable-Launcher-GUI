//! The launcher's own SHA-256 manifests (`integrity/<id>.sha256`), in a
//! `sha256sum`-compatible format with `/`-separated paths relative to the
//! launcher root.

use std::collections::BTreeMap;
use std::path::PathBuf;

use futures::StreamExt;
use mclaunch_core::{LauncherPaths, Progress, ProgressFn};
use mclaunch_safety::SafePath;

use crate::hash;
use crate::{DownloadError, Result};

#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct IntegrityManifest {
    pub version: String,
    /// relative path -> lowercase hex SHA-256
    pub entries: BTreeMap<String, String>,
}

#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct VerifyReport {
    pub version: String,
    pub total: usize,
    pub ok: usize,
    pub missing: Vec<String>,
    pub corrupt: Vec<String>,
}

impl VerifyReport {
    pub fn is_ok(&self) -> bool {
        self.missing.is_empty() && self.corrupt.is_empty()
    }

    pub fn bad(&self) -> impl Iterator<Item = &String> {
        self.missing.iter().chain(self.corrupt.iter())
    }

    pub fn summary(&self) -> String {
        if self.is_ok() {
            format!("✓ {} files verified (SHA-256)", self.ok)
        } else {
            format!(
                "{} OK, {} missing, {} corrupt (of {})",
                self.ok,
                self.missing.len(),
                self.corrupt.len(),
                self.total
            )
        }
    }
}

fn threads() -> usize {
    std::thread::available_parallelism()
        .map(|n| n.get())
        .unwrap_or(4)
        .clamp(2, 16)
}

impl IntegrityManifest {
    pub fn to_text(&self) -> String {
        let mut s = String::new();
        s.push_str("# mclaunch integrity manifest (SHA-256, sha256sum format)\n");
        s.push_str(&format!("# version: {}\n", self.version));
        s.push_str(&format!("# files: {}\n", self.entries.len()));
        for (path, sha) in &self.entries {
            s.push_str(sha);
            s.push_str("  ");
            s.push_str(path);
            s.push('\n');
        }
        s
    }

    pub fn parse(version: &str, text: &str) -> Result<Self> {
        let mut entries = BTreeMap::new();
        for (n, line) in text.lines().enumerate() {
            let line = line.trim_end();
            if line.is_empty() || line.starts_with('#') {
                continue;
            }
            let (sha, path) = line.split_once("  ").ok_or_else(|| {
                DownloadError::Other(format!("integrity manifest line {}: malformed", n + 1))
            })?;
            if sha.len() != 64 || !sha.chars().all(|c| c.is_ascii_hexdigit()) {
                return Err(DownloadError::Other(format!(
                    "integrity manifest line {}: bad hash",
                    n + 1
                )));
            }
            let path = path.strip_prefix('*').unwrap_or(path);
            if path.split('/').any(|p| p == "..") || path.starts_with('/') {
                return Err(DownloadError::Other(format!(
                    "integrity manifest line {}: unsafe path",
                    n + 1
                )));
            }
            entries.insert(path.to_string(), sha.to_ascii_lowercase());
        }
        Ok(Self {
            version: version.to_string(),
            entries,
        })
    }

    pub fn load(paths: &LauncherPaths, version: &str) -> Result<Option<Self>> {
        let path = paths.integrity_file(version);
        match std::fs::read_to_string(&path) {
            Ok(text) => Self::parse(version, &text).map(Some),
            Err(e) if e.kind() == std::io::ErrorKind::NotFound => Ok(None),
            Err(e) => Err(crate::io_err(&path)(e)),
        }
    }

    pub fn save(&self, paths: &LauncherPaths, safe: &SafePath) -> Result<()> {
        safe.write(
            &paths.integrity_file(&self.version),
            self.to_text().as_bytes(),
        )?;
        Ok(())
    }

    /// Hash `files` (absolute paths under the root) in parallel.
    pub async fn build(
        paths: &LauncherPaths,
        version: &str,
        files: Vec<PathBuf>,
        progress: &ProgressFn,
    ) -> Result<Self> {
        let total = files.len() as u64;
        let mut done = 0u64;
        let mut entries = BTreeMap::new();
        let mut stream = futures::stream::iter(files.into_iter().map(|file| {
            let rel = paths.relative(&file);
            async move {
                let f = file.clone();
                let res = tokio::task::spawn_blocking(move || hash::sha256_file(&f)).await;
                (file, rel, res)
            }
        }))
        .buffer_unordered(threads());
        while let Some((file, rel, res)) = stream.next().await {
            let rel = rel.ok_or_else(|| {
                DownloadError::Other(format!("{} is outside the launcher folder", file.display()))
            })?;
            let sha = res
                .map_err(|e| DownloadError::Other(e.to_string()))?
                .map_err(crate::io_err(&file))?;
            entries.insert(rel, sha);
            done += 1;
            if done.is_multiple_of(64) || done == total {
                progress(Progress {
                    stage: "Recording SHA-256 manifest".into(),
                    done,
                    total,
                    ..Default::default()
                });
            }
        }
        Ok(Self {
            version: version.to_string(),
            entries,
        })
    }

    /// Re-hash every file and compare with the stored SHA-256.
    pub async fn verify(&self, paths: &LauncherPaths, progress: &ProgressFn) -> VerifyReport {
        let total = self.entries.len();
        let mut report = VerifyReport {
            version: self.version.clone(),
            total,
            ..Default::default()
        };
        let mut done = 0u64;
        let items: Vec<(PathBuf, String, String)> = self
            .entries
            .iter()
            .map(|(rel, sha)| (paths.from_relative(rel), rel.clone(), sha.clone()))
            .collect();
        let mut stream =
            futures::stream::iter(items.into_iter().map(|(path, rel, expected)| async move {
                let res = tokio::task::spawn_blocking(move || {
                    if !path.is_file() {
                        return Status::Missing;
                    }
                    match hash::sha256_file(&path) {
                        Ok(h) if h == expected => Status::Ok,
                        Ok(_) => Status::Corrupt,
                        Err(_) => Status::Missing,
                    }
                })
                .await
                .unwrap_or(Status::Missing);
                (rel, res)
            }))
            .buffer_unordered(threads());
        while let Some((rel, status)) = stream.next().await {
            match status {
                Status::Ok => report.ok += 1,
                Status::Missing => report.missing.push(rel),
                Status::Corrupt => report.corrupt.push(rel),
            }
            done += 1;
            if done.is_multiple_of(64) || done == total as u64 {
                progress(Progress {
                    stage: format!("Verifying {} (SHA-256)", self.version),
                    done,
                    total: total as u64,
                    ..Default::default()
                });
            }
        }
        report.missing.sort();
        report.corrupt.sort();
        report
    }
}

enum Status {
    Ok,
    Missing,
    Corrupt,
}

#[cfg(test)]
mod tests {
    use super::*;
    use mclaunch_core::progress::noop_progress;

    #[test]
    fn text_roundtrip_and_validation() {
        let mut m = IntegrityManifest {
            version: "1.8.9".into(),
            ..Default::default()
        };
        m.entries.insert(
            "versions/1.8.9/1.8.9.jar".into(),
            "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad".into(),
        );
        let text = m.to_text();
        assert!(text.contains(
            "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad  versions/1.8.9/1.8.9.jar"
        ));
        assert_eq!(IntegrityManifest::parse("1.8.9", &text).unwrap(), m);
        assert!(IntegrityManifest::parse("x", "zz  a").is_err());
        assert!(IntegrityManifest::parse(
            "x",
            "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad  ../../etc/passwd"
        )
        .is_err());
    }

    #[tokio::test]
    async fn build_and_verify_detects_missing_and_corrupt() {
        let dir = tempfile::tempdir().unwrap();
        let safe = SafePath::new(dir.path()).unwrap();
        let paths = LauncherPaths::new(safe.root());
        let files: Vec<PathBuf> = ["libraries/a.jar", "libraries/b.jar", "versions/x/x.jar"]
            .iter()
            .map(|r| {
                let p = paths.from_relative(r);
                std::fs::create_dir_all(p.parent().unwrap()).unwrap();
                std::fs::write(&p, r.as_bytes()).unwrap();
                p
            })
            .collect();
        let m = IntegrityManifest::build(&paths, "x", files.clone(), &noop_progress())
            .await
            .unwrap();
        m.save(&paths, &safe).unwrap();
        let loaded = IntegrityManifest::load(&paths, "x").unwrap().unwrap();
        assert_eq!(loaded, m);
        let r = loaded.verify(&paths, &noop_progress()).await;
        assert!(r.is_ok());
        assert_eq!(r.ok, 3);

        std::fs::write(&files[0], b"tampered").unwrap();
        std::fs::remove_file(&files[2]).unwrap();
        let r = loaded.verify(&paths, &noop_progress()).await;
        assert!(!r.is_ok());
        assert_eq!(r.corrupt, vec!["libraries/a.jar"]);
        assert_eq!(r.missing, vec!["versions/x/x.jar"]);
        assert_eq!(r.ok, 1);
        assert!(IntegrityManifest::load(&paths, "nope").unwrap().is_none());
    }
}
