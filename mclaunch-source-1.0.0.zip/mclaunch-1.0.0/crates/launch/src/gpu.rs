//! Picks GPU / OpenGL information out of game logs (OptiFine, Sodium, Iris
//! and some vanilla versions print it) for the shader pre-flight check.

use std::sync::OnceLock;

use regex::Regex;

#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct GpuInfo {
    pub renderer: Option<String>,
    /// `major.minor`
    pub gl_version: Option<String>,
}

impl GpuInfo {
    /// `Some(false)` when the reported OpenGL is older than 3.2.
    pub fn gl_ok(&self) -> Option<bool> {
        let v = self.gl_version.as_deref()?;
        let (maj, min) = v.split_once('.')?;
        let (maj, min): (u32, u32) = (maj.parse().ok()?, min.parse().ok()?);
        Some((maj, min) >= (3, 2))
    }

    pub fn summary(&self) -> String {
        match (&self.renderer, &self.gl_version) {
            (Some(r), Some(v)) => format!("{r} — OpenGL {v}"),
            (Some(r), None) => r.clone(),
            (None, Some(v)) => format!("OpenGL {v}"),
            (None, None) => "unknown".into(),
        }
    }
}

struct Patterns {
    version: Vec<Regex>,
    renderer: Vec<Regex>,
    combined: Regex,
}

fn patterns() -> &'static Patterns {
    static P: OnceLock<Patterns> = OnceLock::new();
    P.get_or_init(|| Patterns {
        version: [
            r"(?i)\bGL version[:=]?\s+([0-9]+\.[0-9]+)",
            r"(?i)OpenGL version[:=]?\s+([0-9]+\.[0-9]+)",
            r"(?i)OpenGL Version: ([0-9]+\.[0-9]+)",
        ]
        .iter()
        .map(|p| Regex::new(p).expect("valid regex"))
        .collect(),
        renderer: [
            r"(?i)OpenGL Renderer[:=]\s*(.+)$",
            r"(?i)GL Renderer[:=]\s*(.+)$",
            r"(?i)Graphics (?:adapter|card)[:=]\s*(.+)$",
        ]
        .iter()
        .map(|p| Regex::new(p).expect("valid regex"))
        .collect(),
        // OptiFine: "OpenGL: NVIDIA GeForce GTX 1080/PCIe/SSE2, version 4.6.0 NVIDIA 535.54, NVIDIA Corporation"
        combined: Regex::new(r"OpenGL: (.+?), version ([0-9]+\.[0-9]+)").expect("valid regex"),
    })
}

#[derive(Debug, Default)]
pub struct GpuSniffer {
    info: GpuInfo,
}

impl GpuSniffer {
    pub fn feed(&mut self, line: &str) {
        let p = patterns();
        if let Some(c) = p.combined.captures(line) {
            self.info
                .renderer
                .get_or_insert_with(|| c[1].trim().to_string());
            self.info.gl_version.get_or_insert_with(|| c[2].to_string());
            return;
        }
        if self.info.gl_version.is_none() {
            if let Some(c) = p.version.iter().find_map(|r| r.captures(line)) {
                self.info.gl_version = Some(c[1].to_string());
            }
        }
        if self.info.renderer.is_none() {
            if let Some(c) = p.renderer.iter().find_map(|r| r.captures(line)) {
                self.info.renderer = Some(c[1].trim().to_string());
            }
        }
    }

    pub fn info(&self) -> Option<GpuInfo> {
        (self.info != GpuInfo::default()).then(|| self.info.clone())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn optifine_line() {
        let mut s = GpuSniffer::default();
        s.feed("[OptiFine] OpenGL: NVIDIA GeForce GTX 1080/PCIe/SSE2, version 4.6.0 NVIDIA 535.54, NVIDIA Corporation");
        let i = s.info().unwrap();
        assert_eq!(i.gl_version.as_deref(), Some("4.6"));
        assert_eq!(i.gl_ok(), Some(true));
        assert!(i.renderer.unwrap().contains("GTX 1080"));
    }

    #[test]
    fn old_gl_is_flagged() {
        let mut s = GpuSniffer::default();
        s.feed("OpenGL Renderer: Intel(R) GMA 950");
        s.feed("OpenGL Version: 2.1.0 - Build 8.15");
        let i = s.info().unwrap();
        assert_eq!(i.gl_ok(), Some(false));
        assert_eq!(i.summary(), "Intel(R) GMA 950 — OpenGL 2.1");
        assert!(GpuSniffer::default().info().is_none());
    }
}
