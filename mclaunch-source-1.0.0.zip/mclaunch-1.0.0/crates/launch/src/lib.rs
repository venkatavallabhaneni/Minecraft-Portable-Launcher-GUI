//! Turning an installed version + instance into a running game: classpath,
//! natives extraction, legacy asset layouts, old alpha/beta offline fixes,
//! argument building, process spawning and log streaming.

pub mod gpu;
pub mod log;

pub use log::{Level, LogLine, LogParser};

use std::path::{Path, PathBuf};
use std::process::Stdio;
use std::sync::Arc;
use std::time::{Instant, SystemTime};

use mclaunch_core::args::{self, ArgOptions, QuickJoin, VarInputs};
use mclaunch_core::assets::AssetIndex;
use mclaunch_core::instance::InstanceConfig;
use mclaunch_core::version::{ResolvedVersion, VersionJson};
use mclaunch_core::{javareq, offline, platform, LauncherPaths, RuleContext};
use mclaunch_java::{JavaPick, JavaRuntime};
use mclaunch_safety::SafePath;
use tokio::io::{AsyncBufReadExt, BufReader};

#[derive(Debug, thiserror::Error)]
pub enum LaunchError {
    #[error("{0}")]
    NoJava(String),
    #[error("required file missing: {0} — press Repair")]
    Missing(PathBuf),
    #[error("I/O error on {path}: {source}")]
    Io {
        path: PathBuf,
        #[source]
        source: std::io::Error,
    },
    #[error("cannot read natives jar {path}: {message}")]
    Natives { path: PathBuf, message: String },
    #[error("could not start Java ({java}): {source}")]
    Spawn {
        java: PathBuf,
        #[source]
        source: std::io::Error,
    },
    #[error(transparent)]
    Safety(#[from] mclaunch_safety::SafetyError),
    #[error(transparent)]
    Core(#[from] mclaunch_core::CoreError),
    #[error(transparent)]
    Download(#[from] mclaunch_download::DownloadError),
}

pub type Result<T> = std::result::Result<T, LaunchError>;

fn io_err(path: &Path) -> impl FnOnce(std::io::Error) -> LaunchError + '_ {
    move |source| LaunchError::Io {
        path: path.to_path_buf(),
        source,
    }
}

/// Everything needed to start the game process.
#[derive(Debug, Clone)]
pub struct LaunchPlan {
    pub version_id: String,
    pub java: PathBuf,
    pub args: Vec<String>,
    pub game_dir: PathBuf,
    pub natives_dir: PathBuf,
    pub main_class: String,
    pub required_java: u32,
    /// Extra environment variables for the game process.
    pub env: Vec<(String, String)>,
    /// Notes for the user (shown in the log before launch).
    pub notes: Vec<String>,
}

impl LaunchPlan {
    /// The full command line, for the log.
    pub fn command_line(&self) -> String {
        let mut s = shell_quote(&self.java.to_string_lossy());
        for a in &self.args {
            s.push(' ');
            s.push_str(&shell_quote(a));
        }
        s
    }
}

fn shell_quote(s: &str) -> String {
    if !s.is_empty() && !s.contains([' ', '"', '\'', '$', ';']) {
        s.to_string()
    } else {
        format!("\"{}\"", s.replace('"', "\\\""))
    }
}

/// What the user asked for.
#[derive(Debug, Clone)]
pub struct LaunchRequest<'a> {
    pub instance: &'a InstanceConfig,
    pub username: &'a str,
    pub quick_join: Option<QuickJoin>,
    pub java: PathBuf,
}

/// Choose the Java binary for an instance: per-instance override (a path or
/// a major version number) or the best detected runtime.
pub fn choose_java(
    runtimes: &[JavaRuntime],
    instance: &InstanceConfig,
    version: &VersionJson,
) -> Result<(PathBuf, Option<String>)> {
    let required = javareq::required_java(version);
    let mc = version.base_version();
    if let Some(ov) = instance
        .java_override
        .as_deref()
        .map(str::trim)
        .filter(|s| !s.is_empty())
    {
        if let Ok(major) = ov.parse::<u32>() {
            return match runtimes.iter().find(|r| r.info.major == major) {
                Some(r) => Ok((r.java_bin.clone(), (major != required).then(|| {
                    format!("Using Java {major} (override); Minecraft {mc} normally uses Java {required}")
                }))),
                None => Err(LaunchError::NoJava(format!(
                    "This instance is set to Java {major}, but no Java {major} runtime was found — drop a JDK {major} zip into java/"
                ))),
            };
        }
        let path = PathBuf::from(ov);
        if path.is_file() {
            return Ok((path, Some("Using a custom Java path (override)".into())));
        }
        return Err(LaunchError::NoJava(format!(
            "Java override not found: {ov}"
        )));
    }
    match mclaunch_java::pick_runtime(runtimes, required, mc) {
        JavaPick::Exact(r) => Ok((r.java_bin.clone(), None)),
        JavaPick::Compatible(r) => Ok((
            r.java_bin.clone(),
            Some(format!(
                "Minecraft {mc} asks for Java {required}; using Java {} instead",
                r.info.major
            )),
        )),
        JavaPick::Missing(msg) => Err(LaunchError::NoJava(msg)),
    }
}

/// Extract old-style `natives-*` classifier jars into `dir`.
pub fn extract_natives(paths: &LauncherPaths, version: &VersionJson, dir: &Path) -> Result<usize> {
    let ctx = RuleContext::current();
    let mut count = 0;
    for lib in version.effective_libraries(&ctx) {
        let Some(native) = lib.native_artifact(&ctx) else {
            continue;
        };
        let jar = paths.libraries_dir().join(&native.path);
        if !jar.is_file() {
            return Err(LaunchError::Missing(jar));
        }
        let excludes = lib.extract_excludes();
        let bad = |message: String| LaunchError::Natives {
            path: jar.clone(),
            message,
        };
        let file = std::fs::File::open(&jar).map_err(io_err(&jar))?;
        let mut zip =
            zip::ZipArchive::new(std::io::BufReader::new(file)).map_err(|e| bad(e.to_string()))?;
        for i in 0..zip.len() {
            let mut entry = zip.by_index(i).map_err(|e| bad(e.to_string()))?;
            if entry.is_dir() {
                continue;
            }
            let name = entry.name().to_string();
            if excludes.iter().any(|ex| name.starts_with(ex.as_str())) {
                continue;
            }
            let Some(rel) = entry.enclosed_name() else {
                continue;
            };
            let out = dir.join(rel);
            if let Some(p) = out.parent() {
                std::fs::create_dir_all(p).map_err(io_err(p))?;
            }
            let mut f = std::fs::File::create(&out).map_err(io_err(&out))?;
            std::io::copy(&mut entry, &mut f).map_err(io_err(&out))?;
            count += 1;
        }
    }
    Ok(count)
}

/// Classpath: every applicable library artifact, then the client jar.
pub fn build_classpath(paths: &LauncherPaths, version: &VersionJson) -> Result<Vec<PathBuf>> {
    let ctx = RuleContext::current();
    let mut cp: Vec<PathBuf> = Vec::new();
    for lib in version.effective_libraries(&ctx) {
        if let Some(a) = lib.artifact() {
            let p = paths.libraries_dir().join(&a.path);
            if !cp.contains(&p) {
                cp.push(p);
            }
        }
    }
    let jar = paths.version_jar(version.client_jar_id());
    if !cp.contains(&jar) {
        cp.push(jar);
    }
    for p in &cp {
        if !p.is_file() {
            return Err(LaunchError::Missing(p.clone()));
        }
    }
    Ok(cp)
}

/// Pre-1.6 versions and old alpha/beta builds need help to run offline.
pub fn is_legacy_offline_target(version: &VersionJson, index: Option<&AssetIndex>) -> bool {
    version.kind.as_ref().is_some_and(|k| k.is_legacy())
        || index.is_some_and(|i| i.map_to_resources)
        || version.main_class.as_deref() == Some("com.mojang.rubydung.RubyDung")
}

/// JVM flags that make ancient versions boot without network: skin and
/// sound downloads go through an unreachable local proxy so they fail
/// instantly instead of hanging on dead Amazon S3 URLs, the applet wrapper
/// gets its target directory, and Java 7+'s TimSort is relaxed.
pub fn legacy_offline_jvm_args(game_dir: &Path) -> Vec<String> {
    vec![
        "-Dhttp.proxyHost=127.0.0.1".into(),
        "-Dhttp.proxyPort=1".into(),
        format!("-Dminecraft.applet.TargetDirectory={}", game_dir.display()),
        "-Djava.util.Arrays.useLegacyMergeSort=true".into(),
    ]
}

/// Does this version use LWJGL 2 (`org.lwjgl.lwjgl:lwjgl:2.x`)?
pub fn uses_lwjgl2(version: &VersionJson) -> bool {
    version
        .libraries
        .iter()
        .any(|l| l.name.starts_with("org.lwjgl.lwjgl:lwjgl:2."))
}

fn find_in_path(program: &str) -> Option<PathBuf> {
    let path = std::env::var_os("PATH")?;
    std::env::split_paths(&path)
        .map(|d| d.join(program))
        .find(|p| p.is_file())
}

const XRANDR_SHIM: &str = "#!/bin/sh
# mclaunch: minimal stand-in for `xrandr -q`. LWJGL 2 parses this program's
# output to list display modes and crashes without it. Install your distro's
# x11-xserver-utils package to use the real one instead.
cat <<'MODES'
Screen 0: minimum 320 x 200, current 1920 x 1080, maximum 16384 x 16384
mclaunch-0 connected primary 1920x1080+0+0 (normal left inverted right x axis y axis) 0mm x 0mm
   1920x1080     60.00*+
   1600x900      60.00
   1280x720      60.00
   854x480       60.00
MODES
";

/// LWJGL 2 on Linux needs the `xrandr` program. When it is missing, put a
/// tiny shim on the game's PATH. Returns the shim folder if one is used.
pub fn xrandr_shim(
    paths: &LauncherPaths,
    safe: &SafePath,
    version: &VersionJson,
) -> Result<Option<PathBuf>> {
    if !cfg!(target_os = "linux") || !uses_lwjgl2(version) || find_in_path("xrandr").is_some() {
        return Ok(None);
    }
    let dir = paths.cache_dir().join("shims");
    let script = dir.join("xrandr");
    if std::fs::read_to_string(&script).ok().as_deref() != Some(XRANDR_SHIM) {
        safe.write(&script, XRANDR_SHIM.as_bytes())?;
    }
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        std::fs::set_permissions(&script, std::fs::Permissions::from_mode(0o755))
            .map_err(io_err(&script))?;
    }
    Ok(Some(dir))
}

fn unique_suffix() -> String {
    let nanos = SystemTime::now()
        .duration_since(SystemTime::UNIX_EPOCH)
        .map(|d| d.as_nanos())
        .unwrap_or(0);
    format!("{}-{:x}", std::process::id(), nanos & 0xffff_ffff)
}

/// Build the launch plan. Files must already be installed and verified.
pub fn prepare(
    paths: &LauncherPaths,
    safe: &SafePath,
    resolved: &ResolvedVersion,
    req: &LaunchRequest<'_>,
) -> Result<LaunchPlan> {
    let v = &resolved.merged;
    let inst = req.instance;
    let game_dir = paths.instance_dir(&inst.name);
    safe.create_dir_all(&game_dir)?;

    // Per-launch natives folder.
    let natives_dir = paths
        .natives_root()
        .join(format!("{}-{}", sanitize(&v.id), unique_suffix()));
    safe.create_dir_all(&natives_dir)?;
    let extracted = extract_natives(paths, v, &natives_dir)?;
    tracing::debug!(count = extracted, dir = %natives_dir.display(), "natives extracted");

    // Assets.
    let index_id = v.asset_index_id();
    let index: Option<AssetIndex> = mclaunch_core::read_json(&paths.asset_index(&index_id)).ok();
    let game_assets = match &index {
        Some(idx) if idx.map_to_resources => {
            let target = game_dir.join("resources");
            mclaunch_download::install::copy_assets_to(paths, safe, idx, &target)?;
            target
        }
        Some(idx) if idx.is_virtual => {
            let target = paths.virtual_assets_dir(&index_id);
            mclaunch_download::install::copy_assets_to(paths, safe, idx, &target)?;
            target
        }
        _ => paths.assets_dir(),
    };

    let classpath = build_classpath(paths, v)?;
    let cp_string = classpath
        .iter()
        .map(|p| p.to_string_lossy().into_owned())
        .collect::<Vec<_>>()
        .join(platform::classpath_separator());

    let uuid = offline::offline_uuid(req.username);
    let s = |p: &Path| p.to_string_lossy().into_owned();
    let (game_dir_s, assets_root_s, game_assets_s, natives_s, libs_s) = (
        s(&game_dir),
        s(&paths.assets_dir()),
        s(&game_assets),
        s(&natives_dir),
        s(&paths.libraries_dir()),
    );
    let version_type = v
        .kind
        .as_ref()
        .map(|k| k.as_str().to_string())
        .unwrap_or_else(|| "release".into());
    let vars = args::standard_vars(&VarInputs {
        username: req.username,
        uuid: &uuid,
        access_token: offline::OFFLINE_ACCESS_TOKEN,
        user_type: offline::user_type_for(v.kind.as_ref()),
        version_name: &v.id,
        version_type: &version_type,
        game_dir: &game_dir_s,
        assets_root: &assets_root_s,
        assets_index_name: &index_id,
        game_assets: &game_assets_s,
        natives_dir: &natives_s,
        library_dir: &libs_s,
        classpath: &cp_string,
    });

    let mut extra_jvm = vec![
        format!("-Xmx{}M", inst.max_memory_mb.max(256)),
        format!(
            "-Xms{}M",
            inst.min_memory_mb.clamp(128, inst.max_memory_mb.max(256))
        ),
        "-Dlog4j2.formatMsgNoLookups=true".to_string(),
    ];
    if let Some(log) = v.client_logging() {
        let file = paths.log_configs_dir().join(&log.file.id);
        if file.is_file() {
            extra_jvm.push(log.argument.replace("${path}", &file.to_string_lossy()));
        }
    }
    if is_legacy_offline_target(v, index.as_ref()) {
        extra_jvm.extend(legacy_offline_jvm_args(&game_dir));
    }
    if v.main_class.as_deref() == Some("net.minecraft.launchwrapper.Launch")
        && v.libraries
            .iter()
            .any(|l| l.name.starts_with("net.minecraftforge:"))
    {
        extra_jvm.push("-Dfml.ignoreInvalidMinecraftCertificates=true".into());
        extra_jvm.push("-Dfml.ignorePatchDiscrepancies=true".into());
    }
    extra_jvm.extend(args::split_user_args(&inst.jvm_args));

    let opts = ArgOptions {
        resolution: inst.resolution,
        quick_join: req.quick_join.clone(),
        extra_jvm,
        extra_game: args::split_user_args(&inst.game_args),
    };
    let built = args::build_args(v, &vars, &opts);

    let mut env = Vec::new();
    let mut notes = Vec::new();
    if let Some(shim) = xrandr_shim(paths, safe, v)? {
        let mut path = std::ffi::OsString::from(shim.as_os_str());
        if let Some(old) = std::env::var_os("PATH") {
            path.push(":");
            path.push(old);
        }
        env.push(("PATH".to_string(), path.to_string_lossy().into_owned()));
        notes.push(
            "LWJGL 2 needs `xrandr`, which is not installed; using a built-in stand-in \
             (install x11-xserver-utils for the real one)"
                .to_string(),
        );
    }

    Ok(LaunchPlan {
        env,
        notes,
        version_id: v.id.clone(),
        java: req.java.clone(),
        main_class: built.main_class.clone(),
        args: built.command_line(),
        game_dir,
        natives_dir,
        required_java: javareq::required_java(v),
    })
}

fn sanitize(id: &str) -> String {
    id.chars()
        .map(|c| {
            if c.is_ascii_alphanumeric() || c == '.' || c == '-' {
                c
            } else {
                '_'
            }
        })
        .collect()
}

/// Events emitted while the game runs.
#[derive(Debug, Clone)]
pub enum GameEvent {
    Started { pid: Option<u32> },
    Log(LogLine),
}

#[derive(Debug, Clone)]
pub struct ExitInfo {
    pub code: Option<i32>,
    pub success: bool,
    pub killed: bool,
    pub duration_secs: u64,
    pub crash_report: Option<PathBuf>,
    pub gpu: Option<gpu::GpuInfo>,
}

pub type EventSink = Arc<dyn Fn(GameEvent) + Send + Sync>;

/// Spawn the game and stream its output until it exits (or `kill` fires).
/// The per-launch natives folder is removed afterwards.
pub async fn run(
    plan: LaunchPlan,
    safe: SafePath,
    sink: EventSink,
    kill: Arc<tokio::sync::Notify>,
) -> Result<ExitInfo> {
    let started = Instant::now();
    let start_time = SystemTime::now();
    sink(GameEvent::Log(LogLine::launcher(format!(
        "Launching {} with {}",
        plan.version_id,
        plan.java.display()
    ))));
    for note in &plan.notes {
        sink(GameEvent::Log(LogLine::launcher(note.clone())));
    }
    tracing::info!(cmd = %plan.command_line(), "launching");

    let mut cmd = tokio::process::Command::new(&plan.java);
    cmd.args(&plan.args)
        .envs(plan.env.iter().map(|(k, v)| (k.as_str(), v.as_str())))
        .current_dir(&plan.game_dir)
        .stdin(Stdio::null())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped());
    #[cfg(windows)]
    cmd.creation_flags(0x0800_0000); // CREATE_NO_WINDOW
    let mut child = match cmd.spawn() {
        Ok(c) => c,
        Err(source) => {
            let _ = safe.remove_dir_all(&plan.natives_dir);
            return Err(LaunchError::Spawn {
                java: plan.java.clone(),
                source,
            });
        }
    };
    sink(GameEvent::Started { pid: child.id() });

    let gpu = Arc::new(std::sync::Mutex::new(gpu::GpuSniffer::default()));
    let mut readers = Vec::new();
    for (stream, is_err) in [
        (
            child
                .stdout
                .take()
                .map(|s| Box::new(s) as Box<dyn tokio::io::AsyncRead + Unpin + Send>),
            false,
        ),
        (
            child
                .stderr
                .take()
                .map(|s| Box::new(s) as Box<dyn tokio::io::AsyncRead + Unpin + Send>),
            true,
        ),
    ] {
        let Some(stream) = stream else { continue };
        let sink = sink.clone();
        let gpu = gpu.clone();
        readers.push(tokio::spawn(async move {
            let mut reader = BufReader::new(stream);
            let mut parser = LogParser::new();
            let mut buf = Vec::new();
            loop {
                buf.clear();
                match reader.read_until(b'\n', &mut buf).await {
                    Ok(0) | Err(_) => break,
                    Ok(_) => {
                        let raw = String::from_utf8_lossy(&buf);
                        for line in parser.push(&raw, is_err) {
                            if let Ok(mut g) = gpu.lock() {
                                g.feed(&line.text);
                            }
                            sink(GameEvent::Log(line));
                        }
                    }
                }
            }
            for line in parser.finish() {
                sink(GameEvent::Log(line));
            }
        }));
    }

    let (status, killed) = tokio::select! {
        s = child.wait() => (s, false),
        _ = kill.notified() => {
            let _ = child.start_kill();
            (child.wait().await, true)
        }
    };
    for r in readers {
        let _ = r.await;
    }
    let code = status.as_ref().ok().and_then(|s| s.code());
    let success = status.as_ref().map(|s| s.success()).unwrap_or(false);
    if let Err(e) = safe.remove_dir_all(&plan.natives_dir) {
        tracing::debug!(error = %e, "could not remove natives dir");
    }
    let crash_report = if success || killed {
        None
    } else {
        find_crash_report(&plan.game_dir, start_time)
    };
    let duration_secs = started.elapsed().as_secs();
    sink(GameEvent::Log(LogLine::launcher(match (killed, code) {
        (true, _) => "Game was stopped by the launcher".to_string(),
        (_, Some(c)) => format!("Game exited with code {c} after {duration_secs}s"),
        (_, None) => "Game exited".to_string(),
    })));
    let gpu = gpu.lock().ok().and_then(|g| g.info());
    Ok(ExitInfo {
        code,
        success,
        killed,
        duration_secs,
        crash_report,
        gpu,
    })
}

/// Newest crash report (or JVM `hs_err` log) written since `since`.
pub fn find_crash_report(game_dir: &Path, since: SystemTime) -> Option<PathBuf> {
    let mut candidates = Vec::new();
    if let Ok(rd) = std::fs::read_dir(game_dir.join("crash-reports")) {
        candidates.extend(rd.flatten().map(|e| e.path()));
    }
    if let Ok(rd) = std::fs::read_dir(game_dir) {
        candidates.extend(rd.flatten().map(|e| e.path()).filter(|p| {
            p.file_name()
                .is_some_and(|n| n.to_string_lossy().starts_with("hs_err_pid"))
        }));
    }
    candidates
        .into_iter()
        .filter_map(|p| {
            let m = std::fs::metadata(&p).ok()?.modified().ok()?;
            (m >= since).then_some((m, p))
        })
        .max_by_key(|(m, _)| *m)
        .map(|(_, p)| p)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn quoting() {
        assert_eq!(shell_quote("-Xmx2G"), "-Xmx2G");
        assert_eq!(shell_quote("a b"), "\"a b\"");
        assert_eq!(shell_quote(""), "\"\"");
    }

    #[test]
    fn legacy_detection() {
        let v: VersionJson = serde_json_from(r#"{"id": "b1.7.3", "type": "old_beta"}"#);
        assert!(is_legacy_offline_target(&v, None));
        let v: VersionJson = serde_json_from(r#"{"id": "1.20.1", "type": "release"}"#);
        assert!(!is_legacy_offline_target(&v, None));
        let args = legacy_offline_jvm_args(Path::new("/g"));
        assert!(args.contains(&"-Dhttp.proxyHost=127.0.0.1".to_string()));
    }

    fn serde_json_from(s: &str) -> VersionJson {
        VersionJson::parse(s.as_bytes()).unwrap()
    }

    #[test]
    fn crash_report_lookup() {
        let dir = tempfile::tempdir().unwrap();
        let before = SystemTime::now() - std::time::Duration::from_secs(5);
        assert!(find_crash_report(dir.path(), before).is_none());
        std::fs::create_dir_all(dir.path().join("crash-reports")).unwrap();
        let f = dir
            .path()
            .join("crash-reports/crash-2026-10-13_10.00.00-client.txt");
        std::fs::write(&f, "---- Minecraft Crash Report ----").unwrap();
        assert_eq!(find_crash_report(dir.path(), before), Some(f));
    }

    #[test]
    fn java_override() {
        let rt = |major: u32| JavaRuntime {
            source: mclaunch_java::RuntimeSource::System {
                origin: "PATH".into(),
            },
            java_bin: PathBuf::from(format!("/j{major}/bin/java")),
            info: mclaunch_java::JavaInfo {
                version: major.to_string(),
                major,
                vendor: "t".into(),
                arch: String::new(),
                java_home: PathBuf::new(),
            },
        };
        let runtimes = vec![rt(8), rt(21)];
        let v: VersionJson =
            serde_json_from(r#"{"id": "1.21", "javaVersion": {"majorVersion": 21}}"#);
        let mut inst = InstanceConfig::new("x", "1.21", 2048);
        assert_eq!(
            choose_java(&runtimes, &inst, &v).unwrap().0,
            PathBuf::from("/j21/bin/java")
        );
        inst.java_override = Some("8".into());
        let (bin, warn) = choose_java(&runtimes, &inst, &v).unwrap();
        assert_eq!(bin, PathBuf::from("/j8/bin/java"));
        assert!(warn.is_some());
        inst.java_override = Some("17".into());
        assert!(choose_java(&runtimes, &inst, &v).is_err());
        let v25: VersionJson =
            serde_json_from(r#"{"id": "26.3", "javaVersion": {"majorVersion": 25}}"#);
        inst.java_override = None;
        let err = choose_java(&runtimes, &inst, &v25).unwrap_err().to_string();
        assert!(err.contains("needs Java 25"), "{err}");
    }
}
