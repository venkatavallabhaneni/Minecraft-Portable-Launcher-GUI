//! Game log lines: plain stdout/stderr and Mojang's log4j XML layout.

use std::sync::OnceLock;

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub enum Level {
    Trace,
    Debug,
    Info,
    Warn,
    Error,
    Fatal,
}

impl Level {
    pub fn parse(s: &str) -> Option<Level> {
        Some(match s.to_ascii_uppercase().as_str() {
            "TRACE" => Level::Trace,
            "DEBUG" => Level::Debug,
            "INFO" => Level::Info,
            "WARN" | "WARNING" => Level::Warn,
            "ERROR" | "SEVERE" => Level::Error,
            "FATAL" => Level::Fatal,
            _ => return None,
        })
    }

    pub fn label(self) -> &'static str {
        match self {
            Level::Trace => "TRACE",
            Level::Debug => "DEBUG",
            Level::Info => "INFO",
            Level::Warn => "WARN",
            Level::Error => "ERROR",
            Level::Fatal => "FATAL",
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct LogLine {
    pub level: Level,
    pub thread: Option<String>,
    pub text: String,
    pub stderr: bool,
}

impl LogLine {
    pub fn plain(text: impl Into<String>, stderr: bool) -> Self {
        let text = text.into();
        let level = guess_level(&text).unwrap_or(if stderr { Level::Warn } else { Level::Info });
        Self {
            level,
            thread: None,
            text,
            stderr,
        }
    }

    pub fn launcher(text: impl Into<String>) -> Self {
        Self {
            level: Level::Info,
            thread: Some("mclaunch".into()),
            text: text.into(),
            stderr: false,
        }
    }

    /// `[thread/LEVEL] text` like the vanilla console.
    pub fn display(&self) -> String {
        match &self.thread {
            Some(t) => format!("[{t}/{}] {}", self.level.label(), self.text),
            None => self.text.clone(),
        }
    }

    /// Does this line look like part of a crash or exception?
    pub fn is_crash_marker(&self) -> bool {
        let t = &self.text;
        t.contains("---- Minecraft Crash Report ----")
            || t.contains("Exception in thread")
            || t.starts_with("Caused by:")
            || t.contains("#@!@# Game crashed!")
            || t.contains("A fatal error has been detected by the Java Runtime Environment")
            || t.contains("Crash report saved to")
    }
}

fn level_regex() -> &'static regex::Regex {
    static RE: OnceLock<regex::Regex> = OnceLock::new();
    RE.get_or_init(|| {
        regex::Regex::new(r"(?:\[[^\]]*/|\[)(TRACE|DEBUG|INFO|WARN|WARNING|ERROR|SEVERE|FATAL)\]")
            .expect("valid regex")
    })
}

/// Level from text like `[12:00:00] [Render thread/WARN]: ...`.
pub fn guess_level(text: &str) -> Option<Level> {
    if let Some(c) = level_regex().captures(text) {
        return Level::parse(&c[1]);
    }
    let t = text.trim_start();
    if t.starts_with("at ") || t.starts_with("Caused by:") || t.contains("Exception") {
        return Some(Level::Error);
    }
    None
}

fn attr(tag: &str, name: &str) -> Option<String> {
    let key = format!("{name}=\"");
    let start = tag.find(&key)? + key.len();
    let end = tag[start..].find('"')? + start;
    Some(unescape(&tag[start..end]))
}

fn unescape(s: &str) -> String {
    s.replace("&lt;", "<")
        .replace("&gt;", ">")
        .replace("&quot;", "\"")
        .replace("&apos;", "'")
        .replace("&amp;", "&")
}

fn cdata(block: &str, tag: &str) -> Option<String> {
    let open = format!("<{tag}>");
    let start = block.find(&open)? + open.len();
    let end = block[start..].find(&format!("</{tag}>"))? + start;
    let inner = &block[start..end];
    let inner = inner
        .trim()
        .strip_prefix("<![CDATA[")
        .and_then(|s| s.strip_suffix("]]>"))
        .map(str::to_string)
        .unwrap_or_else(|| unescape(inner.trim()));
    Some(inner)
}

/// Incremental parser turning raw output lines into [`LogLine`]s. Handles
/// the `<log4j:Event>` XML that Mojang's logging config writes to stdout as
/// well as plain text.
#[derive(Debug, Default)]
pub struct LogParser {
    event: Option<String>,
}

impl LogParser {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn push(&mut self, raw: &str, stderr: bool) -> Vec<LogLine> {
        let line = raw.trim_end_matches(['\r', '\n']);
        if let Some(buf) = &mut self.event {
            buf.push_str(line);
            buf.push('\n');
            if line.contains("</log4j:Event>") {
                let block = self.event.take().unwrap_or_default();
                return parse_event(&block, stderr);
            }
            return Vec::new();
        }
        if line.trim_start().starts_with("<log4j:Event") {
            let mut buf = String::from(line);
            buf.push('\n');
            if line.contains("</log4j:Event>") {
                return parse_event(&buf, stderr);
            }
            self.event = Some(buf);
            return Vec::new();
        }
        vec![LogLine::plain(line, stderr)]
    }

    /// Flush a dangling partial event (process exited mid-event).
    pub fn finish(&mut self) -> Vec<LogLine> {
        match self.event.take() {
            Some(buf) => buf.lines().map(|l| LogLine::plain(l, false)).collect(),
            None => Vec::new(),
        }
    }
}

fn parse_event(block: &str, stderr: bool) -> Vec<LogLine> {
    let tag_end = block.find('>').unwrap_or(block.len());
    let tag = &block[..tag_end];
    let level = attr(tag, "level")
        .and_then(|l| Level::parse(&l))
        .unwrap_or(Level::Info);
    let thread = attr(tag, "thread");
    let mut out = Vec::new();
    if let Some(msg) = cdata(block, "log4j:Message") {
        for (i, l) in msg.lines().enumerate() {
            out.push(LogLine {
                level,
                thread: if i == 0 { thread.clone() } else { None },
                text: l.to_string(),
                stderr,
            });
        }
    }
    if let Some(t) = cdata(block, "log4j:Throwable") {
        for l in t.lines() {
            out.push(LogLine {
                level: Level::Error,
                thread: None,
                text: l.to_string(),
                stderr,
            });
        }
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn xml_events() {
        let mut p = LogParser::new();
        assert!(p
            .push(r#"<log4j:Event logger="net.minecraft.client.Minecraft" timestamp="1" level="INFO" thread="Render thread">"#, false)
            .is_empty());
        assert!(p
            .push(
                "  <log4j:Message><![CDATA[Setting user: Steve]]></log4j:Message>",
                false
            )
            .is_empty());
        let lines = p.push("</log4j:Event>", false);
        assert_eq!(lines.len(), 1);
        assert_eq!(lines[0].level, Level::Info);
        assert_eq!(lines[0].thread.as_deref(), Some("Render thread"));
        assert_eq!(lines[0].text, "Setting user: Steve");
        assert_eq!(
            lines[0].display(),
            "[Render thread/INFO] Setting user: Steve"
        );
    }

    #[test]
    fn xml_with_throwable() {
        let mut p = LogParser::new();
        let block = [
            r#"<log4j:Event logger="x" timestamp="1" level="ERROR" thread="main">"#,
            "<log4j:Message><![CDATA[Failed & died]]></log4j:Message>",
            "<log4j:Throwable><![CDATA[java.lang.RuntimeException: boom",
            "\tat a.b.C.d(C.java:1)",
            "]]></log4j:Throwable>",
            "</log4j:Event>",
        ];
        let mut out = Vec::new();
        for l in block {
            out.extend(p.push(l, false));
        }
        assert_eq!(out.len(), 3);
        assert_eq!(out[0].text, "Failed & died");
        assert_eq!(out[1].level, Level::Error);
        assert!(out[1].text.contains("RuntimeException"));
    }

    #[test]
    fn plain_lines() {
        let mut p = LogParser::new();
        let l = &p.push("[12:00:01] [Render thread/WARN]: Something odd", false)[0];
        assert_eq!(l.level, Level::Warn);
        let l = &p.push(
            "Exception in thread \"main\" java.lang.NoClassDefFoundError",
            true,
        )[0];
        assert_eq!(l.level, Level::Error);
        assert!(l.is_crash_marker());
        let l = &p.push("hello", false)[0];
        assert_eq!(l.level, Level::Info);
    }
}
