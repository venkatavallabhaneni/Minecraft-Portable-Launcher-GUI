//! Shared helpers for the ignored integration tests.

#![allow(dead_code)]

use std::path::PathBuf;
use std::sync::{Arc, Mutex};
use std::time::Duration;

use mclaunch_core::instance::InstanceConfig;
use mclaunch_core::progress::noop_progress;
use mclaunch_core::version::load_resolved;
use mclaunch_core::LauncherPaths;
use mclaunch_download::{Http, Installer};
use mclaunch_java::{JavaManager, JavaRuntime};
use mclaunch_launch::{GameEvent, LaunchRequest};
use mclaunch_safety::SafePath;

pub fn root() -> PathBuf {
    std::env::var_os("MCLAUNCH_IT_ROOT")
        .map(PathBuf::from)
        .unwrap_or_else(|| PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("../../target/it-root"))
}

/// Resolve `latest-release` / `latest-snapshot` and run [`launch_id`].
pub async fn check(spec: &str) {
    let (manifest, _) = env().installer.fetch_manifest().await.unwrap();
    let id = match spec {
        "latest-release" => manifest.latest.release.clone(),
        "latest-snapshot" => manifest.latest.snapshot.clone(),
        other => other.to_string(),
    };
    eprintln!("== {spec} -> {id}");
    launch_id(&id).await;
}

pub struct Env {
    pub paths: LauncherPaths,
    pub safe: SafePath,
    pub installer: Installer,
}

pub fn env() -> Env {
    let root = root();
    LauncherPaths::new(&root).ensure_layout().unwrap();
    let safe = SafePath::new(&root).unwrap();
    let paths = LauncherPaths::new(safe.root());
    let installer = Installer::new(paths.clone(), safe.clone(), Http::new(false).unwrap(), 16);
    Env {
        paths,
        safe,
        installer,
    }
}

pub fn runtimes(e: &Env) -> Vec<JavaRuntime> {
    JavaManager::new(e.paths.clone(), e.safe.clone())
        .scan(true, false, &noop_progress())
        .runtimes
}

/// Install/verify `id`, build its launch plan and (with MCLAUNCH_IT_LAUNCH=1) run it.
pub async fn launch_id(id: &str) {
    let e = env();
    let (paths, safe, installer) = (e.paths.clone(), e.safe.clone(), e.installer.clone());
    let id = id.to_string();
    let report = installer.ensure_ready(&id, &noop_progress()).await.unwrap();
    assert!(report.is_ok(), "{id}: {}", report.summary());
    eprintln!("   {}", report.summary());

    let resolved = load_resolved(&paths, &id).unwrap();
    let runtimes = runtimes(&e);
    let mut inst = InstanceConfig::new(&format!("it-{}", id.replace(['.', ' '], "_")), &id, 1536);
    inst.resolution = Some((854, 480));
    inst.save(&paths, &safe).unwrap();
    let (java, note) = mclaunch_launch::choose_java(&runtimes, &inst, &resolved.merged)
        .unwrap_or_else(|e| panic!("{id}: {e}"));
    if let Some(n) = note {
        eprintln!("   note: {n}");
    }
    let plan = mclaunch_launch::prepare(
        &paths,
        &safe,
        &resolved,
        &LaunchRequest {
            instance: &inst,
            username: "ItPlayer",
            quick_join: None,
            java,
        },
    )
    .unwrap();
    assert_eq!(plan.main_class, resolved.merged.main_class.clone().unwrap());
    let jar = paths.version_jar(resolved.merged.client_jar_id());
    assert!(
        plan.args
            .iter()
            .any(|a| a.contains(&*jar.to_string_lossy())),
        "client jar on classpath"
    );
    assert!(
        !plan.args.iter().any(|a| a.contains("${")),
        "unsubstituted placeholder: {:?}",
        plan.args
    );
    eprintln!("   java {} | main {}", plan.java.display(), plan.main_class);

    if std::env::var("MCLAUNCH_IT_LAUNCH").as_deref() != Ok("1") {
        safe.remove_dir_all(&plan.natives_dir).unwrap();
        return;
    }

    let lines: Arc<Mutex<Vec<String>>> = Arc::default();
    let sink_lines = lines.clone();
    let sink: mclaunch_launch::EventSink = Arc::new(move |ev| {
        if let GameEvent::Log(l) = ev {
            sink_lines.lock().unwrap().push(l.display());
        }
    });
    let kill = Arc::new(tokio::sync::Notify::new());
    let k2 = kill.clone();
    let watched = lines.clone();
    let watchdog = tokio::spawn(async move {
        // Stop once the game is clearly up, or after 25 s.
        for _ in 0..50 {
            tokio::time::sleep(Duration::from_millis(500)).await;
            let up = watched.lock().unwrap().iter().any(|l| {
                [
                    "Sound engine started",
                    "Created: ",
                    "Reloading ResourceManager",
                    "OpenAL initialized",
                    "Narrator library",
                ]
                .iter()
                .any(|m| l.contains(m))
            });
            if up {
                tokio::time::sleep(Duration::from_secs(3)).await;
                break;
            }
        }
        k2.notify_one();
    });
    let exit = mclaunch_launch::run(plan, safe.clone(), sink, kill)
        .await
        .unwrap();
    watchdog.abort();
    let log = lines.lock().unwrap().join("\n");
    let crashed = !exit.killed
        || log.contains("---- Minecraft Crash Report ----")
        || log.contains("Exception in thread \"main\"");
    if crashed || std::env::var("MCLAUNCH_IT_VERBOSE").as_deref() == Ok("1") {
        eprintln!("{log}");
    }
    assert!(
        exit.killed,
        "{id}: game exited by itself (code {:?}) — see log above",
        exit.code
    );
    assert!(!crashed, "{id} crashed");
    eprintln!(
        "   launched OK, ran {}s, {} log lines",
        exit.duration_secs,
        lines.lock().unwrap().len()
    );
}
