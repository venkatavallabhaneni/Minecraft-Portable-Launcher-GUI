//! Milestone 4 integration test list: vanilla launch of rd-132211, a1.2.6,
//! b1.7.3, 1.5.2, 1.8.9, 1.12.2, 1.16.5, 1.20.1, the latest release and the
//! latest snapshot.
//!
//! These need the network on the first run and Java runtimes (8, 17, 21, 25)
//! as archives in `$MCLAUNCH_IT_ROOT/java/` (or on PATH). They are ignored by
//! default:
//!
//! ```text
//! MCLAUNCH_IT_ROOT=/some/dir cargo test -p mclaunch-launch --test launch_matrix -- --ignored --test-threads=1
//! ```
//!
//! With `MCLAUNCH_IT_LAUNCH=1` each game is actually started (a window
//! opens), watched for ~20 s for a crash, and then stopped.

mod common;

use common::check;

macro_rules! launch_tests {
    ($($name:ident => $id:expr),* $(,)?) => {$(
        #[tokio::test(flavor = "multi_thread")]
        #[ignore = "network + Java runtimes"]
        async fn $name() {
            check($id).await;
        }
    )*};
}

launch_tests! {
    rd_132211 => "rd-132211",
    a1_2_6 => "a1.2.6",
    b1_7_3 => "b1.7.3",
    v1_5_2 => "1.5.2",
    v1_8_9 => "1.8.9",
    v1_12_2 => "1.12.2",
    v1_16_5 => "1.16.5",
    v1_20_1 => "1.20.1",
    latest_release => "latest-release",
    latest_snapshot => "latest-snapshot",
}
