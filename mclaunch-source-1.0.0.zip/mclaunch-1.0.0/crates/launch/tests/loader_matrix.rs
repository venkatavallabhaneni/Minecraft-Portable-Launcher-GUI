//! Milestone 6 integration tests: install mod loaders for real and launch
//! them. Ignored by default (network + Java runtimes), see `launch_matrix.rs`.
//!
//! ```text
//! MCLAUNCH_IT_ROOT=/some/dir cargo test -p mclaunch-launch --test loader_matrix -- --ignored --test-threads=1
//! ```

mod common;

use mclaunch_core::progress::noop_progress;
use mclaunch_core::version::load_resolved;
use mclaunch_java::JavaPick;
use mclaunch_loaders::{Loaders, Software};

async fn install_and_launch(
    software: Software,
    mc: &str,
    pick: fn(&[mclaunch_loaders::LoaderVersion]) -> String,
) {
    let e = common::env();
    let loaders = Loaders::new(e.installer.clone());
    let (versions, _) = loaders.versions(software, mc).await.unwrap();
    assert!(
        !versions.is_empty(),
        "{} has no versions for {mc}",
        software.label()
    );
    let version = pick(&versions);
    eprintln!("== {} {version} for {mc}", software.label());
    // Java matching the Minecraft version runs the installer.
    e.installer.install(mc, &noop_progress()).await.unwrap();
    let required =
        mclaunch_core::javareq::required_java(&load_resolved(&e.paths, mc).unwrap().merged);
    let runtimes = common::runtimes(&e);
    let java = match mclaunch_java::pick_runtime(&runtimes, required, mc) {
        JavaPick::Exact(r) | JavaPick::Compatible(r) => r.java_bin.clone(),
        JavaPick::Missing(m) => panic!("{m}"),
    };
    let installed = loaders
        .install_client(software, mc, &version, Some(&java), &noop_progress())
        .await
        .unwrap_or_else(|e| panic!("{} install failed: {e}", software.label()));
    eprintln!("   installed {}", installed.version_id);
    common::launch_id(&installed.version_id).await;
}

fn newest_stable(v: &[mclaunch_loaders::LoaderVersion]) -> String {
    v.iter().find(|x| x.stable).unwrap_or(&v[0]).version.clone()
}

fn recommended_or_newest(v: &[mclaunch_loaders::LoaderVersion]) -> String {
    v.iter()
        .find(|x| x.recommended)
        .unwrap_or(&v[0])
        .version
        .clone()
}

#[tokio::test(flavor = "multi_thread")]
#[ignore = "network + Java runtimes"]
async fn fabric_1_21_4() {
    install_and_launch(Software::Fabric, "1.21.4", newest_stable).await;
}

#[tokio::test(flavor = "multi_thread")]
#[ignore = "network + Java runtimes"]
async fn quilt_1_20_1() {
    install_and_launch(Software::Quilt, "1.20.1", newest_stable).await;
}

#[tokio::test(flavor = "multi_thread")]
#[ignore = "network + Java runtimes"]
async fn forge_1_20_1() {
    install_and_launch(Software::Forge, "1.20.1", recommended_or_newest).await;
}

#[tokio::test(flavor = "multi_thread")]
#[ignore = "network + Java runtimes"]
async fn forge_1_12_2() {
    install_and_launch(Software::Forge, "1.12.2", recommended_or_newest).await;
}

#[tokio::test(flavor = "multi_thread")]
#[ignore = "network + Java runtimes"]
async fn forge_legacy_1_7_10() {
    install_and_launch(Software::Forge, "1.7.10", recommended_or_newest).await;
}

#[tokio::test(flavor = "multi_thread")]
#[ignore = "network + Java runtimes"]
async fn neoforge_1_21_1() {
    install_and_launch(Software::NeoForge, "1.21.1", newest_stable).await;
}
