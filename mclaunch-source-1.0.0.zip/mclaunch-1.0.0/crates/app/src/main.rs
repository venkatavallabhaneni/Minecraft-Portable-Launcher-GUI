//! mclaunch — offline-first Minecraft: Java Edition launcher.

#![cfg_attr(all(windows, not(debug_assertions)), windows_subsystem = "windows")]

mod app;
mod backend;
mod game;
mod icon;
mod logging;
mod screenshot;
mod servers;
mod shaders;
mod theme;
#[cfg(test)]
mod ui_tests;
mod views;
mod widgets;

use std::sync::atomic::AtomicUsize;
use std::sync::Arc;

use anyhow::Context;
use eframe::egui;
use mclaunch_core::{Config, LauncherPaths};

fn main() -> anyhow::Result<()> {
    let paths = LauncherPaths::detect().context("cannot locate launcher folder")?;
    paths
        .ensure_layout()
        .with_context(|| format!("cannot create launcher folders in {}", paths.root.display()))?;
    let _log_guard = logging::init(&paths.logs_dir())?;
    let safe = mclaunch_safety::SafePath::new(&paths.root)?;
    let config = match Config::load(&paths.config_file()) {
        Ok(c) => c,
        Err(e) => {
            tracing::error!(error = %e, "config.toml is invalid; using defaults");
            Config::default()
        }
    };
    tracing::info!(root = %paths.root.display(), version = mclaunch_core::LAUNCHER_VERSION, "mclaunch starting");

    let runtime = tokio::runtime::Builder::new_multi_thread()
        .enable_all()
        .thread_name("mclaunch-worker")
        .build()
        .context("cannot start async runtime")?;
    let services = backend::Services {
        paths,
        safe,
        http: mclaunch_download::Http::new(config.offline_mode)?,
        threads: Arc::new(AtomicUsize::new(config.download_threads)),
    };

    let options = eframe::NativeOptions {
        viewport: egui::ViewportBuilder::default()
            .with_title("mclaunch")
            .with_app_id("mclaunch")
            .with_inner_size([1180.0, 740.0])
            .with_min_inner_size([900.0, 560.0])
            .with_icon(Arc::new(icon::window_icon()))
            .with_drag_and_drop(true),
        ..Default::default()
    };
    // Files passed on the command line ("Open with mclaunch"): modpacks,
    // shader packs, mods, Java archives…
    let open: Vec<std::path::PathBuf> = std::env::args_os()
        .skip(1)
        .map(std::path::PathBuf::from)
        .filter(|p| p.is_file())
        .collect();
    let handle = runtime.handle().clone();
    let result = eframe::run_native(
        "mclaunch",
        options,
        Box::new(move |cc| Ok(Box::new(app::McApp::new(cc, services, config, handle, open)))),
    );
    runtime.shutdown_timeout(std::time::Duration::from_secs(2));
    if let Err(e) = result {
        tracing::error!(error = %e, "UI failed");
        anyhow::bail!("could not start the user interface: {e}");
    }
    Ok(())
}
