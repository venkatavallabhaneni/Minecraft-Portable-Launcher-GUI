//! Logging: a daily-rolling file in `logs/` plus stderr in debug builds.

use std::path::Path;

use tracing_appender::non_blocking::WorkerGuard;
use tracing_subscriber::{fmt, prelude::*, EnvFilter};

/// Initialise tracing. Keep the returned guard alive for the whole program so
/// buffered log lines are flushed on exit.
pub fn init(logs_dir: &Path) -> anyhow::Result<WorkerGuard> {
    std::fs::create_dir_all(logs_dir)?;
    let appender = tracing_appender::rolling::Builder::new()
        .rotation(tracing_appender::rolling::Rotation::DAILY)
        .filename_prefix("mclaunch")
        .filename_suffix("log")
        .max_log_files(14)
        .build(logs_dir)?;
    let (writer, guard) = tracing_appender::non_blocking(appender);

    let filter = EnvFilter::try_from_env("MCLAUNCH_LOG")
        .unwrap_or_else(|_| EnvFilter::new("info,wgpu=warn,eframe=warn,egui_glow=warn,naga=warn"));
    let file_layer = fmt::layer().with_ansi(false).with_writer(writer);
    let stderr_layer = cfg!(debug_assertions).then(|| fmt::layer().with_writer(std::io::stderr));
    tracing_subscriber::registry()
        .with(filter)
        .with(file_layer)
        .with(stderr_layer)
        .try_init()
        .map_err(|e| anyhow::anyhow!("logging init failed: {e}"))?;
    Ok(guard)
}
