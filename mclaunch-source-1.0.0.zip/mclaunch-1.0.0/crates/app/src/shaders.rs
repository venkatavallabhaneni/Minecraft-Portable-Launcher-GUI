//! Shader actions, drag-and-drop imports and the OpenGL pre-flight check.

use std::path::{Path, PathBuf};

use mclaunch_core::LoaderKind;
use mclaunch_loaders::{shaders, Loaders};
use mclaunch_safety::SafetyError;

use crate::app::{McApp, Screen, ToastKind};
use crate::backend::JobDone;

/// What a dropped file is.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum DropKind {
    Modpack,
    ShaderPack,
    ResourcePack,
    Mod,
    OptiFine,
    JavaArchive,
    Unknown,
}

/// Look inside a dropped file to decide where it goes (blocking).
pub fn classify(path: &Path) -> DropKind {
    let name = path
        .file_name()
        .map(|n| n.to_string_lossy().to_lowercase())
        .unwrap_or_default();
    if name.ends_with(".tar.gz") || name.ends_with(".tgz") {
        return DropKind::JavaArchive;
    }
    if name.ends_with(".jar") {
        return if mclaunch_loaders::optifine::parse_name(
            &path.file_name().unwrap_or_default().to_string_lossy(),
        )
        .is_some()
        {
            DropKind::OptiFine
        } else {
            DropKind::Mod
        };
    }
    if name.ends_with(".mrpack") {
        return DropKind::Modpack;
    }
    if !name.ends_with(".zip") {
        return DropKind::Unknown;
    }
    if mclaunch_loaders::modpack::sniff(path).is_some() {
        return DropKind::Modpack;
    }
    let Ok(entries) = mclaunch_loaders::zip_entry_names(path) else {
        return DropKind::Unknown;
    };
    let has = |pred: &dyn Fn(&str) -> bool| entries.iter().any(|e| pred(e));
    if has(&|e| e.ends_with("bin/java") || e.ends_with("bin/java.exe")) {
        DropKind::JavaArchive
    } else if has(&|e| e.starts_with("shaders/") || e.split('/').nth(1) == Some("shaders")) {
        DropKind::ShaderPack
    } else if has(&|e| e == "pack.mcmeta") {
        DropKind::ResourcePack
    } else {
        DropKind::Unknown
    }
}

/// Parse an OpenGL version string ("4.6.0 NVIDIA 535", "4.2 (Core Profile)
/// Mesa 24.0") into `major.minor`. OpenGL ES strings return `None`.
pub fn gl_major_minor(version: &str) -> Option<String> {
    if version.contains("OpenGL ES") {
        return None;
    }
    let start = version.find(|c: char| c.is_ascii_digit())?;
    let rest = &version[start..];
    let mut parts = rest.split(|c: char| !c.is_ascii_digit());
    let major = parts.next()?;
    let minor = parts.next()?;
    Some(format!("{major}.{minor}"))
}

/// `major.minor` comparison against 3.2.
pub fn gl_at_least_3_2(v: &str) -> Option<bool> {
    let (a, b) = v.split_once('.')?;
    Some((a.parse::<u32>().ok()?, b.parse::<u32>().ok()?) >= (3, 2))
}

impl McApp {
    /// Refresh the cached shader status of an instance (background).
    pub fn refresh_shader_status(&mut self, name: &str) {
        let Some(inst) = self.instances.iter().find(|i| i.name == name) else {
            return;
        };
        let dir = self.services().paths.instance_dir(name);
        let loader = inst.loader;
        let name = name.to_string();
        let b = self.backend.clone();
        self.backend.spawn(async move {
            if let Ok(st) = tokio::task::spawn_blocking(move || shaders::status(&dir, loader)).await
            {
                b.apply(move |app| {
                    app.shader_status.insert(name, st);
                });
            }
        });
    }

    pub fn shader_status_text(&mut self, name: &str) -> String {
        match self.shader_status.get(name) {
            Some(st) => st.summary(),
            None => {
                self.shader_status
                    .insert(name.to_string(), Default::default());
                self.refresh_shader_status(name);
                "…".into()
            }
        }
    }

    /// One click: install the shader mods for this instance's loader.
    pub fn enable_shaders(&mut self, name: &str) {
        let Some(inst) = self.instances.iter().find(|i| i.name == name).cloned() else {
            return;
        };
        if inst.loader == LoaderKind::Vanilla {
            self.toast(
                ToastKind::Info,
                format!(
                    "Vanilla needs OptiFine for shaders: download OptiFine for {} from optifine.net, then import it here (or install Fabric for Iris).",
                    inst.mc_version
                ),
            );
            self.loaders_ui.mc = inst.mc_version.clone();
            self.screen = Screen::Loaders;
            return;
        }
        let dir = self.services().paths.instance_dir(name);
        let name = name.to_string();
        self.backend.job(
            format!("Enabling shaders for {name}"),
            move |j| async move {
                let loaders = Loaders::new(j.services.installer());
                let report =
                    shaders::enable(&loaders, inst.loader, &inst.mc_version, &dir, &j.progress)
                        .await?;
                let mut cfg = inst.clone();
                cfg.shaders = true;
                let mut notes = Vec::new();
                if cfg.max_memory_mb < 4096 {
                    cfg.max_memory_mb = 4096;
                    notes.push("memory raised to 4 GB");
                }
                if cfg.jvm_args.trim().is_empty() {
                    cfg.jvm_args = mclaunch_core::instance::DEFAULT_JVM_ARGS.to_string();
                }
                let mut msg = format!("{} ready for {name}", report.engine);
                if !report.added.is_empty() {
                    msg.push_str(&format!(": added {}", report.added.join(", ")));
                }
                if !notes.is_empty() {
                    msg.push_str(&format!(" ({})", notes.join(", ")));
                }
                Ok(JobDone::msg(msg).then(move |app| {
                    if let Err(e) = app.save_instance(&cfg) {
                        app.toast(ToastKind::Error, e);
                    }
                    app.refresh_shader_status(&cfg.name);
                }))
            },
        );
    }

    /// Ask for shader pack zips to add to the selected instance.
    pub fn pick_shader_packs(&mut self) {
        let dialog = rfd::AsyncFileDialog::new()
            .set_title("Add shader packs")
            .add_filter("Shader pack", &["zip"])
            .pick_files();
        let b = self.backend.clone();
        self.backend.spawn(async move {
            if let Some(files) = dialog.await {
                let paths: Vec<PathBuf> = files.iter().map(|f| f.path().to_path_buf()).collect();
                b.apply(move |app| app.import_files(paths));
            }
        });
    }

    /// Handle files dropped onto the window (or picked in a dialog).
    pub fn import_files(&mut self, files: Vec<PathBuf>) {
        let target = self.selected_instance().map(|i| (i.name.clone(), i.loader));
        let svc = self.services().clone();
        let b = self.backend.clone();
        self.backend.job("Importing files", move |_j| async move {
            let results = tokio::task::spawn_blocking(move || {
                files
                    .into_iter()
                    .map(|f| {
                        let kind = classify(&f);
                        let file_name = f.file_name().map(|n| n.to_os_string()).unwrap_or_default();
                        let dest = match (kind, &target) {
                            (DropKind::ShaderPack, Some((n, _))) => Some(svc.paths.instance_dir(n).join("shaderpacks").join(&file_name)),
                            (DropKind::ResourcePack, Some((n, _))) => Some(svc.paths.instance_dir(n).join("resourcepacks").join(&file_name)),
                            (DropKind::Mod, Some((n, l))) if l.uses_mods_folder() => Some(svc.paths.instance_dir(n).join("mods").join(&file_name)),
                            (DropKind::JavaArchive, _) => Some(svc.paths.java_dir().join(&file_name)),
                            _ => None,
                        };
                        let outcome = match dest {
                            Some(dest) => match svc.safe.copy_new(&f, &dest) {
                                Ok(_) => Ok(format!("Added {}", dest.display())),
                                Err(SafetyError::AlreadyExists(_)) => Ok(format!("{} is already there", dest.display())),
                                Err(e) => Err(e.to_string()),
                            },
                            None => Ok(String::new()),
                        };
                        (f, kind, outcome)
                    })
                    .collect::<Vec<_>>()
            })
            .await?;
            b.apply(move |app| {
                let mut rescan_java = false;
                for (path, kind, outcome) in results {
                    let name = path.file_name().map(|n| n.to_string_lossy().into_owned()).unwrap_or_default();
                    match (kind, outcome) {
                        (DropKind::OptiFine, _) => app.import_optifine(path),
                        (DropKind::Modpack, _) => app.open_modpack(path),
                        (DropKind::Unknown, _) => app.toast(
                            ToastKind::Error,
                            format!("{name}: not a modpack, shader pack, resource pack, mod, OptiFine or Java archive"),
                        ),
                        (_, Ok(msg)) if msg.is_empty() => app.toast(
                            ToastKind::Error,
                            match kind {
                                DropKind::Mod => format!("{name}: select a modded instance first (Fabric, Quilt, Forge, NeoForge)"),
                                _ => format!("{name}: select an instance first"),
                            },
                        ),
                        (_, Ok(msg)) => {
                            if kind == DropKind::JavaArchive {
                                rescan_java = true;
                            }
                            app.toast(ToastKind::Success, msg);
                        }
                        (_, Err(e)) => app.toast(ToastKind::Error, format!("{name}: {e}")),
                    }
                }
                if rescan_java {
                    app.rescan_java(false);
                    app.screen = Screen::Java;
                }
                if let Some(n) = app.selected_instance().map(|i| i.name.clone()) {
                    app.refresh_shader_status(&n);
                }
            });
            Ok(JobDone::quiet())
        });
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;

    fn zip_with(dir: &Path, name: &str, entries: &[&str]) -> PathBuf {
        let p = dir.join(name);
        let mut z = zip::ZipWriter::new(std::fs::File::create(&p).unwrap());
        for e in entries {
            z.start_file(*e, zip::write::SimpleFileOptions::default())
                .unwrap();
            z.write_all(b"x").unwrap();
        }
        z.finish().unwrap();
        p
    }

    #[test]
    fn classify_drops() {
        let d = tempfile::tempdir().unwrap();
        assert_eq!(
            classify(&zip_with(d.path(), "BSL.zip", &["shaders/final.fsh"])),
            DropKind::ShaderPack
        );
        assert_eq!(
            classify(&zip_with(
                d.path(),
                "Nested.zip",
                &["Nested/shaders/final.fsh"]
            )),
            DropKind::ShaderPack
        );
        assert_eq!(
            classify(&zip_with(d.path(), "jdk.zip", &["jdk-21/bin/java.exe"])),
            DropKind::JavaArchive
        );
        assert_eq!(
            classify(&zip_with(d.path(), "rp.zip", &["pack.mcmeta", "assets/x"])),
            DropKind::ResourcePack
        );
        assert_eq!(
            classify(&zip_with(d.path(), "junk.zip", &["a.txt"])),
            DropKind::Unknown
        );
        assert_eq!(
            classify(Path::new("OptiFine_1.20.1_HD_U_I6.jar")),
            DropKind::OptiFine
        );
        assert_eq!(classify(Path::new("sodium.jar")), DropKind::Mod);
        assert_eq!(classify(Path::new("jdk.tar.gz")), DropKind::JavaArchive);
        assert_eq!(classify(Path::new("pack.mrpack")), DropKind::Modpack);
        assert_eq!(
            classify(&zip_with(
                d.path(),
                "cf.zip",
                &["manifest.json", "overrides/config/shaders/x.txt"]
            )),
            DropKind::Unknown,
            "manifest.json that is not a CurseForge manifest"
        );
        assert_eq!(
            classify(&zip_with(
                d.path(),
                "plain.zip",
                &["Pack/mods/a.jar", "Pack/config/shaders/x.txt"]
            )),
            DropKind::Modpack
        );
    }

    #[test]
    fn gl_versions() {
        assert_eq!(
            gl_major_minor("4.6.0 NVIDIA 535.54").as_deref(),
            Some("4.6")
        );
        assert_eq!(
            gl_major_minor("4.2 (Core Profile) Mesa 24.2.8").as_deref(),
            Some("4.2")
        );
        assert_eq!(gl_major_minor("OpenGL ES 3.0 Mesa"), None);
        assert_eq!(gl_at_least_3_2("3.1"), Some(false));
        assert_eq!(gl_at_least_3_2("3.2"), Some(true));
        assert_eq!(gl_at_least_3_2("4.10"), Some(true));
    }
}
