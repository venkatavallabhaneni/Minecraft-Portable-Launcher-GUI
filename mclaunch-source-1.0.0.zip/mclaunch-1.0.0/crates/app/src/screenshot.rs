//! Developer aid: `MCLAUNCH_SCREENSHOT=out.png` saves a PNG of the window
//! after a few frames and exits (`MCLAUNCH_SCREEN=versions` picks the tab).
//! Includes a tiny dependency-free PNG encoder.

use std::io::Write;
use std::path::Path;

use flate2::write::ZlibEncoder;
use flate2::{Compression, Crc};

fn chunk(out: &mut Vec<u8>, kind: &[u8; 4], data: &[u8]) {
    out.extend_from_slice(&(data.len() as u32).to_be_bytes());
    out.extend_from_slice(kind);
    out.extend_from_slice(data);
    let mut crc = Crc::new();
    crc.update(kind);
    crc.update(data);
    out.extend_from_slice(&crc.sum().to_be_bytes());
}

/// Encode 8-bit RGBA pixels as PNG.
pub fn encode_png(width: u32, height: u32, rgba: &[u8]) -> std::io::Result<Vec<u8>> {
    let mut out = b"\x89PNG\r\n\x1a\n".to_vec();
    let mut ihdr = Vec::with_capacity(13);
    ihdr.extend_from_slice(&width.to_be_bytes());
    ihdr.extend_from_slice(&height.to_be_bytes());
    ihdr.extend_from_slice(&[8, 6, 0, 0, 0]); // 8-bit RGBA
    chunk(&mut out, b"IHDR", &ihdr);
    let mut z = ZlibEncoder::new(Vec::new(), Compression::default());
    let stride = width as usize * 4;
    for row in rgba.chunks(stride) {
        z.write_all(&[0])?; // filter: none
        z.write_all(row)?;
    }
    chunk(&mut out, b"IDAT", &z.finish()?);
    chunk(&mut out, b"IEND", &[]);
    Ok(out)
}

pub fn save(path: &Path, image: &eframe::egui::ColorImage) -> std::io::Result<()> {
    let rgba: Vec<u8> = image.pixels.iter().flat_map(|c| c.to_array()).collect();
    let png = encode_png(image.size[0] as u32, image.size[1] as u32, &rgba)?;
    std::fs::write(path, png)
}

#[cfg(test)]
mod tests {
    #[test]
    fn png_header() {
        let png = super::encode_png(1, 1, &[1, 2, 3, 255]).unwrap();
        assert_eq!(&png[..8], b"\x89PNG\r\n\x1a\n");
        assert_eq!(&png[12..16], b"IHDR");
        assert_eq!(&png[png.len() - 8..png.len() - 4], b"IEND");
    }
}
