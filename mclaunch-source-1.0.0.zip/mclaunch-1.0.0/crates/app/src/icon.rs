//! Procedurally drawn pixel-art grass block used as the window icon, so the
//! binary needs no image files.

use eframe::egui;

const GRID: usize = 16;

/// Deterministic per-pixel noise in 0..=255.
fn noise(x: usize, y: usize) -> u8 {
    let mut h = (x as u32).wrapping_mul(374_761_393) ^ (y as u32).wrapping_mul(668_265_263);
    h = (h ^ (h >> 13)).wrapping_mul(1_274_126_177);
    (h >> 24) as u8
}

/// RGBA of the 16×16 icon.
pub fn pixels() -> Vec<[u8; 4]> {
    let mut px = Vec::with_capacity(GRID * GRID);
    for y in 0..GRID {
        for x in 0..GRID {
            let n = noise(x, y);
            // grass drips a little into the dirt
            let grass_depth = 4 + (noise(x, 99) % 3) as usize;
            let rgb = if y < grass_depth {
                match n % 3 {
                    0 => [0x5D, 0xBB, 0x63],
                    1 => [0x4C, 0xA0, 0x52],
                    _ => [0x6F, 0xCC, 0x74],
                }
            } else {
                match n % 4 {
                    0 => [0x86, 0x5A, 0x3A],
                    1 => [0x6E, 0x48, 0x2E],
                    2 => [0x96, 0x6C, 0x4A],
                    _ => [0x7A, 0x52, 0x34],
                }
            };
            px.push([rgb[0], rgb[1], rgb[2], 0xFF]);
        }
    }
    px
}

pub fn window_icon() -> egui::IconData {
    const SCALE: usize = 4;
    let size = GRID * SCALE;
    let src = pixels();
    let mut rgba = Vec::with_capacity(size * size * 4);
    for y in 0..size {
        for x in 0..size {
            rgba.extend_from_slice(&src[(y / SCALE) * GRID + x / SCALE]);
        }
    }
    egui::IconData {
        rgba,
        width: size as u32,
        height: size as u32,
    }
}

#[cfg(test)]
mod tests {
    #[test]
    fn icon_size() {
        let i = super::window_icon();
        assert_eq!(i.rgba.len(), (i.width * i.height * 4) as usize);
    }
}
