//! Small reusable widgets.

use eframe::egui::{
    self, Align2, Color32, CornerRadius, FontId, Margin, Response, RichText, Sense, Stroke, Ui,
    Vec2,
};

use crate::theme::{self, Palette};

/// A rounded panel.
pub fn card<R>(ui: &mut Ui, pal: &Palette, add: impl FnOnce(&mut Ui) -> R) -> R {
    egui::Frame::new()
        .fill(pal.panel)
        .stroke(Stroke::new(1.0_f32, pal.border))
        .corner_radius(CornerRadius::same(8))
        .inner_margin(Margin::same(14))
        .show(ui, add)
        .inner
}

/// A fixed-size area that reacts to clicks anywhere on it while widgets
/// drawn inside (buttons) still get their own clicks. The area's sense is
/// registered first: egui gives a click to the last-registered widget under
/// the pointer, so registering it after the contents would swallow them.
pub fn clickable_area(ui: &mut Ui, size: Vec2, add: impl FnOnce(&mut Ui)) -> Response {
    let (rect, resp) = ui.allocate_exact_size(size, Sense::click());
    let mut child = ui.new_child(
        egui::UiBuilder::new()
            .max_rect(rect)
            .layout(egui::Layout::top_down(egui::Align::LEFT)),
    );
    add(&mut child);
    resp
}

/// An on/off switch (clearer than a checkbox in striped tables).
pub fn toggle(ui: &mut Ui, pal: &Palette, on: &mut bool) -> Response {
    let size = ui.spacing().interact_size.y * egui::vec2(1.8, 0.9);
    let (rect, mut resp) = ui.allocate_exact_size(size, Sense::click());
    if resp.clicked() {
        *on = !*on;
        resp.mark_changed();
    }
    let (enabled, value) = (ui.is_enabled(), *on);
    resp.widget_info(|| egui::WidgetInfo::selected(egui::WidgetType::Checkbox, enabled, value, ""));
    if ui.is_rect_visible(rect) {
        let t = ui.ctx().animate_bool_responsive(resp.id, *on);
        let radius = 0.5 * rect.height();
        let off = pal.dim.gamma_multiply(0.55);
        let bg = Color32::from_rgb(
            egui::lerp(off.r() as f32..=pal.accent.r() as f32, t) as u8,
            egui::lerp(off.g() as f32..=pal.accent.g() as f32, t) as u8,
            egui::lerp(off.b() as f32..=pal.accent.b() as f32, t) as u8,
        );
        ui.painter().rect_filled(rect, radius, bg);
        let x = egui::lerp((rect.left() + radius)..=(rect.right() - radius), t);
        ui.painter()
            .circle_filled(egui::pos2(x, rect.center().y), radius * 0.72, Color32::WHITE);
    }
    resp
}

/// Small coloured pill (painted directly so it never stretches).
pub fn badge(ui: &mut Ui, text: impl Into<String>, color: Color32) -> Response {
    let font = egui::TextStyle::Small.resolve(ui.style());
    let galley = ui.painter().layout_no_wrap(text.into(), font, color);
    let pad = Vec2::new(7.0, 2.0);
    let (rect, resp) = ui.allocate_exact_size(galley.size() + pad * 2.0, Sense::hover());
    if ui.is_rect_visible(rect) {
        let p = ui.painter();
        p.rect_filled(rect, 6.0_f32, color.gamma_multiply(0.18));
        p.rect_stroke(
            rect,
            6.0_f32,
            Stroke::new(1.0_f32, color.gamma_multiply(0.75)),
            egui::StrokeKind::Inside,
        );
        p.galley(rect.min + pad, galley, color);
    }
    resp
}

/// A left-aligned label in a fixed-width slot.
pub fn fixed_label(ui: &mut Ui, width: f32, text: impl Into<RichText>) -> Response {
    ui.allocate_ui_with_layout(
        Vec2::new(width, ui.spacing().interact_size.y),
        egui::Layout::left_to_right(egui::Align::Center),
        |ui| {
            ui.set_min_width(width);
            ui.add(egui::Label::new(text.into()).truncate())
        },
    )
    .inner
}

/// Header in the pixel font.
pub fn pixel_heading(ui: &mut Ui, text: &str, size: f32) -> Response {
    ui.label(RichText::new(text).font(theme::pixel(size)))
}

pub fn accent_button(ui: &mut Ui, pal: &Palette, text: &str) -> Response {
    ui.add(
        egui::Button::new(RichText::new(text).color(pal.accent_text).strong())
            .fill(pal.accent)
            .corner_radius(CornerRadius::same(8)),
    )
}

/// The big PLAY button.
pub fn play_button(ui: &mut Ui, pal: &Palette, label: &str, enabled: bool) -> Response {
    let size = Vec2::new(280.0_f32.min(ui.available_width()), 64.0);
    let (rect, resp) = ui.allocate_exact_size(
        size,
        if enabled {
            Sense::click()
        } else {
            Sense::hover()
        },
    );
    if ui.is_rect_visible(rect) {
        let base = if enabled { pal.accent } else { pal.panel_hi };
        let fill = if enabled && resp.is_pointer_button_down_on() {
            base.gamma_multiply(0.8)
        } else if enabled && resp.hovered() {
            base.gamma_multiply(1.12)
        } else {
            base
        };
        let painter = ui.painter();
        // A darker "pixel" bottom edge for a blocky look.
        painter.rect_filled(
            rect.translate(Vec2::new(0.0, 4.0)),
            8.0_f32,
            fill.gamma_multiply(0.55),
        );
        painter.rect_filled(rect, 8.0_f32, fill);
        let text_color = if enabled { pal.accent_text } else { pal.dim };
        painter.text(
            rect.center(),
            Align2::CENTER_CENTER,
            label,
            theme::pixel(20.0),
            text_color,
        );
    }
    if enabled {
        resp.on_hover_cursor(egui::CursorIcon::PointingHand)
    } else {
        resp
    }
}

/// Toggle chip used for filters.
pub fn chip(ui: &mut Ui, pal: &Palette, on: &mut bool, text: &str) -> Response {
    let resp = ui.add(
        egui::Button::new(RichText::new(text).color(if *on { pal.accent_text } else { pal.text }))
            .fill(if *on { pal.accent } else { pal.panel_hi })
            .corner_radius(CornerRadius::same(12)),
    );
    if resp.clicked() {
        *on = !*on;
    }
    resp
}

pub fn dim(text: impl Into<String>, pal: &Palette) -> RichText {
    RichText::new(text.into()).color(pal.dim)
}

pub fn mono(text: impl Into<String>) -> RichText {
    RichText::new(text.into()).font(FontId::monospace(12.5))
}

/// Format a duration in seconds as "3h 12m".
pub fn play_time(secs: u64) -> String {
    let h = secs / 3600;
    let m = (secs % 3600) / 60;
    if h > 0 {
        format!("{h}h {m}m")
    } else {
        format!("{m}m")
    }
}

/// "5 minutes ago"-style relative time.
pub fn ago(t: chrono::DateTime<chrono::Utc>) -> String {
    let secs = (chrono::Utc::now() - t).num_seconds().max(0);
    match secs {
        0..=59 => "just now".into(),
        60..=3599 => format!("{} min ago", secs / 60),
        3600..=86_399 => format!("{} h ago", secs / 3600),
        _ => format!("{} days ago", secs / 86_400),
    }
}

/// The grass-block logo, drawn from the same pixels as the window icon.
pub fn logo(ui: &mut Ui, px: f32) -> Response {
    let pixels = crate::icon::pixels();
    let side = 16.0 * px;
    let (rect, resp) = ui.allocate_exact_size(Vec2::splat(side), Sense::hover());
    let painter = ui.painter();
    for (i, [r, g, b, _]) in pixels.iter().enumerate() {
        let (x, y) = ((i % 16) as f32, (i / 16) as f32);
        let min = rect.min + Vec2::new(x * px, y * px);
        painter.rect_filled(
            egui::Rect::from_min_size(min, Vec2::splat(px)),
            0.0_f32,
            Color32::from_rgb(*r, *g, *b),
        );
    }
    resp
}

#[cfg(test)]
mod tests {
    #[test]
    fn play_time() {
        assert_eq!(super::play_time(59), "0m");
        assert_eq!(super::play_time(3 * 3600 + 12 * 60), "3h 12m");
    }
}

#[cfg(test)]
mod click_tests {
    use super::*;

    /// Run one frame with `events`; returns (area clicked, button clicked,
    /// button rect).
    fn frame(ctx: &egui::Context, events: Vec<egui::Event>) -> (bool, bool, egui::Rect) {
        let mut out = (false, false, egui::Rect::NOTHING);
        let input = egui::RawInput {
            screen_rect: Some(egui::Rect::from_min_size(egui::Pos2::ZERO, egui::vec2(400.0, 300.0))),
            events,
            ..Default::default()
        };
        let _ = ctx.run(input, |ctx| {
            egui::CentralPanel::default().show(ctx, |ui| {
                let area = clickable_area(ui, egui::vec2(200.0, 120.0), |ui| {
                    ui.add_space(60.0);
                    let b = ui.button("Play");
                    out.1 = b.clicked();
                    out.2 = b.rect;
                });
                out.0 = area.clicked();
            });
        });
        out
    }

    fn click(ctx: &egui::Context, pos: egui::Pos2) -> (bool, bool) {
        let press = |pressed| egui::Event::PointerButton {
            pos,
            button: egui::PointerButton::Primary,
            pressed,
            modifiers: Default::default(),
        };
        frame(ctx, vec![egui::Event::PointerMoved(pos)]);
        frame(ctx, vec![press(true)]);
        let (a, b, _) = frame(ctx, vec![press(false)]);
        (a, b)
    }

    #[test]
    fn buttons_inside_a_clickable_area_get_their_clicks() {
        let ctx = egui::Context::default();
        let (_, _, button) = frame(&ctx, vec![]);
        assert!(button.width() > 0.0);
        assert_eq!(click(&ctx, button.center()), (false, true), "button, not the card");
        let empty = egui::pos2(button.center().x, button.top() - 30.0);
        assert_eq!(click(&ctx, empty), (true, false), "card background");
    }
}
