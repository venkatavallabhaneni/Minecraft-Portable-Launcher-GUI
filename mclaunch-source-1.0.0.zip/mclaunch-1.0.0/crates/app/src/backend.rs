//! Background work. Long tasks run on the tokio runtime; the UI receives
//! progress and results over a `tokio::sync::mpsc` channel and never blocks.

use std::future::Future;
use std::panic::AssertUnwindSafe;
use std::sync::atomic::{AtomicU64, AtomicUsize, Ordering};
use std::sync::Arc;

use eframe::egui;
use futures::FutureExt;
use mclaunch_core::{LauncherPaths, Progress, ProgressFn};
use mclaunch_download::{Http, Installer};
use mclaunch_safety::SafePath;
use tokio::sync::mpsc::UnboundedSender;

use crate::app::McApp;

pub type JobId = u64;
/// A state update produced off the UI thread and applied on it.
pub type Apply = Box<dyn FnOnce(&mut McApp) + Send>;

pub enum AppEvent {
    Progress(JobId, Progress),
    Finished(JobId, Result<Option<String>, String>),
    Apply(Apply),
}

/// Result of a job: an optional toast message and an optional state update.
pub struct JobDone {
    pub message: Option<String>,
    pub apply: Option<Apply>,
}

impl JobDone {
    pub fn quiet() -> Self {
        Self {
            message: None,
            apply: None,
        }
    }

    pub fn msg(message: impl Into<String>) -> Self {
        Self {
            message: Some(message.into()),
            apply: None,
        }
    }

    pub fn then(mut self, f: impl FnOnce(&mut McApp) + Send + 'static) -> Self {
        self.apply = Some(Box::new(f));
        self
    }
}

/// Shared services handed to background jobs.
#[derive(Clone)]
pub struct Services {
    pub paths: LauncherPaths,
    pub safe: SafePath,
    pub http: Http,
    pub threads: Arc<AtomicUsize>,
}

impl Services {
    pub fn installer(&self) -> Installer {
        Installer::new(
            self.paths.clone(),
            self.safe.clone(),
            self.http.clone(),
            self.threads.load(Ordering::Relaxed),
        )
    }
}

pub struct JobCtx {
    pub services: Services,
    pub progress: ProgressFn,
    pub backend: Backend,
}

#[derive(Clone)]
pub struct Backend {
    pub services: Services,
    rt: tokio::runtime::Handle,
    tx: UnboundedSender<AppEvent>,
    ctx: egui::Context,
    next_id: Arc<AtomicU64>,
}

impl Backend {
    pub fn new(
        services: Services,
        rt: tokio::runtime::Handle,
        tx: UnboundedSender<AppEvent>,
        ctx: egui::Context,
    ) -> Self {
        Self {
            services,
            rt,
            tx,
            ctx,
            next_id: Arc::new(AtomicU64::new(1)),
        }
    }

    pub fn send(&self, ev: AppEvent) {
        let _ = self.tx.send(ev);
        self.ctx.request_repaint();
    }

    /// Queue a state update for the UI thread.
    pub fn apply(&self, f: impl FnOnce(&mut McApp) + Send + 'static) {
        self.send(AppEvent::Apply(Box::new(f)));
    }

    /// Fire-and-forget future on the runtime.
    pub fn spawn(&self, fut: impl Future<Output = ()> + Send + 'static) {
        self.rt.spawn(fut);
    }

    /// Run a tracked job with progress reporting (shown in the status bar).
    pub fn job<F, Fut>(&self, label: impl Into<String>, f: F) -> JobId
    where
        F: FnOnce(JobCtx) -> Fut + Send + 'static,
        Fut: Future<Output = anyhow::Result<JobDone>> + Send + 'static,
    {
        let id = self.next_id.fetch_add(1, Ordering::Relaxed);
        let label = label.into();
        tracing::info!(job = id, %label, "job started");
        self.apply(move |app| app.job_started(id, label));
        let sender = self.clone();
        let progress: ProgressFn = Arc::new(move |p| sender.send(AppEvent::Progress(id, p)));
        let jctx = JobCtx {
            services: self.services.clone(),
            progress,
            backend: self.clone(),
        };
        let done = self.clone();
        self.rt.spawn(async move {
            let res = AssertUnwindSafe(f(jctx)).catch_unwind().await;
            match res {
                Ok(Ok(JobDone { message, apply })) => {
                    if let Some(apply) = apply {
                        done.send(AppEvent::Apply(apply));
                    }
                    done.send(AppEvent::Finished(id, Ok(message)));
                }
                Ok(Err(e)) => {
                    tracing::warn!(job = id, error = %format!("{e:#}"), "job failed");
                    done.send(AppEvent::Finished(id, Err(format!("{e:#}"))));
                }
                Err(_) => {
                    tracing::error!(job = id, "job panicked");
                    done.send(AppEvent::Finished(
                        id,
                        Err("internal error (see logs)".into()),
                    ));
                }
            }
        });
        id
    }
}
