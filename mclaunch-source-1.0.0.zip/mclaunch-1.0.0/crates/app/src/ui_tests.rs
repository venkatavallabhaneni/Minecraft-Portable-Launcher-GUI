//! Drive the real app headlessly: build `McApp`, run frames, find widgets
//! through the accessibility tree and click them.

use std::path::Path;
use std::sync::atomic::AtomicUsize;
use std::sync::Arc;
use std::time::{Duration, Instant};

use eframe::egui;
use mclaunch_core::{Config, InstanceConfig, LauncherPaths};

use crate::app::{McApp, Screen};

pub struct Harness {
    _rt: tokio::runtime::Runtime,
    pub ctx: egui::Context,
    pub app: McApp,
    frame: eframe::Frame,
    nodes: Vec<(String, egui::Rect)>,
    checkboxes: Vec<egui::Rect>,
}

impl Harness {
    pub fn new(root: &Path, instances: &[&str]) -> Self {
        let safe = mclaunch_safety::SafePath::new(root).unwrap();
        let paths = LauncherPaths::new(safe.root());
        paths.ensure_layout().unwrap();
        for name in instances {
            let mut cfg = InstanceConfig::new(name, "1.20.1", 2048);
            cfg.loader = mclaunch_core::LoaderKind::Fabric;
            cfg.save(&paths, &safe).unwrap();
        }
        let config = Config {
            accounts: vec!["Steve".into()],
            offline_mode: true,
            ..Default::default()
        };
        let rt = tokio::runtime::Builder::new_multi_thread()
            .enable_all()
            .build()
            .unwrap();
        let services = crate::backend::Services {
            paths: paths.clone(),
            safe,
            http: mclaunch_download::Http::new(true).unwrap(),
            threads: Arc::new(AtomicUsize::new(4)),
        };
        let ctx = egui::Context::default();
        ctx.enable_accesskit();
        let cc = eframe::CreationContext::_new_kittest(ctx.clone());
        let app = McApp::new(&cc, services, config, rt.handle().clone(), Vec::new());
        let mut h = Self {
            _rt: rt,
            ctx,
            app,
            frame: eframe::Frame::_new_kittest(),
            nodes: Vec::new(),
            checkboxes: Vec::new(),
        };
        h.run_until(|app| app.instances.len() == instances.len());
        h
    }

    pub fn step(&mut self, events: Vec<egui::Event>) {
        let input = egui::RawInput {
            screen_rect: Some(egui::Rect::from_min_size(
                egui::Pos2::ZERO,
                egui::vec2(1180.0, 740.0),
            )),
            events,
            ..Default::default()
        };
        let (app, frame) = (&mut self.app, &mut self.frame);
        let out = self.ctx.run(input, |ctx| {
            eframe::App::update(app, ctx, frame);
        });
        if let Some(update) = out.platform_output.accesskit_update {
            let rect = |b: egui::accesskit::Rect| {
                egui::Rect::from_min_max(
                    egui::pos2(b.x0 as f32, b.y0 as f32),
                    egui::pos2(b.x1 as f32, b.y1 as f32),
                )
            };
            self.checkboxes = update
                .nodes
                .iter()
                .filter(|(_, n)| n.role() == egui::accesskit::Role::CheckBox)
                .filter_map(|(_, n)| n.bounds().map(rect))
                .collect();
            self.checkboxes.sort_by(|a, b| a.top().total_cmp(&b.top()));
            self.nodes = update
                .nodes
                .iter()
                .filter_map(|(_, n)| {
                    let label = n.label()?.to_string();
                    let b = n.bounds()?;
                    let rect = egui::Rect::from_min_max(
                        egui::pos2(b.x0 as f32, b.y0 as f32),
                        egui::pos2(b.x1 as f32, b.y1 as f32),
                    );
                    Some((label, rect))
                })
                .collect();
        }
    }

    /// Run frames (letting background jobs finish) until `done` holds.
    pub fn run_until(&mut self, done: impl Fn(&McApp) -> bool) {
        let start = Instant::now();
        while !done(&self.app) {
            assert!(start.elapsed() < Duration::from_secs(10), "timed out");
            self.step(Vec::new());
            std::thread::sleep(Duration::from_millis(20));
        }
        self.step(Vec::new());
    }

    /// Rects of widgets whose accessible label is exactly `label`, in
    /// reading order (top to bottom, left to right).
    pub fn find(&self, label: &str) -> Vec<egui::Rect> {
        let mut v: Vec<egui::Rect> = self
            .nodes
            .iter()
            .filter(|(l, _)| l == label)
            .map(|(_, r)| *r)
            .collect();
        v.sort_by(|a, b| {
            let key = |r: &egui::Rect| ((r.top() / 24.0) as i32, r.left() as i32);
            key(a).cmp(&key(b))
        });
        v
    }

    pub fn click_at(&mut self, pos: egui::Pos2) {
        let press = |pressed| egui::Event::PointerButton {
            pos,
            button: egui::PointerButton::Primary,
            pressed,
            modifiers: Default::default(),
        };
        self.step(vec![egui::Event::PointerMoved(pos)]);
        self.step(vec![press(true)]);
        self.step(vec![press(false)]);
        self.step(Vec::new());
    }

    pub fn click(&mut self, label: &str, nth: usize) {
        let rects = self.find(label);
        let r = rects
            .get(nth)
            .unwrap_or_else(|| panic!("no widget #{nth} labelled {label:?}: {:?}", self.labels()));
        self.click_at(r.center());
    }

    pub fn labels(&self) -> Vec<String> {
        self.nodes.iter().map(|(l, _)| l.clone()).collect()
    }
}

#[test]
fn instance_card_buttons() {
    let dir = tempfile::tempdir().unwrap();
    let mut h = Harness::new(dir.path(), &["Alpha", "Beta"]);
    h.app.screen = Screen::Instances;
    h.step(Vec::new());
    h.step(Vec::new());
    eprintln!("labels: {:?}", h.labels());

    h.click("✏", 0);
    assert!(h.app.instance_dialog.is_some(), "Edit opens the dialog");
    h.app.instance_dialog = None;
    h.step(Vec::new());

    h.click("🗑", 1);
    assert_eq!(
        h.app.delete_dialog.as_ref().map(|d| d.name.as_str()),
        Some("Beta"),
        "Delete asks about the right instance"
    );
    h.app.delete_dialog = None;
    h.step(Vec::new());

    h.click("📋", 0);
    h.run_until(|app| app.instances.len() == 3);
}

fn fabric_jar(path: &Path, id: &str, name: &str) {
    use std::io::Write;
    let mut z = zip::ZipWriter::new(std::fs::File::create(path).unwrap());
    z.start_file("fabric.mod.json", zip::write::SimpleFileOptions::default())
        .unwrap();
    write!(
        z,
        r#"{{"id": "{id}", "name": "{name}", "version": "1.0", "depends": {{"minecraft": "1.20.1"}}}}"#
    )
    .unwrap();
    z.finish().unwrap();
}

#[test]
fn mods_screen_import_toggle_remove_dialog() {
    let dir = tempfile::tempdir().unwrap();
    let mut h = Harness::new(dir.path(), &["Alpha"]);
    h.click("🔌  Mods", 0);
    assert_eq!(h.app.screen, Screen::Mods);
    h.run_until(|app| app.mods_ui.loaded_for.is_some());
    assert_eq!(
        h.app.mods_ui.target,
        Some(crate::views::mods::ModsTarget::Instance("Alpha".into()))
    );

    let jar = dir.path().join("zoom.jar");
    fabric_jar(&jar, "zoom", "Zoomy");
    h.app.import_mod_jars(vec![jar]);
    h.run_until(|app| app.mods_ui.installed.len() == 1 && !app.mods_ui.loading);
    assert_eq!(h.app.mods_ui.installed[0].name, "Zoomy", "listed by its mod name");

    // Untick: disabled, not deleted.
    let cb = h.checkboxes[h.checkboxes.len() - 1];
    h.click_at(cb.center());
    let mods = dir.path().join("instances/Alpha/mods");
    h.run_until(|app| app.mods_ui.installed.first().is_some_and(|m| !m.enabled));
    assert!(mods.join("zoom.jar.disabled").is_file());
    let cb = h.checkboxes[h.checkboxes.len() - 1];
    h.click_at(cb.center());
    h.run_until(|app| app.mods_ui.installed.first().is_some_and(|m| m.enabled));
    assert!(mods.join("zoom.jar").is_file());

    // Remove asks first; Cancel keeps the file.
    h.click("🗑", 0);
    assert!(h.app.mods_ui.confirm_remove.is_some());
    h.step(Vec::new());
    h.click("Cancel", 0);
    assert!(h.app.mods_ui.confirm_remove.is_none());
    assert!(mods.join("zoom.jar").is_file());

    // Browse tab and the global target.
    h.click("Browse Modrinth / CurseForge", 0);
    assert_eq!(h.app.mods_ui.tab, crate::views::mods::Tab::Browse);
    h.app.mods_ui.target = Some(crate::views::mods::ModsTarget::Global);
    h.click("Installed", 0);
    h.run_until(|app| app.mods_ui.loaded_for == app.mods_ui.target);
    assert!(h.app.mods_ui.global.is_empty());
    assert!(!h.find("⟳ Apply to instances now").is_empty(), "global view shown");
}
