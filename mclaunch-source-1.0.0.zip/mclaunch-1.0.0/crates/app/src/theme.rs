//! Colours, fonts and egui style.

use std::sync::Arc;

use eframe::egui::{
    self, Color32, CornerRadius, FontData, FontDefinitions, FontFamily, FontId, Stroke, TextStyle,
};
use mclaunch_core::config::{parse_hex_color, Theme};

/// Pixel font for headers only (Press Start 2P, SIL OFL 1.1).
const PIXEL_FONT: &[u8] = include_bytes!("../assets/fonts/PressStart2P-Regular.ttf");
pub const PIXEL: &str = "pixel";

pub const ACCENT_DEFAULT: Color32 = Color32::from_rgb(0x5D, 0xBB, 0x63);
pub const DANGER: Color32 = Color32::from_rgb(0xE5, 0x53, 0x4B);
pub const WARN: Color32 = Color32::from_rgb(0xE3, 0xB3, 0x41);
pub const INFO: Color32 = Color32::from_rgb(0x5B, 0x9B, 0xD5);

#[derive(Debug, Clone, Copy)]
pub struct Palette {
    pub bg: Color32,
    pub panel: Color32,
    pub panel_hi: Color32,
    pub border: Color32,
    pub text: Color32,
    pub dim: Color32,
    pub accent: Color32,
    pub accent_text: Color32,
    pub danger: Color32,
    pub warn: Color32,
    pub info: Color32,
    pub dark: bool,
}

impl Palette {
    pub fn new(theme: Theme, accent: &str) -> Self {
        let accent = parse_hex_color(accent)
            .map(|[r, g, b]| Color32::from_rgb(r, g, b))
            .unwrap_or(ACCENT_DEFAULT);
        match theme {
            Theme::Dark => Self {
                bg: Color32::from_rgb(0x1E, 0x1F, 0x22),
                panel: Color32::from_rgb(0x2B, 0x2D, 0x31),
                panel_hi: Color32::from_rgb(0x35, 0x37, 0x3C),
                border: Color32::from_rgb(0x3F, 0x41, 0x47),
                text: Color32::from_rgb(0xE3, 0xE5, 0xE8),
                dim: Color32::from_rgb(0x9A, 0x9C, 0xA2),
                accent,
                accent_text: Color32::from_rgb(0x10, 0x14, 0x10),
                danger: DANGER,
                warn: WARN,
                info: INFO,
                dark: true,
            },
            Theme::Light => Self {
                bg: Color32::from_rgb(0xF2, 0xF3, 0xF5),
                panel: Color32::from_rgb(0xFF, 0xFF, 0xFF),
                panel_hi: Color32::from_rgb(0xE8, 0xEA, 0xED),
                border: Color32::from_rgb(0xD4, 0xD7, 0xDC),
                text: Color32::from_rgb(0x1E, 0x1F, 0x22),
                dim: Color32::from_rgb(0x5C, 0x5E, 0x66),
                accent: accent.gamma_multiply(0.85),
                accent_text: Color32::WHITE,
                danger: Color32::from_rgb(0xC9, 0x3C, 0x35),
                warn: Color32::from_rgb(0xA8, 0x7A, 0x10),
                info: Color32::from_rgb(0x2F, 0x6E, 0xB0),
                dark: false,
            },
        }
    }
}

pub fn pixel_family() -> FontFamily {
    FontFamily::Name(PIXEL.into())
}

pub fn pixel(size: f32) -> FontId {
    FontId::new(size, pixel_family())
}

pub fn install_fonts(ctx: &egui::Context) {
    let mut fonts = FontDefinitions::default();
    fonts
        .font_data
        .insert(PIXEL.into(), Arc::new(FontData::from_static(PIXEL_FONT)));
    // Fall back to the default proportional fonts for glyphs the pixel font
    // lacks (emoji, accents).
    let mut family = vec![PIXEL.to_string()];
    family.extend(
        fonts
            .families
            .get(&FontFamily::Proportional)
            .cloned()
            .unwrap_or_default(),
    );
    fonts.families.insert(pixel_family(), family);
    ctx.set_fonts(fonts);
}

pub fn apply(ctx: &egui::Context, pal: &Palette, scale: f32) {
    ctx.set_zoom_factor(scale.clamp(0.5, 3.0));
    let mut visuals = if pal.dark {
        egui::Visuals::dark()
    } else {
        egui::Visuals::light()
    };
    let r = CornerRadius::same(8);
    visuals.panel_fill = pal.bg;
    visuals.window_fill = pal.panel;
    visuals.window_stroke = Stroke::new(1.0_f32, pal.border);
    visuals.window_corner_radius = r;
    visuals.menu_corner_radius = r;
    visuals.extreme_bg_color = if pal.dark {
        Color32::from_rgb(0x18, 0x19, 0x1C)
    } else {
        Color32::from_rgb(0xFA, 0xFB, 0xFC)
    };
    visuals.faint_bg_color = pal.panel_hi;
    visuals.hyperlink_color = pal.accent;
    visuals.selection.bg_fill = pal.accent.gamma_multiply(0.55);
    visuals.selection.stroke = Stroke::new(1.0_f32, pal.accent);
    visuals.override_text_color = Some(pal.text);

    let w = &mut visuals.widgets;
    w.noninteractive.bg_fill = pal.panel;
    w.noninteractive.weak_bg_fill = pal.panel;
    w.noninteractive.bg_stroke = Stroke::new(1.0_f32, pal.border);
    w.noninteractive.fg_stroke = Stroke::new(1.0_f32, pal.text);
    w.noninteractive.corner_radius = r;
    w.inactive.bg_fill = pal.panel_hi;
    w.inactive.weak_bg_fill = pal.panel_hi;
    w.inactive.fg_stroke = Stroke::new(1.0_f32, pal.text);
    w.inactive.corner_radius = r;
    w.hovered.bg_fill = pal.panel_hi.gamma_multiply(1.15);
    w.hovered.weak_bg_fill = pal.panel_hi.gamma_multiply(1.15);
    w.hovered.bg_stroke = Stroke::new(1.0_f32, pal.accent.gamma_multiply(0.7));
    w.hovered.corner_radius = r;
    w.active.bg_fill = pal.accent.gamma_multiply(0.6);
    w.active.weak_bg_fill = pal.accent.gamma_multiply(0.6);
    w.active.corner_radius = r;
    w.open.corner_radius = r;
    ctx.set_visuals(visuals);

    ctx.style_mut(|style| {
        style.spacing.item_spacing = egui::vec2(8.0, 6.0);
        style.spacing.button_padding = egui::vec2(10.0, 5.0);
        style.spacing.interact_size.y = 26.0;
        style.text_styles.insert(TextStyle::Heading, pixel(15.0));
        style
            .text_styles
            .insert(TextStyle::Body, FontId::new(14.0, FontFamily::Proportional));
        style.text_styles.insert(
            TextStyle::Button,
            FontId::new(14.0, FontFamily::Proportional),
        );
        style.text_styles.insert(
            TextStyle::Small,
            FontId::new(11.5, FontFamily::Proportional),
        );
        style.text_styles.insert(
            TextStyle::Monospace,
            FontId::new(12.5, FontFamily::Monospace),
        );
    });
}
