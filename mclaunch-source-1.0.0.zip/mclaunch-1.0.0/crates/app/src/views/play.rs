//! Play: the selected instance card, the big PLAY button, recent instances
//! and quick-join.

use eframe::egui::{self, Align, Layout, RichText, Ui};
use mclaunch_core::config::SavedServer;
use mclaunch_core::instance::LoaderKind;
use mclaunch_java::JavaPick;

use crate::app::{McApp, Screen};
use crate::views::instances::InstanceDialog;
use crate::views::settings::open_path;
use crate::widgets;

enum Action {
    Play(String),
    Stop,
    Verify(String),
    Repair(String),
    Folder(String),
    Edit(String),
    Select(String),
    New,
    SaveServer,
    RemoveServer(usize),
    EnableShaders(String),
    AddShaderPack,
    ShaderFolder(String),
}

pub fn show(app: &mut McApp, ui: &mut Ui) {
    let pal = app.pal;
    let mut actions = Vec::new();

    let Some(inst) = app.selected_instance().cloned() else {
        widgets::pixel_heading(ui, "Play", 16.0);
        ui.add_space(12.0);
        widgets::card(ui, &pal, |ui| {
            ui.label(RichText::new("Welcome to mclaunch!").strong().size(16.0));
            ui.label(widgets::dim(
                "Create an instance to get started. Every version from rd-132211 to the newest snapshot works, offline once downloaded.",
                &pal,
            ));
            ui.add_space(8.0);
            if widgets::accent_button(ui, &pal, "+ New instance").clicked() {
                actions.push(Action::New);
            }
        });
        apply(app, actions);
        return;
    };

    let running = app.game.as_ref().is_some_and(|g| g.instance == inst.name);
    let other_running = app.game.is_some() && !running;
    let launching = app.launching.as_deref() == Some(inst.name.as_str());
    let busy = app.busy_versions.contains(&inst.version_id);

    egui::ScrollArea::vertical()
        .id_salt("play_scroll_1")
        .auto_shrink([false, false])
        .show(ui, |ui| {
            widgets::card(ui, &pal, |ui| {
                ui.horizontal(|ui| {
                    ui.label(RichText::new(&inst.icon).size(26.0));
                    widgets::pixel_heading(ui, &format!("Instance: \"{}\"", inst.name), 14.0);
                });
                ui.add_space(8.0);

                // MC 1.21.4 • Fabric 0.16 • Java 21 ✓
                ui.horizontal(|ui| {
                    ui.label(RichText::new(format!("MC {}", inst.mc_version)).strong());
                    ui.label(widgets::dim("•", &pal));
                    match inst.loader {
                        LoaderKind::Vanilla => ui.label("Vanilla"),
                        l => ui.label(format!(
                            "{l} {}",
                            inst.loader_version.as_deref().unwrap_or("")
                        )),
                    };
                    ui.label(widgets::dim("•", &pal));
                    java_status(app, ui, &inst);
                });

                // Shaders: Iris ON (BSL_v8.2.zip)
                ui.horizontal(|ui| {
                    ui.label(widgets::dim("Shaders:", &pal));
                    let summary = app.shader_status_text(&inst.name);
                    let has_engine = app
                        .shader_status
                        .get(&inst.name)
                        .is_some_and(|s| s.engine.is_some());
                    ui.label(summary);
                    if !has_engine && ui.small_button("✨ Enable shaders").clicked() {
                        actions.push(Action::EnableShaders(inst.name.clone()));
                    }
                    if ui.small_button("+ Shader pack…").clicked() {
                        actions.push(Action::AddShaderPack);
                    }
                    if ui
                        .small_button("📂")
                        .on_hover_text("Open shaderpacks/")
                        .clicked()
                    {
                        actions.push(Action::ShaderFolder(inst.name.clone()));
                    }
                });

                // GPU pre-flight: the game's own log wins, else our GL context.
                let gpu = inst
                    .gpu
                    .clone()
                    .map(|g| (g, inst.gl_version.clone(), "from the game log"))
                    .or_else(|| {
                        app.host_gl.as_ref().map(|(r, v)| {
                            (
                                format!("{r} — {v}"),
                                crate::shaders::gl_major_minor(v),
                                "detected by the launcher",
                            )
                        })
                    });
                if let Some((text, gl, source)) = gpu {
                    ui.horizontal(|ui| {
                        ui.label(widgets::dim("GPU:", &pal));
                        ui.label(text).on_hover_text(source);
                        if gl.as_deref().and_then(crate::shaders::gl_at_least_3_2) == Some(false) {
                            widgets::badge(ui, "⚠ OpenGL < 3.2: shaders will not work", pal.danger);
                        }
                    });
                }

                // Integrity line
                ui.horizontal(|ui| {
                    ui.label(widgets::dim("Integrity:", &pal));
                    match app.reports.get(&inst.version_id) {
                        Some(r) if r.is_ok() => {
                            ui.label(RichText::new(r.summary()).color(pal.accent));
                        }
                        Some(r) => {
                            ui.label(RichText::new(format!("⚠ {}", r.summary())).color(pal.danger));
                        }
                        None if app.is_installed(&inst.version_id) => {
                            ui.label(widgets::dim("installed — not verified this session", &pal));
                        }
                        None => {
                            ui.label(widgets::dim(
                                "☁ not downloaded yet (Play downloads it)",
                                &pal,
                            ));
                        }
                    }
                });
                ui.add_space(8.0);
                ui.horizontal(|ui| {
                    let installed = app.is_installed(&inst.version_id);
                    if ui
                        .add_enabled(installed && !busy, egui::Button::new("✔ Verify"))
                        .clicked()
                    {
                        actions.push(Action::Verify(inst.version_id.clone()));
                    }
                    if ui
                        .add_enabled(!busy, egui::Button::new("🛠 Repair"))
                        .clicked()
                    {
                        actions.push(Action::Repair(inst.version_id.clone()));
                    }
                    if ui.button("📂 Open folder").clicked() {
                        actions.push(Action::Folder(inst.name.clone()));
                    }
                    if ui.button("✏ Edit").clicked() {
                        actions.push(Action::Edit(inst.name.clone()));
                    }
                    if busy {
                        ui.spinner();
                    }
                });
                ui.add_space(14.0);

                ui.vertical_centered(|ui| {
                    let (label, enabled) = if running {
                        ("■  STOP", true)
                    } else if launching {
                        ("LAUNCHING…", false)
                    } else if other_running {
                        ("▶  PLAY", false)
                    } else {
                        ("▶  PLAY", !busy)
                    };
                    let resp = widgets::play_button(ui, &pal, label, enabled);
                    if resp.clicked() {
                        actions.push(if running {
                            Action::Stop
                        } else {
                            Action::Play(inst.name.clone())
                        });
                    }
                    if let Some(g) = &app.game {
                        let secs = g.started.elapsed().as_secs();
                        ui.label(widgets::dim(
                            format!(
                                "{} running for {} (pid {})",
                                g.instance,
                                widgets::play_time(secs),
                                g.pid.map(|p| p.to_string()).unwrap_or_default()
                            ),
                            &pal,
                        ));
                    } else {
                        ui.label(widgets::dim("Press Enter to play", &pal));
                    }
                });
                ui.add_space(10.0);

                // Quick join
                ui.horizontal(|ui| {
                    ui.label(widgets::dim("Join server:", &pal));
                    let current = if app.quick_join.is_empty() {
                        "None (main menu)".to_string()
                    } else {
                        app.quick_join.clone()
                    };
                    egui::ComboBox::from_id_salt("quick_join")
                        .selected_text(current)
                        .width(220.0)
                        .show_ui(ui, |ui| {
                            if ui
                                .selectable_label(app.quick_join.is_empty(), "None (main menu)")
                                .clicked()
                            {
                                app.quick_join.clear();
                            }
                            for (i, s) in app.config.servers.iter().enumerate() {
                                ui.horizontal(|ui| {
                                    if ui
                                        .selectable_label(
                                            app.quick_join == s.address,
                                            format!("{} — {}", s.name, s.address),
                                        )
                                        .clicked()
                                    {
                                        app.quick_join = s.address.clone();
                                    }
                                    if ui.small_button("🗑").clicked() {
                                        actions.push(Action::RemoveServer(i));
                                    }
                                });
                            }
                            for game in &app.lan_games {
                                let addr = game.address();
                                if ui
                                    .selectable_label(
                                        app.quick_join == addr,
                                        format!("🌐 {} — {addr}", game.motd),
                                    )
                                    .clicked()
                                {
                                    app.quick_join = addr;
                                }
                            }
                        });
                    ui.add(
                        egui::TextEdit::singleline(&mut app.quick_join)
                            .hint_text("host:port")
                            .desired_width(160.0),
                    );
                    let can_save = !app.quick_join.trim().is_empty()
                        && !app
                            .config
                            .servers
                            .iter()
                            .any(|s| s.address == app.quick_join.trim());
                    if ui
                        .add_enabled(can_save, egui::Button::new("☆ Save"))
                        .clicked()
                    {
                        actions.push(Action::SaveServer);
                    }
                });
            });

            // Recent
            let recent: Vec<String> = app
                .config
                .recent_instances
                .iter()
                .filter(|n| app.instances.iter().any(|i| &i.name == *n))
                .cloned()
                .collect();
            if !recent.is_empty() {
                ui.add_space(12.0);
                ui.horizontal_wrapped(|ui| {
                    ui.label(widgets::dim("Recent:", &pal));
                    for name in recent {
                        let icon = app
                            .instances
                            .iter()
                            .find(|i| i.name == name)
                            .map(|i| i.icon.clone())
                            .unwrap_or_default();
                        if ui
                            .selectable_label(name == inst.name, format!("{icon} {name}"))
                            .clicked()
                        {
                            actions.push(Action::Select(name));
                        }
                    }
                });
            }

            if let Some(crash) = &app.last_crash {
                ui.add_space(12.0);
                let crash = crash.clone();
                widgets::card(ui, &pal, |ui| {
                    ui.label(
                        RichText::new(format!("💥 {} crashed", crash.instance))
                            .color(pal.danger)
                            .strong(),
                    );
                    ui.label(&crash.summary);
                    for hint in &crash.hints {
                        ui.label(RichText::new(format!("💡 {hint}")).color(pal.warn));
                    }
                    ui.with_layout(Layout::left_to_right(Align::Center), |ui| {
                        if ui.button("📜 Open Logs").clicked() {
                            app.screen = Screen::Logs;
                        }
                    });
                });
            }
        });

    apply(app, actions);
}

fn java_status(app: &mut McApp, ui: &mut Ui, inst: &mclaunch_core::InstanceConfig) {
    let pal = app.pal;
    app.ensure_version_java(&inst.version_id);
    if let Some(ov) = inst.java_override.as_deref().filter(|s| !s.is_empty()) {
        ui.label(format!("Java {ov} (override)"));
        return;
    }
    match app.version_java.get(&inst.version_id).copied() {
        Some(req) if req > 0 => match mclaunch_java::pick_runtime(&app.java, req, &inst.mc_version)
        {
            JavaPick::Exact(_) => {
                ui.label(RichText::new(format!("Java {req} ✔")).color(pal.accent));
            }
            JavaPick::Compatible(r) => {
                ui.label(
                    RichText::new(format!("Java {req} → using {}", r.info.major)).color(pal.warn),
                )
                .on_hover_text("No exact match; a newer Java will be used");
            }
            JavaPick::Missing(msg) => {
                ui.label(RichText::new(format!("⚠ Java {req} missing")).color(pal.danger))
                    .on_hover_text(msg);
            }
        },
        _ => {
            ui.label(widgets::dim("Java: decided after download", &pal));
        }
    }
}

fn apply(app: &mut McApp, actions: Vec<Action>) {
    for a in actions {
        match a {
            Action::Play(n) => app.launch_instance(&n),
            Action::Stop => app.stop_game(),
            Action::Verify(id) => app.verify_version(id),
            Action::Repair(id) => app.repair_version(id),
            Action::Folder(n) => {
                let dir = app.services().paths.instance_dir(&n);
                open_path(app, &dir);
            }
            Action::Edit(n) => {
                if let Some(cfg) = app.instances.iter().find(|i| i.name == n) {
                    app.instance_dialog = Some(InstanceDialog::edit(cfg));
                }
            }
            Action::Select(n) => app.select_instance(&n),
            Action::New => app.instance_dialog = Some(InstanceDialog::new_instance(app, None)),
            Action::SaveServer => {
                let address = app.quick_join.trim().to_string();
                let name = format!("Server {}", app.config.servers.len() + 1);
                app.config.servers.push(SavedServer { name, address });
                app.save_config();
            }
            Action::EnableShaders(n) => app.enable_shaders(&n),
            Action::AddShaderPack => app.pick_shader_packs(),
            Action::ShaderFolder(n) => {
                let dir = app.services().paths.instance_dir(&n).join("shaderpacks");
                open_path(app, &dir);
            }
            Action::RemoveServer(i) => {
                if i < app.config.servers.len() {
                    app.config.servers.remove(i);
                    app.save_config();
                }
            }
        }
    }
}
