//! Servers: create/start/stop local servers, live console, properties form,
//! EULA checkbox and RAM.

use std::collections::HashSet;

use eframe::egui::{self, Align, Layout, RichText, Ui};
use mclaunch_core::manifest::VersionType;
use mclaunch_loaders::{LoaderVersion, Loaders};
use mclaunch_server::{ServerConfig, ServerKind, ServerProperties};

use crate::app::{McApp, ToastKind};
use crate::views::settings::open_path;
use crate::widgets;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum ServerTab {
    #[default]
    Console,
    Properties,
}

pub struct NewServerDialog {
    pub name: String,
    pub kind: ServerKind,
    pub mc: String,
    pub ram_mb: u32,
    pub versions_for: Option<(ServerKind, String)>,
    pub versions: Option<Result<Vec<LoaderVersion>, String>>,
    pub loader_version: Option<String>,
    pub error: Option<String>,
}

#[derive(Default)]
pub struct ServersUi {
    pub selected: Option<String>,
    pub installing: HashSet<String>,
    pub new_dialog: Option<NewServerDialog>,
    pub delete: Option<(String, String)>,
    pub console_input: String,
    pub tab: ServerTab,
    /// Editable copy of the selected server's properties.
    pub props: Option<(String, ServerProperties)>,
}

enum Action {
    New,
    Select(String),
    Start(String),
    Stop(String),
    Send(String, String),
    Eula(String, bool),
    SaveRam(String, u32),
    SaveProps(String),
    ReloadProps(String),
    Folder(String),
    Update(String),
    Delete(String),
    Join(u16),
}

pub fn show(app: &mut McApp, ui: &mut Ui) {
    let pal = app.pal;
    let mut actions = Vec::new();
    ui.horizontal(|ui| {
        widgets::pixel_heading(ui, "Servers", 16.0);
        ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
            if widgets::accent_button(ui, &pal, "+ New server").clicked() {
                actions.push(Action::New);
            }
        });
    });
    ui.add_space(10.0);

    if app.servers_ui.selected.is_none() {
        app.servers_ui.selected = app.servers.first().map(|s| s.name.clone());
    }
    let selected = app.servers_ui.selected.clone();

    ui.horizontal_top(|ui| {
        // List
        ui.vertical(|ui| {
            ui.set_width(210.0);
            if app.servers.is_empty() {
                widgets::card(ui, &pal, |ui| {
                    ui.label("No servers yet.");
                    ui.label(widgets::dim("Vanilla, Paper, Purpur, Folia, Spigot, Fabric, Forge or NeoForge.", &pal));
                });
            }
            for s in &app.servers {
                let running = app.running_servers.contains_key(&s.name);
                let is_sel = selected.as_deref() == Some(s.name.as_str());
                let text = format!("{} {}\n{} {}", if running { "▶" } else { "■" }, s.name, s.kind.label(), s.mc_version);
                let resp = ui.add_sized(
                    [210.0, 44.0],
                    egui::Button::new(RichText::new(text).color(if is_sel { pal.accent_text } else { pal.text }))
                        .fill(if is_sel { pal.accent } else { pal.panel })
                        .corner_radius(egui::CornerRadius::same(8)),
                );
                if resp.clicked() {
                    actions.push(Action::Select(s.name.clone()));
                }
            }
        });
        ui.add_space(12.0);

        // Details
        ui.vertical(|ui| {
            let Some(cfg) = selected.as_ref().and_then(|n| app.servers.iter().find(|s| &s.name == n)).cloned() else {
                return;
            };
            let dir = app.services().paths.server_dir(&cfg.name);
            let running = app.running_servers.get(&cfg.name).map(|r| r.started);
            let installing = app.servers_ui.installing.contains(&cfg.name);
            let installed = cfg.is_installed(&app.services().paths);
            let eula = mclaunch_server::eula_accepted(&dir);
            if app.servers_ui.props.as_ref().map(|(n, _)| n != &cfg.name).unwrap_or(true) {
                actions.push(Action::ReloadProps(cfg.name.clone()));
            }

            widgets::card(ui, &pal, |ui| {
                ui.horizontal(|ui| {
                    widgets::pixel_heading(ui, &cfg.name, 14.0);
                    widgets::badge(ui, format!("{} {}", cfg.kind.label(), cfg.mc_version), pal.info);
                    if let Some(lv) = &cfg.loader_version {
                        widgets::badge(ui, lv, pal.dim);
                    }
                    match running {
                        Some(t) => {
                            widgets::badge(ui, format!("▶ running {}", widgets::play_time(t.elapsed().as_secs())), pal.accent);
                        }
                        None if !installed => {
                            widgets::badge(ui, "not installed", pal.warn);
                        }
                        None => {
                            widgets::badge(ui, "stopped", pal.dim);
                        }
                    }
                });
                ui.add_space(8.0);
                ui.horizontal(|ui| {
                    if running.is_some() {
                        if ui.button("■ Stop").clicked() {
                            actions.push(Action::Stop(cfg.name.clone()));
                        }
                    } else if ui
                        .add_enabled(installed && eula && !installing, egui::Button::new("▶ Start"))
                        .on_disabled_hover_text("Install the server and accept the EULA first")
                        .clicked()
                    {
                        actions.push(Action::Start(cfg.name.clone()));
                    }
                    let port = app.servers_ui.props.as_ref().map(|(_, p)| p.port()).unwrap_or(25565);
                    if ui
                        .add_enabled(running.is_some() && app.game.is_none(), egui::Button::new("🎮 Join with selected instance"))
                        .clicked()
                    {
                        actions.push(Action::Join(port));
                    }
                    if ui.button("📂 Folder").clicked() {
                        actions.push(Action::Folder(cfg.name.clone()));
                    }
                    if installing {
                        ui.spinner();
                    } else if ui
                        .add_enabled(running.is_none(), egui::Button::new(if installed { "⟳ Reinstall/update" } else { "⬇ Install" }))
                        .on_hover_text("Re-downloads the server software; worlds, plugins and mods are kept")
                        .clicked()
                    {
                        actions.push(Action::Update(cfg.name.clone()));
                    }
                    if ui.add_enabled(running.is_none(), egui::Button::new("🗑")).on_hover_text("Delete (recycle bin)").clicked() {
                        actions.push(Action::Delete(cfg.name.clone()));
                    }
                });
                ui.add_space(6.0);
                ui.horizontal(|ui| {
                    let mut accepted = eula;
                    if ui.checkbox(&mut accepted, "I accept the Minecraft EULA").changed() {
                        actions.push(Action::Eula(cfg.name.clone(), accepted));
                    }
                    if ui.link("(read it)").clicked() {
                        let _ = open::that_detached("https://aka.ms/MinecraftEULA");
                    }
                    ui.add_space(16.0);
                    let mut ram = cfg.ram_mb;
                    ui.label("RAM");
                    if ui
                        .add(egui::Slider::new(&mut ram, 512..=16384).step_by(256.0).suffix(" MB"))
                        .changed()
                    {
                        actions.push(Action::SaveRam(cfg.name.clone(), ram));
                    }
                });
                if let Some((_, props)) = &app.servers_ui.props {
                    if !props.online_mode() {
                        ui.add_space(6.0);
                        egui::Frame::new()
                            .fill(pal.warn.gamma_multiply(0.15))
                            .corner_radius(egui::CornerRadius::same(6))
                            .inner_margin(egui::Margin::same(8))
                            .show(ui, |ui| {
                                ui.label(
                                    RichText::new(
                                        "⚠ online-mode=false: anyone can join with any name. Only use this for LAN / private play, and use a whitelist if the port is reachable from the internet.",
                                    )
                                    .color(pal.warn),
                                );
                            });
                    }
                }
            });
            ui.add_space(8.0);
            ui.horizontal(|ui| {
                ui.selectable_value(&mut app.servers_ui.tab, ServerTab::Console, "Console");
                ui.selectable_value(&mut app.servers_ui.tab, ServerTab::Properties, "server.properties");
            });
            ui.add_space(4.0);
            match app.servers_ui.tab {
                ServerTab::Console => console(app, ui, &cfg, running.is_some(), &mut actions),
                ServerTab::Properties => properties_form(app, ui, &cfg, &mut actions),
            }
        });
    });

    new_server_dialog(app, ui.ctx());
    delete_dialog(app, ui.ctx());

    for a in actions {
        match a {
            Action::New => {
                let mc = app
                    .manifest
                    .as_ref()
                    .map(|m| m.latest.release.clone())
                    .unwrap_or_default();
                let name = unique_server_name(app, "My Server");
                app.servers_ui.new_dialog = Some(NewServerDialog {
                    name,
                    kind: ServerKind::Paper,
                    mc,
                    ram_mb: 2048,
                    versions_for: None,
                    versions: None,
                    loader_version: None,
                    error: None,
                });
            }
            Action::Select(n) => app.servers_ui.selected = Some(n),
            Action::Start(n) => app.start_server(&n),
            Action::Stop(n) => app.stop_server(&n),
            Action::Send(n, c) => app.send_server_command(&n, c),
            Action::Eula(n, accepted) => {
                let svc = app.services().clone();
                if let Err(e) =
                    mclaunch_server::set_eula(&svc.safe, &svc.paths.server_dir(&n), accepted)
                {
                    app.toast(ToastKind::Error, e.to_string());
                }
            }
            Action::SaveRam(n, ram) => {
                if let Some(s) = app.servers.iter_mut().find(|s| s.name == n) {
                    s.ram_mb = ram;
                    let s = s.clone();
                    let svc = app.services().clone();
                    if let Err(e) = s.save(&svc.paths, &svc.safe) {
                        app.toast(ToastKind::Error, e.to_string());
                    }
                }
            }
            Action::SaveProps(n) => {
                if let Some((_, props)) = app.servers_ui.props.clone() {
                    app.save_server_properties(&n, &props);
                }
            }
            Action::ReloadProps(n) => {
                let dir = app.services().paths.server_dir(&n);
                app.servers_ui.props = Some((n, mclaunch_server::read_properties(&dir)));
            }
            Action::Folder(n) => {
                let dir = app.services().paths.server_dir(&n);
                open_path(app, &dir);
            }
            Action::Update(n) => {
                if let Some(cfg) = app.servers.iter().find(|s| s.name == n).cloned() {
                    app.install_server(cfg, false);
                }
            }
            Action::Delete(n) => app.servers_ui.delete = Some((n, String::new())),
            Action::Join(port) => app.join_local_server(port),
        }
    }
}

fn unique_server_name(app: &McApp, base: &str) -> String {
    let paths = &app.services().paths;
    if !paths.server_dir(base).exists() {
        return base.to_string();
    }
    (2..)
        .map(|n| format!("{base} {n}"))
        .find(|n| !paths.server_dir(n).exists())
        .unwrap_or_else(|| base.to_string())
}

fn console(
    app: &mut McApp,
    ui: &mut Ui,
    cfg: &ServerConfig,
    running: bool,
    actions: &mut Vec<Action>,
) {
    let pal = app.pal;
    let empty = Default::default();
    let lines = app.server_logs.get(&cfg.name).unwrap_or(&empty);
    egui::Frame::new()
        .fill(ui.visuals().extreme_bg_color)
        .corner_radius(egui::CornerRadius::same(8))
        .inner_margin(egui::Margin::same(8))
        .show(ui, |ui| {
            let row_h = ui.text_style_height(&egui::TextStyle::Monospace);
            egui::ScrollArea::both()
                .id_salt("servers_scroll_1")
                .auto_shrink([false, false])
                .max_height(ui.available_height() - 44.0)
                .stick_to_bottom(true)
                .show_rows(ui, row_h, lines.len(), |ui, range| {
                    ui.style_mut().wrap_mode = Some(egui::TextWrapMode::Extend);
                    for l in lines.iter().skip(range.start).take(range.len()) {
                        let color = if l.contains("ERROR") || l.contains("Exception") {
                            pal.danger
                        } else if l.contains("WARN") {
                            pal.warn
                        } else if l.starts_with("[mclaunch]") || l.starts_with("> ") {
                            pal.accent
                        } else {
                            pal.text
                        };
                        ui.label(
                            RichText::new(l)
                                .font(egui::FontId::monospace(12.5))
                                .color(color),
                        );
                    }
                });
            if lines.is_empty() {
                ui.label(widgets::dim("Server output appears here.", &pal));
            }
        });
    ui.horizontal(|ui| {
        let resp = ui.add_enabled(
            running,
            egui::TextEdit::singleline(&mut app.servers_ui.console_input)
                .hint_text("command (e.g. op Venkat, say hi, stop)")
                .desired_width(ui.available_width() - 80.0),
        );
        let enter = resp.lost_focus() && ui.input(|i| i.key_pressed(egui::Key::Enter));
        if (ui.add_enabled(running, egui::Button::new("Send")).clicked() || enter)
            && !app.servers_ui.console_input.trim().is_empty()
        {
            let cmd = std::mem::take(&mut app.servers_ui.console_input);
            actions.push(Action::Send(
                cfg.name.clone(),
                cmd.trim().trim_start_matches('/').to_string(),
            ));
            resp.request_focus();
        }
    });
}

fn properties_form(app: &mut McApp, ui: &mut Ui, cfg: &ServerConfig, actions: &mut Vec<Action>) {
    let pal = app.pal;
    let Some((_, props)) = &mut app.servers_ui.props else {
        return;
    };
    egui::ScrollArea::vertical()
        .id_salt("servers_scroll_2")
        .auto_shrink([false, false])
        .show(ui, |ui| {
            widgets::card(ui, &pal, |ui| {
                egui::Grid::new("props")
                    .num_columns(2)
                    .spacing([20.0, 8.0])
                    .show(ui, |ui| {
                        text_prop(ui, props, "motd", "Message of the day");
                        num_prop(ui, props, "server-port", "Port", 1, 65535);
                        num_prop(ui, props, "max-players", "Max players", 1, 1000);
                        choice_prop(
                            ui,
                            props,
                            "gamemode",
                            "Game mode",
                            &["survival", "creative", "adventure", "spectator"],
                        );
                        choice_prop(
                            ui,
                            props,
                            "difficulty",
                            "Difficulty",
                            &["peaceful", "easy", "normal", "hard"],
                        );
                        bool_prop(ui, props, "pvp", "PvP");
                        bool_prop(
                            ui,
                            props,
                            "online-mode",
                            "Online mode (Microsoft accounts only)",
                        );
                        bool_prop(ui, props, "white-list", "Whitelist");
                        bool_prop(ui, props, "allow-flight", "Allow flight");
                        bool_prop(ui, props, "enable-command-block", "Command blocks");
                        num_prop(ui, props, "view-distance", "View distance", 2, 32);
                        num_prop(ui, props, "spawn-protection", "Spawn protection", 0, 256);
                        text_prop(ui, props, "level-name", "World folder");
                        text_prop(ui, props, "level-seed", "Seed");
                    });
                ui.add_space(8.0);
                ui.horizontal(|ui| {
                    if widgets::accent_button(ui, &pal, "💾 Save").clicked() {
                        actions.push(Action::SaveProps(cfg.name.clone()));
                    }
                    if ui.button("Revert").clicked() {
                        actions.push(Action::ReloadProps(cfg.name.clone()));
                    }
                    ui.label(widgets::dim(
                        "Other keys in server.properties are kept as they are.",
                        &pal,
                    ));
                });
            });
        });
}

fn text_prop(ui: &mut Ui, p: &mut ServerProperties, key: &str, label: &str) {
    ui.label(label);
    let mut v = p.get(key).unwrap_or("").to_string();
    if ui
        .add(egui::TextEdit::singleline(&mut v).desired_width(260.0))
        .changed()
    {
        p.set(key, &v);
    }
    ui.end_row();
}

fn num_prop(ui: &mut Ui, p: &mut ServerProperties, key: &str, label: &str, min: i64, max: i64) {
    ui.label(label);
    let mut v: i64 = p
        .get(key)
        .and_then(|s| s.trim().parse().ok())
        .unwrap_or(min);
    if ui
        .add(egui::DragValue::new(&mut v).range(min..=max))
        .changed()
    {
        p.set(key, &v.to_string());
    }
    ui.end_row();
}

fn bool_prop(ui: &mut Ui, p: &mut ServerProperties, key: &str, label: &str) {
    ui.label(label);
    let mut v = p.get(key).map(|s| s.trim() == "true").unwrap_or(false);
    if ui.checkbox(&mut v, "").changed() {
        p.set(key, if v { "true" } else { "false" });
    }
    ui.end_row();
}

fn choice_prop(ui: &mut Ui, p: &mut ServerProperties, key: &str, label: &str, options: &[&str]) {
    ui.label(label);
    let current = p.get(key).unwrap_or(options[0]).trim().to_string();
    egui::ComboBox::from_id_salt(key)
        .selected_text(&current)
        .show_ui(ui, |ui| {
            for o in options {
                if ui.selectable_label(current == *o, *o).clicked() {
                    p.set(key, o);
                }
            }
        });
    ui.end_row();
}

fn new_server_dialog(app: &mut McApp, ctx: &egui::Context) {
    let Some(mut dlg) = app.servers_ui.new_dialog.take() else {
        return;
    };
    let pal = app.pal;
    // Fetch loader versions when needed.
    if dlg.kind.needs_loader_version()
        && dlg.versions_for.as_ref() != Some(&(dlg.kind, dlg.mc.clone()))
        && !dlg.mc.is_empty()
    {
        dlg.versions_for = Some((dlg.kind, dlg.mc.clone()));
        dlg.versions = None;
        dlg.loader_version = None;
        if let Some(software) = dlg.kind.software() {
            let loaders = Loaders::new(app.services().installer());
            let (kind, mc) = (dlg.kind, dlg.mc.clone());
            let b = app.backend.clone();
            app.backend.spawn(async move {
                let res = loaders
                    .versions(software, &mc)
                    .await
                    .map(|(v, _)| v)
                    .map_err(|e| e.to_string());
                b.apply(move |app| {
                    if let Some(d) = &mut app.servers_ui.new_dialog {
                        if d.versions_for == Some((kind, mc)) {
                            if let Ok(v) = &res {
                                d.loader_version = v
                                    .iter()
                                    .find(|x| x.recommended)
                                    .or_else(|| v.iter().find(|x| x.stable))
                                    .or(v.first())
                                    .map(|x| x.version.clone());
                            }
                            d.versions = Some(res);
                        }
                    }
                });
            });
        }
    }
    let mut open = true;
    let mut create = false;
    egui::Window::new("New server")
        .collapsible(false)
        .resizable(false)
        .anchor(egui::Align2::CENTER_CENTER, [0.0, 0.0])
        .open(&mut open)
        .show(ctx, |ui| {
            ui.set_width(460.0);
            egui::Grid::new("new_server").num_columns(2).spacing([16.0, 10.0]).show(ui, |ui| {
                ui.label("Name");
                ui.add(egui::TextEdit::singleline(&mut dlg.name).desired_width(260.0));
                ui.end_row();
                ui.label("Software");
                egui::ComboBox::from_id_salt("server_kind")
                    .selected_text(dlg.kind.label())
                    .show_ui(ui, |ui| {
                        for k in ServerKind::ALL {
                            ui.selectable_value(&mut dlg.kind, k, k.label());
                        }
                    });
                ui.end_row();
                ui.label("Minecraft version");
                egui::ComboBox::from_id_salt("server_mc")
                    .selected_text(&dlg.mc)
                    .height(300.0)
                    .show_ui(ui, |ui| {
                        if let Some(m) = &app.manifest {
                            for e in m.versions.iter().filter(|e| e.kind == VersionType::Release) {
                                ui.selectable_value(&mut dlg.mc, e.id.clone(), &e.id);
                            }
                        }
                    });
                ui.end_row();
                if dlg.kind.needs_loader_version() {
                    ui.label(format!("{} version", dlg.kind.label()));
                    match &dlg.versions {
                        None => {
                            ui.spinner();
                        }
                        Some(Err(e)) => {
                            ui.label(RichText::new(e).color(pal.danger));
                        }
                        Some(Ok(v)) if v.is_empty() => {
                            ui.label(RichText::new(format!("No {} for {}", dlg.kind.label(), dlg.mc)).color(pal.warn));
                        }
                        Some(Ok(v)) => {
                            let mc = dlg.mc.clone();
                            let shown = |s: &str| s.strip_prefix(&format!("{mc}-")).unwrap_or(s).to_string();
                            let current = dlg.loader_version.clone().unwrap_or_default();
                            egui::ComboBox::from_id_salt("server_loader")
                                .selected_text(shown(&current))
                                .height(300.0)
                                .show_ui(ui, |ui| {
                                    for x in v {
                                        let label = if x.recommended { format!("{} ★", shown(&x.version)) } else { shown(&x.version) };
                                        if ui.selectable_label(current == x.version, label).clicked() {
                                            dlg.loader_version = Some(x.version.clone());
                                        }
                                    }
                                });
                        }
                    }
                    ui.end_row();
                }
                ui.label("RAM");
                ui.add(egui::Slider::new(&mut dlg.ram_mb, 512..=16384).step_by(256.0).suffix(" MB"));
                ui.end_row();
            });
            ui.add_space(6.0);
            ui.label(widgets::dim(
                "Local servers start with online-mode=false so offline profiles can join. You'll accept the EULA yourself before the first start.",
                &pal,
            ));
            if dlg.kind == ServerKind::Spigot {
                ui.label(widgets::dim("Spigot is built from source with BuildTools (needs git on Linux/macOS; takes a few minutes).", &pal));
            }
            if let Some(e) = &dlg.error {
                ui.label(RichText::new(e).color(pal.danger));
            }
            ui.add_space(6.0);
            if widgets::accent_button(ui, &pal, "Create server").clicked() {
                create = true;
            }
        });
    if create {
        let err = if let Err(e) = mclaunch_core::instance::validate_name(&dlg.name) {
            Some(e)
        } else if app.services().paths.server_dir(&dlg.name).exists() {
            Some("A server with that name already exists".into())
        } else if dlg.mc.is_empty() {
            Some("Choose a Minecraft version".into())
        } else if dlg.kind.needs_loader_version() && dlg.loader_version.is_none() {
            Some("Choose a loader version".into())
        } else {
            None
        };
        if let Some(e) = err {
            dlg.error = Some(e);
            app.servers_ui.new_dialog = Some(dlg);
            return;
        }
        let cfg = ServerConfig {
            name: dlg.name.clone(),
            kind: dlg.kind,
            mc_version: dlg.mc.clone(),
            loader_version: dlg.loader_version.clone(),
            ram_mb: dlg.ram_mb,
            ..Default::default()
        };
        let svc = app.services().clone();
        if let Err(e) = cfg.save(&svc.paths, &svc.safe) {
            dlg.error = Some(e.to_string());
            app.servers_ui.new_dialog = Some(dlg);
            return;
        }
        app.servers.push(cfg.clone());
        app.servers_ui.selected = Some(cfg.name.clone());
        app.install_server(cfg, true);
        return;
    }
    if open {
        app.servers_ui.new_dialog = Some(dlg);
    }
}

fn delete_dialog(app: &mut McApp, ctx: &egui::Context) {
    let Some((name, typed)) = &mut app.servers_ui.delete else {
        return;
    };
    let pal = app.pal;
    let mut open = true;
    let mut confirm = false;
    egui::Window::new("Delete server")
        .collapsible(false)
        .resizable(false)
        .anchor(egui::Align2::CENTER_CENTER, [0.0, 0.0])
        .open(&mut open)
        .show(ctx, |ui| {
            ui.set_width(400.0);
            ui.label(
                RichText::new(format!(
                    "Move server \"{name}\" (including its worlds) to the recycle bin?"
                ))
                .strong(),
            );
            ui.label(format!("Type {name} to confirm:"));
            ui.add(egui::TextEdit::singleline(typed).desired_width(f32::INFINITY));
            let ok = typed == name;
            if ui
                .add_enabled(
                    ok,
                    egui::Button::new(
                        RichText::new("🗑 Move to recycle bin").color(egui::Color32::WHITE),
                    )
                    .fill(if ok { pal.danger } else { pal.panel_hi }),
                )
                .clicked()
            {
                confirm = true;
            }
        });
    if confirm {
        let (n, t) = (name.clone(), typed.clone());
        app.servers_ui.delete = None;
        app.trash_server(n, t);
    } else if !open {
        app.servers_ui.delete = None;
    }
}
