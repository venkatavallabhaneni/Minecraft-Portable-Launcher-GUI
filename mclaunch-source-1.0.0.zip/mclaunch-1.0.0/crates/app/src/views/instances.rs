//! Instances: card grid plus the New/Edit/Delete dialogs.

use eframe::egui::{self, Align, Layout, RichText, Ui};
use mclaunch_core::instance::{validate_name, InstanceConfig, LoaderKind, DEFAULT_JVM_ARGS};
use mclaunch_core::manifest::VersionType;

use crate::app::{McApp, Screen, ToastKind};
use crate::views::settings::open_path;
use crate::widgets;

pub const ICONS: &[&str] = &[
    "⛏", "⚒", "🌍", "🎮", "⚡", "★", "☕", "🌙", "☀", "🔒", "🛠", "📦",
];

pub struct InstanceDialog {
    /// Original name when editing; `None` for a new instance.
    pub editing: Option<String>,
    pub cfg: InstanceConfig,
    pub version_search: String,
    pub show_snapshots: bool,
    pub show_old: bool,
    pub custom_java: String,
    pub error: Option<String>,
}

impl InstanceDialog {
    pub fn new_instance(app: &McApp, version: Option<&str>) -> Self {
        let version = version
            .map(str::to_string)
            .or_else(|| app.manifest.as_ref().map(|m| m.latest.release.clone()))
            .unwrap_or_default();
        let base = if version.is_empty() {
            "New instance".to_string()
        } else {
            format!("Minecraft {version}")
        };
        let name = mclaunch_core::instance::unique_name(&app.services().paths, &base);
        Self {
            editing: None,
            cfg: InstanceConfig::new(&name, &version, app.config.default_ram_mb),
            version_search: String::new(),
            show_snapshots: false,
            show_old: false,
            custom_java: String::new(),
            error: None,
        }
    }

    pub fn edit(cfg: &InstanceConfig) -> Self {
        let custom_java = cfg
            .java_override
            .clone()
            .filter(|j| j.parse::<u32>().is_err())
            .unwrap_or_default();
        Self {
            editing: Some(cfg.name.clone()),
            cfg: cfg.clone(),
            version_search: String::new(),
            show_snapshots: false,
            show_old: false,
            custom_java,
            error: None,
        }
    }
}

pub struct DeleteDialog {
    pub name: String,
    pub typed: String,
}

enum Action {
    Select(String),
    Play(String),
    Edit(String),
    Duplicate(String),
    Delete(String),
    Folder(String),
    New,
    ImportModpack,
}

pub fn show(app: &mut McApp, ui: &mut Ui) {
    let pal = app.pal;
    let mut actions = Vec::new();
    ui.horizontal(|ui| {
        widgets::pixel_heading(ui, "Instances", 16.0);
        ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
            if widgets::accent_button(ui, &pal, "+ New instance").clicked() {
                actions.push(Action::New);
            }
            if ui.button("📥 Import modpack…").clicked() {
                actions.push(Action::ImportModpack);
            }
        });
    });
    ui.add_space(10.0);

    if app.instances.is_empty() {
        widgets::card(ui, &pal, |ui| {
            ui.label("No instances yet.");
            ui.label(widgets::dim(
                "An instance is a game folder (saves, mods, shaders…) plus the version and settings used to play it.",
                &pal,
            ));
            ui.add_space(6.0);
            if widgets::accent_button(ui, &pal, "+ Create your first instance").clicked() {
                actions.push(Action::New);
            }
        });
    }

    let selected = app.selected_instance().map(|i| i.name.clone());
    let running = app.game.as_ref().map(|g| g.instance.clone());
    egui::ScrollArea::vertical()
        .id_salt("instances_scroll_1")
        .auto_shrink([false, false])
        .show(ui, |ui| {
            ui.horizontal_wrapped(|ui| {
                ui.spacing_mut().item_spacing = egui::vec2(12.0, 12.0);
                for inst in &app.instances {
                    let is_sel = selected.as_deref() == Some(inst.name.as_str());
                    let is_running = running.as_deref() == Some(inst.name.as_str());
                    let resp = widgets::clickable_area(ui, egui::vec2(262.0, 168.0), |ui| {
                                egui::Frame::new()
                                    .fill(pal.panel)
                                    .stroke(egui::Stroke::new(
                                        if is_sel { 2.0_f32 } else { 1.0_f32 },
                                        if is_sel { pal.accent } else { pal.border },
                                    ))
                                    .corner_radius(egui::CornerRadius::same(8))
                                    .inner_margin(egui::Margin::same(12))
                                    .show(ui, |ui| {
                                        ui.set_width(236.0);
                                        ui.set_height(140.0);
                                        ui.horizontal(|ui| {
                                            ui.label(RichText::new(&inst.icon).size(30.0));
                                            ui.vertical(|ui| {
                                                ui.add(
                                                    egui::Label::new(
                                                        RichText::new(&inst.name)
                                                            .strong()
                                                            .size(15.0),
                                                    )
                                                    .truncate(),
                                                );
                                                let loader = match inst.loader {
                                                    LoaderKind::Vanilla => "Vanilla".to_string(),
                                                    l => format!(
                                                        "{l} {}",
                                                        inst.loader_version
                                                            .as_deref()
                                                            .unwrap_or("")
                                                    ),
                                                };
                                                ui.add(
                                                    egui::Label::new(widgets::dim(
                                                        format!(
                                                            "MC {} · {loader}",
                                                            inst.mc_version
                                                        ),
                                                        &pal,
                                                    ))
                                                    .truncate(),
                                                );
                                            });
                                        });
                                        ui.add_space(4.0);
                                        let played = match inst.last_played {
                                            Some(t) => format!(
                                                "Played {} · {}",
                                                widgets::ago(t),
                                                widgets::play_time(inst.play_time_secs)
                                            ),
                                            None => "Never played".into(),
                                        };
                                        ui.label(widgets::dim(played, &pal));
                                        ui.horizontal(|ui| {
                                            if is_running {
                                                widgets::badge(ui, "▶ running", pal.accent);
                                            }
                                            if inst.shaders {
                                                widgets::badge(ui, "Shaders", pal.info);
                                            }
                                        });
                                        ui.with_layout(Layout::bottom_up(Align::LEFT), |ui| {
                                            ui.horizontal(|ui| {
                                                if ui.button("▶ Play").clicked() {
                                                    actions.push(Action::Play(inst.name.clone()));
                                                }
                                                if ui.button("✏").on_hover_text("Edit").clicked()
                                                {
                                                    actions.push(Action::Edit(inst.name.clone()));
                                                }
                                                if ui
                                                    .button("📋")
                                                    .on_hover_text("Duplicate")
                                                    .clicked()
                                                {
                                                    actions
                                                        .push(Action::Duplicate(inst.name.clone()));
                                                }
                                                if ui
                                                    .button("📂")
                                                    .on_hover_text("Open folder")
                                                    .clicked()
                                                {
                                                    actions.push(Action::Folder(inst.name.clone()));
                                                }
                                                if ui
                                                    .button("🗑")
                                                    .on_hover_text("Delete (recycle bin)")
                                                    .clicked()
                                                {
                                                    actions.push(Action::Delete(inst.name.clone()));
                                                }
                                            });
                                        });
                                    });
                    });
                    if resp.clicked() {
                        actions.push(Action::Select(inst.name.clone()));
                    }
                    if resp.double_clicked() {
                        actions.push(Action::Play(inst.name.clone()));
                    }
                }
            });
        });

    for a in actions {
        match a {
            Action::Select(n) => app.select_instance(&n),
            Action::Play(n) => {
                app.select_instance(&n);
                app.screen = Screen::Play;
                app.launch_instance(&n);
            }
            Action::Edit(n) => {
                if let Some(cfg) = app.instances.iter().find(|i| i.name == n) {
                    app.instance_dialog = Some(InstanceDialog::edit(cfg));
                }
            }
            Action::Duplicate(n) => app.duplicate_instance(&n),
            Action::Delete(n) => {
                app.delete_dialog = Some(DeleteDialog {
                    name: n,
                    typed: String::new(),
                })
            }
            Action::Folder(n) => {
                let dir = app.services().paths.instance_dir(&n);
                open_path(app, &dir);
            }
            Action::New => app.instance_dialog = Some(InstanceDialog::new_instance(app, None)),
            Action::ImportModpack => {
                app.screen = Screen::Modpacks;
                app.pick_modpack();
            }
        }
    }
}

/// Version picker shared by the instance dialog: manifest + installed ids.
fn version_picker(app: &McApp, ui: &mut Ui, dlg: &mut InstanceDialog) {
    let pal = app.pal;
    ui.horizontal(|ui| {
        ui.add(
            egui::TextEdit::singleline(&mut dlg.version_search)
                .hint_text("🔍 filter")
                .desired_width(120.0),
        );
        ui.checkbox(&mut dlg.show_snapshots, "Snapshots");
        ui.checkbox(&mut dlg.show_old, "Beta/Alpha");
    });
    let search = dlg.version_search.trim().to_lowercase();
    let mut ids: Vec<(String, String)> = Vec::new();
    for v in &app.installed {
        if v.inherits_from.is_some() {
            ids.push((v.id.clone(), "loader".into()));
        }
    }
    if let Some(m) = &app.manifest {
        for e in &m.versions {
            let ok = match e.kind {
                VersionType::Release => true,
                VersionType::Snapshot => dlg.show_snapshots,
                VersionType::OldBeta | VersionType::OldAlpha => dlg.show_old,
                VersionType::Other(_) => dlg.show_snapshots,
            };
            if ok {
                ids.push((e.id.clone(), e.kind.label().to_string()));
            }
        }
    } else {
        for v in &app.installed {
            if v.inherits_from.is_none() {
                ids.push((v.id.clone(), "installed".into()));
            }
        }
    }
    ids.retain(|(id, _)| search.is_empty() || id.to_lowercase().contains(&search));
    egui::ComboBox::from_id_salt("version_pick")
        .selected_text(if dlg.cfg.version_id.is_empty() {
            "Choose a version…".to_string()
        } else {
            dlg.cfg.version_id.clone()
        })
        .width(260.0)
        .height(320.0)
        .show_ui(ui, |ui| {
            for (id, kind) in &ids {
                let installed = app.is_installed(id);
                let text = format!("{}{id}   ({kind})", if installed { "✔ " } else { "" });
                if ui
                    .selectable_label(dlg.cfg.version_id == *id, RichText::new(text))
                    .clicked()
                {
                    dlg.cfg.version_id = id.clone();
                    // Loader profiles keep their own mc_version.
                    match app
                        .installed
                        .iter()
                        .find(|v| v.id == *id && v.inherits_from.is_some())
                    {
                        Some(v) => {
                            dlg.cfg.mc_version = v.inherits_from.clone().unwrap_or_default();
                            if let Some((kind, ver)) = mclaunch_loaders::detect_loader(id) {
                                dlg.cfg.loader = kind;
                                dlg.cfg.loader_version = Some(ver);
                            }
                        }
                        None => {
                            dlg.cfg.mc_version = id.clone();
                            dlg.cfg.loader = LoaderKind::Vanilla;
                            dlg.cfg.loader_version = None;
                        }
                    }
                }
            }
            if ids.is_empty() {
                ui.label(widgets::dim("No matching versions", &pal));
            }
        });
}

pub fn dialog(app: &mut McApp, ctx: &egui::Context) {
    let Some(mut dlg) = app.instance_dialog.take() else {
        return;
    };
    let pal = app.pal;
    let mut open = true;
    let mut save = false;
    let mut cancel = false;
    let title = if dlg.editing.is_some() {
        "Edit instance"
    } else {
        "New instance"
    };
    egui::Window::new(title)
        .collapsible(false)
        .resizable(false)
        .anchor(egui::Align2::CENTER_CENTER, [0.0, 0.0])
        .open(&mut open)
        .show(ctx, |ui| {
            ui.set_width(560.0);
            egui::ScrollArea::vertical()
        .id_salt("instances_scroll_2").max_height(520.0).show(ui, |ui| {
                egui::Grid::new("inst_form").num_columns(2).spacing([16.0, 10.0]).show(ui, |ui| {
                    ui.label("Name");
                    ui.add_enabled(
                        dlg.editing.is_none(),
                        egui::TextEdit::singleline(&mut dlg.cfg.name).desired_width(300.0),
                    )
                    .on_disabled_hover_text("The folder name can't change; duplicate the instance to rename it.");
                    ui.end_row();

                    ui.label("Icon");
                    ui.horizontal_wrapped(|ui| {
                        for icon in ICONS {
                            if ui
                                .selectable_label(dlg.cfg.icon == *icon, RichText::new(*icon).size(18.0))
                                .clicked()
                            {
                                dlg.cfg.icon = icon.to_string();
                            }
                        }
                    });
                    ui.end_row();

                    ui.label("Minecraft version");
                    ui.vertical(|ui| version_picker(app, ui, &mut dlg));
                    ui.end_row();

                    ui.label("Loader");
                    ui.vertical(|ui| {
                        let loader = match dlg.cfg.loader {
                            LoaderKind::Vanilla => "Vanilla".to_string(),
                            l => format!("{l} {}", dlg.cfg.loader_version.as_deref().unwrap_or("")),
                        };
                        ui.label(loader);
                        ui.label(widgets::dim("Install Fabric, Quilt, Forge, NeoForge or OptiFine from the Loaders tab.", &pal));
                    });
                    ui.end_row();

                    ui.label("Java");
                    ui.vertical(|ui| {
                        let current = dlg.cfg.java_override.clone().unwrap_or_default();
                        let label = if current.is_empty() {
                            "Automatic (recommended)".to_string()
                        } else if let Ok(m) = current.parse::<u32>() {
                            format!("Java {m}")
                        } else {
                            "Custom path".to_string()
                        };
                        egui::ComboBox::from_id_salt("java_pick")
                            .selected_text(label)
                            .width(260.0)
                            .show_ui(ui, |ui| {
                                if ui.selectable_label(current.is_empty(), "Automatic (recommended)").clicked() {
                                    dlg.cfg.java_override = None;
                                }
                                let mut majors: Vec<u32> = app.java.iter().map(|r| r.info.major).collect();
                                majors.sort_unstable();
                                majors.dedup();
                                for m in majors {
                                    if ui
                                        .selectable_label(current == m.to_string(), format!("Java {m}"))
                                        .clicked()
                                    {
                                        dlg.cfg.java_override = Some(m.to_string());
                                    }
                                }
                                if ui.selectable_label(label_is_custom(&current), "Custom path…").clicked() {
                                    dlg.cfg.java_override = Some(dlg.custom_java.clone());
                                }
                            });
                        let custom = label_is_custom(&current)
                            || matches!(&dlg.cfg.java_override, Some(s) if s.is_empty());
                        if custom
                            && ui
                                .add(
                                    egui::TextEdit::singleline(&mut dlg.custom_java)
                                        .hint_text("path to bin/java")
                                        .desired_width(300.0),
                                )
                                .changed()
                        {
                            dlg.cfg.java_override = Some(dlg.custom_java.clone());
                        }
                    });
                    ui.end_row();

                    ui.label("Memory");
                    ui.vertical(|ui| {
                        ui.add(
                            egui::Slider::new(&mut dlg.cfg.max_memory_mb, 1024..=16384)
                                .step_by(256.0)
                                .text("max")
                                .suffix(" MB"),
                        );
                        let max = dlg.cfg.max_memory_mb;
                        ui.add(
                            egui::Slider::new(&mut dlg.cfg.min_memory_mb, 256..=max)
                                .step_by(256.0)
                                .text("min")
                                .suffix(" MB"),
                        );
                    });
                    ui.end_row();

                    ui.label("Window size");
                    ui.horizontal(|ui| {
                        let mut custom = dlg.cfg.resolution.is_some();
                        if ui.checkbox(&mut custom, "Custom").changed() {
                            dlg.cfg.resolution = custom.then_some((1280, 720));
                        }
                        if let Some((w, h)) = &mut dlg.cfg.resolution {
                            ui.add(egui::DragValue::new(w).range(320..=7680).suffix(" w"));
                            ui.add(egui::DragValue::new(h).range(240..=4320).suffix(" h"));
                        }
                    });
                    ui.end_row();

                    ui.label("JVM arguments");
                    ui.vertical(|ui| {
                        ui.add(
                            egui::TextEdit::multiline(&mut dlg.cfg.jvm_args)
                                .desired_rows(3)
                                .desired_width(380.0)
                                .font(egui::TextStyle::Monospace),
                        );
                        if ui.small_button("Reset to tuned defaults (G1GC)").clicked() {
                            dlg.cfg.jvm_args = DEFAULT_JVM_ARGS.to_string();
                        }
                    });
                    ui.end_row();

                    ui.label("Game arguments");
                    ui.add(egui::TextEdit::singleline(&mut dlg.cfg.game_args).desired_width(380.0));
                    ui.end_row();

                    ui.label("Shaders");
                    ui.vertical(|ui| {
                        ui.checkbox(&mut dlg.cfg.shaders, "Shaders (installs the shader mods on save)");
                        ui.label(widgets::dim(
                            "Fabric/Quilt: Sodium + Iris · NeoForge: Iris or Embeddium + Oculus · Forge: Embeddium + Oculus · Vanilla: OptiFine",
                            &pal,
                        ));
                    });
                    ui.end_row();

                    ui.label("Notes");
                    ui.add(egui::TextEdit::multiline(&mut dlg.cfg.notes).desired_rows(2).desired_width(380.0));
                    ui.end_row();
                });
            });
            if let Some(e) = &dlg.error {
                ui.label(RichText::new(e).color(pal.danger));
            }
            ui.add_space(6.0);
            ui.horizontal(|ui| {
                if widgets::accent_button(ui, &pal, if dlg.editing.is_some() { "Save" } else { "Create" }).clicked() {
                    save = true;
                }
                if ui.button("Cancel").clicked() {
                    cancel = true;
                }
            });
        });

    if save {
        let cfg = dlg.cfg.clone();
        let err = if let Err(e) = validate_name(&cfg.name) {
            Some(e)
        } else if dlg.editing.is_none() && app.services().paths.instance_dir(&cfg.name).exists() {
            Some("An instance with that name already exists".to_string())
        } else if cfg.version_id.is_empty() {
            Some("Choose a Minecraft version".to_string())
        } else {
            None
        };
        if let Some(e) = err {
            dlg.error = Some(e);
            app.instance_dialog = Some(dlg);
            return;
        }
        let was_on = dlg
            .editing
            .as_ref()
            .and_then(|n| app.instances.iter().find(|i| &i.name == n))
            .is_some_and(|i| i.shaders);
        match app.save_instance(&cfg) {
            Ok(()) => {
                app.select_instance(&cfg.name);
                if cfg.shaders && !was_on {
                    app.enable_shaders(&cfg.name);
                } else if !cfg.shaders && was_on {
                    app.toast(
                        ToastKind::Info,
                        "Shader mods stay in mods/ (mclaunch never deletes user files); turn shaders off in-game or remove the jars yourself.",
                    );
                }
                let verb = if dlg.editing.is_some() {
                    "Saved"
                } else {
                    "Created"
                };
                app.toast(ToastKind::Success, format!("{verb} {}", cfg.name));
            }
            Err(e) => {
                dlg.error = Some(e);
                app.instance_dialog = Some(dlg);
            }
        }
        return;
    }
    if open && !cancel {
        app.instance_dialog = Some(dlg);
    }
}

fn label_is_custom(current: &str) -> bool {
    !current.is_empty() && current.parse::<u32>().is_err()
}

pub fn delete_dialog(app: &mut McApp, ctx: &egui::Context) {
    let Some(dlg) = &mut app.delete_dialog else {
        return;
    };
    let pal = app.pal;
    let mut open = true;
    let mut confirm = false;
    let mut cancel = false;
    egui::Window::new("Delete instance")
        .collapsible(false)
        .resizable(false)
        .anchor(egui::Align2::CENTER_CENTER, [0.0, 0.0])
        .open(&mut open)
        .show(ctx, |ui| {
            ui.set_width(420.0);
            ui.label(RichText::new(format!("Move \"{}\" to the recycle bin?", dlg.name)).strong());
            ui.label(widgets::dim(
                "Everything in the folder goes to the recycle bin (saves, mods, screenshots), so it can still be restored from there.",
                &pal,
            ));
            ui.add_space(6.0);
            ui.label(format!("Type {} to confirm:", dlg.name));
            ui.add(egui::TextEdit::singleline(&mut dlg.typed).desired_width(f32::INFINITY));
            ui.add_space(6.0);
            ui.horizontal(|ui| {
                let ok = dlg.typed == dlg.name;
                if ui
                    .add_enabled(
                        ok,
                        egui::Button::new(RichText::new("🗑 Move to recycle bin").color(egui::Color32::WHITE))
                            .fill(if ok { pal.danger } else { pal.panel_hi }),
                    )
                    .clicked()
                {
                    confirm = true;
                }
                if ui.button("Cancel").clicked() {
                    cancel = true;
                }
            });
        });
    if confirm {
        let (name, typed) = (dlg.name.clone(), dlg.typed.clone());
        app.delete_dialog = None;
        app.trash_instance(name, typed);
    } else if !open || cancel {
        app.delete_dialog = None;
    }
}
