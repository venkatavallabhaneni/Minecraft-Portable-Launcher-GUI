//! Java: detected runtimes from `java/*.zip|*.tar.gz` (and the system).

use eframe::egui::{self, Align, Layout, RichText, Ui};
use mclaunch_java::RuntimeSource;

use crate::app::McApp;
use crate::views::settings::open_path;
use crate::widgets;

pub fn show(app: &mut McApp, ui: &mut Ui) {
    let pal = app.pal;
    let mut rescan = false;
    let mut open_dir = false;
    ui.horizontal(|ui| {
        widgets::pixel_heading(ui, "Java", 16.0);
        ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
            if app.java_scanning {
                ui.spinner();
            } else if ui
                .button("⟳ Rescan")
                .on_hover_text("Re-hash every archive (SHA-256) and re-detect versions")
                .clicked()
            {
                rescan = true;
            }
            if ui.button("📂 Open java/ folder").clicked() {
                open_dir = true;
            }
        });
    });
    ui.add_space(6.0);
    ui.label(widgets::dim(
        "Drop JDK or JRE archives (.zip / .tar.gz) into the java/ folder, e.g. java/8.zip, java/17.zip, java/21.zip, java/25.zip. \
         Each archive is SHA-256 hashed, extracted once to java/.extracted/, and its real version is detected by running it.",
        &pal,
    ));
    ui.add_space(10.0);

    egui::ScrollArea::vertical()
        .id_salt("java_scroll_1").auto_shrink([false, false]).show(ui, |ui| {
        widgets::card(ui, &pal, |ui| {
            if app.java.is_empty() {
                ui.label(if app.java_scanning {
                    "Scanning…"
                } else {
                    "No Java runtimes found yet. Drop a JDK zip into java/ and press Rescan."
                });
                return;
            }
            egui::Grid::new("java_table")
                .num_columns(7)
                .striped(true)
                .spacing([18.0, 8.0])
                .show(ui, |ui| {
                    for h in ["Source", "Version", "Major", "Vendor", "Arch", "SHA-256", "Path"] {
                        ui.label(RichText::new(h).color(pal.dim).strong());
                    }
                    ui.end_row();
                    for rt in &app.java {
                        match &rt.source {
                            RuntimeSource::Archive { file_name, .. } => {
                                ui.label(format!("📦 {file_name}"));
                            }
                            RuntimeSource::System { origin } => {
                                ui.label(widgets::dim(format!("🖥 system ({origin})"), &pal));
                            }
                            RuntimeSource::Manual => {
                                ui.label("manual");
                            }
                        }
                        ui.label(RichText::new(&rt.info.version).strong());
                        widgets::badge(ui, format!("Java {}", rt.info.major), pal.accent);
                        ui.label(&rt.info.vendor);
                        ui.label(&rt.info.arch);
                        ui.label(widgets::mono(rt.sha256_short().unwrap_or("—")));
                        ui.add(egui::Label::new(widgets::mono(rt.java_bin.display().to_string())).truncate())
                            .on_hover_text(rt.java_bin.display().to_string());
                        ui.end_row();
                    }
                });
        });
        if !app.java_errors.is_empty() {
            ui.add_space(10.0);
            widgets::card(ui, &pal, |ui| {
                ui.label(RichText::new("⚠ Archives that could not be used").color(pal.warn).strong());
                for e in &app.java_errors {
                    ui.label(format!("{}: {}", e.file_name, e.message));
                }
            });
        }
        ui.add_space(10.0);
        widgets::card(ui, &pal, |ui| {
            ui.label(RichText::new("Which Java does each version need?").strong());
            ui.label(widgets::dim(
                "From the version's own JSON (javaVersion.majorVersion). Fallback: ≤1.16.5 → 8, 1.17 → 16, 1.18–1.20.4 → 17, 1.20.5+ → 21, newer → whatever the JSON says (26.x → 25).",
                &pal,
            ));
            let mut sys = app.config.use_system_java;
            if ui.checkbox(&mut sys, "Also use Java from JAVA_HOME / PATH").changed() {
                app.config.use_system_java = sys;
                app.save_config();
                rescan = true;
            }
        });
    });

    if rescan {
        app.rescan_java(true);
    }
    if open_dir {
        let dir = app.services().paths.java_dir();
        open_path(app, &dir);
    }
}
