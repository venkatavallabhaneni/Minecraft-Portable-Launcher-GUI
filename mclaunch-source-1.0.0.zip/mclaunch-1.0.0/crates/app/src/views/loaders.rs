//! Loaders: compatibility matrix for a Minecraft version and installers for
//! Fabric, Quilt, Forge, NeoForge and OptiFine (user-imported).

use std::collections::HashMap;

use eframe::egui::{self, Align, Layout, RichText, Ui};
use mclaunch_core::instance::{unique_name, InstanceConfig};
use mclaunch_core::manifest::VersionType;
use mclaunch_core::version::load_resolved;
use mclaunch_core::{Progress, ProgressFn};
use mclaunch_java::{JavaPick, JavaRuntime};
use mclaunch_loaders::{forge::FORGE_SUPPORT_URL, LoaderVersion, Loaders, Software};

use crate::app::{McApp, Screen, ToastKind};
use crate::backend::{JobDone, Services};
use crate::widgets;

pub enum Cell {
    Loading,
    Ready {
        versions: Vec<LoaderVersion>,
        cached: bool,
    },
    Error(String),
}

#[derive(Default)]
pub struct LoadersUi {
    pub mc: String,
    pub matrix_mc: String,
    pub cells: HashMap<Software, Cell>,
    pub chosen: HashMap<Software, String>,
    /// Apply to the selected instance instead of creating a new one.
    pub apply_to_selected: bool,
    pub installing: Option<Software>,
}

impl McApp {
    /// Fetch every loader's availability for `mc` concurrently.
    pub fn refresh_matrix(&mut self, mc: String) {
        self.loaders_ui.matrix_mc = mc.clone();
        for s in Software::ALL {
            self.loaders_ui.cells.insert(s, Cell::Loading);
        }
        let loaders = Loaders::new(self.services().installer());
        let b = self.backend.clone();
        self.backend
            .job(format!("Checking loaders for {mc}"), move |_j| async move {
                let futs = Software::ALL.map(|s| {
                    let loaders = loaders.clone();
                    let mc = mc.clone();
                    let b = b.clone();
                    async move {
                        let res = loaders.versions(s, &mc).await;
                        b.apply(move |app| {
                            if app.loaders_ui.matrix_mc != mc {
                                return;
                            }
                            let cell = match res {
                                Ok((versions, cached)) => {
                                    if !app.loaders_ui.chosen.contains_key(&s)
                                        || versions.iter().all(|v| {
                                            Some(&v.version) != app.loaders_ui.chosen.get(&s)
                                        })
                                    {
                                        if let Some(v) = versions
                                            .iter()
                                            .find(|v| v.recommended)
                                            .or_else(|| versions.iter().find(|v| v.stable))
                                            .or(versions.first())
                                        {
                                            app.loaders_ui.chosen.insert(s, v.version.clone());
                                        }
                                    }
                                    Cell::Ready { versions, cached }
                                }
                                Err(e) => Cell::Error(e.to_string()),
                            };
                            app.loaders_ui.cells.insert(s, cell);
                        });
                    }
                });
                futures::future::join_all(futs).await;
                Ok(JobDone::quiet())
            });
    }

    /// Install a client loader, then create or update an instance.
    pub fn install_loader(&mut self, software: Software, mc: String, version: String) {
        if self.loaders_ui.installing.is_some() {
            return;
        }
        self.loaders_ui.installing = Some(software);
        let runtimes = self.java.clone();
        let target = if self.loaders_ui.apply_to_selected {
            self.selected_instance()
                .filter(|i| i.mc_version == mc)
                .cloned()
        } else {
            None
        };
        let new_name = unique_name(
            &self.services().paths,
            &format!("{mc} {}", software.label()),
        );
        let default_ram = self.config.default_ram_mb;
        let label = format!("Installing {} {version} for {mc}", software.label());
        self.backend.job(label, move |j| async move {
            let svc = j.services.clone();
            let result = install_game(
                &svc,
                &runtimes,
                Some(software),
                &mc,
                &version,
                &j.progress,
            )
            .await;
            j.backend.apply(|app| app.loaders_ui.installing = None);
            let installed = result?;
            let kind = software.loader_kind().unwrap_or_default();
            let loader_version = installed.loader_version.unwrap_or_default();
            let mut cfg = match target {
                Some(t) => t,
                None => {
                    let mut c = InstanceConfig::new(&new_name, &mc, default_ram);
                    c.icon = "🛠".into();
                    c
                }
            };
            cfg.version_id = installed.version_id.clone();
            cfg.mc_version = mc.clone();
            cfg.loader = kind;
            cfg.loader_version = Some(loader_version.clone());
            let name = cfg.name.clone();
            Ok(JobDone::msg(format!(
                "{} {loader_version} installed → {name}",
                software.label(),
            ))
            .then(move |app| {
                if let Err(e) = app.save_instance(&cfg) {
                    app.toast(ToastKind::Error, e);
                    return;
                }
                app.select_instance(&name);
                app.refresh_installed();
                app.screen = Screen::Play;
            }))
        });
    }

    /// Ask for an OptiFine jar and import it.
    pub fn pick_optifine(&mut self) {
        let dialog = rfd::AsyncFileDialog::new()
            .set_title("Import OptiFine jar")
            .add_filter("OptiFine jar", &["jar"])
            .pick_file();
        let b = self.backend.clone();
        self.backend.spawn(async move {
            if let Some(file) = dialog.await {
                let path = file.path().to_path_buf();
                b.apply(move |app| app.import_optifine(path));
            }
        });
    }

    pub fn import_optifine(&mut self, path: std::path::PathBuf) {
        let svc = self.services().clone();
        match mclaunch_loaders::optifine::import(&svc.paths, &svc.safe, &path) {
            Ok(info) => {
                self.toast(
                    ToastKind::Success,
                    format!(
                        "Imported OptiFine {} for Minecraft {}",
                        info.edition, info.mc
                    ),
                );
                self.loaders_ui.mc = info.mc.clone();
                self.loaders_ui
                    .chosen
                    .insert(Software::OptiFine, info.edition);
                self.refresh_matrix(info.mc);
                self.screen = Screen::Loaders;
            }
            Err(e) => self.toast(ToastKind::Error, e.to_string()),
        }
    }
}

/// The game version and loader an instance launches.
pub struct InstalledGame {
    pub version_id: String,
    pub loader_version: Option<String>,
}

/// Install Minecraft `mc`, pick a Java runtime for it, then install
/// `software` (if any) on top. Shared by the Loaders and Modpacks screens.
pub async fn install_game(
    svc: &Services,
    runtimes: &[JavaRuntime],
    software: Option<Software>,
    mc: &str,
    version: &str,
    progress: &ProgressFn,
) -> anyhow::Result<InstalledGame> {
    progress(Progress::stage(format!("Installing Minecraft {mc}")));
    svc.installer().install(mc, progress).await?;
    let Some(software) = software else {
        return Ok(InstalledGame {
            version_id: mc.to_string(),
            loader_version: None,
        });
    };
    let resolved = load_resolved(&svc.paths, mc)?;
    let required = mclaunch_core::javareq::required_java(&resolved.merged);
    let java = match mclaunch_java::pick_runtime(runtimes, required, mc) {
        JavaPick::Exact(r) | JavaPick::Compatible(r) => Some(r.java_bin.clone()),
        JavaPick::Missing(msg) => {
            if matches!(software, Software::Forge | Software::NeoForge) {
                anyhow::bail!("{msg}");
            }
            None
        }
    };
    let installed = Loaders::new(svc.installer())
        .install_client(software, mc, version, java.as_deref(), progress)
        .await?;
    Ok(InstalledGame {
        version_id: installed.version_id,
        loader_version: Some(installed.loader_version),
    })
}

enum Action {
    Refresh(String),
    Install(Software, String),
    ImportOptiFine,
    AddOptiFineToMods,
    OpenUrl(&'static str),
    Servers,
}

pub fn show(app: &mut McApp, ui: &mut Ui) {
    let pal = app.pal;
    let mut actions = Vec::new();
    if app.loaders_ui.mc.is_empty() {
        app.loaders_ui.mc = app
            .selected_instance()
            .map(|i| i.mc_version.clone())
            .filter(|v| !v.is_empty())
            .or_else(|| app.manifest.as_ref().map(|m| m.latest.release.clone()))
            .unwrap_or_default();
    }
    if !app.loaders_ui.mc.is_empty() && app.loaders_ui.matrix_mc != app.loaders_ui.mc {
        actions.push(Action::Refresh(app.loaders_ui.mc.clone()));
    }

    ui.horizontal(|ui| {
        widgets::pixel_heading(ui, "Loaders", 16.0);
        ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
            if ui.button("📦 Import OptiFine jar…").clicked() {
                actions.push(Action::ImportOptiFine);
            }
        });
    });
    ui.add_space(8.0);
    ui.horizontal(|ui| {
        ui.label("Minecraft version");
        let mut mc = app.loaders_ui.mc.clone();
        egui::ComboBox::from_id_salt("loader_mc")
            .selected_text(if mc.is_empty() {
                "…".to_string()
            } else {
                mc.clone()
            })
            .height(320.0)
            .show_ui(ui, |ui| {
                if let Some(m) = &app.manifest {
                    for e in m.versions.iter().filter(|e| e.kind == VersionType::Release) {
                        ui.selectable_value(&mut mc, e.id.clone(), &e.id);
                    }
                }
            });
        if mc != app.loaders_ui.mc {
            app.loaders_ui.mc = mc;
        }
        if ui.button("⟳").on_hover_text("Refresh").clicked() {
            actions.push(Action::Refresh(app.loaders_ui.mc.clone()));
        }
        ui.add_space(16.0);
        let sel = app
            .selected_instance()
            .map(|i| (i.name.clone(), i.mc_version.clone()));
        match sel {
            Some((name, inst_mc)) if inst_mc == app.loaders_ui.mc => {
                ui.checkbox(
                    &mut app.loaders_ui.apply_to_selected,
                    format!("Apply to \"{name}\" instead of a new instance"),
                );
            }
            _ => {
                app.loaders_ui.apply_to_selected = false;
                ui.label(widgets::dim("Installing creates a new instance", &pal));
            }
        }
    });
    ui.add_space(10.0);

    let mc = app.loaders_ui.mc.clone();
    egui::ScrollArea::vertical()
        .id_salt("loaders_scroll_1").auto_shrink([false, false]).show(ui, |ui| {
        widgets::card(ui, &pal, |ui| {
            egui::Grid::new("matrix")
                .num_columns(5)
                .striped(true)
                .spacing([20.0, 10.0])
                .min_col_width(80.0)
                .show(ui, |ui| {
                    for h in ["Software", "Side", "Availability", "Version", ""] {
                        ui.label(RichText::new(h).color(pal.dim).strong());
                    }
                    ui.end_row();
                    for s in Software::ALL {
                        ui.label(RichText::new(s.label()).strong());
                        if s.client_side() {
                            widgets::badge(ui, "client", pal.info);
                        } else {
                            widgets::badge(ui, "server", pal.warn);
                        }
                        let cell = app.loaders_ui.cells.get(&s);
                        let mut versions: &[LoaderVersion] = &[];
                        match cell {
                            None | Some(Cell::Loading) => {
                                ui.horizontal(|ui| {
                                    ui.spinner();
                                    ui.label(widgets::dim("checking…", &pal));
                                });
                            }
                            Some(Cell::Error(e)) => {
                                ui.label(RichText::new("⚠ unavailable").color(pal.warn)).on_hover_text(e);
                            }
                            Some(Cell::Ready { versions: v, cached }) => {
                                versions = v;
                                ui.horizontal(|ui| {
                                    if v.is_empty() {
                                        if s == Software::OptiFine {
                                            ui.label(widgets::dim("import the jar", &pal));
                                        } else {
                                            ui.label(RichText::new("✖ not available").color(pal.dim));
                                        }
                                    } else if s.client_side() {
                                        ui.label(RichText::new(format!("✔ {} version(s)", v.len())).color(pal.accent));
                                    } else {
                                        ui.label(RichText::new("✔ available").color(pal.accent));
                                    }
                                    if *cached {
                                        widgets::badge(ui, "cached", pal.dim);
                                    }
                                });
                            }
                        }
                        // Version picker
                        if s.client_side() && !versions.is_empty() {
                            let chosen = app.loaders_ui.chosen.entry(s).or_insert_with(|| versions[0].version.clone());
                            let shown = |v: &str| v.strip_prefix(&format!("{mc}-")).unwrap_or(v).to_string();
                            egui::ComboBox::from_id_salt(("ver", s.label()))
                                .selected_text(shown(chosen))
                                .width(170.0)
                                .height(300.0)
                                .show_ui(ui, |ui| {
                                    for v in versions {
                                        let mut text = shown(&v.version);
                                        if v.recommended {
                                            text.push_str("  ★ recommended");
                                        } else if !v.stable {
                                            text.push_str("  (beta)");
                                        }
                                        ui.selectable_value(chosen, v.version.clone(), text);
                                    }
                                });
                        } else if !s.client_side() && !versions.is_empty() {
                            ui.label(widgets::dim(&versions[0].version, &pal));
                        } else {
                            ui.label("");
                        }
                        // Action
                        let busy = app.loaders_ui.installing.is_some();
                        if s.client_side() {
                            let chosen = app.loaders_ui.chosen.get(&s).cloned();
                            let ok = !versions.is_empty() && chosen.is_some() && !busy;
                            ui.horizontal(|ui| {
                                if app.loaders_ui.installing == Some(s) {
                                    ui.spinner();
                                } else if ui.add_enabled(ok, egui::Button::new("⬇ Install")).clicked() {
                                    if let Some(v) = chosen {
                                        actions.push(Action::Install(s, v));
                                    }
                                }
                                if s == Software::OptiFine
                                    && !versions.is_empty()
                                    && ui
                                        .button("+ mods/")
                                        .on_hover_text("Add the jar to the selected instance's mods/ (Forge, or Fabric with OptiFabric)")
                                        .clicked()
                                {
                                    actions.push(Action::AddOptiFineToMods);
                                }
                            });
                        } else if !versions.is_empty() {
                            if ui.button("🖥 Servers tab").clicked() {
                                actions.push(Action::Servers);
                            }
                        } else {
                            ui.label("");
                        }
                        ui.end_row();
                    }
                });
        });
        ui.add_space(10.0);
        widgets::card(ui, &pal, |ui| {
            ui.label(RichText::new("Notes").strong());
            ui.label(widgets::dim(
                "Installers and version lists are cached in loaders/, so reinstalling works offline.",
                &pal,
            ));
            ui.horizontal_wrapped(|ui| {
                ui.label(widgets::dim(
                    "OptiFine's licence forbids redistribution: download it yourself from optifine.net, then import or drop the jar here. Fabric needs OptiFabric to load it.",
                    &pal,
                ));
            });
            ui.horizontal_wrapped(|ui| {
                ui.label(widgets::dim(
                    "Forge is funded by ads on its download page; if you use it a lot, consider supporting the project:",
                    &pal,
                ));
                if ui.link("Forge on Patreon").clicked() {
                    actions.push(Action::OpenUrl(FORGE_SUPPORT_URL));
                }
            });
        });
    });

    for a in actions {
        match a {
            Action::Refresh(mc) => {
                if !mc.is_empty() {
                    app.refresh_matrix(mc);
                }
            }
            Action::Install(s, v) => {
                let mc = app.loaders_ui.mc.clone();
                app.install_loader(s, mc, v);
            }
            Action::ImportOptiFine => app.pick_optifine(),
            Action::AddOptiFineToMods => {
                let mc = app.loaders_ui.mc.clone();
                let edition = app
                    .loaders_ui
                    .chosen
                    .get(&Software::OptiFine)
                    .cloned()
                    .unwrap_or_default();
                let svc = app.services().clone();
                let Some(inst) = app.selected_instance().cloned() else {
                    app.toast(ToastKind::Error, "Select an instance first");
                    continue;
                };
                match mclaunch_loaders::optifine::find_imported(&svc.paths, &mc, &edition) {
                    Some(jar) => match mclaunch_loaders::optifine::add_to_mods(
                        &svc.safe,
                        &svc.paths.instance_dir(&inst.name),
                        &jar,
                    ) {
                        Ok(p) => app.toast(
                            ToastKind::Success,
                            format!("Added {} to {}", p.display(), inst.name),
                        ),
                        Err(e) => app.toast(ToastKind::Error, e.to_string()),
                    },
                    None => app.toast(ToastKind::Error, "Import the OptiFine jar first"),
                }
            }
            Action::OpenUrl(url) => {
                let _ = open::that_detached(url);
            }
            Action::Servers => app.screen = Screen::Servers,
        }
    }
}
