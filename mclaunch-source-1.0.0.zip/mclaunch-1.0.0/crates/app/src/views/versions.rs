//! Versions: searchable list of every version in Mojang's manifest plus
//! locally installed loader profiles, with install / verify / repair.

use eframe::egui::{self, Align, Layout, RichText, Ui};
use mclaunch_core::manifest::VersionType;

use crate::app::McApp;
use crate::widgets;

struct Row {
    id: String,
    kind: Option<VersionType>,
    date: String,
    april: bool,
    loader_profile: bool,
}

enum Action {
    Install(String),
    Verify(String),
    Repair(String),
    Refresh,
}

fn kind_color(app: &McApp, kind: Option<&VersionType>) -> egui::Color32 {
    match kind {
        Some(VersionType::Release) => app.pal.accent,
        Some(VersionType::Snapshot) => app.pal.info,
        Some(VersionType::OldBeta) => app.pal.warn,
        Some(VersionType::OldAlpha) => app.pal.danger,
        _ => app.pal.dim,
    }
}

pub fn show(app: &mut McApp, ui: &mut Ui) {
    let pal = app.pal;
    let mut actions = Vec::new();

    ui.horizontal(|ui| {
        widgets::pixel_heading(ui, "Versions", 16.0);
        ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
            if ui.button("⟳ Refresh list").clicked() {
                actions.push(Action::Refresh);
            }
            if let Some(m) = &app.manifest {
                let src = match app.manifest_source {
                    Some(mclaunch_download::ManifestSource::Network) => "from Mojang",
                    _ => "from offline cache",
                };
                ui.label(widgets::dim(
                    format!(
                        "{} versions {src} · latest {} / {}",
                        m.versions.len(),
                        m.latest.release,
                        m.latest.snapshot
                    ),
                    &pal,
                ));
            }
        });
    });
    ui.add_space(8.0);

    let vui = &mut app.versions_ui;
    ui.horizontal(|ui| {
        let resp = ui.add(
            egui::TextEdit::singleline(&mut vui.search)
                .hint_text("🔍 Search versions  (Ctrl+F)")
                .desired_width(240.0),
        );
        if vui.focus_search {
            resp.request_focus();
            vui.focus_search = false;
        }
        ui.add_space(8.0);
        widgets::chip(ui, &pal, &mut vui.release, "Release");
        widgets::chip(ui, &pal, &mut vui.snapshot, "Snapshot");
        widgets::chip(ui, &pal, &mut vui.beta, "Beta");
        widgets::chip(ui, &pal, &mut vui.alpha, "Alpha");
        ui.add_space(8.0);
        widgets::chip(ui, &pal, &mut vui.installed_only, "✔ Installed");
    });
    ui.add_space(8.0);

    // Build the row list: manifest entries + installed ids not in it.
    let search = app.versions_ui.search.trim().to_lowercase();
    let mut rows: Vec<Row> = Vec::new();
    if let Some(m) = &app.manifest {
        for e in &m.versions {
            rows.push(Row {
                id: e.id.clone(),
                kind: Some(e.kind.clone()),
                date: e.release_time.get(..10).unwrap_or("").to_string(),
                april: e.is_april_fools(),
                loader_profile: false,
            });
        }
    }
    for v in &app.installed {
        if !rows.iter().any(|r| r.id == v.id) {
            rows.push(Row {
                id: v.id.clone(),
                kind: v.kind.clone(),
                date: String::new(),
                april: false,
                loader_profile: v.inherits_from.is_some(),
            });
        }
    }
    let f = &app.versions_ui;
    rows.retain(|r| {
        if !search.is_empty() && !r.id.to_lowercase().contains(&search) {
            return false;
        }
        let installed = app.installed.iter().any(|v| v.id == r.id);
        if f.installed_only && !installed {
            return false;
        }
        if r.loader_profile {
            return true;
        }
        match &r.kind {
            Some(VersionType::Release) => f.release,
            Some(VersionType::Snapshot) => f.snapshot,
            Some(VersionType::OldBeta) => f.beta,
            Some(VersionType::OldAlpha) => f.alpha,
            _ => f.snapshot || f.installed_only,
        }
    });

    if app.manifest.is_none() && rows.is_empty() {
        widgets::card(ui, &pal, |ui| {
            ui.label("Loading the version list…");
            ui.label(widgets::dim(
                "The first start needs the network once; afterwards the list is cached for offline use.",
                &pal,
            ));
        });
    }

    let row_h = 34.0;
    egui::ScrollArea::vertical()
        .id_salt("versions_scroll_1")
        .auto_shrink([false, false])
        .show_rows(ui, row_h, rows.len(), |ui, range| {
            for row in &rows[range] {
                let busy = app.busy_versions.contains(&row.id);
                let installed = app.is_installed(&row.id);
                let partial = !installed && app.installed.iter().any(|v| v.id == row.id);
                let report = app.reports.get(&row.id);
                let (rect, _) = ui.allocate_exact_size(
                    egui::vec2(ui.available_width(), row_h),
                    egui::Sense::hover(),
                );
                ui.painter().rect_filled(rect, 6.0_f32, pal.panel);
                let mut row_ui = ui.new_child(
                    egui::UiBuilder::new()
                        .max_rect(rect.shrink2(egui::vec2(10.0, 0.0)))
                        .layout(Layout::left_to_right(Align::Center)),
                );
                {
                    let ui = &mut row_ui;
                    {
                        widgets::fixed_label(ui, 190.0, RichText::new(&row.id).strong());
                        let label = if row.loader_profile {
                            "Loader".to_string()
                        } else {
                            row.kind
                                .as_ref()
                                .map(|k| k.label().to_string())
                                .unwrap_or_else(|| "Custom".into())
                        };
                        widgets::badge(ui, label, kind_color(app, row.kind.as_ref()));
                        if row.april {
                            widgets::badge(ui, "April Fools", pal.warn);
                        }
                        ui.label(widgets::dim(&row.date, &pal));
                        ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
                            if busy {
                                ui.spinner();
                                ui.label(widgets::dim("working…", &pal));
                                return;
                            }
                            if installed || partial {
                                if ui.button("Repair").clicked() {
                                    actions.push(Action::Repair(row.id.clone()));
                                }
                                if installed && ui.button("Verify").clicked() {
                                    actions.push(Action::Verify(row.id.clone()));
                                }
                            } else if ui.button("⬇ Download").clicked() {
                                actions.push(Action::Install(row.id.clone()));
                            }
                            match report {
                                Some(r) if !r.is_ok() => {
                                    widgets::badge(ui, "⚠ corrupt", pal.danger)
                                        .on_hover_text(r.summary());
                                }
                                _ if installed => {
                                    let b = widgets::badge(ui, "✔ installed", pal.accent);
                                    if let Some(r) = report {
                                        b.on_hover_text(r.summary());
                                    }
                                }
                                _ if partial => {
                                    widgets::badge(ui, "… incomplete", pal.warn).on_hover_text(
                                        "Files exist but were never verified. Press Repair.",
                                    );
                                }
                                _ => {
                                    widgets::badge(ui, "☁ not downloaded", pal.dim);
                                }
                            }
                        });
                    }
                }
            }
        });

    for a in actions {
        match a {
            Action::Install(id) => app.install_version(id),
            Action::Verify(id) => app.verify_version(id),
            Action::Repair(id) => app.repair_version(id),
            Action::Refresh => app.refresh_manifest(true),
        }
    }
}
