//! LAN: games discovered on the local network plus manual IP:port join.

use eframe::egui::{self, Align, Layout, RichText, Ui};

use crate::app::{McApp, Screen, ToastKind};
use crate::widgets;

#[derive(Default)]
pub struct LanUi {
    pub manual: String,
}

pub fn show(app: &mut McApp, ui: &mut Ui) {
    let pal = app.pal;
    let mut join: Option<String> = None;
    ui.horizontal(|ui| {
        widgets::pixel_heading(ui, "LAN", 16.0);
        ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
            if app.lan_error.is_none() {
                ui.spinner();
                ui.label(widgets::dim("listening on 224.0.2.60:4445", &pal));
            }
        });
    });
    ui.add_space(6.0);
    ui.label(widgets::dim(
        "Worlds opened with \"Open to LAN\" on this network appear here automatically. Joining uses the selected instance, so pick one with the same Minecraft version.",
        &pal,
    ));
    ui.add_space(10.0);

    if let Some(e) = &app.lan_error {
        widgets::card(ui, &pal, |ui| {
            ui.label(RichText::new(format!("⚠ LAN discovery unavailable: {e}")).color(pal.warn));
            ui.label(widgets::dim("You can still join by address below.", &pal));
        });
        ui.add_space(10.0);
    }

    let instance = app
        .selected_instance()
        .map(|i| (i.name.clone(), i.mc_version.clone()));
    widgets::card(ui, &pal, |ui| {
        if app.lan_games.is_empty() {
            ui.label("No LAN games found yet.");
            ui.label(widgets::dim(
                "In Minecraft: Esc → Open to LAN. Firewalls must allow UDP 4445 and the game's TCP port.",
                &pal,
            ));
        }
        for g in &app.lan_games {
            ui.horizontal(|ui| {
                ui.label(RichText::new("🌐").size(20.0));
                ui.vertical(|ui| {
                    ui.label(RichText::new(&g.motd).strong());
                    ui.label(widgets::dim(
                        format!(
                            "{} · seen {}s ago",
                            g.address(),
                            g.last_seen.elapsed().as_secs()
                        ),
                        &pal,
                    ));
                });
                ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
                    if ui
                        .add_enabled(
                            instance.is_some() && app.game.is_none(),
                            egui::Button::new("▶ Join"),
                        )
                        .clicked()
                    {
                        join = Some(g.address());
                    }
                });
            });
            ui.separator();
        }
    });
    ui.add_space(10.0);
    widgets::card(ui, &pal, |ui| {
        ui.label(RichText::new("Join by address").strong());
        ui.horizontal(|ui| {
            ui.add(
                egui::TextEdit::singleline(&mut app.lan_ui.manual)
                    .hint_text("192.168.1.20:25565")
                    .desired_width(220.0),
            );
            let valid = mclaunch_core::args::QuickJoin::parse(&app.lan_ui.manual).is_some();
            if ui
                .add_enabled(
                    valid && instance.is_some() && app.game.is_none(),
                    egui::Button::new("▶ Join"),
                )
                .clicked()
            {
                join = Some(app.lan_ui.manual.trim().to_string());
            }
        });
        match &instance {
            Some((name, mc)) => ui.label(widgets::dim(
                format!("Uses instance \"{name}\" (MC {mc})"),
                &pal,
            )),
            None => ui.label(RichText::new("Create or select an instance first").color(pal.warn)),
        };
    });

    if let Some(addr) = join {
        if let Some((name, _)) = instance {
            app.quick_join = addr.clone();
            app.toast(ToastKind::Info, format!("Joining {addr} with {name}"));
            app.screen = Screen::Play;
            app.launch_instance(&name);
        }
    }
}
