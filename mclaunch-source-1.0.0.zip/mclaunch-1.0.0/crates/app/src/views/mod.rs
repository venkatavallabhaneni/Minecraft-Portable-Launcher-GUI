//! One module per screen.

pub mod accounts;
pub mod instances;
pub mod java;
pub mod lan;
pub mod loaders;
pub mod logs;
pub mod modpacks;
pub mod mods;
pub mod play;
pub mod servers;
pub mod settings;
pub mod versions;
