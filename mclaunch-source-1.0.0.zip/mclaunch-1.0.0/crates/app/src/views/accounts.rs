//! Offline profiles: the account menu in the top bar and the "add profile"
//! dialog. No sign-in, ever.

use eframe::egui::{self, RichText, Ui};
use mclaunch_core::offline::{offline_uuid, validate_username};

use crate::app::{McApp, ToastKind};
use crate::widgets;

#[derive(Default)]
pub struct AccountDialog {
    pub name: String,
    focused: bool,
}

/// The "👤 Name ▾" menu.
pub fn menu(app: &mut McApp, ui: &mut Ui) {
    let label = match app.config.active_username() {
        Some(n) => format!("👤 {n} ⏷"),
        None => "👤 Add profile ⏷".to_string(),
    };
    let mut select = None;
    let mut remove = None;
    let mut add = false;
    ui.menu_button(label, |ui| {
        ui.set_min_width(220.0);
        for (i, name) in app.config.accounts.iter().enumerate() {
            ui.horizontal(|ui| {
                if ui
                    .selectable_label(i == app.config.active_account, format!("👤 {name}"))
                    .on_hover_text(format!("Offline UUID {}", offline_uuid(name)))
                    .clicked()
                {
                    select = Some(i);
                    ui.close_menu();
                }
                if ui
                    .small_button("🗑")
                    .on_hover_text("Remove profile")
                    .clicked()
                {
                    remove = Some(i);
                    ui.close_menu();
                }
            });
        }
        if !app.config.accounts.is_empty() {
            ui.separator();
        }
        if ui.button("+ Add offline profile…").clicked() {
            add = true;
            ui.close_menu();
        }
    });
    if let Some(i) = select {
        app.config.active_account = i;
        app.save_config();
    }
    if let Some(i) = remove {
        app.config.accounts.remove(i);
        app.config = std::mem::take(&mut app.config).sanitized();
        app.save_config();
    }
    if add {
        app.account_dialog = Some(AccountDialog::default());
    }
}

pub fn dialog(app: &mut McApp, ctx: &egui::Context) {
    let Some(dlg) = &mut app.account_dialog else {
        return;
    };
    let pal = app.pal;
    let mut open = true;
    let mut submit = false;
    egui::Window::new("Offline profile")
        .collapsible(false)
        .resizable(false)
        .anchor(egui::Align2::CENTER_CENTER, [0.0, 0.0])
        .open(&mut open)
        .show(ctx, |ui| {
            ui.set_width(380.0);
            ui.label("Pick a username. No sign-in is needed.");
            ui.add_space(6.0);
            let resp = ui.add(
                egui::TextEdit::singleline(&mut dlg.name)
                    .hint_text("Username (3–16: letters, digits, _)")
                    .desired_width(f32::INFINITY),
            );
            if !dlg.focused {
                resp.request_focus();
                dlg.focused = true;
            }
            let valid = validate_username(&dlg.name);
            match &valid {
                Ok(()) => {
                    ui.label(widgets::dim(
                        format!("UUID {}", offline_uuid(&dlg.name)),
                        &pal,
                    ))
                    .on_hover_text("Same UUID a vanilla offline-mode server gives this name");
                }
                Err(e) if !dlg.name.is_empty() => {
                    ui.label(RichText::new(e).color(pal.danger));
                }
                Err(_) => {}
            }
            ui.add_space(6.0);
            ui.label(widgets::dim(
                "Offline mode is meant for players who own Minecraft: Java Edition.",
                &pal,
            ));
            ui.add_space(8.0);
            ui.horizontal(|ui| {
                let enter = resp.lost_focus() && ui.input(|i| i.key_pressed(egui::Key::Enter));
                if ui
                    .add_enabled(valid.is_ok(), egui::Button::new("Add profile"))
                    .clicked()
                    || (enter && valid.is_ok())
                {
                    submit = true;
                }
            });
        });
    if submit {
        let name = dlg.name.clone();
        if let Some(i) = app
            .config
            .accounts
            .iter()
            .position(|a| a.eq_ignore_ascii_case(&name))
        {
            app.config.active_account = i;
        } else {
            app.config.accounts.push(name.clone());
            app.config.active_account = app.config.accounts.len() - 1;
        }
        app.save_config();
        app.toast(ToastKind::Success, format!("Playing as {name}"));
        app.account_dialog = None;
    } else if !open {
        app.account_dialog = None;
    }
}
