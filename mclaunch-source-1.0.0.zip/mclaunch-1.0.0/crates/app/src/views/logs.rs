//! Logs: live game output with level colours, filtering, copy/export and a
//! crash-report highlighter.

use eframe::egui::{self, Align, Color32, Layout, RichText, Ui};
use mclaunch_launch::{Level, LogLine};

use crate::app::{McApp, ToastKind};
use crate::widgets;

pub struct LogUi {
    pub filter: String,
    pub min_level: Level,
    pub follow: bool,
    pub jump_to_crash: bool,
}

impl Default for LogUi {
    fn default() -> Self {
        Self {
            filter: String::new(),
            min_level: Level::Info,
            follow: true,
            jump_to_crash: false,
        }
    }
}

fn level_color(pal: &crate::theme::Palette, line: &LogLine) -> Color32 {
    if line.thread.as_deref() == Some("mclaunch") {
        return pal.accent;
    }
    match line.level {
        Level::Trace | Level::Debug => pal.dim,
        Level::Info => pal.text,
        Level::Warn => pal.warn,
        Level::Error | Level::Fatal => pal.danger,
    }
}

pub fn show(app: &mut McApp, ui: &mut Ui) {
    let pal = app.pal;
    let mut copy = false;
    let mut export = false;
    let mut clear = false;
    let mut open_report = None;

    ui.horizontal(|ui| {
        widgets::pixel_heading(ui, "Logs", 16.0);
        if let Some(g) = &app.game {
            widgets::badge(
                ui,
                format!("▶ {} ({}) running", g.instance, g.version),
                pal.accent,
            );
        }
        ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
            if ui.button("🗑 Clear").clicked() {
                clear = true;
            }
            if ui.button("💾 Export").clicked() {
                export = true;
            }
            if ui.button("📋 Copy").clicked() {
                copy = true;
            }
        });
    });
    ui.add_space(6.0);
    ui.horizontal(|ui| {
        ui.add(
            egui::TextEdit::singleline(&mut app.log_ui.filter)
                .hint_text("🔍 filter")
                .desired_width(220.0),
        );
        egui::ComboBox::from_id_salt("min_level")
            .selected_text(format!("{}+", app.log_ui.min_level.label()))
            .show_ui(ui, |ui| {
                for l in [Level::Debug, Level::Info, Level::Warn, Level::Error] {
                    ui.selectable_value(&mut app.log_ui.min_level, l, format!("{}+", l.label()));
                }
            });
        ui.checkbox(&mut app.log_ui.follow, "Follow");
        ui.label(widgets::dim(format!("{} lines", app.game_log.len()), &pal));
    });
    ui.add_space(6.0);

    // Crash highlighter
    if let Some(crash) = app.last_crash.clone() {
        egui::Frame::new()
            .fill(pal.danger.gamma_multiply(0.15))
            .stroke(egui::Stroke::new(1.0_f32, pal.danger))
            .corner_radius(egui::CornerRadius::same(8))
            .inner_margin(egui::Margin::same(10))
            .show(ui, |ui| {
                ui.set_width(ui.available_width());
                ui.label(
                    RichText::new(format!(
                        "💥 {} crashed{}",
                        crash.instance,
                        crash
                            .code
                            .map(|c| format!(" (exit code {c})"))
                            .unwrap_or_default()
                    ))
                    .color(pal.danger)
                    .strong(),
                );
                ui.label(&crash.summary);
                for hint in &crash.hints {
                    ui.label(RichText::new(format!("💡 {hint}")).color(pal.warn));
                }
                if let Some(report) = &crash.report {
                    ui.horizontal(|ui| {
                        ui.label(widgets::mono(report.display().to_string()));
                        if ui.button("Open crash report").clicked() {
                            open_report = Some(report.clone());
                        }
                    });
                }
            });
        ui.add_space(6.0);
    }

    let jump = std::mem::take(&mut app.log_ui.jump_to_crash);
    let filter = app.log_ui.filter.to_lowercase();
    let min = app.log_ui.min_level;
    let lines: Vec<&LogLine> = app
        .game_log
        .iter()
        .filter(|l| {
            l.level >= min || l.thread.as_deref() == Some("mclaunch") || l.is_crash_marker()
        })
        .filter(|l| filter.is_empty() || l.text.to_lowercase().contains(&filter))
        .collect();
    let crash_row = lines.iter().position(|l| l.is_crash_marker());

    egui::Frame::new()
        .fill(ui.visuals().extreme_bg_color)
        .corner_radius(egui::CornerRadius::same(8))
        .inner_margin(egui::Margin::same(8))
        .show(ui, |ui| {
            let row_h = ui.text_style_height(&egui::TextStyle::Monospace);
            let mut area = egui::ScrollArea::both()
                .id_salt("logs_scroll_1")
                .auto_shrink([false, false])
                .stick_to_bottom(app.log_ui.follow);
            if jump {
                if let Some(row) = crash_row {
                    area = area.vertical_scroll_offset(
                        (row as f32 * (row_h + ui.spacing().item_spacing.y) - 40.0).max(0.0),
                    );
                }
            }
            area.show_rows(ui, row_h, lines.len(), |ui, range| {
                ui.style_mut().wrap_mode = Some(egui::TextWrapMode::Extend);
                for line in &lines[range] {
                    let text = RichText::new(line.display())
                        .font(egui::FontId::monospace(12.5))
                        .color(level_color(&pal, line));
                    if line.is_crash_marker() {
                        ui.label(text.background_color(pal.danger.gamma_multiply(0.25)));
                    } else {
                        ui.label(text);
                    }
                }
            });
            if lines.is_empty() {
                ui.label(widgets::dim(
                    "Game output appears here when you press Play.",
                    &pal,
                ));
            }
        });

    if copy {
        let text: String = app.game_log.iter().map(|l| l.display() + "\n").collect();
        ui.ctx().copy_text(text);
        app.toast(ToastKind::Success, "Log copied to the clipboard");
    }
    if export {
        let name = format!(
            "game-{}-{}.log",
            app.game
                .as_ref()
                .map(|g| g.instance.clone())
                .or_else(|| app.config.selected_instance.clone())
                .unwrap_or_else(|| "log".into())
                .replace([' ', '/', '\\'], "_"),
            chrono::Local::now().format("%Y%m%d-%H%M%S")
        );
        let path = app.services().paths.logs_dir().join(name);
        let text: String = app.game_log.iter().map(|l| l.display() + "\n").collect();
        match app.services().safe.create_new(&path, text.as_bytes()) {
            Ok(()) => app.toast(ToastKind::Success, format!("Saved {}", path.display())),
            Err(e) => app.toast(ToastKind::Error, format!("Export failed: {e}")),
        }
    }
    if clear {
        app.game_log.clear();
        app.last_crash = None;
    }
    if let Some(p) = open_report {
        if let Err(e) = open::that_detached(&p) {
            app.toast(
                ToastKind::Error,
                format!("Cannot open {}: {e}", p.display()),
            );
        }
    }
}
