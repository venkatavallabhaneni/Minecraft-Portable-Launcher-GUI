//! Mods: install and manage the mods of an instance, or the global mod list
//! that is added to every compatible instance when it launches.

use std::collections::{HashMap, HashSet};
use std::path::PathBuf;

use eframe::egui::{self, Align, Layout, RichText, Ui};
use mclaunch_core::InstanceConfig;
use mclaunch_core::LoaderKind;
use mclaunch_loaders::mods::{
    self, GlobalMod, InstalledMod, ModVersion, ProjectRef, SearchHit, Source, Update,
};
use mclaunch_loaders::Loaders;

use crate::app::{McApp, ToastKind};
use crate::backend::JobDone;
use crate::views::settings::open_path;
use crate::widgets;

/// Whose mods are shown.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ModsTarget {
    Global,
    Instance(String),
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum Tab {
    #[default]
    Installed,
    Browse,
}

pub struct ModsUi {
    pub target: Option<ModsTarget>,
    pub tab: Tab,
    /// Installed mods of `loaded_for`.
    pub installed: Vec<InstalledMod>,
    pub global: Vec<GlobalMod>,
    pub loaded_for: Option<ModsTarget>,
    pub loading: bool,
    pub filter: String,
    pub updates: HashMap<String, Update>,
    pub checking: bool,
    pub source: Source,
    pub query: String,
    pub results: Vec<SearchHit>,
    pub searched: bool,
    pub searching: bool,
    pub search_error: Option<String>,
    pub cf_id: String,
    /// Project ids being installed.
    pub installing: HashSet<String>,
    /// File (or global id) waiting for "remove?" confirmation.
    pub confirm_remove: Option<(String, String)>,
    /// The "choose version" window.
    pub picker: Option<Picker>,
}

/// Minecraft version → compatible loader → mod version.
pub struct Picker {
    pub project: ProjectRef,
    pub page: String,
    pub loading: bool,
    pub error: Option<String>,
    pub versions: Vec<ModVersion>,
    pub mc: String,
    pub loader: Option<LoaderKind>,
    /// `file.version_id` of the chosen version.
    pub version: String,
    pub snapshots: bool,
}

/// `1.20.1`, `26.1`: release ids (no snapshots or pre-releases).
fn release_like(v: &str) -> bool {
    v.split('.').count() >= 2
        && v.split('.').all(|p| !p.is_empty() && p.chars().all(|c| c.is_ascii_digit()))
}

impl Picker {
    /// Minecraft versions this mod supports, newest first.
    pub fn mc_versions(&self) -> Vec<String> {
        let mut v: Vec<String> = self
            .versions
            .iter()
            .flat_map(|m| m.game_versions.iter().cloned())
            .filter(|g| self.snapshots || release_like(g))
            .collect::<HashSet<_>>()
            .into_iter()
            .collect();
        v.sort_by(|a, b| mclaunch_loaders::version_cmp(b, a));
        v
    }

    /// Loaders the mod supports on Minecraft `mc`.
    pub fn loaders(&self, mc: &str) -> Vec<LoaderKind> {
        [LoaderKind::Fabric, LoaderKind::Quilt, LoaderKind::Forge, LoaderKind::NeoForge]
            .into_iter()
            .filter(|l| {
                self.versions
                    .iter()
                    .any(|m| m.loaders.contains(l) && m.game_versions.iter().any(|g| g == mc))
            })
            .collect()
    }

    /// Mod versions for `mc` + `loader`, newest first.
    pub fn matching(&self, mc: &str, loader: LoaderKind) -> Vec<&ModVersion> {
        self.versions
            .iter()
            .filter(|m| m.loaders.contains(&loader) && m.game_versions.iter().any(|g| g == mc))
            .collect()
    }

    pub fn chosen(&self) -> Option<&ModVersion> {
        self.versions.iter().find(|m| m.file.version_id == self.version)
    }

    /// After picking a Minecraft version: keep the loader if it still fits
    /// (else prefer `prefer`), and choose the newest release.
    pub fn pick_mc(&mut self, mc: String, prefer: Option<LoaderKind>) {
        self.mc = mc;
        let loaders = self.loaders(&self.mc);
        let keep = self.loader.filter(|l| loaders.contains(l));
        self.loader = keep
            .or(prefer.filter(|l| loaders.contains(l)))
            .or(loaders.first().copied());
        self.pick_latest();
    }

    pub fn pick_latest(&mut self) {
        let Some(loader) = self.loader else {
            self.version.clear();
            return;
        };
        let list = self.matching(&self.mc, loader);
        self.version = list
            .iter()
            .find(|m| m.release)
            .or(list.first())
            .map(|m| m.file.version_id.clone())
            .unwrap_or_default();
    }
}

impl Default for ModsUi {
    fn default() -> Self {
        Self {
            target: None,
            tab: Tab::Installed,
            installed: Vec::new(),
            global: Vec::new(),
            loaded_for: None,
            loading: false,
            filter: String::new(),
            updates: HashMap::new(),
            checking: false,
            source: Source::Modrinth,
            query: String::new(),
            results: Vec::new(),
            searched: false,
            searching: false,
            search_error: None,
            cf_id: String::new(),
            installing: HashSet::new(),
            confirm_remove: None,
            picker: None,
        }
    }
}

impl McApp {
    fn mods_instance(&self, name: &str) -> Option<InstanceConfig> {
        self.instances.iter().find(|i| i.name == name).cloned()
    }

    fn cf_key(&self) -> Option<String> {
        self.config.curseforge_key()
    }

    /// Reload the installed list (or the global list) in the background.
    pub fn refresh_mods(&mut self) {
        let Some(target) = self.mods_ui.target.clone() else {
            return;
        };
        self.mods_ui.loading = true;
        self.mods_ui.updates.clear();
        let paths = self.services().paths.clone();
        let b = self.backend.clone();
        self.backend.spawn(async move {
            let t = target.clone();
            let res = tokio::task::spawn_blocking(move || match &t {
                ModsTarget::Global => (Vec::new(), mods::load_global(&paths)),
                ModsTarget::Instance(n) => (mods::list_installed(&paths.instance_dir(n)), Vec::new()),
            })
            .await;
            b.apply(move |app| {
                if app.mods_ui.target.as_ref() != Some(&target) {
                    return;
                }
                app.mods_ui.loading = false;
                if let Ok((installed, global)) = res {
                    app.mods_ui.installed = installed;
                    app.mods_ui.global = global;
                    app.mods_ui.loaded_for = Some(target);
                }
            });
        });
    }

    fn set_mod_enabled(&mut self, file: String, enabled: bool) {
        let svc = self.services().clone();
        let res = match self.mods_ui.target.clone() {
            Some(ModsTarget::Instance(n)) => {
                mods::set_enabled(&svc.safe, &svc.paths.instance_dir(&n), &file, enabled).map(|_| ())
            }
            Some(ModsTarget::Global) => {
                let g = self.mods_ui.global.iter().find(|g| g.id == file).cloned();
                match g {
                    Some(g) => mods::set_global_enabled(&svc.safe, &svc.paths, g.source, &g.id, enabled),
                    None => Ok(()),
                }
            }
            None => Ok(()),
        };
        if let Err(e) = res {
            self.toast(ToastKind::Error, e.to_string());
        }
        self.refresh_mods();
    }

    fn remove_mod(&mut self, file: String) {
        let svc = self.services().clone();
        let res = match self.mods_ui.target.clone() {
            Some(ModsTarget::Instance(n)) => mods::remove(&svc.safe, &svc.paths.instance_dir(&n), &file),
            Some(ModsTarget::Global) => {
                match self.mods_ui.global.iter().find(|g| g.id == file).cloned() {
                    Some(g) => mods::remove_global(&svc.safe, &svc.paths, g.source, &g.id),
                    None => Ok(()),
                }
            }
            None => Ok(()),
        };
        match res {
            Ok(()) => self.toast(ToastKind::Success, "Moved to the recycle bin"),
            Err(e) => self.toast(ToastKind::Error, e.to_string()),
        }
        self.refresh_mods();
    }

    /// Pick jars on the computer and add them to the target.
    fn pick_mod_jars(&mut self) {
        let dialog = rfd::AsyncFileDialog::new()
            .set_title("Add mods")
            .add_filter("Mod jar", &["jar"])
            .pick_files();
        let b = self.backend.clone();
        self.backend.spawn(async move {
            if let Some(files) = dialog.await {
                let paths: Vec<PathBuf> = files.iter().map(|f| f.path().to_path_buf()).collect();
                b.apply(move |app| app.import_mod_jars(paths));
            }
        });
    }

    pub fn import_mod_jars(&mut self, files: Vec<PathBuf>) {
        let Some(target) = self.mods_ui.target.clone() else {
            return;
        };
        let svc = self.services().clone();
        let results = match &target {
            ModsTarget::Global => mods::import_global(&svc.safe, &svc.paths, &files),
            ModsTarget::Instance(n) => mods::import_local(&svc.safe, &svc.paths.instance_dir(n), &files),
        };
        for (name, res) in results {
            match res {
                Ok(title) => self.toast(ToastKind::Success, format!("Added {title}")),
                Err(e) => self.toast(ToastKind::Error, format!("{name}: {e}")),
            }
        }
        self.refresh_mods();
    }

    fn search_mods(&mut self) {
        let filter = match &self.mods_ui.target {
            Some(ModsTarget::Instance(n)) => self.mods_instance(n).map(|i| (i.loader, i.mc_version)),
            _ => None,
        };
        let (source, query, key) = (self.mods_ui.source, self.mods_ui.query.clone(), self.cf_key());
        self.mods_ui.searching = true;
        self.mods_ui.search_error = None;
        let loaders = Loaders::new(self.services().installer());
        let b = self.backend.clone();
        self.backend.spawn(async move {
            let filter = filter.as_ref().map(|(l, mc)| (*l, mc.as_str()));
            let res = mods::search(&loaders, key.as_deref(), source, &query, filter).await;
            b.apply(move |app| {
                app.mods_ui.searching = false;
                app.mods_ui.searched = true;
                match res {
                    Ok(hits) => app.mods_ui.results = hits,
                    Err(e) => {
                        app.mods_ui.results.clear();
                        app.mods_ui.search_error = Some(e.to_string());
                    }
                }
            });
        });
    }

    fn install_mod(&mut self, project: ProjectRef) {
        let Some(target) = self.mods_ui.target.clone() else {
            return;
        };
        let svc = self.services().clone();
        if target == ModsTarget::Global {
            match mods::add_global(&svc.safe, &svc.paths, &project) {
                Ok(true) => self.toast(
                    ToastKind::Success,
                    format!(
                        "Added {} to global mods. It is installed into each compatible instance when it launches.",
                        project.title
                    ),
                ),
                Ok(false) => self.toast(ToastKind::Info, format!("{} is already a global mod", project.title)),
                Err(e) => self.toast(ToastKind::Error, e.to_string()),
            }
            self.refresh_mods();
            return;
        }
        let ModsTarget::Instance(name) = target else { return };
        let Some(inst) = self.mods_instance(&name) else { return };
        let key = self.cf_key();
        self.mods_ui.installing.insert(project.id.clone());
        let title = if project.title.is_empty() { project.id.clone() } else { project.title.clone() };
        self.backend.job(format!("Installing {title}"), move |j| async move {
            let loaders = Loaders::new(j.services.installer());
            let t = mods::Target::for_instance(&j.services.paths, &inst);
            let res = mods::install(&loaders, key.as_deref(), &project, &t, false, &j.progress).await;
            let id = project.id.clone();
            j.backend.apply(move |app| {
                app.mods_ui.installing.remove(&id);
                app.refresh_mods();
            });
            let r = res?;
            let mut msg = match r.installed.split_first() {
                Some((main, [])) => format!("Installed {main} into {name}"),
                Some((main, deps)) => format!("Installed {main} into {name} (+ {})", deps.join(", ")),
                None => format!("{title} is already installed in {name}"),
            };
            for n in &r.notes {
                msg.push_str(&format!("\n{n}"));
            }
            Ok(JobDone::msg(msg))
        });
    }

    /// Open the version picker and load every version of the mod.
    fn open_picker(&mut self, project: ProjectRef, page: String) {
        let key = self.cf_key();
        let (prefer_mc, prefer_loader) = match &self.mods_ui.target {
            Some(ModsTarget::Instance(n)) => self
                .mods_instance(n)
                .map(|i| (Some(i.mc_version), Some(i.loader)))
                .unwrap_or((None, None)),
            _ => (None, None),
        };
        self.mods_ui.picker = Some(Picker {
            project: project.clone(),
            page,
            loading: true,
            error: None,
            versions: Vec::new(),
            mc: String::new(),
            loader: None,
            version: String::new(),
            snapshots: false,
        });
        let loaders = Loaders::new(self.services().installer());
        let b = self.backend.clone();
        self.backend.spawn(async move {
            let res = mods::list_versions(&loaders, key.as_deref(), &project).await;
            b.apply(move |app| {
                let Some(p) = app.mods_ui.picker.as_mut().filter(|p| p.project == project) else {
                    return;
                };
                p.loading = false;
                match res {
                    Ok(v) if v.is_empty() => p.error = Some("No downloadable versions found".into()),
                    Ok(v) => {
                        p.versions = v;
                        let mcs = p.mc_versions();
                        // The instance's version if the mod has it, else newest.
                        let mc = prefer_mc
                            .filter(|m| mcs.contains(m))
                            .or_else(|| mcs.first().cloned())
                            .unwrap_or_default();
                        p.pick_mc(mc, prefer_loader);
                    }
                    Err(e) => p.error = Some(e.to_string()),
                }
            });
        });
    }

    /// Install the version chosen in the picker.
    fn install_picked(&mut self) {
        let Some(p) = &self.mods_ui.picker else { return };
        let (Some(version), Some(loader)) = (p.chosen().cloned(), p.loader) else {
            return;
        };
        let mc = p.mc.clone();
        let Some(ModsTarget::Instance(name)) = self.mods_ui.target.clone() else {
            return;
        };
        let dir = self.services().paths.instance_dir(&name);
        let key = self.cf_key();
        let title = version.file.project.title.clone();
        let id = version.file.project.id.clone();
        self.mods_ui.picker = None;
        self.mods_ui.installing.insert(id.clone());
        self.backend.job(format!("Installing {title} {}", version.file.version), move |j| async move {
            let loaders = Loaders::new(j.services.installer());
            let t = mods::Target { dir, loader, mc };
            let res = mods::install_version(&loaders, key.as_deref(), &version, &t, &j.progress).await;
            j.backend.apply(move |app| {
                app.mods_ui.installing.remove(&id);
                app.refresh_mods();
            });
            let r = res?;
            let mut msg = format!("Installed {title} {} into {name}", version.file.version);
            if r.installed.len() > 1 {
                msg.push_str(&format!(" (+ {})", r.installed[1..].join(", ")));
            }
            for n in &r.notes {
                msg.push_str(&format!("\n{n}"));
            }
            Ok(JobDone::msg(msg))
        });
    }

    fn check_mod_updates(&mut self) {
        let Some(ModsTarget::Instance(name)) = self.mods_ui.target.clone() else { return };
        let Some(inst) = self.mods_instance(&name) else { return };
        let installed = self.mods_ui.installed.clone();
        self.mods_ui.checking = true;
        self.backend.job("Checking for mod updates", move |j| async move {
            let loaders = Loaders::new(j.services.installer());
            let t = mods::Target::for_instance(&j.services.paths, &inst);
            let res = mods::check_updates(&loaders, &t, &installed).await;
            j.backend.apply(|app| app.mods_ui.checking = false);
            let updates = res?;
            let msg = match updates.len() {
                0 => "All mods are up to date".to_string(),
                n => format!("{n} update(s) available"),
            };
            Ok(JobDone::msg(msg).then(move |app| {
                app.mods_ui.updates = updates.into_iter().map(|u| (u.file.clone(), u)).collect();
            }))
        });
    }

    fn update_mods(&mut self, files: Vec<String>) {
        let Some(ModsTarget::Instance(name)) = self.mods_ui.target.clone() else { return };
        let Some(inst) = self.mods_instance(&name) else { return };
        let updates: Vec<Update> = files.iter().filter_map(|f| self.mods_ui.updates.get(f).cloned()).collect();
        if updates.is_empty() {
            return;
        }
        self.backend.job(format!("Updating {} mod(s)", updates.len()), move |j| async move {
            let loaders = Loaders::new(j.services.installer());
            let t = mods::Target::for_instance(&j.services.paths, &inst);
            let mut done = Vec::new();
            let mut failed = Vec::new();
            for u in &updates {
                (j.progress)(mclaunch_core::Progress::stage(format!("Updating {}", u.title)));
                match mods::apply_update(&loaders, &t, u).await {
                    Ok(()) => done.push(format!("{} → {}", u.title, u.to.version)),
                    Err(e) => failed.push(format!("{}: {e}", u.title)),
                }
            }
            j.backend.apply(|app| app.refresh_mods());
            if !failed.is_empty() {
                anyhow::bail!("{}", failed.join("\n"));
            }
            Ok(JobDone::msg(format!("Updated {}", done.join(", "))))
        });
    }

    fn apply_global_now(&mut self) {
        let instances = self.instances.clone();
        let key = self.cf_key();
        self.backend.job("Adding global mods to instances", move |j| async move {
            let loaders = Loaders::new(j.services.installer());
            let reports =
                mods::sync_global_all(&loaders, key.as_deref(), &j.services.paths, &instances, &j.progress)
                    .await;
            let changed: Vec<String> = reports
                .iter()
                .filter(|(_, r)| !r.added.is_empty() || !r.disabled.is_empty())
                .map(|(n, r)| format!("{n}: +{} −{}", r.added.len(), r.disabled.len()))
                .collect();
            let notes: Vec<String> = reports
                .iter()
                .flat_map(|(n, r)| r.notes.iter().map(move |x| format!("{n}: {x}")))
                .collect();
            let mut msg = if changed.is_empty() {
                "Global mods: every instance is up to date".to_string()
            } else {
                format!("Global mods applied — {}", changed.join(", "))
            };
            for n in notes.iter().take(3) {
                msg.push_str(&format!("\n{n}"));
            }
            Ok(JobDone::msg(msg))
        });
    }
}

enum Action {
    Target(ModsTarget),
    Tab(Tab),
    Toggle(String, bool),
    AskRemove(String, String),
    Remove(String),
    CancelRemove,
    Import,
    Folder,
    CheckUpdates,
    Update(Vec<String>),
    Search,
    Install(ProjectRef),
    Url(String),
    Versions(ProjectRef, String),
    InstallPicked,
    ClosePicker,
    UseGlobal(bool),
    ApplyGlobal,
}

fn target_label(app: &McApp, t: &ModsTarget) -> String {
    match t {
        ModsTarget::Global => "🌐 Global (all instances)".into(),
        ModsTarget::Instance(n) => match app.instances.iter().find(|i| &i.name == n) {
            Some(i) => format!("{n}  —  MC {} · {}", i.mc_version, i.loader.label()),
            None => n.clone(),
        },
    }
}

pub fn show(app: &mut McApp, ui: &mut Ui) {
    let pal = app.pal;
    let mut actions = Vec::new();

    // Default target: the selected instance if it loads mods.
    if app.mods_ui.target.is_none() {
        let t = app
            .selected_instance()
            .filter(|i| i.loader.uses_mods_folder())
            .map(|i| ModsTarget::Instance(i.name.clone()))
            .or_else(|| {
                app.instances
                    .iter()
                    .find(|i| i.loader.uses_mods_folder())
                    .map(|i| ModsTarget::Instance(i.name.clone()))
            })
            .unwrap_or(ModsTarget::Global);
        actions.push(Action::Target(t));
    } else if let Some(ModsTarget::Instance(n)) = &app.mods_ui.target {
        if !app.instances.iter().any(|i| &i.name == n) && !app.instances.is_empty() {
            actions.push(Action::Target(ModsTarget::Global));
        }
    }
    if app.mods_ui.loaded_for != app.mods_ui.target && !app.mods_ui.loading && app.mods_ui.target.is_some() {
        app.refresh_mods();
    }

    let target = app.mods_ui.target.clone().unwrap_or(ModsTarget::Global);
    let inst = match &target {
        ModsTarget::Instance(n) => app.instances.iter().find(|i| &i.name == n).cloned(),
        ModsTarget::Global => None,
    };

    ui.horizontal(|ui| {
        widgets::pixel_heading(ui, "Mods", 16.0);
        ui.add_space(16.0);
        egui::ComboBox::from_id_salt("mods_target")
            .selected_text(target_label(app, &target))
            .width(340.0)
            .height(400.0)
            .show_ui(ui, |ui| {
                if ui
                    .selectable_label(target == ModsTarget::Global, target_label(app, &ModsTarget::Global))
                    .clicked()
                {
                    actions.push(Action::Target(ModsTarget::Global));
                }
                for i in &app.instances {
                    let t = ModsTarget::Instance(i.name.clone());
                    let ok = i.loader.uses_mods_folder();
                    let resp = ui
                        .add_enabled(ok, egui::SelectableLabel::new(target == t, target_label(app, &t)))
                        .on_disabled_hover_text("Install Fabric, Quilt, Forge or NeoForge on this instance to use mods");
                    if resp.clicked() {
                        actions.push(Action::Target(t));
                    }
                }
            });
        ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
            if ui.button("📂 Open folder").clicked() {
                actions.push(Action::Folder);
            }
            if ui.button("+ Import from computer…").clicked() {
                actions.push(Action::Import);
            }
        });
    });
    ui.add_space(8.0);
    ui.horizontal(|ui| {
        let mut installed = app.mods_ui.tab == Tab::Installed;
        if widgets::chip(ui, &pal, &mut installed, "Installed").clicked() {
            actions.push(Action::Tab(Tab::Installed));
        }
        let mut browse = app.mods_ui.tab == Tab::Browse;
        if widgets::chip(ui, &pal, &mut browse, "Browse Modrinth / CurseForge").clicked() {
            actions.push(Action::Tab(Tab::Browse));
        }
        ui.add_space(12.0);
        match &inst {
            Some(i) => {
                let mut on = i.global_mods;
                if ui
                    .checkbox(&mut on, "Use global mods")
                    .on_hover_text("Add the global mods that fit this instance when it launches")
                    .changed()
                {
                    actions.push(Action::UseGlobal(on));
                }
            }
            None => {
                ui.label(widgets::dim(
                    "Global mods are added to every compatible instance (right Minecraft version and loader) when it launches.",
                    &pal,
                ));
            }
        }
    });
    ui.add_space(8.0);

    match app.mods_ui.tab {
        Tab::Installed => match &target {
            ModsTarget::Instance(_) => installed_tab(app, ui, &mut actions),
            ModsTarget::Global => global_tab(app, ui, &mut actions),
        },
        Tab::Browse => browse_tab(app, ui, inst.as_ref(), &mut actions),
    }

    // Remove confirmation.
    if let Some((file, name)) = app.mods_ui.confirm_remove.clone() {
        egui::Window::new("Remove mod")
            .collapsible(false)
            .resizable(false)
            .anchor(egui::Align2::CENTER_CENTER, egui::Vec2::ZERO)
            .show(ui.ctx(), |ui| {
                ui.label(format!("Remove {name}?"));
                ui.label(widgets::dim("The file goes to the recycle bin, so you can restore it.", &pal));
                ui.add_space(8.0);
                ui.horizontal(|ui| {
                    if ui.button(RichText::new("🗑 Remove").color(pal.danger)).clicked() {
                        actions.push(Action::Remove(file.clone()));
                    }
                    if ui.button("Cancel").clicked() {
                        actions.push(Action::CancelRemove);
                    }
                });
            });
    }

    picker_window(app, ui.ctx(), inst.as_ref(), &mut actions);

    for a in actions {
        match a {
            Action::Target(t) => {
                app.mods_ui.target = Some(t);
                app.mods_ui.results.clear();
                app.mods_ui.searched = false;
                app.refresh_mods();
            }
            Action::Tab(t) => app.mods_ui.tab = t,
            Action::Toggle(f, on) => app.set_mod_enabled(f, on),
            Action::AskRemove(f, n) => app.mods_ui.confirm_remove = Some((f, n)),
            Action::Remove(f) => {
                app.mods_ui.confirm_remove = None;
                app.remove_mod(f);
            }
            Action::CancelRemove => app.mods_ui.confirm_remove = None,
            Action::Import => app.pick_mod_jars(),
            Action::Folder => {
                let dir = match &target {
                    ModsTarget::Global => mods::global_dir(&app.services().paths),
                    ModsTarget::Instance(n) => app.services().paths.instance_dir(n).join("mods"),
                };
                open_path(app, &dir);
            }
            Action::CheckUpdates => app.check_mod_updates(),
            Action::Update(files) => app.update_mods(files),
            Action::Search => app.search_mods(),
            Action::Install(p) => app.install_mod(p),
            Action::Versions(p, page) => app.open_picker(p, page),
            Action::InstallPicked => app.install_picked(),
            Action::ClosePicker => app.mods_ui.picker = None,
            Action::Url(u) => {
                if let Err(e) = open::that_detached(&u) {
                    app.toast(ToastKind::Error, format!("Cannot open {u}: {e}"));
                }
            }
            Action::UseGlobal(on) => {
                if let Some(mut cfg) = inst.clone() {
                    cfg.global_mods = on;
                    if let Err(e) = app.save_instance(&cfg) {
                        app.toast(ToastKind::Error, e);
                    }
                }
            }
            Action::ApplyGlobal => app.apply_global_now(),
        }
    }
}

fn installed_tab(app: &mut McApp, ui: &mut Ui, actions: &mut Vec<Action>) {
    let pal = app.pal;
    let st = &mut app.mods_ui;
    ui.horizontal(|ui| {
        ui.add(
            egui::TextEdit::singleline(&mut st.filter)
                .hint_text("🔍 Filter")
                .desired_width(220.0),
        );
        let enabled = st.installed.iter().filter(|m| m.enabled).count();
        ui.label(widgets::dim(
            format!("{} mod(s), {enabled} enabled", st.installed.len()),
            &pal,
        ));
        ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
            if !st.updates.is_empty()
                && widgets::accent_button(ui, &pal, &format!("⬆ Update all ({})", st.updates.len())).clicked()
            {
                actions.push(Action::Update(st.updates.keys().cloned().collect()));
            }
            if st.checking {
                ui.spinner();
            } else if ui
                .add_enabled(!st.installed.is_empty(), egui::Button::new("⟳ Check for updates"))
                .on_hover_text("Looks up every jar on Modrinth by its checksum")
                .clicked()
            {
                actions.push(Action::CheckUpdates);
            }
        });
    });
    ui.add_space(6.0);
    if st.loading && st.installed.is_empty() {
        ui.spinner();
        return;
    }
    if st.installed.is_empty() {
        widgets::card(ui, &pal, |ui| {
            ui.set_width(ui.available_width());
            ui.label("No mods yet.");
            ui.label(widgets::dim(
                "Browse Modrinth or CurseForge, import jars from your computer, or drop .jar files onto the window.",
                &pal,
            ));
            ui.add_space(6.0);
            if widgets::accent_button(ui, &pal, "Browse mods").clicked() {
                actions.push(Action::Tab(Tab::Browse));
            }
        });
        return;
    }
    let filter = st.filter.to_lowercase();
    egui::ScrollArea::vertical()
        .id_salt("mods_installed_scroll")
        .auto_shrink([false, false])
        .show(ui, |ui| {
            egui::Grid::new("mods_installed")
                .num_columns(6)
                .striped(true)
                .spacing([14.0, 8.0])
                .show(ui, |ui| {
                    for m in &st.installed {
                        if !filter.is_empty()
                            && !m.name.to_lowercase().contains(&filter)
                            && !m.file.to_lowercase().contains(&filter)
                        {
                            continue;
                        }
                        let mut on = m.enabled;
                        if widgets::toggle(ui, &pal, &mut on)
                            .on_hover_text(if m.enabled { "Disable" } else { "Enable" })
                            .changed()
                        {
                            actions.push(Action::Toggle(m.file.clone(), on));
                        }
                        let name = RichText::new(&m.name).strong();
                        let name = if m.enabled { name } else { name.color(pal.dim).strikethrough() };
                        ui.vertical(|ui| {
                            widgets::fixed_label(ui, 260.0, name).on_hover_text(&m.name);
                            widgets::fixed_label(ui, 260.0, widgets::dim(&m.version, &pal));
                        });
                        ui.horizontal(|ui| {
                            let (label, color) = match m.source() {
                                Source::Modrinth => ("Modrinth", pal.accent),
                                Source::CurseForge => ("CurseForge", pal.warn),
                                Source::Local => ("Local", pal.dim),
                            };
                            widgets::badge(ui, label, color);
                            if m.record.as_ref().is_some_and(|r| r.global) {
                                widgets::badge(ui, "global", pal.info);
                            } else if m.record.as_ref().is_some_and(|r| r.dependency) {
                                widgets::badge(ui, "dependency", pal.dim);
                            }
                        });
                        widgets::fixed_label(ui, 260.0, widgets::mono(&m.file).color(pal.dim))
                            .on_hover_text(&m.file);
                        match st.updates.get(&m.file) {
                            Some(u) => {
                                if ui
                                    .button(format!("⬆ {}", u.to.version))
                                    .on_hover_text(format!("Update {} → {}", u.from, u.to.version))
                                    .clicked()
                                {
                                    actions.push(Action::Update(vec![m.file.clone()]));
                                }
                            }
                            None => {
                                ui.label("");
                            }
                        }
                        if ui.button("🗑").on_hover_text("Remove (recycle bin)").clicked() {
                            actions.push(Action::AskRemove(m.file.clone(), m.name.clone()));
                        }
                        ui.end_row();
                    }
                });
        });
}

fn global_tab(app: &mut McApp, ui: &mut Ui, actions: &mut Vec<Action>) {
    let pal = app.pal;
    let st = &app.mods_ui;
    ui.horizontal(|ui| {
        ui.label(widgets::dim(format!("{} global mod(s)", st.global.len()), &pal));
        ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
            if ui
                .add_enabled(!st.global.is_empty(), egui::Button::new("⟳ Apply to instances now"))
                .on_hover_text("Otherwise this happens when each instance launches")
                .clicked()
            {
                actions.push(Action::ApplyGlobal);
            }
        });
    });
    ui.add_space(6.0);
    if st.global.is_empty() {
        widgets::card(ui, &pal, |ui| {
            ui.set_width(ui.available_width());
            ui.label("No global mods yet.");
            ui.label(widgets::dim(
                "Global mods are added to every instance with a matching loader when it launches. For Modrinth and CurseForge mods the right version for each instance's Minecraft version is downloaded; imported jars are only added where they fit.",
                &pal,
            ));
            ui.add_space(6.0);
            if widgets::accent_button(ui, &pal, "Browse mods").clicked() {
                actions.push(Action::Tab(Tab::Browse));
            }
        });
        return;
    }
    egui::ScrollArea::vertical()
        .id_salt("mods_global_scroll")
        .auto_shrink([false, false])
        .show(ui, |ui| {
            egui::Grid::new("mods_global")
                .num_columns(4)
                .striped(true)
                .spacing([14.0, 8.0])
                .show(ui, |ui| {
                    for g in &st.global {
                        let mut on = g.enabled;
                        if widgets::toggle(ui, &pal, &mut on)
                            .on_hover_text(if g.enabled { "Switch off" } else { "Switch on" })
                            .changed()
                        {
                            actions.push(Action::Toggle(g.id.clone(), on));
                        }
                        let title = if g.title.is_empty() { &g.id } else { &g.title };
                        widgets::fixed_label(ui, 320.0, RichText::new(title).strong());
                        let (label, color) = match g.source {
                            Source::Modrinth => ("Modrinth", pal.accent),
                            Source::CurseForge => ("CurseForge", pal.warn),
                            Source::Local => ("Local jar", pal.dim),
                        };
                        widgets::badge(ui, label, color);
                        if ui.button("🗑").on_hover_text("Remove from global mods").clicked() {
                            actions.push(Action::AskRemove(g.id.clone(), title.clone()));
                        }
                        ui.end_row();
                    }
                });
        });
}

fn browse_tab(app: &mut McApp, ui: &mut Ui, inst: Option<&InstanceConfig>, actions: &mut Vec<Action>) {
    let pal = app.pal;
    let has_key = app.config.curseforge_key().is_some();
    let st = &mut app.mods_ui;
    ui.horizontal(|ui| {
        ui.selectable_value(&mut st.source, Source::Modrinth, "Modrinth");
        ui.selectable_value(&mut st.source, Source::CurseForge, "CurseForge");
        ui.add_space(8.0);
        let cf_blocked = st.source == Source::CurseForge && !has_key;
        let resp = ui.add_enabled(
            !cf_blocked,
            egui::TextEdit::singleline(&mut st.query)
                .hint_text("Search mods…")
                .desired_width(300.0),
        );
        let enter = resp.lost_focus() && ui.input(|i| i.key_pressed(egui::Key::Enter));
        if st.searching {
            ui.spinner();
        } else if (ui.add_enabled(!cf_blocked, egui::Button::new("🔍 Search")).clicked() || enter)
            && !cf_blocked
        {
            actions.push(Action::Search);
        }
        if let Some(i) = inst {
            ui.label(widgets::dim(
                format!("showing mods for MC {} · {}", i.mc_version, i.loader.label()),
                &pal,
            ));
        }
    });
    if st.source == Source::CurseForge {
        ui.add_space(6.0);
        widgets::card(ui, &pal, |ui| {
            ui.set_width(ui.available_width());
            if !has_key {
                ui.label(widgets::dim(
                    "CurseForge only allows searching with an API key (Settings → Network). Without one you can still install a mod by its Project ID, shown on the right side of its CurseForge page.",
                    &pal,
                ));
            }
            ui.horizontal(|ui| {
                ui.label("Project ID");
                ui.add(egui::TextEdit::singleline(&mut st.cf_id).desired_width(120.0).hint_text("e.g. 238222"));
                let id = st.cf_id.trim().to_string();
                let valid = !id.is_empty() && id.chars().all(|c| c.is_ascii_digit());
                let label = if inst.is_some() { "⬇ Install" } else { "+ Add to global" };
                let project = ProjectRef {
                    source: Source::CurseForge,
                    id: id.clone(),
                    title: String::new(),
                };
                if ui.add_enabled(valid, egui::Button::new(label)).clicked() {
                    actions.push(Action::Install(project.clone()));
                }
                if inst.is_some() && ui.add_enabled(valid, egui::Button::new("Versions…")).clicked() {
                    actions.push(Action::Versions(
                        project,
                        format!("https://www.curseforge.com/projects/{id}"),
                    ));
                }
            });
        });
    }
    ui.add_space(6.0);
    if let Some(e) = &st.search_error {
        ui.label(RichText::new(e).color(pal.danger));
    }
    if st.searched && st.results.is_empty() && st.search_error.is_none() && !st.searching {
        ui.label(widgets::dim("No mods found.", &pal));
    }
    let have: HashSet<(Source, String)> = st
        .installed
        .iter()
        .filter_map(|m| m.record.as_ref())
        .map(|r| (r.source, r.project_id.clone()))
        .chain(st.global.iter().map(|g| (g.source, g.id.clone())))
        .collect();
    egui::ScrollArea::vertical()
        .id_salt("mods_browse_scroll")
        .auto_shrink([false, false])
        .show(ui, |ui| {
            for hit in &st.results {
                widgets::card(ui, &pal, |ui| {
                    ui.set_width(ui.available_width());
                    ui.horizontal(|ui| {
                        // Leave room for the buttons so long text truncates.
                        let text_width = (ui.available_width() - 180.0).max(120.0);
                        ui.vertical(|ui| {
                            ui.set_max_width(text_width);
                            ui.horizontal(|ui| {
                                ui.label(RichText::new(&hit.project.title).strong().size(15.0));
                                if !hit.author.is_empty() {
                                    ui.label(widgets::dim(format!("by {}", hit.author), &pal));
                                }
                                ui.label(widgets::dim(format!("⬇ {}", downloads(hit.downloads)), &pal));
                            });
                            ui.add(egui::Label::new(widgets::dim(&hit.description, &pal)).truncate());
                        });
                        ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
                            if st.installing.contains(&hit.project.id) {
                                ui.spinner();
                            } else if have.contains(&(hit.project.source, hit.project.id.clone())) {
                                ui.label(RichText::new("✔ Installed").color(pal.accent));
                            } else {
                                let label = if inst.is_some() { "⬇ Install" } else { "+ Add to global" };
                                if widgets::accent_button(ui, &pal, label).clicked() {
                                    actions.push(Action::Install(hit.project.clone()));
                                }
                            }
                            if ui.button("🌐").on_hover_text("Open the mod's page").clicked() {
                                actions.push(Action::Url(hit.page.clone()));
                            }
                            if inst.is_some()
                                && ui
                                    .button("Versions…")
                                    .on_hover_text("Choose the Minecraft version, loader and mod version")
                                    .clicked()
                            {
                                actions.push(Action::Versions(hit.project.clone(), hit.page.clone()));
                            }
                        });
                    });
                });
                ui.add_space(6.0);
            }
        });
}

fn downloads(n: u64) -> String {
    match n {
        n if n >= 1_000_000 => format!("{:.1}M", n as f64 / 1e6),
        n if n >= 1_000 => format!("{:.0}k", n as f64 / 1e3),
        n => n.to_string(),
    }
}

fn picker_window(app: &mut McApp, ctx: &egui::Context, inst: Option<&InstanceConfig>, actions: &mut Vec<Action>) {
    let pal = app.pal;
    let installed_records: Vec<mods::ModRecord> = app
        .mods_ui
        .installed
        .iter()
        .filter_map(|m| m.record.clone())
        .collect();
    let Some(p) = app.mods_ui.picker.as_mut() else { return };
    let title = if p.project.title.is_empty() {
        format!("CurseForge project {}", p.project.id)
    } else {
        p.project.title.clone()
    };
    let mut open = true;
    egui::Window::new(format!("Choose version — {title}"))
        .id(egui::Id::new("mod_version_picker"))
        .open(&mut open)
        .collapsible(false)
        .resizable(false)
        .anchor(egui::Align2::CENTER_CENTER, egui::Vec2::ZERO)
        .show(ctx, |ui| {
            ui.set_min_width(460.0);
            if p.loading {
                ui.horizontal(|ui| {
                    ui.spinner();
                    ui.label("Loading versions…");
                });
                return;
            }
            if let Some(e) = &p.error {
                ui.label(RichText::new(e).color(pal.danger));
                return;
            }
            let mcs = p.mc_versions();
            egui::Grid::new("picker_grid")
                .num_columns(2)
                .spacing([20.0, 10.0])
                .show(ui, |ui| {
                    ui.label("Minecraft");
                    ui.horizontal(|ui| {
                        let mut mc = p.mc.clone();
                        egui::ComboBox::from_id_salt("picker_mc")
                            .selected_text(if mc.is_empty() { "—" } else { mc.as_str() })
                            .width(140.0)
                            .height(320.0)
                            .show_ui(ui, |ui| {
                                for v in &mcs {
                                    ui.selectable_value(&mut mc, v.clone(), v);
                                }
                            });
                        if mc != p.mc {
                            p.pick_mc(mc, inst.map(|i| i.loader));
                        }
                        if ui.checkbox(&mut p.snapshots, "snapshots").changed() && !p.mc_versions().contains(&p.mc) {
                            if let Some(first) = p.mc_versions().first().cloned() {
                                p.pick_mc(first, inst.map(|i| i.loader));
                            }
                        }
                    });
                    ui.end_row();

                    ui.label("Loader");
                    let loaders = p.loaders(&p.mc);
                    let mut loader = p.loader;
                    egui::ComboBox::from_id_salt("picker_loader")
                        .selected_text(loader.map(|l| l.label()).unwrap_or("—"))
                        .width(140.0)
                        .show_ui(ui, |ui| {
                            for l in &loaders {
                                ui.selectable_value(&mut loader, Some(*l), l.label());
                            }
                        });
                    if loader != p.loader {
                        p.loader = loader;
                        p.pick_latest();
                    }
                    ui.end_row();

                    ui.label("Mod version");
                    let list: Vec<(String, String)> = p
                        .loader
                        .map(|l| {
                            p.matching(&p.mc, l)
                                .into_iter()
                                .map(|m| {
                                    let mut t = m.file.version.clone();
                                    if !m.release {
                                        t.push_str("  (beta)");
                                    }
                                    (m.file.version_id.clone(), t)
                                })
                                .collect()
                        })
                        .unwrap_or_default();
                    let shown = list
                        .iter()
                        .find(|(id, _)| *id == p.version)
                        .map(|(_, t)| t.clone())
                        .unwrap_or_else(|| "—".into());
                    egui::ComboBox::from_id_salt("picker_version")
                        .selected_text(shown)
                        .width(300.0)
                        .height(320.0)
                        .show_ui(ui, |ui| {
                            for (i, (id, t)) in list.iter().enumerate() {
                                let label = if i == 0 { format!("{t}  ★ latest") } else { t.clone() };
                                ui.selectable_value(&mut p.version, id.clone(), label);
                            }
                        });
                    ui.end_row();
                });
            if let Some(v) = p.chosen() {
                let size = v.file.size.map(mclaunch_core::human_bytes).unwrap_or_default();
                ui.label(widgets::dim(format!("{}  {size}", v.file.file_name), &pal));
                if !v.file.deps.is_empty() {
                    ui.label(widgets::dim(
                        format!("+ {} required dependency(ies), installed for the same version", v.file.deps.len()),
                        &pal,
                    ));
                }
            }
            let installed = app_installed_version(&p.project, &installed_records);
            if let Some(v) = &installed {
                ui.label(widgets::dim(
                    format!("Installed now: {v}. Installing another version replaces it (the old file goes to the recycle bin)."),
                    &pal,
                ));
            }
            if let (Some(i), Some(l)) = (inst, p.loader) {
                let loader_ok = i.loader == l || (i.loader == LoaderKind::Quilt && l == LoaderKind::Fabric);
                if i.mc_version != p.mc || !loader_ok {
                    ui.label(
                        RichText::new(format!(
                            "⚠ {} runs Minecraft {} with {}; this file is for {} with {} and may not load.",
                            i.name, i.mc_version, i.loader.label(), p.mc, l.label()
                        ))
                        .color(pal.warn),
                    );
                }
            }
            ui.add_space(8.0);
            ui.horizontal(|ui| {
                let ok = p.chosen().is_some();
                let label = match inst {
                    Some(i) => format!("⬇ Install into {}", i.name),
                    None => "⬇ Install".into(),
                };
                if ui.add_enabled(ok, widgets_accent(&pal, &label)).clicked() {
                    actions.push(Action::InstallPicked);
                }
                if ui.button("Cancel").clicked() {
                    actions.push(Action::ClosePicker);
                }
                if ui.link("Mod page").clicked() {
                    actions.push(Action::Url(p.page.clone()));
                }
            });
        });
    if !open {
        actions.push(Action::ClosePicker);
    }
}

/// Version of `project` installed in the shown instance, if any.
fn app_installed_version(project: &ProjectRef, records: &[mods::ModRecord]) -> Option<String> {
    records
        .iter()
        .find(|r| r.source == project.source && r.project_id == project.id)
        .map(|r| if r.version.is_empty() { r.file.clone() } else { r.version.clone() })
}

fn widgets_accent(pal: &crate::theme::Palette, text: &str) -> egui::Button<'static> {
    egui::Button::new(RichText::new(text.to_string()).color(pal.accent_text)).fill(pal.accent)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn version(id: &str, mc: &[&str], loaders: &[LoaderKind], release: bool) -> ModVersion {
        ModVersion {
            file: mods::ModFile {
                project: ProjectRef { source: Source::Modrinth, id: "p".into(), title: "P".into() },
                version_id: id.into(),
                version: id.into(),
                file_name: format!("{id}.jar"),
                urls: vec!["u".into()],
                sha1: None,
                size: None,
                deps: Vec::new(),
                page: String::new(),
            },
            game_versions: mc.iter().map(|s| s.to_string()).collect(),
            loaders: loaders.to_vec(),
            release,
        }
    }

    #[test]
    fn picker_cascades() {
        use LoaderKind::*;
        let mut p = Picker {
            project: ProjectRef { source: Source::Modrinth, id: "p".into(), title: "P".into() },
            page: String::new(),
            loading: false,
            error: None,
            // newest first, as the services return them
            versions: vec![
                version("4.0-beta", &["1.21.1"], &[Fabric, NeoForge], false),
                version("3.0", &["1.21.1"], &[Fabric], true),
                version("2.5", &["1.20.1", "1.20"], &[Fabric, Forge], true),
                version("2.0", &["1.20.1", "24w10a"], &[Forge], true),
            ],
            mc: String::new(),
            loader: None,
            version: String::new(),
            snapshots: false,
        };
        assert_eq!(p.mc_versions(), ["1.21.1", "1.20.1", "1.20"]);
        p.snapshots = true;
        assert!(p.mc_versions().contains(&"24w10a".to_string()));
        p.snapshots = false;

        p.pick_mc("1.21.1".into(), Some(NeoForge));
        assert_eq!(p.loaders("1.21.1"), [Fabric, NeoForge]);
        assert_eq!(p.loader, Some(NeoForge), "preferred loader when available");
        assert_eq!(p.version, "4.0-beta", "only version for NeoForge");

        p.loader = Some(Fabric);
        p.pick_latest();
        assert_eq!(p.version, "3.0", "newest release beats a newer beta");

        // Fabric still fits 1.20.1, so it is kept.
        p.pick_mc("1.20.1".into(), None);
        assert_eq!(p.loader, Some(Fabric));
        assert_eq!(p.version, "2.5");
        p.loader = Some(Forge);
        p.pick_latest();
        assert_eq!(p.matching("1.20.1", Forge).len(), 2);
        assert_eq!(p.version, "2.5");

        // Forge is not available on 1.21.1: falls back to the first loader.
        p.pick_mc("1.21.1".into(), None);
        assert_eq!(p.loader, Some(Fabric));
    }
}
