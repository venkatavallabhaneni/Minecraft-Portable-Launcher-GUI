//! Local server lifecycle for the Servers screen.

use std::path::PathBuf;
use std::sync::Arc;
use std::time::Instant;

use mclaunch_java::{JavaPick, JavaRuntime};
use mclaunch_loaders::Loaders;
use mclaunch_server::{ServerConfig, ServerProperties};
use tokio::sync::{mpsc, Notify};

use crate::app::{McApp, Screen, ToastKind};
use crate::backend::JobDone;

const MAX_SERVER_LINES: usize = 20_000;

pub struct RunningServer {
    pub stdin: mpsc::UnboundedSender<String>,
    pub stop: Arc<Notify>,
    pub started: Instant,
}

fn pick_java(
    runtimes: &[JavaRuntime],
    cfg: &ServerConfig,
    required: u32,
) -> Result<PathBuf, String> {
    if let Some(ov) = cfg.java_override.as_deref().filter(|s| !s.is_empty()) {
        if let Ok(major) = ov.parse::<u32>() {
            return runtimes
                .iter()
                .find(|r| r.info.major == major)
                .map(|r| r.java_bin.clone())
                .ok_or_else(|| {
                    format!("no Java {major} runtime found — drop a JDK {major} zip into java/")
                });
        }
        return Ok(PathBuf::from(ov));
    }
    match mclaunch_java::pick_runtime(runtimes, required, &cfg.mc_version) {
        JavaPick::Exact(r) | JavaPick::Compatible(r) => Ok(r.java_bin.clone()),
        JavaPick::Missing(m) => Err(m),
    }
}

impl McApp {
    pub fn refresh_servers(&mut self) {
        let paths = self.services().paths.clone();
        let b = self.backend.clone();
        self.backend.spawn(async move {
            let list = tokio::task::spawn_blocking(move || mclaunch_server::list_servers(&paths))
                .await
                .unwrap_or_default();
            b.apply(move |app| app.servers = list);
        });
    }

    pub fn push_server_line(&mut self, name: &str, line: String) {
        let log = self.server_logs.entry(name.to_string()).or_default();
        if log.len() >= MAX_SERVER_LINES {
            log.pop_front();
        }
        log.push_back(line);
    }

    /// Install (or reinstall) server software; worlds and plugins are kept.
    pub fn install_server(&mut self, mut cfg: ServerConfig, is_new: bool) {
        if !self.servers_ui.installing.insert(cfg.name.clone()) {
            return;
        }
        let runtimes = self.java.clone();
        let name = cfg.name.clone();
        self.backend
            .job(format!("Installing server {name}"), move |j| async move {
                let svc = j.services.clone();
                let loaders = Loaders::new(svc.installer());
                let res = async {
                    let resolved = svc
                        .installer()
                        .ensure_json_chain(&cfg.mc_version, None)
                        .await?;
                    let required = mclaunch_core::javareq::required_java(&resolved.merged);
                    let java = pick_java(&runtimes, &cfg, required).ok();
                    if java.is_none()
                        && matches!(
                            cfg.kind,
                            mclaunch_server::ServerKind::Spigot
                                | mclaunch_server::ServerKind::Forge
                                | mclaunch_server::ServerKind::NeoForge
                        )
                    {
                        anyhow::bail!("{}", pick_java(&runtimes, &cfg, required).unwrap_err());
                    }
                    let spec =
                        mclaunch_server::install(&loaders, &cfg, java.as_deref(), &j.progress)
                            .await?;
                    cfg.launch = Some(spec);
                    if cfg.created.is_none() {
                        cfg.created = Some(chrono::Utc::now());
                    }
                    cfg.save(&svc.paths, &svc.safe)?;
                    anyhow::Ok(cfg)
                }
                .await;
                let n2 = name.clone();
                j.backend.apply(move |app| {
                    app.servers_ui.installing.remove(&n2);
                });
                let cfg = res?;
                let verb = if is_new { "created" } else { "updated" };
                Ok(
                    JobDone::msg(format!("Server {name} {verb}")).then(move |app| {
                        app.servers_ui.selected = Some(cfg.name.clone());
                        app.refresh_servers();
                    }),
                )
            });
    }

    pub fn start_server(&mut self, name: &str) {
        if self.running_servers.contains_key(name) {
            return;
        }
        let Some(cfg) = self.servers.iter().find(|s| s.name == name).cloned() else {
            return;
        };
        let dir = self.services().paths.server_dir(name);
        if !mclaunch_server::eula_accepted(&dir) {
            self.toast(
                ToastKind::Error,
                "Tick \"I accept the Minecraft EULA\" first",
            );
            return;
        }
        let runtimes = self.java.clone();
        let (stdin_tx, stdin_rx) = mpsc::unbounded_channel();
        let stop = Arc::new(Notify::new());
        self.running_servers.insert(
            name.to_string(),
            RunningServer {
                stdin: stdin_tx,
                stop: stop.clone(),
                started: Instant::now(),
            },
        );
        let name = name.to_string();
        let b = self.backend.clone();
        let svc = self.services().clone();
        self.backend.spawn(async move {
            let res = async {
                let resolved = svc
                    .installer()
                    .ensure_json_chain(&cfg.mc_version, None)
                    .await?;
                let required = mclaunch_core::javareq::required_java(&resolved.merged);
                let java = pick_java(&runtimes, &cfg, required).map_err(anyhow::Error::msg)?;
                let b2 = b.clone();
                let n2 = name.clone();
                let on_line: Arc<dyn Fn(String) + Send + Sync> = Arc::new(move |l| {
                    let n = n2.clone();
                    b2.apply(move |app| app.push_server_line(&n, l));
                });
                let code = mclaunch_server::run(cfg, dir, java, on_line, stdin_rx, stop).await?;
                anyhow::Ok(code)
            }
            .await;
            b.apply(move |app| {
                app.running_servers.remove(&name);
                match res {
                    Ok(Some(0)) | Ok(None) => {
                        app.toast(ToastKind::Info, format!("Server {name} stopped"))
                    }
                    Ok(Some(c)) => app.toast(
                        ToastKind::Error,
                        format!("Server {name} exited with code {c}"),
                    ),
                    Err(e) => {
                        app.push_server_line(&name, format!("[mclaunch] {e:#}"));
                        app.toast(ToastKind::Error, format!("Server {name}: {e:#}"));
                    }
                }
            });
        });
    }

    pub fn stop_server(&mut self, name: &str) {
        if let Some(s) = self.running_servers.get(name) {
            s.stop.notify_one();
        }
    }

    pub fn send_server_command(&mut self, name: &str, command: String) {
        let Some(tx) = self.running_servers.get(name).map(|s| s.stdin.clone()) else {
            return;
        };
        self.push_server_line(name, format!("> {command}"));
        let _ = tx.send(command);
    }

    pub fn save_server_properties(&mut self, name: &str, props: &ServerProperties) {
        if self.running_servers.contains_key(name) {
            self.toast(
                ToastKind::Error,
                "Stop the server before editing server.properties (it rewrites the file on exit)",
            );
            return;
        }
        let svc = self.services().clone();
        let dir = svc.paths.server_dir(name);
        match mclaunch_server::write_properties(&svc.safe, &dir, props) {
            Ok(()) => self.toast(ToastKind::Success, "server.properties saved"),
            Err(e) => self.toast(ToastKind::Error, e.to_string()),
        }
    }

    pub fn trash_server(&mut self, name: String, typed: String) {
        if self.running_servers.contains_key(&name) {
            self.toast(ToastKind::Error, "Stop the server first");
            return;
        }
        self.backend
            .job(format!("Deleting server {name}"), move |j| async move {
                let safe = j.services.safe.clone();
                let n = name.clone();
                tokio::task::spawn_blocking(move || safe.trash_server(&n, &typed)).await??;
                Ok(
                    JobDone::msg(format!("Server {name} moved to the recycle bin")).then(
                        move |app| {
                            app.servers.retain(|s| s.name != name);
                            app.server_logs.remove(&name);
                            if app.servers_ui.selected.as_deref() == Some(name.as_str()) {
                                app.servers_ui.selected = None;
                            }
                        },
                    ),
                )
            });
    }

    /// Start the selected instance and join a local server.
    pub fn join_local_server(&mut self, port: u16) {
        let Some(name) = self.selected_instance().map(|i| i.name.clone()) else {
            self.toast(ToastKind::Error, "Select an instance to join with");
            return;
        };
        self.quick_join = format!("localhost:{port}");
        self.screen = Screen::Play;
        self.launch_instance(&name);
    }
}
