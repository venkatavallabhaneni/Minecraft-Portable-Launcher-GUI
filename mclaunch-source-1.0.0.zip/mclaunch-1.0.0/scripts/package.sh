#!/usr/bin/env bash
# Build release binaries of mclaunch into dist/.
#
# * Native build for the current OS (Linux/macOS: dist/mclaunch-<os>-<arch>,
#   Windows (Git Bash): dist/mclaunch.exe).
# * On Linux/macOS, also cross-compiles dist/mclaunch.exe for Windows when
#   `zig` and `cargo-zigbuild` are on PATH:
#       cargo install cargo-zigbuild
#       # put zig (https://ziglang.org/download/) on PATH
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p dist

cargo build --release -p mclaunch
case "$(uname -s)" in
  Linux*)  cp target/release/mclaunch "dist/mclaunch-linux-$(uname -m)" ;;
  Darwin*) cp target/release/mclaunch "dist/mclaunch-macos-$(uname -m)" ;;
  MINGW*|MSYS*|CYGWIN*) cp target/release/mclaunch.exe dist/mclaunch.exe ;;
esac

if [[ "$(uname -s)" != MINGW* && "$(uname -s)" != MSYS* ]] \
   && command -v zig >/dev/null && command -v cargo-zigbuild >/dev/null; then
  rustup target add x86_64-pc-windows-gnu >/dev/null
  cargo zigbuild --release -p mclaunch --target x86_64-pc-windows-gnu
  cp target/x86_64-pc-windows-gnu/release/mclaunch.exe dist/mclaunch.exe
fi

ls -lh dist/
